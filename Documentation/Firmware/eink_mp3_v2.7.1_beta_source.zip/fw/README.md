# E-ink MP3 Player Firmware

STM32U575RGT6 · CS43131 DAC/HP-amp · nPM1300 PMIC · SSD1681 1.54" 200×200 e-ink · microSD (SDMMC1 via TXS02612) · USB-C.

**Firmware 2.7.1 (beta)** — 2.7.0 with headphone detect fixed (internal pull-up on the codec INT line, which V2 lacks; no lost plug/unplug events; see `CHANGELOG.md`). 2.7.0: the panel is now driven by a fork of InkBoy's display driver (github.com/kuslota/InkBoy), carried over from the display-test firmware together with its hardened SD-card driver, settings kept in internal flash and adjustable key timing. Menus and song changes no longer flash; a clean refresh runs every so often. New on top: a headphone gate (no playback with the jack empty), a quick menu on Now Playing (sleep timer, remove from playlist, loop song, podcast speed, the queue), podcasts from `/Podcasts` with a position per episode, a new main-menu order, **Device settings** with sections, lists that wrap around and five cursor styles. **2.7.0 has not run on the board yet**; it builds cleanly and its PC-side tests pass. 2.6.7 (rail stays on during sleep) is the base. **Hardware revision: "Schematic1 V2" (MP3 mainboard V2).** See `CHANGELOG.md` for everything that changed, and `docs/DISPLAY.md` for the display driver.

Formats: MP3, FLAC, WAV, M4A/AAC (LC + HE-AAC), Opus, DSD (DSF/DFF) as DoP — DSD64 and DSD128; DSD256 files are skipped (V2 has no native DSD wiring, see below).

**Tested on hardware (2.5.0): MP3 and AAC (M4A) only.** FLAC, WAV, Opus and DSD/DoP are built in and decode in the same pipeline, but haven't been played on the board yet — treat them as untested. USB modes: mass storage (raw card) and UAC2 USB-DAC, chosen on-screen at plug-in. No RTOS — interrupt-driven superloop with a Stop 2 deep-sleep state.

## Layout

```
Core/        entry point, clock tree, IRQ handlers, HAL config, board.h (pin map),
             syscalls (heap)
Core/esp_compat  the few ESP-IDF calls InkBoy's display code uses (2.7.0)
drivers/     eink (panel front-end), ssd1681_fast/ + inkboy/ (InkBoy display
             driver fork, 2.7.0), gfx (1-bpp renderer), buttons, i2c_bus,
             cs43131, npm1300, sdcard, sai_audio
audio/       decoder dispatch, ogg demux, resampler, pipeline (ring+DMA, DoP),
             dsd (DSF/DFF -> DoP), tags (+JPEG album art), timestretch
             (podcast speed)
app/         power (sleep/wake), player state machine, playlist, podcast,
             settings (+ flash_store), ui, usb (MSC/UAC2), diskio
docs/        DISPLAY.md: display driver fork, file map, rules
assets/      bitmap fonts (generated from DejaVu by tools/gen_font.py)
ld/ cmake/   linker script, toolchain file
tools/       gen_font.py, build_windows.ps1, check_safety.py (panel command
             audit), host_test/ (driver, time stretcher and card code on the
             PC), ui_sim/ (the real ui.c on the PC, screens to PNG)
third_party/ fetch.sh pins: STM32CubeU5 (HAL + CMSIS submodules), FatFs R0.15,
             dr_libs, minimp4, picojpeg, helix-aac, libopus (fixed-point),
             TinyUSB 0.17
```

## Build

**Step-by-step guide: `BUILDING.md`.** It covers ready-made files in `release\`, VS Code (one-click build/flash/debug via `CMakePresets.json` + `tools\vscode\`, copied to `.vscode\`), the PowerShell script, and flashing with STM32CubeProgrammer.

Needs: Arm GNU toolchain (arm-none-eabi-gcc ≥ 12; built and tested with 13.2), CMake ≥ 3.22, Ninja (or Make), Git + curl for the one-time fetch.

**Windows** (PowerShell, from the `firmware` folder):

```
powershell -ExecutionPolicy Bypass -File tools\build_windows.ps1 -Install   # first time: installs missing tools via winget
powershell -ExecutionPolicy Bypass -File tools\build_windows.ps1            # afterwards
```

The script reuses toolchains it finds already (PATH, PlatformIO, STM32CubeCLT/IDE, Arm's installer), runs `fetch.sh` through Git Bash if the dependencies are missing, then configures and builds.

**Linux / macOS / Git Bash:**

```
cd firmware
./third_party/fetch.sh                      # one-time dependency fetch (also patches ffconf.h)
cmake -B build -G Ninja -DCMAKE_TOOLCHAIN_FILE=cmake/arm-none-eabi.cmake -DCMAKE_BUILD_TYPE=Release
cmake --build build
```

Produces `build/eink_mp3.elf/.bin/.hex`. Current image: **≈ 474 KB of the 504 KB a bank may hold** (the last 8 KB page keeps the settings), **RAM 99.7 %** including the 160 KB heap and 48 KB stack — 2 KB of static RAM is spare, so a new static buffer has to replace an old one.

Checks that need no board: `tools/host_test/run.sh` (panel driver against a fake SSD1681, time stretcher, card code on a RAM disk), `tools/ui_sim/run.sh` (every screen through the real `ui.c`, written to PNG) and `python3 tools/check_safety.py`. The decode paths (Opus, Helix AAC, decoder glue, resampler, pipeline) are built `-O2`; everything else `-Os`.

## Flash

SWD (recommended during bring-up): `st-flash write build/eink_mp3.bin 0x08000000` or STM32CubeProgrammer, via the PA13/PA14 header. V2 brings **SWO out on PB3** (header pin), so ITM trace works; PA15/PB4 (JTDI/NJTRST) are unconnected and parked. Note: the debugger loses the core while it is in Stop 2 — set "Debug in low-power modes" in your probe software (or `HAL_DBGMCU_EnableDBGStopMode()`) when debugging sleep.

**SD card (field, 2.6.0+):** copy `eink_mp3_vX.Y.Z_….bin` into `/Firmware/` on the card, then **Settings → Firmware → Install X.Y.Z**. The new image is written to the other 512 KB flash bank, verified, and started; the old one stays as **Previous** and comes back automatically if the new one restarts three times within its first 20 s. See `BRINGUP.md` §5. The old USB-DFU entry is gone (on this board it only restarted the player). The first install of 2.6.0 must go over SWD.

## SD card layout

```
/Music/...            audio files (any folder tree; "Play all" scans here,
                      or the whole card if /Music is absent)
/Playlists/<name>.m3u playlist name = file name; one path per line
/Podcasts/...         podcast episodes (2.7.0; sub-folders allowed). Listed
                      under Podcasts, never mixed into the music lists
/settings.txt         human-editable settings + resume state (auto-created)
/crashlog.txt         one line per unexpected restart (fault/brownout/watchdog)
/Firmware/*.bin       firmware images offered under Settings > Firmware
/.eplayer/            music-library index (rebuilt automatically, safe to delete);
                      podcasts.idx (episode list) and podcasts.dat (positions -
                      deleting it marks every episode as new)
```

Playlist files must end in `.m3u`, `.m3u8` or `.txt`; hidden files (macOS `._name.m3u`, `desktop.ini`) are ignored. The "Play all" index (`/.playall.idx`) is rebuilt on the first Play all after every mount (power-up, card insert, end of a USB-storage session), so music copied with a card reader appears without deleting it by hand.

## Power behaviour (sleep / wake)

The player **never sleeps while music is playing** (nor while USB storage or the USB DAC is active). Only when nothing is playing — paused or stopped — and no button has been touched for the user-selected time does it go to sleep: **Settings → Sleep after: 2 min / 5 min / 10 min (default) / 30 min / 1 hour / never**, stored as `sleep_timeout` in `settings.txt`. The steps are deliberately long: each sleep costs one full white refresh of the panel, the most power-hungry thing it does.

Going to sleep (`app/power.c`):

1. saves the current state (playlist, track, position, shuffle order) to `settings.txt`;
2. turns the screen **completely white** (one full refresh, also in dark mode);
3. puts the panel into deep sleep, drops the TXB0106 OE, unmounts the SD card and stops its bus (clock off and held low, CMD/DAT high-Z);
4. stops the codec's headphone amp, crystal and CLKOUT (headphone detection stays on);
5. **leaves the +3.3 V rail (nPM1300 BUCK2) on** (2.6.7) — the SD card idles in standby (typically 0.1–0.3 mA), the panel sits in deep sleep, VDDUSB is isolated inside the MCU. Up to 2.6.6 the rail was switched off, which could leave the card unresponsive after a long sleep;
6. puts the STM32 into **Stop 2** (all RAM retained).

It wakes on **any button**, **USB power being plugged in**, or **headphones being plugged in** (CS43131 INT, PB10; unplugging while asleep does not wake it). Any of these that happens *while* it is going to sleep (the white refresh takes about 2 s) wakes it straight back up.

While paused, the DAC and headphone amp are switched off after 30 s; the next play press switches them back on.

### The PC3 ↔ nPM1300 GPIO0 wire

One wire can't be both the PMIC's BUCK2-enable *input* and its interrupt *output*, and the two chips can't both drive it (push-pull contention), so the firmware gives it one role — CMake option `PC3_PMIC_IRQ`:

| `PC3_PMIC_IRQ` | GPIO0 is | USB plug-in wake | 3.3 V rail switched by |
|---|---|---|---|
| **ON (default)** | nPM1300 **interrupt output** (VBUS detected), PC3 = EXTI3 | **instant** — the PMIC drives PC3 high, the MCU wakes and turns the rail on (~0.3 ms of I²C) | I²C (`BUCK2ENASET/CLR`) |
| OFF | BUCK2 **enable input**, driven by PC3 | RTC poll every **250 ms** (`PWR_VBUS_POLL_MS`) | PC3 level |

With the default there is no polling at all while asleep, and while awake USB plug/unplug is also interrupt-driven (with a 2 s safety poll). For a future board spin, routing a spare nPM1300 GPIO (GPIO1–4) to a free MCU pin (PB1/PB2/PC13) would let both schemes run at once.

On wake the panel is re-initialised and — because it is known to be blank white — the previous screen is painted with a fast **partial** refresh (album-art greys appear as black/white until the next full clean). Everything shown is still in RAM, so the screen comes back first; the SD card (which stayed powered, so no power-on reset is involved) is re-initialised and the paused track restored behind it. The button press that woke the player is swallowed: **pressing play while asleep only wakes it and shows the song where it left off; press play again to start the music.**

## Battery and charging

**No battery fitted (USB power only):** the battery icon shows a **cross** instead of the fill and no charging bolt. Detection uses the nPM1300's own `BATTERYDETECTED` flag plus a sanity check of the battery-pin voltage from the nPM1300's internal ADC (2.5–4.5 V). The STM32's ADC can't do this job: its VBAT pin is on the 1.8 V rail, not the cell.

The cell is a **Sony NP-BJ1** ("J" type, 3.6 V, 700 mAh / 2.5 Wh, 4.2 V termination). Default charge current is **350 mA (0.5C)**. **Settings → Charge rate** cycles 100 / 200 / 350 / 500 / 650 / 800 mA (`charge_ma` in `settings.txt`, any value 32–800 accepted there) for use with a different, larger cell — don't raise it for the NP-BJ1. The USB input-current limit follows the charge rate (charge current + 150 mA for the system, at least 500 mA); it only goes above 500 mA if the charge rate needs it *and* the USB-C source advertises 1.5 A/3 A — with the NP-BJ1 default it is 500 mA on every source.

## Design decisions

Full rationale (including the LVGL / 1-bpp / grayscale trade-offs) lives in `../software_design_decisions.md`. Summary:

**Clocking — the DAC owns the audio clock.** The only crystal on V2 is the 22.5792 MHz on the CS43131 (there is **no LSE** — PC14/PC15 are unconnected — so the RTC runs from LSI and is used only as the sleep wake-up timer). The MCU runs HSI16→PLL at 160 MHz; USB runs HSI48+CRS synced to SOF; SAI1's kernel clock is the CS43131 CLKOUT (11.2896 MHz) on PA0/AUDIOCLK. The DAC is always the I²S master and the SAI a slave transmitter, so no MCU-PLL jitter ever touches the audio path.

**Both rate families native (2.6.0).** 22.5792 MHz generates 44.1/88.2/176.4 kHz exactly; for 32/48/96/192 kHz the CS43131's own PLL makes a 24.576 MHz MCLK from the same crystal (register values from the Linux cs43130 driver), powered only while such a stream plays. Every common rate therefore reaches the DAC **bit-perfect** — no resampling for 48 k files, Opus (always 48 k) or a 48/96 k USB-DAC stream. `audio/resampler.c` (64-tap Kaiser-windowed sinc, float; dedicated 79-tap half-band for 352.8/384 → 176.4/192 kHz) is only used for odd rates (8–24 kHz) and as a fallback should the PLL fail to lock. MP3 is decoded in float (more than 16 bits of resolution); FLAC/WAV keep their native 24/32-bit depth; AAC and Opus are 16-bit by decoder design.

**EQ (2.6.0).** Settings → EQ: 10 bands (31 Hz–16 kHz, ±12 dB), presets Bass / Warm / Bright / Vocal / Loudness / Custom. Fixed-point biquads (Q29 coefficients, 64-bit accumulate, noise-shaped rounding: ≈ −134 dBFS arithmetic noise), automatic pre-amp from the real response so boosts never clip, bit-perfect when off. Bypassed above 96 kHz (CPU budget); never applied to DSD.

**Gapless (2.6.0, Settings → Gapless).** At the end of a track the next one is opened straight away and its audio follows the last sample of the previous one in the same ring buffer, as long as the sample rate is the same (a rate change still needs a short DAC restart). MP3 encoder delay/padding (LAME header) and AAC priming/padding (iTunSMPB tag or edit list) are trimmed, so albums mixed as one piece play without clicks or gaps.

**Library (2.6.0).** Main menu → Music (every song A–Z), Artists (album artist if tagged, else artist; "The" ignored when sorting) → albums → songs, Albums (A–Z). Built in the background from the tags of the "Play all" scan into `/.eplayer/` (playback keeps running; rebuilt only when the file list changes; limits 4096 songs / 1024 artists / 1536 albums). Playlists, artists and albums open as Shuffle / Play / bold line / songs.

**Firmware update from SD (2.6.0).** Dual-bank: the running image is never written; the update goes to the other bank, is CRC-verified, its vector table written last, then `SWAP_BANK` flips. A trial counter in an RTC backup register rolls back after three restarts inside the first 20 s. The linker caps the image at 512 KB.

**DSD on V2 = DoP.** The V2 schematic leaves the CS43131's native DSD port (DSDA/DSDB/DSDCLK) unconnected, and PB3/PC3 — the V1 DSD pins — are now SWO and the 3.3 V rail enable. DSD files are therefore sent as **DoP** (DSD-over-PCM: 16 DSD bits + 0x05/0xFA marker per 24-bit sample) on the normal I²S link, and the DAC routes the ASP into its DSD processor (`DSD_SRC = ASP`). DSD64 → 176.4 kHz frames (same link rate as 176.4 k PCM). DSD128 → 352.8 kHz frames, i.e. a 22.58 MHz I²S bit clock, above what the STM32U5 SAI is specified for as a slave transmitter at 1.8 V — verify on hardware. DSD256 would need 705.6 kHz, beyond the CS43131 serial port, so those files are skipped. The DoP markers are stamped in the DMA callback, so they alternate correctly even through underruns and pauses (which are filled with DSD silence, not PCM zeros).

**E-ink strategy (2.7.0).** The default **fast** drive is InkBoy's: after one clean refresh the controller holds a register-loaded one-frame waveform, and a screen change is a burst of ~20 ms scans in which only the pixels that change are driven, 8 pulses each (per-pixel counters in `drivers/inkboy/drive_counters.c`). The burst is delivered one scan per main-loop lap, so keys are read between scans and a new frame simply replaces the target. Clean (flashing) refreshes: at session start, on **Full refresh** (often / normal / rarely = 40 / 120 / 250 screen changes) and before the driver's 2400-scan limit. The **classic** drive (Device settings, and automatically during USB modes, for the boot screen and after a fault restart) is the 2.6.x behaviour described below, minus the hot-weather "fast full", which measured slower than the normal full on this panel. **Ink strength** (4–8 pulses) replaces Contrast. Details and rules: `docs/DISPLAY.md`.

**E-ink, classic drive.** Black and white only: grays (separators, secondary text, scroll track) are 2×2 ordered dot patterns and album art is Floyd-Steinberg dithered, so every refresh uses one of the panel's factory OTP waveforms (the experimental register-loaded 4-gray LUT was removed in 2.5.0, the register partial waveform of 2.5.1–2.6.2 in 2.6.3). Refreshes are blocking (0.3–2 s), so the decoder and USB stack are serviced from inside the refresh wait; the audio ring only holds ~186 ms. Partial refreshes leave the panel's analog boosters on (update control `0xFC`) and the boosters are switched off (`0x83`) 1.5 s after the last one, so a burst of menu steps doesn't pay the booster start-up each time. Held keys never queue more than one auto-repeat, and lists scroll a page at a time. Partial refreshes support **windowing**: the battery icon and progress bar update via *threshold ticks* — the widget redraws only when its fill edge crosses a 1-px column (~5.5 % of charge, ~2 s of a 4-min track), and only that widget's rows/columns are re-driven. **Refresh policy (2.6.3).** Now Playing gets a normal full refresh on entry, track change and every N partials (album art is where ghosting shows, and music is playing anyway). In menus with **Menu refresh: gentle** (default) a screen change is a partial followed by a *reinforcing pass* — RED RAM set to the inverse of the new image, so every pixel is driven once more towards its own colour — which removes most ghosting with no flash; after N partials (a reinforcing pass counts as two) menus get a *fast* full refresh, the OTP's hot-weather waveform selected by writing 100 °C to the temperature register (0x1A, then 0x91 / 0xC7), used only when the nPM1300 die is ≥ 15 °C (≥ 30 °C while charging). **Classic** = full refresh on every screen change (2.6.1). N is the user-facing "Anim speed" setting (8/30/120) — your chosen ghosting tolerance. "Contrast" biases VSH/VSL/VCOM around the OTP values (level 2 = factory). **Dark mode** (Settings) inverts all four levels at render time — free, no extra buffer.

**Now-playing layout (200×200 is square — vertical space is precious).** The **artist** sits in the status bar; the right edge is an icon cluster: pause `||`, shuffle (crossed arrows), charging bolt, battery. No track counter — dropped as noise. Album art (**120×120**) is centred under the status bar. 2.6.5: one 3-px gap is used throughout. The progress bar (12 px tall) sits at the bottom of the panel with that gap below it, and runs from the left edge to the **track length** on the right. There is no elapsed-time counter: it changed on every redraw and ghosted. The **song title** sits the same gap above the bar and wraps onto a second line at small text size (which then meets the art at the same gap); medium and large text use one line. While the volume keys are in use, a **volume indicator** (speaker + level bar) replaces the status-bar title, and it disappears 3 s after the last key press. Menus show no transport strip; the status bar is identical everywhere. The battery icon keeps its 22×10 iPod-style footprint with a continuous 18-px fill; with **Settings → Battery %** on (fuel gauge, 2.6.0) the percentage is printed beside it; when charging, a lightning bolt appears beside the shell — beside, not inside, so it's visible over a full black fill — and is included in the icon's partial-refresh window. Screen renders live in `../renders/`; battery-life estimates in `../battery_life.txt`.

**Menus (2.7.0).** Main menu: Last played, Playlists, Shuffle all, Music, Albums, Artists, Podcasts (when `/Podcasts` has episodes), Device settings. Lists wrap around at both ends (a held key stops there). **Highlight** picks the cursor: Invert, Bold (selected row bold and one size larger), Arrow, Bar or Frame. Device settings is one list with section headings (Display, Playback, Sleep timer, Controls, Power & USB, System). On Now Playing, both skip keys held ~0.35 s (or a long press of play — **Quick menu**) open the **quick menu** while the music plays: podcast speed, sleep timer (a moon and the minutes you set appear in the status bar; it does not count down), remove from playlist (confirmed with a long press of play), loop song, and the queue ("Up next" — choosing a song jumps to it). **Headphone detect**: with the jack empty a song loads but will not play.

**Buttons.** EXTI is used only to wake; a 1 kHz SysTick integrator does 20 ms debounce, then short/long(700 ms)/double(300 ms, SW1 only)/repeat semantics: SW1 play-pause/select, long = resume last context, double = back (on the main menu: forward to Now Playing); SW2/SW3 next/prev + menu scroll with auto-repeat, SW1 double / SW3 long = back one level everywhere; SW4/SW5 volume (gain on the EQ screen). SW4+SW5 held 5 s = save settings and reboot (2.6.0: with SW1 also held it is the same plain reboot — USB DFU never worked on this board). While two or more keys are held nothing else happens (the recovery chords no longer start playback or change the volume), and the reboot chord only arms after vol− and vol+ have each been released once since power-up, so a stuck key can't cause a reset loop.

**USB.** VBUS presence comes from the nPM1300 (it also reads the USB-C CC current advertisement and the firmware sets its input-current limit from it — UCPD unused). VDDUSB is on the switched 3.3 V rail. When USB power appears (any source: computer, charger, power bank) the e-ink asks: storage / DAC / charge-only (or a fixed choice in Settings). With the cable already in at power-up the question is the first screen. MSC hands the host the *raw* card — FatFs is unmounted and playback stopped first, deliberately, to avoid dual-writer corruption. While storage or DAC is active a "USB storage"/"USB DAC" screen replaces the menus, so nothing local can touch the card or the audio path. If no computer enumerates the player within 6 s (a charger), it falls back to charge-only; ejecting the drive on the computer also hands the card back to the player. The DAC personality is UAC2 async with feedback EP at 44.1/48/88.2/96 kHz (the full-speed USB limit), all played natively; the USB-DAC screen shows the rate and whether the path is bit-perfect.

**Crash log.** Nothing diagnostic is shown on screen. If the player restarts on its own (CPU fault, init error, brownout, reset pin, watchdog), the next boot appends one line to `/crashlog.txt` with the fault registers and the step it was in; the file rotates to `crashlog.old` above 32 KB. Normal power-ups and deliberate restarts are not logged. See `BRINGUP.md` §7.

**Album art: yes.** Embedded JPEG (ID3 APIC / FLAC PICTURE / MP4 covr) is decoded by picojpeg, box-filtered to 120×120 gray, Floyd-Steinberg dithered to black and white and centred on the Now Playing screen — looks surprisingly good on e-paper, costs ~6 KB flash. Covers of 960 px and up (most of them) are decoded in picojpeg's DC-only "reduce" mode, which is roughly 10× faster and still gives at least one sample per output pixel. PNG art is skipped (not worth an inflater). Toggle in Settings.

**Settings & resume on SD — and, since 2.7.0, the device settings in flash too.** The last 8 KB page of the running bank holds a copy of the device settings (`app/flash_store.c`, 32 saves per erase, written only when a setting changes), loaded before the card is touched; volume and the resume point stay on the card. `settings.txt` is human-editable, survives reflashes, and wins over the flash copy when it loads; changes are batched and written 5 s after the first unsaved change (and immediately before sleep, a reboot chord or USB storage hand-off). The card is re-read whenever it is mounted (boot, insert, after USB storage), so edits made on a computer are picked up. Resume state (playlist, index, position, shuffle on/off and seed) rides in the same file — SW1 long-press restores it ("playlist 2, shuffle" style); the shuffle seed is saved with it so the order survives sleep and reboot.

**Fonts.** DejaVu Sans Condensed rendered to 1-bpp (`tools/gen_font.py`): 11/14/18-bold px plus 17/21 px for **Settings → Text size** (Small = the 2.5 size, 6 list rows; Medium 5; Large 4), ASCII-only (~15 KB total): CJK would cost 200 KB–1 MB (`flash_budget.md` §6) — non-ASCII tag characters render as `?`.

**Fault policy.** HardFault et al. record a report and reset the device — for a pocket player a reboot beats a lock-up; the resume file makes it nearly invisible, and the report makes it debuggable.

## Bring-up checklist / known-unverified

Software tasks from the V1 list are done (dependency fetch fixed, `ffconf.h` patched automatically, firmware builds cleanly with zero warnings in project code). What remains needs the real board:

- **New (2.7.0), nothing of it has run on the board:**
  - fast drive with audio playing — watch Device settings → About (faults, scan time) and `/crashlog.txt`; if it misbehaves, Display drive: classic is the 2.6.7 path;
  - wake from sleep: screen back via an OTP partial from white, then one clean refresh;
  - headphone gate at power-up with the jack empty (the codec only reports plug / unplug *events*; the first unplug event after enabling detection is what tells the firmware) — if playback is wrongly blocked, switch Headphone detect off;
  - SD at 12 MHz and the DAT0-only fallback; FLAC at 24/192 on a 1-bit bus may underrun;
  - flash settings page: change a setting, power-cycle without a card, check it stuck;
  - podcast speed on real speech (0.8–2.0×), CPU headroom at 2.0× with AAC;
  - the SW2 + SW3 chord (0.35 s) against accidental skips.
- CS43131 undocumented pop-free helper registers (0x10010/0x80032/0x80046) are used exactly as in the datasheet examples; verify no pops on real hardware.
- Verify the crystal actually fitted is the 8 pF cut and check startup with `XTAL_IBIAS` per DS Table 5-1; measure CLKOUT.
- **New (V2):** DoP — confirm `DSD_PATH_CTL_2` (0x070004) = `DSD_SRC=ASP | DSD_EN | DSD_SPEED` switches the DAC into DoP (encoding follows the Linux cs43130 driver), and listen for clean DSD64. Then test DSD128 (22.58 MHz SAI slave clock).
- **New (V2):** sleep — confirm headphone-plug detection still raises INT with the CS43131 crystal powered down and MCLK on the RCO (`cs43131_sleep()`); if not, keep `PDN_XTAL` cleared in sleep (costs ~1 mA).
- **New (V2):** nPM1300 GPIO0 as interrupt output (`GPIOMODE0` = GPOIRQ, VBUS-detected interrupt): scope PC3 on USB plug-in, and check the 3.3 V rail follows `BUCK2ENASET/CLR`. Measure sleep current (target: tens of µA plus the PMIC's quiescent current). If the IRQ route misbehaves, build with `-DPC3_PMIC_IRQ=OFF`.
- **New (V2):** wake-from-white partial refresh on the actual WeAct panel (waveform 0xFF after reset) — check for faint ghosting of the pre-sleep image.
- SSD1681 partial refresh now runs with the boosters left on (0x22=0xFC, off with 0x83 after 1.5 s idle); contrast table values could still be tuned on the actual WeAct panel batch.
- nPM1300 charge current: 350 mA (0.5C) default for the NP-BJ1, user-adjustable — confirm the cell charges at 350 mA and terminates at 4.2 V.
- UAC2 descriptor block and feedback-EP rate handling need host-side testing (Windows/macOS/Linux differ); MSC is the low-risk path.
- **Verified (2.5.0):** the battery cross with no battery fitted, and stable operation on USB and battery after the SW2 pull-up fix (a 3 Ω part had been fitted instead of 47 kΩ).
- **New (2.3):** BUCK1 (MCU 1.8 V) runs in forced-PWM mode while awake (`BUCK1PWMSET`, 0x0404) for lower ripple, and goes back to auto before Stop 2. Check sleep current is unchanged.
- I²C runs at 400 kHz with 10 kΩ pull-ups on 1.8 V — check rise time on a scope (drop to 100 kHz by changing `Timing` in `i2c_bus.c` if it is marginal).
