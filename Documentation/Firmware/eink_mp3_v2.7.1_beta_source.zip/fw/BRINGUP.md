# Bring-up and first flash: MP3 mainboard V2

Windows host. This is for the case where the board is powered with correct rails, but Windows shows no device and doesn't chime.

## 0. What to expect from a blank chip

A new STM32U575 has an **empty flash**.

- **BOOT0 low:** it runs nothing, and USB stays silent. This is normal.
- **BOOT0 high at the moment of reset:** it starts ST's ROM bootloader. Windows should chime and show **"STM32 BOOTLOADER"**, under *Universal Serial Bus devices*, or under *Other devices* if the driver isn't installed.

The firmware in this folder is also silent on USB until the e-ink prompt is answered. When USB power appears it asks *storage / DAC / charge only*, and only enumerates after you pick one. So no chime after flashing is expected until you press a button.

## 1. Most likely cause: BOOT0 was never sampled

BOOT0 (PH3) is read **only at reset**. With the NP-BJ1 connected, the nPM1300 keeps BUCK1 (1.8 V) running. Plugging in USB doesn't reset the MCU, so holding BOOT0 while plugging in does nothing. There's no reset button; NRST only goes to the debug header.

Do this:

1. Disconnect **both** the battery and USB, and wait a few seconds for the 1.8 V rail to fall below about 1 V.
2. Hold **BOOT**.
3. Plug in USB, with no battery fitted.
4. Release BOOT after about 1 s.

Alternatively, with power applied, hold BOOT and briefly short header pin **NRST** to **GND**.

**Check:** with a meter on PH3 (MCU pin 60) while BOOT is held, you should read about **1.8 V**. When released it should read 0 V; R21 is the 47k pull-down.

## 2. If it still doesn't enumerate, measure these

Put the board in bootloader mode as in section 1, then measure:

| # | Where | Expect | If not |
|---|---|---|---|
| 1 | NRST (header) | steady 1.8 V | pulsing means a reset loop or BOR (1.8 V rail sagging); 0 V means something holds reset |
| 2 | VCAP (pin 30) | **About 0.8–0.9 V** with a blank chip or when stuck in reset defaults: the regulator is on in its lowest range, so the core is alive. **About 1.1–1.2 V** once the bootloader or our firmware has raised the voltage range (our firmware uses range 1 for 160 MHz). | 0 V means the core regulator is off: check VDD/VSS pins, chip orientation and solder. If it reads about 0.8–0.9 V while D+ is 0 V, the chip is alive but not in the bootloader, so go to SWD (section 4). |
| 3 | VDDUSB (pin 48) | 3.3 V | |
| 4 | **D+ at the connector** (A6/B6), USB plugged in | **about 3.0–3.3 V** (the MCU's internal 1.5 k pull-up). This is what makes Windows chime. | 0 V means the bootloader isn't running USB: redo section 1 and see row 5. 3.3 V but still no chime points to the cable, the host port or the D+/D− routing (section 3). |
| 5 | D+ over the first 1–2 s | stays high | High briefly then drops can mean the bootloader locked onto another interface. On V2, USART1 RX (PA10) is the codec's I²S data input and floats in bootloader mode, so noise can look like a USART sync byte. As a bring-up test, tie PA10 high through 10 k. |

## 3. Board checks with power off

- **Cable:** try a cable that is known to carry data with a phone. Many USB-C cables are charge-only. Also try a USB-A-to-C cable into a port directly on the PC, not a hub.
- **Continuity:** connector DP1/DP2 (A6/B6) to MCU **PA12, pin 45**, and DN1/DN2 (A7/B7) to **PA11, pin 44**. Look for no short between D+ and D−, and none to GND or 3.3 V.
- **USBLC6-2SC6 footprint:** the part passes each line between pins **1↔6 (I/O1)** and **3↔4 (I/O2)**. On the PCB, IN_D− and D− must sit on the same pair, as must IN_D+ and D+. If a net lands on 1 and 3, the data lines are broken or crossed. Pin 2 is GND, pin 5 is VBUS (+3.3 V in this design).
- **Orientation:** flip the USB-C plug. Both DP1/DP2 and DN1/DN2 are tied in the schematic, so both ways should work. If only one works, the PCB is missing one of those ties.

## 4. Flash over SWD (recommended, independent of USB)

### Hardware

**Measured on the first board:** D+ 0 V, NRST 1.8 V, VCAP 0.8 V. The MCU is powered and its core regulator is running at reset defaults, but the USB bootloader never started. SWD should connect.

**STLINK-V3MINIE** uses the 14-pin 1.27 mm STDC14 connector. Use a 2×7 1.27 mm breakout, or flying leads into the supplied cable. Check pin 1 against the probe's marking and user manual (UM2910).

| STDC14 pin | Signal | Board header |
|---|---|---|
| 3 | T_VCC (sense) | VDD (+1.8 V) |
| 4 | T_SWDIO | SWDIO |
| 5, 7 | GND | GND |
| 6 | T_SWCLK | SWCLK |
| 8 | T_SWO | SWO (optional) |
| 12 | T_NRST | NRST |
| 1, 2, 9, 10, 11, 13, 14 | reserved / JTAG / VCP | leave unconnected |

Use an **STLINK-V3MINIE** or a genuine ST-LINK/V2. A J-Link also works. They sense the target voltage and drive SWD at **1.8 V**.

Avoid the cheap blue "ST-LINK V2" clones. They drive 3.3 V into a 1.8 V MCU, and NRST isn't 3.3 V tolerant. If you must use one, leave NRST unconnected.

| Header pin | Probe pin |
|---|---|
| VDD (+1.8 V) | T_VCC / VTref (sense only; the probe does not power the board) |
| SWDIO | SWDIO |
| SWCLK | SWCLK |
| NRST | NRST / T_NRST |
| SWO | SWO (optional, for trace) |
| GND | GND |

Power the board from the battery or USB. The probe should report about 1.8 V target voltage.

### Using a 3.3 V-only probe (clone ST-LINK V2 with STM32F103C8T6, Muse Lab nanoDAP)

Neither of these probes has level translation. Their SWD pins swing 0–3.3 V, and they can't sense the target's VDD. They can still flash this board if you take these precautions:

**Why it can work:** SWDIO (PA13) and SWCLK (PA14) are 5 V-tolerant (FT) pins on the STM32U5, so 3.3 V into them is within spec while the board is powered. Confirm the I/O structure column in the DS13737 pin table. The target's 1.8 V high level is read by the probe's FT input, whose threshold is about 1.55 V on an F103. That's only a small margin, so keep the SWD clock slow.

**Rules:**

1. Connect **GND, SWDIO and SWCLK only**. Put 330–1 kΩ series resistors in SWDIO and SWCLK if you have them.
2. **Do not connect the probe's 3.3 V or 5 V pins** to anything. They would back-feed the 1.8 V rail.
3. **Leave NRST unconnected.** The clone drives it push-pull at 3.3 V. With a blank chip, plain "Normal" connect works without it.
4. Power the board **before** plugging in the probe, and unplug the probe before removing board power.
5. SWD clock 100–480 kHz.

**Clone ST-LINK V2 with STM32CubeProgrammer:**

- Set mode **Normal**, reset **Software reset**, frequency 480 kHz (or 100 kHz).
- It reports a nonsense target voltage; ignore it.
- If it refuses because the probe firmware is too old for STM32U5, use OpenOCD (below) rather than "upgrading" a clone.

**nanoDAP (CMSIS-DAP)**, or the clone, via OpenOCD:

```
openocd -f interface/cmsis-dap.cfg -c "transport select swd; adapter speed 400" -f target/stm32u5x.cfg -c "program build/eink_mp3.elf verify reset exit"
```

For the clone, use `-f interface/stlink.cfg` instead of the CMSIS-DAP interface file. `xpack-openocd` is a ready-made Windows build.

**pyOCD** (`pip install pyocd`):

```
pyocd pack install stm32u575rg
pyocd flash -t stm32u575rgtx -f 400k build/eink_mp3.hex
```

**Check before the first connect (two minutes, with a meter):**

1. Put a 1 kΩ resistor in series with SWDIO and another with SWCLK.
2. Power the probe from USB, then power the board.
3. Measure across each resistor while the probe is idle and while it connects. Almost 0 mV (µA leakage) means the pin is tolerant. **About 1 V or more** (≈1 mA) means a clamp is conducting into the 1.8 V rail, so stop and use a level shifter.
4. With the board unpowered and the probe powered and wired, the 1.8 V rail (header VDD) must stay at about 0 V. Anything higher is back-feeding.

**Optional NRST via a diode:** fit a BAT54 or 1N5819 Schottky with its anode on the board's NRST and its cathode on the probe's NRST. The probe can then only pull NRST low. When the probe drives 3.3 V the diode blocks, and the MCU's internal pull-up keeps NRST at 1.8 V. That makes "connect under reset" possible without putting 3.3 V on a pin that isn't tolerant.

**The probe's small 6-pin (SOT-23-6) "LCV" parts** next to the SWD and USB pins, tied to its 3.3 V, are ESD clamp arrays, not level shifters. They don't change the 3.3 V drive. They also can't push current into the board while the probe is powered, because 1.8 V signals never exceed the probe's 3.3 V. Always plug the probe into USB before connecting it to a powered board, so the target never feeds the probe's unpowered rail through those clamps.

**If you prefer proper level shifting**, a TXS0108E or TXB0104 breakout works for SWD. Power its A side from the board's VDD (1.8 V) and its B side from the probe's 3.3 V, and pass SWDIO, SWCLK and NRST through it.

### STM32CubeProgrammer (GUI)

1. Install **STM32CubeProgrammer**. It also installs the ST-LINK and DFU drivers.
2. Build the firmware: `powershell -ExecutionPolicy Bypass -File tools\build_windows.ps1 -Install`, which produces `build\eink_mp3.hex`.
3. In CubeProgrammer, select **ST-LINK** and set:
   - Port: SWD
   - Frequency: 1000 kHz
   - Mode: **Under reset**
   - Reset mode: **Hardware reset**

   Then click **Connect**. If it fails, use **Normal** mode with **Core reset**, then drop the frequency to 480 kHz.
4. Go to **OB (Option bytes)** and check:
   - **RDP = AA** (level 0)
   - **TZEN = unchecked** (TrustZone off; the firmware is non-secure)
   - **nSWBOOT0 = checked** (BOOT0 pin used)
   - **nBOOT0 = checked**
   - **NSBOOTADD0 = 0x08000000** (start of user flash)
   - BOR level 0 (1.7 V). A higher level holds a 1.8 V part in reset.

   Fix any that differ and **Apply**.
5. **Erasing & programming:** Full chip erase, then pick the file `build\eink_mp3.hex`. Tick **Verify programming** and **Run after programming**, then **Start Programming**.

### Command line equivalent

```
STM32_Programmer_CLI -c port=SWD freq=1000 mode=UR reset=HWrst -ob displ
STM32_Programmer_CLI -c port=SWD freq=1000 mode=UR reset=HWrst -e all -d build\eink_mp3.hex -v -rst
```

## 5. Updating from the SD card (2.6.0 onwards)

The ROM USB-DFU route never worked on this board (it only restarted the player), so 2.6.0 removes it. **The first install of 2.6.0 has to go over SWD** (§4). After that:

1. Copy the new `eink_mp3_vX.Y.Z_<channel>.bin` (the `.bin`, not the `.hex`) into a folder **`Firmware`** in the root of the SD card — e.g. with USB storage mode.
2. On the player: **Settings → Firmware**. The list shows the running version, **Previous** (the firmware in the other flash bank) and one **Install X.Y.Z** line per `.bin` found.
3. Pick the file, **play** to confirm. The player erases the *other* bank, writes and CRC-verifies the image (progress on screen, ~5–10 s), then restarts into it.
4. The new firmware is on trial for its first 20 s of running. If it restarts three times before reaching that (crash loop), the player switches back to the previous firmware by itself and says "Update failed: rolled back". Once it passes, "Firmware X.Y.Z installed" appears.

**Rolling back by hand:** Settings → Firmware → **Previous: …** switches to the other bank instantly. Installing an older `.bin` from `/Firmware` works too.

Safety: the running firmware is never written; an interrupted update (card pulled, battery flat) leaves the player on the old firmware. The new image's first 16 bytes (stack pointer + reset vector) are written last, so a half-written bank never looks bootable. Images are limited to 512 KB (one bank) by the linker script.

**Note for SWD users after an SD update:** the banks may now be swapped (`SWAP_BANK = 1` in the option bytes). Programming a `.hex` at 0x08000000 still writes the bank that runs; that's expected.

## 6. After flashing: what should happen

1. The e-ink shows **"e.player"** and the version, e.g. **"v2.6.0 beta"** (splash, full refresh). Then it shows the main menu, or *No SD card* / *Audio codec error*.
2. With USB plugged in, the screen asks **"Use this cable for:"**. Choose *USB storage* to get the chime and a drive letter.

## 7. If the firmware doesn't come up

- **It restarts by itself:** the firmware records why. Since 2.5.0 nothing is shown on screen; after an abnormal restart a line is appended to **`/crashlog.txt`** on the SD card (PC, LR, CFSR, HFSR, fault address, SP and stacked registers, the step it was in). Normal power-ups are not logged. How to read it:
  - *HardFault / BusFault / UsageFault @address*: a firmware bug. Look the PC up in `eink_mp3.elf`: `arm-none-eabi-addr2line -e eink_mp3.elf 0x0800XXXX` and send it with the crashlog line.
  - *Brownout (1.8V dip)*: the 1.8 V rail fell below the MCU's BOR level without switching off completely, so a power problem rather than a code one. Typical when running from USB with no battery and the supply can't follow a load step. Check the option bytes are at BOR level 0 (1.7 V), scope VDD at a header pin while reproducing it, and try with the battery fitted.
  - *Reset pin (NRST)*: something pulled NRST low, either a connected debugger or the board.
- **Blank screen, NRST pulsing:** this is a reset loop. Fault handlers and `Error_Handler()` record the reason and call `NVIC_SystemReset()`. Attach the debugger (next point) and break on `diag_fault_entry` and `Error_Handler`, or read `/crashlog.txt` once it boots.
- **Debugger:**
  - **STM32CubeIDE:** *File > Import > STM32 Cortex-M Executable*, choose `build\eink_mp3.elf`, then debug with ST-LINK GDB server, *connect under reset*.
  - **VS Code:** use *Cortex-Debug* with `"servertype": "stlink"`, `"executable": "build/eink_mp3.elf"`, `"device": "STM32U575RG"`.

  Set a breakpoint on `main` and step over each init call:

  | Call | Hangs or fails here? | What to check |
  |---|---|---|
  | `SystemClock_Config` | ends in `Error_Handler` | the PLL/HSI48 configuration |
  | `npm1300_init` | returns false | I²C. Scope PB8/PB9: 10 k pull-ups, 400 kHz. Is the nPM1300 at 0x6B? |
  | `eink_init` / `ui_splash` | stuck | BUSY on PA1 stuck high. Check that PA3 (OE) goes high and E_RES toggles. |
  | `cs43131_init` | returns false | device ID / I²C at 0x30. Check RST on PB0 goes high. |
  | `sdcard_init` | fails | CD on PC5 is low with a card inserted, and 3.3 V is at the card. |
- **Sleep during debugging:** the debugger disconnects when the board sleeps (Stop 2). Set **Settings > Sleep after > never** in `settings.txt`: `sleep_timeout=5`. Or tick "debug in low-power modes" in the IDE.
- **SWO trace:** PB3 goes to the header, so ITM printf works in the CubeIDE SWV console. Core clock is 160 MHz; set SWO to 2 MHz.
