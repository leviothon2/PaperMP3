# E-ink MP3 player firmware - STM32U575RGT6
#
# Build:
#   cmake -B build -DCMAKE_TOOLCHAIN_FILE=cmake/arm-none-eabi.cmake \
#         -DCMAKE_BUILD_TYPE=Release
#   cmake --build build
# Output: build/eink_mp3.elf / .bin / .hex
#
# Third-party sources are fetched into third_party/ by
# third_party/fetch.sh (pinned versions) - run it once before configuring.

cmake_minimum_required(VERSION 3.22)
project(eink_mp3 C ASM)
set(FW_VERSION "2.7.1")
set(FW_CHANNEL "beta")

set(CMAKE_C_STANDARD 11)
if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE Release)
endif()
# Optimisation levels are set per source below - keep CMake's defaults
# (-O3) out of the way.
set(CMAKE_C_FLAGS_RELEASE "-DNDEBUG")
set(CMAKE_C_FLAGS_DEBUG   "")

if(NOT EXISTS ${CMAKE_CURRENT_SOURCE_DIR}/third_party/STM32CubeU5/Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal.h)
    message(FATAL_ERROR "Third-party sources missing - run third_party/fetch.sh first.")
endif()

set(TP ${CMAKE_CURRENT_SOURCE_DIR}/third_party)
set(CUBE ${TP}/STM32CubeU5)

add_executable(${PROJECT_NAME}
    # core
    Core/Src/main.c
    Core/Src/system_clock.c
    Core/Src/stm32u5xx_it.c
    Core/Src/syscalls.c
    Core/Src/dfu_entry.c
    Core/Src/diag.c
    ${CUBE}/Drivers/CMSIS/Device/ST/STM32U5xx/Source/Templates/system_stm32u5xx.c
    ${CUBE}/Drivers/CMSIS/Device/ST/STM32U5xx/Source/Templates/gcc/startup_stm32u575xx.s
    # drivers
    drivers/i2c_bus.c
    drivers/buttons.c
    drivers/eink.c
    # 2.7.0: InkBoy display driver fork (github.com/kuslota/InkBoy, MIT), as
    # ported and proven by the display-test firmware; see docs/DISPLAY.md
    drivers/ssd1681_fast/ssd1681_fast.c
    drivers/ssd1681_fast/ssd1681_port_stm32.c
    drivers/inkboy/fast_display.c
    drivers/inkboy/drive_counters.c
    Core/esp_compat/esp_compat.c
    drivers/gfx.c
    drivers/cs43131.c
    drivers/npm1300.c
    drivers/sdcard.c
    drivers/sai_audio.c
    # audio
    audio/decoder.c
    audio/ogg_min.c
    audio/resampler.c
    audio/sinc_table.c
    audio/eq.c
    audio/audio_pipeline.c
    audio/dsd.c
    audio/tags.c
    audio/timestretch.c
    # app
    app/power.c
    app/settings.c
    app/playlist.c
    app/player.c
    app/ui.c
    app/usb_app.c
    app/usb_descriptors.c
    app/diskio_sd.c
    app/library.c
    app/fuelgauge.c
    app/fwupdate.c
    app/flash_store.c
    app/podcast.c
    # assets
    assets/font_ui11.c
    assets/font_ui14.c
    assets/font_ui18b.c
    assets/font_ui17.c
    assets/font_ui21.c
    assets/font_ui16b.c
    assets/font_ui19b.c
    assets/font_ui23b.c
    # third-party (single-file / small libs)
    ${TP}/fatfs/ff.c
    ${TP}/fatfs/ffunicode.c
    ${TP}/picojpeg/picojpeg.c
    # Helix AAC, libopus and TinyUSB: source lists in their sources.cmake
)

# Helix AAC + libopus have their own source lists; fetch.sh drops a
# CMake fragment for each after download.
include(${TP}/helix-aac/sources.cmake)
include(${TP}/opus/sources.cmake)
include(${TP}/tinyusb/sources.cmake)

# HAL modules used
file(GLOB HAL_SRC
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_cortex.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_rcc.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_rcc_ex.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_pwr.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_pwr_ex.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_gpio.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_dma.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_dma_ex.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_i2c.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_i2c_ex.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_spi.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_sai.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_sai_ex.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_sd.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_sd_ex.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_ll_sdmmc.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_rtc.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_rtc_ex.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_exti.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_flash.c
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_flash_ex.c
)
target_sources(${PROJECT_NAME} PRIVATE ${HAL_SRC})
set_source_files_properties(${HAL_SRC} ${TP}/fatfs/ff.c ${TP}/fatfs/ffunicode.c
    ${TP}/picojpeg/picojpeg.c PROPERTIES COMPILE_OPTIONS "-Wno-unused-parameter")

target_include_directories(${PROJECT_NAME} PRIVATE
    Core/Inc
    Core/esp_compat
    drivers
    drivers/ssd1681_fast
    drivers/inkboy
    audio
    app
    assets
    ${CUBE}/Drivers/STM32U5xx_HAL_Driver/Inc
    ${CUBE}/Drivers/CMSIS/Device/ST/STM32U5xx/Include
    ${CUBE}/Drivers/CMSIS/Include
    ${TP}/fatfs
    ${TP}/dr_libs
    ${TP}/minimp4
    ${TP}/picojpeg
    ${TP}/helix-aac
    ${TP}/opus/include
    ${TP}/tinyusb/src
)

# PC3 <-> nPM1300 GPIO0 role (see board.h): ON = PMIC interrupt (instant
# USB-plug wake, rail switched over I2C); OFF = PC3 drives the rail enable
# and VBUS is polled every 250 ms in sleep.
option(PC3_PMIC_IRQ "PC3 carries the nPM1300 interrupt" ON)
if(PC3_PMIC_IRQ)
    target_compile_definitions(${PROJECT_NAME} PRIVATE BOARD_PC3_PMIC_IRQ=1)
else()
    target_compile_definitions(${PROJECT_NAME} PRIVATE BOARD_PC3_PMIC_IRQ=0)
endif()

target_compile_definitions(${PROJECT_NAME} PRIVATE
    FW_VERSION="${FW_VERSION}"
    FW_CHANNEL="${FW_CHANNEL}"
    STM32U575xx
    USE_HAL_DRIVER
    # libopus embedded build: fixed point, decoder stack scratch via VLAs
    OPUS_BUILD FIXED_POINT DISABLE_FLOAT_API VAR_ARRAYS HAVE_LRINT HAVE_LRINTF
    # dr_libs: no stdio, no SIMD
    DR_MP3_NO_STDIO DR_FLAC_NO_STDIO DR_WAV_NO_STDIO DR_FLAC_NO_OGG
    DRMP3_NO_SIMD DRFLAC_NO_SIMD
)

# Size-optimised by default; the decode hot paths are built -O2 because
# every MHz saved there is CPU time spent in WFI (battery life).
target_compile_options(${PROJECT_NAME} PRIVATE
    -Os -g3
    -Wall -Wextra
    $<$<COMPILE_LANGUAGE:C>:-Werror=implicit-function-declaration>
)
file(GLOB_RECURSE SPEED_SRC
    ${TP}/opus/celt/*.c ${TP}/opus/silk/*.c ${TP}/helix-aac/*.c)
list(APPEND SPEED_SRC
    ${CMAKE_CURRENT_SOURCE_DIR}/audio/decoder.c
    ${CMAKE_CURRENT_SOURCE_DIR}/audio/resampler.c
    ${CMAKE_CURRENT_SOURCE_DIR}/audio/eq.c
    ${CMAKE_CURRENT_SOURCE_DIR}/audio/audio_pipeline.c
    ${CMAKE_CURRENT_SOURCE_DIR}/audio/timestretch.c
    # the per-pixel drive planner runs once per 20 ms scan
    ${CMAKE_CURRENT_SOURCE_DIR}/drivers/inkboy/drive_counters.c
    ${CMAKE_CURRENT_SOURCE_DIR}/drivers/inkboy/fast_display.c
    ${CMAKE_CURRENT_SOURCE_DIR}/drivers/ssd1681_fast/ssd1681_fast.c)
set_property(SOURCE ${SPEED_SRC} APPEND PROPERTY COMPILE_OPTIONS -O2)

set_target_properties(${PROJECT_NAME} PROPERTIES SUFFIX ".elf")

target_link_options(${PROJECT_NAME} PRIVATE
    -T${CMAKE_CURRENT_SOURCE_DIR}/ld/STM32U575xG.ld
    -Wl,-Map=${PROJECT_NAME}.map
)
target_link_libraries(${PROJECT_NAME} PRIVATE m)   # libm: EQ design, lrintf

# InkBoy's driver logs through ESP_LOGx; warnings and errors are kept in a
# small RAM ring, everything goes to SWO when a debugger enables ITM.
target_compile_definitions(${PROJECT_NAME} PRIVATE LOG_LOCAL_LEVEL=ESP_LOG_INFO)

add_custom_command(TARGET ${PROJECT_NAME} POST_BUILD
    COMMAND ${CMAKE_OBJCOPY} -O binary $<TARGET_FILE:${PROJECT_NAME}> ${PROJECT_NAME}.bin
    COMMAND ${CMAKE_OBJCOPY} -O ihex   $<TARGET_FILE:${PROJECT_NAME}> ${PROJECT_NAME}.hex
    COMMAND ${CMAKE_SIZE} $<TARGET_FILE:${PROJECT_NAME}>
)
