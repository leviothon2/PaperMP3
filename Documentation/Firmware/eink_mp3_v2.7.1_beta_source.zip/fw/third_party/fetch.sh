#!/usr/bin/env bash
# Fetch pinned third-party dependencies into third_party/.
#
# Run once before the first CMake configure (re-running is safe: anything
# already present is skipped). Requires git + curl. Works from Git Bash /
# MSYS2 on Windows as well as Linux/macOS.
#
# Every dependency is pinned to a tag or commit so builds are reproducible.
# Changes vs. the v1 script (see CHANGELOG.md):
#   - STM32CubeU5: the HAL driver and CMSIS device files are git
#     *submodules* of the Cube repo; v1 cloned without them, so the build
#     could never find stm32u5xx_hal.h. Only the two submodules we need
#     are initialised (the full recursive clone is ~2 GB).
#   - FatFs: elm-chan.org is unreachable from many networks/proxies (and
#     v1 silently ignored the failure). Now pulled from ST's GitHub mirror
#     of R0.15, and ffconf.h is patched automatically (LFN, exFAT, ...).
#   - dr_libs / minimp4: pinned to a commit instead of "master".
set -euo pipefail
cd "$(dirname "$0")"

clone() { # repo ref dir   (".fetched" marks a copy without .git)
    if [ ! -d "$3/.git" ] && [ ! -f "$3/.fetched" ]; then
        rm -rf "$3"
        git -c advice.detachedHead=false clone -q --depth 1 --branch "$2" "$1" "$3"
        echo "$1 $2" > "$3/.fetched"
    fi
}

get() { # url dest
    [ -s "$2" ] || curl -fsSL --retry 3 -o "$2" "$1"
}

echo "[1/8] STM32CubeU5 v1.6.0 (HAL + CMSIS device only)"
clone https://github.com/STMicroelectronics/STM32CubeU5.git v1.6.0 STM32CubeU5
(
    cd STM32CubeU5
    if [ ! -f Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal.h ] ||
       [ ! -f Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u575xx.h ]; then
        git submodule update --init --depth 1 \
            Drivers/STM32U5xx_HAL_Driver \
            Drivers/CMSIS/Device/ST/STM32U5xx
    fi
)

echo "[2/8] FatFs R0.15 (ST mirror)"
FATFS_REF=r0.15_stm32cube_20260403
if [ ! -f fatfs/ff.c ]; then
    rm -rf fatfs-src
    git -c advice.detachedHead=false clone -q --depth 1 --branch "$FATFS_REF" \
        https://github.com/STMicroelectronics/stm32_mw_fatfs.git fatfs-src
    mkdir -p fatfs
    for f in ff.c ff.h ffconf_template.h ffunicode.c diskio.h; do
        src=$(find fatfs-src -name "$f" -not -path "*/drivers/*" | head -1)
        [ -n "$src" ] && cp "$src" fatfs/
    done
    [ -f fatfs/ffconf.h ] || cp fatfs/ffconf_template.h fatfs/ffconf.h
    rm -rf fatfs-src
fi
# ffconf.h: LFN on the static work buffer, UTF-8 API, exFAT (SDXC cards),
# string functions for settings.txt, single volume, no relative paths.
sed -i.bak \
    -e 's/^#define FF_USE_LFN[[:space:]].*/#define FF_USE_LFN\t\t1/' \
    -e 's/^#define FF_LFN_UNICODE[[:space:]].*/#define FF_LFN_UNICODE\t2/' \
    -e 's/^#define FF_FS_EXFAT[[:space:]].*/#define FF_FS_EXFAT\t\t1/' \
    -e 's/^#define FF_CODE_PAGE[[:space:]].*/#define FF_CODE_PAGE\t437/' \
    -e 's/^#define FF_USE_STRFUNC[[:space:]].*/#define FF_USE_STRFUNC\t1/' \
    -e 's/^#define FF_PRINT_LLI[[:space:]].*/#define FF_PRINT_LLI\t0/' \
    -e 's/^#define FF_PRINT_FLOAT[[:space:]].*/#define FF_PRINT_FLOAT\t0/' \
    -e 's/^#define FF_FS_RPATH[[:space:]].*/#define FF_FS_RPATH\t\t0/' \
    -e 's/^#define FF_VOLUMES[[:space:]].*/#define FF_VOLUMES\t\t1/' \
    -e 's/^#define FF_FS_NORTC[[:space:]].*/#define FF_FS_NORTC\t\t0/' \
    -e 's/^#define FF_FS_TINY[[:space:]].*/#define FF_FS_TINY\t\t0/' \
    fatfs/ffconf.h && rm -f fatfs/ffconf.h.bak

echo "[3/8] dr_libs (mp3/flac/wav)"
DRLIBS_SHA=5690d4671d7ad07ae6021756d7222eb159745f06     # tag mp3-0.7.3
mkdir -p dr_libs
for f in dr_mp3.h dr_flac.h dr_wav.h; do
    get "https://raw.githubusercontent.com/mackron/dr_libs/$DRLIBS_SHA/$f" "dr_libs/$f"
done

echo "[4/8] minimp4"
MINIMP4_SHA=2a3014a7753cfcba4442adeb469431967238fe6a
mkdir -p minimp4
get "https://raw.githubusercontent.com/lieff/minimp4/$MINIMP4_SHA/minimp4.h" minimp4/minimp4.h

echo "[5/8] picojpeg (master w/ 'reduce' DC-only mode)"
PICOJPEG_SHA=8ab33a909b4115ace4a952b7ffcb64c350f9298d
mkdir -p picojpeg
for f in picojpeg.c picojpeg.h; do
    get "https://raw.githubusercontent.com/richgel999/picojpeg/$PICOJPEG_SHA/$f" "picojpeg/$f"
done

echo "[6/8] Helix AAC (RPSL licence - check fit before selling the product!)"
if [ ! -f helix-aac/aacdec.c ]; then
    rm -rf helix-aac-src
    git -c advice.detachedHead=false clone -q --depth 1 --branch v0.8.6 \
        https://github.com/pschatzmann/arduino-libhelix.git helix-aac-src
    mkdir -p helix-aac/utils
    cp helix-aac-src/src/libhelix-aac/*.[ch] helix-aac/
    cp helix-aac-src/src/libhelix-aac/*.txt helix-aac/ 2>/dev/null || true
    cp helix-aac-src/src/utils/helix_pgm.h helix-aac-src/src/utils/helix_memory.h \
       helix-aac/utils/      # helix_malloc/free are provided by audio/decoder.c
    # Cortex-M33 has SMULL/SMLAL/SSAT: enable Helix's GCC/ARM inline-asm
    # path (the Arduino fork disabled it for ARMv6-M boards).
    sed -i.bak 's/defined(XXXX__arm__)/defined(__arm__)/' helix-aac/assembly.h
    rm -f helix-aac/assembly.h.bak
    rm -rf helix-aac-src
fi
cat > helix-aac/sources.cmake <<'EOF2'
file(GLOB HELIX_SRC ${TP}/helix-aac/*.c)
target_sources(${PROJECT_NAME} PRIVATE ${HELIX_SRC})
# Plain libc malloc/free; Helix is old C: silence its warnings rather
# than patch vendor code.
set_source_files_properties(${HELIX_SRC} PROPERTIES
    COMPILE_OPTIONS "-w" COMPILE_DEFINITIONS "USE_DEFAULT_STDLIB")
EOF2

echo "[7/8] libopus v1.5.2 (fixed-point decoder only)"
clone https://github.com/xiph/opus.git v1.5.2 opus
cat > opus/sources.cmake <<'EOF'
# Fixed-point libopus (decoder path). Arch-specific (x86/NEON/DNN)
# sub-directories are not globbed; test/demo sources are excluded.
file(GLOB OPUS_SRC
    ${TP}/opus/src/opus.c ${TP}/opus/src/opus_decoder.c
    ${TP}/opus/celt/*.c ${TP}/opus/silk/*.c ${TP}/opus/silk/fixed/*.c)
list(FILTER OPUS_SRC EXCLUDE REGEX "demo|test|opus_compare|opus_custom")
# Encoder objects are compiled but dropped by --gc-sections (never called).
target_sources(${PROJECT_NAME} PRIVATE ${OPUS_SRC})
target_include_directories(${PROJECT_NAME} PRIVATE
    ${TP}/opus ${TP}/opus/include ${TP}/opus/celt ${TP}/opus/silk ${TP}/opus/silk/fixed)
set_source_files_properties(${OPUS_SRC} PROPERTIES COMPILE_OPTIONS "-w")
EOF

echo "[8/8] TinyUSB 0.17.0"
clone https://github.com/hathach/tinyusb.git 0.17.0 tinyusb
cat > tinyusb/sources.cmake <<'EOF'
set(TUSB_SRC
    ${TP}/tinyusb/src/tusb.c
    ${TP}/tinyusb/src/common/tusb_fifo.c
    ${TP}/tinyusb/src/device/usbd.c
    ${TP}/tinyusb/src/device/usbd_control.c
    ${TP}/tinyusb/src/class/msc/msc_device.c
    ${TP}/tinyusb/src/class/audio/audio_device.c
    ${TP}/tinyusb/src/portable/synopsys/dwc2/dcd_dwc2.c   # U575 = OTG-FS (DWC2)
    ${TP}/tinyusb/src/portable/synopsys/dwc2/dwc2_common.c)
foreach(f ${TUSB_SRC})
    if(EXISTS ${f})
        target_sources(${PROJECT_NAME} PRIVATE ${f})
    endif()
endforeach()
EOF

echo "All third-party sources fetched."
