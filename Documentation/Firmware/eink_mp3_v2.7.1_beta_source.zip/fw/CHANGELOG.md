# Changelog

## 2.7.1 (beta) — 2026-11-13

2.7.0 with headphone detect fixed. In 2.7.0 the detect state never changed after boot: booted with headphones it never saw them unplugged, booted without it never saw them plugged in.

**Not run on the board yet.** Builds with zero warnings in project code; the new host test below reproduces the 2.7.0 failure and passes with 2.7.1.

### Headphone detect

- **INT pull-up.** The codec's INT# is open drain, and the V2 board has no pull-up on the INT net (`board.h` claimed one; `cs43131_init()` set `GPIO_NOPULL`). After the first event the line was left floating low, so EXTI10 never saw another falling edge. PB10 now uses the STM32's internal pull-up (~40 kΩ to 1.8 V; about 45 µA only while the codec holds INT low). A 10–100 kΩ resistor from INT to +1.8 V on the next board revision is still recommended.
- **No missed edges.** The main loop now also serves INT while PB10 reads low, not only when the EXTI flag is set (`cs43131_hp_poll()`, called from `player_power_poll()`). Once the codec's HP_STATUS register has agreed with a plug/unplug event, the debounced pin level is also re-read every 500 ms. If HP_STATUS ever disagrees with an event, it is ignored from then on and the event flags alone are used.
- **Start-up state is read, not assumed.** The detect block is set up in the datasheet's order (§4.5.1.4: clear status, unmask, debounce with detect off, then enable). 2.7.0 enabled first and then read and discarded the status, which threw away the 0 ms unplug event. The state at boot now comes from the first event after enabling. Booting with headphones in waits up to 0.6 s for the 500 ms plug debounce; without headphones there is no wait.
- **Events during sleep are kept.** `cs43131_wake()` and the crystal and PLL start polls used to read and discard Interrupt Status 1. An unplug while asleep (masked, but still latched) was lost, so the player kept reporting "headphones in". Every read of that register now goes through one function that updates the state, and a change found on wake is reported to the player on the next main-loop lap.
- **Debounce comment corrected.** `0xC4` gives a 0 ms *unplug* (rising) and a 500 ms *plug* (falling) debounce; 2.7.0's comment had them swapped. The value itself is unchanged.
- **Jack polarity switch.** `BOARD_HPDETECT_INVERT` in `board.h` (default 0) sets the codec's HPDETECT_INV. Set it to 1 if the PJ-3401's pin 6–5 switch turns out to be closed with no plug, which would make detection read backwards.

### Checks (no board needed)

- `tools/host_test/run.sh` adds `test_hpdetect.c`: `drivers/cs43131.c` against a model of the codec's detect block (debounce, sticky flags, masks, open-drain INT with or without pull-up, EXTI on falling edges). Scenarios: plug and unplug both ways from either boot state, a lost EXTI edge, unplug while asleep, plug and out-and-in while asleep, and a floating-low INT. Each runs twice, the second time with HP_STATUS polarity swapped. 2.7.0's driver fails scenarios 1–4 in this model.
- Existing host tests, `tools/ui_sim` and `check_safety.py` still pass.

### Notes

- Image 470 KB of the 504 KB limit with the toolchain used for this build (GCC 13.2, Ubuntu `gcc-arm-none-eabi`); the headphone changes add about 0.5 KB. Static RAM is unchanged.

## 2.7.0 (beta) — 2026-11-12

2.6.7 plus everything the display-test firmware (dt-0.1.0 … dt-0.2.1) established, with the panel now driven by the fork of InkBoy's display driver ([github.com/kuslota/InkBoy](https://github.com/kuslota/InkBoy)), and a reworked menu: quick menu on Now Playing, sleep timer, podcasts, new main-menu order, Device settings with sections, wrap-around lists and five cursor styles.

**Not run on the board yet.** It builds with zero warnings in project code, and the parts that can run on a PC are tested there (see "Checks" below). The first install can go through the SD card from 2.6.x (**Settings → Firmware**); 2.6.7 stays in the other bank as **Previous**.

### From the display-test firmware

- **InkBoy display drive ("fast", the default).** `drivers/ssd1681_fast` (driver + STM32 port) and `drivers/inkboy` (dithered drive, per-pixel pulse counters) are the display-test files; `drivers/eink.c` is now a thin front-end over them that keeps the player's `eink_*` calls.
  - A screen change is a burst of about 20 ms scans that drive only the pixels that change, 8 pulses each: about 0.3 s, **no flash**. The main loop delivers one scan per lap, so keys are read between scans and a new frame replaces the target at once — holding a key scrolls without waiting for each refresh to finish.
  - Song changes on Now Playing (album art included) use the same drive, so they no longer flash.
  - A clean (flashing) refresh runs when a session starts (after boot, after wake, after leaving a USB mode), when **Full refresh** (often / normal / rarely = every 40 / 120 / 250 screen changes) says so, and when the driver's own limit of 2400 scans comes into view. InkBoy's limits (2402 activations per power-on, clean every 2400) are unchanged; the front-end renews the session before they are reached.
  - Grayscale is not built in: InkBoy's planner needs over 230 KB of RAM and the player has 2 KB to spare. Album art stays 1-bit dithered.
- **Classic drive** (**Device settings → Display drive: classic**): the factory (OTP) waveforms exactly as in 2.6.7 — full, partial, partial + reinforcing pass. It is also used automatically:
  - **while a USB prompt, USB storage or USB DAC is active.** The register waveforms hung 2.5.1–2.6.2 on exactly those screens and the cause was never isolated (display test DESIGN.md §3.5), so no register waveform is loaded there;
  - **for the boot screen**, so wiring, level shifter, booster and BUSY are proven by the known-good path first;
  - **after a restart caused by a fault, brownout, watchdog or init error**, until the next normal start or until you pick a drive in Device settings — a crash must not turn into a refresh-and-reboot loop.
- **Results applied.**
  - The OTP hot-weather "fast full" is gone: it measured *slower* than the normal full on this panel (1728 ms against 1390 ms).
  - 8 pulses per pixel and 20 MHz panel SPI are the defaults (**Ink strength** 1–5 = 4–8 pulses; `spi_fast=0` in `settings.txt` gives 10 MHz).
  - **Edge clean-up** (off / 1 px / 2 px) is the display test's edge halo.
- **Panel faults are faults.** A BUSY timeout or SPI error closes the driver (deep sleep attempt, level shifter off) instead of carrying on. It is re-opened from a hardware reset 3 s later, twice; if the panel is still silent the +3.3 V rail is cycled once — only while nothing is playing and no USB data mode is active, with a paused track kept — and after that it is retried every 30 s. **About** shows the fault count.
- **USB input limit before the first boost.** The nPM1300's VBUS limit is raised from its 100 mA start-up value before the panel is first driven.
- **Hardened SD driver** (`drivers/sdcard.c` from dt-0.2.1): a reset peripheral and cleared handle for every attempt, the failing stage and error bits kept, CMD12 recovery after a failed transfer, 250 / 500 ms transfer timeouts, and **12 MHz** instead of 24 MHz (the read round trip through the TXS02612 leaves no margin at 24 MHz).
  - The card is started with up to three tries. If it initialises but 4-bit reads fail, it is used on DAT0 only for that session.
  - The "No SD card / bad card" screen and **About** now say why: `SD fail: IDENTIFY CTIMEOUT`, `SD ok, 12 MHz 1-bit (fallback)`.
  - `sd_clock_div` and `sd_4bit` in `settings.txt` change the bus (1 = 24 MHz as in 2.6.7).
- **Settings in internal flash** (`app/flash_store.c`): the device settings are also kept in the last 8 KB page of the running bank and loaded before the card and the panel are touched, so the SD bus settings, key timing and display drive work without a card. `settings.txt` still wins when it loads. Volume and the resume point stay on the card only (they change too often). The image limit is now **504 KB**; the NMI handler tolerates a double-ECC error on that page only.
- **Key timing** (`drivers/buttons.c` from dt-0.2.0): **Double-press back** on/off (off: select acts at once instead of after 300 ms; back is then a long press of the up key), **Keys act on: press / release** for the list keys, **Long press** 0.5 / 0.7 / 1.0 s.
- Not taken over: the test pages themselves (patterns, benchmark, SD diagnostics, results log) and the 2.6.6 rail policy.

### Playback

- **Headphone gate** (**Headphone detect**, on by default). With the jack empty a song still loads — title, art, position — but stays paused, play does nothing ("Plug in headphones"), and unplugging pauses as before. The USB DAC keeps consuming the stream but sends silence. Switch it off if your board's detect pin misbehaves.
- **Quick menu.** On Now Playing, hold **both skip keys** for about 0.35 s, or **hold play** — **Quick menu: skip keys / hold play / either**. The music keeps playing. Rows:
  - **Speed** (podcasts only, at the top) — 0.8×, 1.0×, 1.2×, 1.5×, 1.75×, 2.0×, one global setting.
  - **Sleep timer** — opens a list (off, 5 … 120 min). Choosing one returns to the song, with a moon and the minutes in the status bar. The number is the time you set; it does not count down.
  - **Remove from playlist** — asks first; only a **long press of play** removes, any other key cancels. The line is taken out of the `.m3u` on the card (the audio file stays), the play order of the rest is kept, and the next song starts. Shown only when a playlist file is playing.
  - **Loop song** — repeats the current song; off returns to the Repeat setting you had.
  - **Up next** — the rest of the current list. Choosing a song jumps to it and closes the menu; the queue then starts after that song.
- **Sleep timer options** (Device settings): **Fade out** off / 10 / 30 / 60 s, and **Finish the song** (pause at the end of the current song instead of mid-song; the next song is loaded so resume continues there). When the timer runs out the player pauses and goes to sleep.
- **Podcasts.** Every audio file under `/Podcasts` (sub-folders allowed, up to 200) is one plain list, sorted by name — no Shuffle or Play rows, you choose an episode. Each row shows **new**, **26m left** or **played**. An episode resumes where it stopped and playback stops at its end. Podcasts are left out of Shuffle all, Music, Albums and Artists. The **Podcasts** row appears on the main menu when the folder has episodes.
  - Speed changes the tempo, not the pitch (overlap-add time stretching, `audio/timestretch.c`), for PCM up to 48 kHz; at 1.0× the audio path is untouched.

### Menus

- **Main menu:** Last played, Playlists, Shuffle all, Music, Albums, Artists, (Podcasts), Device settings. Playlists are now one row that opens the list of playlists. **Last played** resumes where you were (it reads **Now playing** while something is loaded).
- **Device settings** (was Settings), one list with section headings: Display, Playback, Sleep timer, Controls, Power & USB, System. Values are right-aligned. **About** shows version, SD status, display drive and scan counts, battery, headphones and the last reset.
- **Lists wrap around:** up from the first row goes to the last and the other way round. A held key stops at the end.
- **Highlight:** Invert (as before), Bold (selected row bold and one size larger), Arrow, Bar, Frame. Only the selected row changes; the others keep their font and position.
- Status bar: sleep-timer mark, pause bars, loop mark, shuffle, battery. Titles without art (and all podcasts) wrap over up to three lines.
- **Contrast** is replaced by **Ink strength** (the forked driver has no raw-voltage interface, by design); the `contrast=` key is ignored.

### Checks (no board needed)

- `tools/host_test/run.sh`:
  - the panel front-end and driver against a fake SSD1681 — every settled refresh matches the framebuffer pixel for pixel, through session start, mid-burst retargeting, the USB guard, sleep / wake, 1400 screen changes across the driver's activation limit, the classic drive, a BUSY fault with rail-cycle recovery and an SPI fault; command 0x30 never sent;
  - the time stretcher at 0.8–2.0× and 22–48 kHz (speed ratio within 2 %, no discontinuities);
  - playlist removal, the podcast list and listening positions with the real FatFs on a RAM disk.
- `tools/ui_sim/run.sh` runs the real `ui.c` with mocked hardware through every screen, checks the navigation rules (wrap-around, headers skipped, quick-menu triggers, remove confirmation, queue jump, headphone gate) and writes the screens to PNG.
- `python3 tools/check_safety.py`: the reviewed panel command list, one LUT loader, SPI1 only in the port, flash writes limited to the updater and settings page 63.

### Notes

- Image 474 KB of the 504 KB limit. Static RAM is at 99.7 % (2 KB spare; the 160 KB heap and 48 KB stack are unchanged) — a new static buffer has to replace an old one.
- New `settings.txt` keys: `display_drive`, `ink`, `edge_cleanup`, `highlight`, `spi_fast`, `hp_detect`, `podcast_speed`, `timer_min`, `timer_fade_s`, `timer_song_end`, `quick_key`, `btn_sw1_double`, `btn_nav_on_press`, `btn_long_ms`, `sd_clock_div`, `sd_4bit`.
- New files on the card: `/.eplayer/podcasts.idx` (the list, rebuilt after every mount) and `/.eplayer/podcasts.dat` (positions).

## 2.6.7 (beta) — 2026-11-06

**The 2.6.6 wake rework is withdrawn.** 2.6.6 made plugging in the SD card unstable while on USB. Until the root cause is known, this build uses the 2.6.5 power code with one change:

- **The +3.3 V rail stays on during sleep.** The SD card is unmounted and its bus stopped: SDMMC clock off, CLK held low so the TXS02612's CLKA input never floats, CMD/DAT high-Z with the shifter's own pull-ups. The card idles in standby on its own supply. On wake `sdcard_init()` re-runs the full identification starting with CMD0, so no power-on reset is needed. That removes the "music lost after a long sleep" failure, which came from the card not getting a clean reset when the rail was switched back on.
- **Cost:** the card's standby current. That's typically 0.1–0.3 mA (card-dependent), plus a few µA for the panel in deep sleep, the two level shifters and BUCK2's own quiescent current. On the 700 mAh NP-BJ1 that is roughly 3–9 months of standby, against much longer with the rail off.
- **Back to 2.6.5 behaviour:**
  - no BUCK2 pull-down;
  - 3 ms rail settle;
  - no rail cycle at boot;
  - screen before SD on wake;
  - no background SD retries;
  - a failed card-ID read is still treated as a card change.
- The rail-switching code (`power_rail_3v3`, `sdcard_power_off`) stays in the source for when the root cause is understood.

### Possible causes of the 2.6.6 instability (to investigate, not fixed)
1. **Background SD retries ignored USB storage.** While "SD card not ready, retrying" was active, `sd_retry_poll()` kept calling `sdcard_init()`, `settings_remount_quiet()` and `player_after_wake()` every second, with no check for the host owning the card. Choosing USB storage in that window gives two masters on one card: SDMMC re-initialised under TinyUSB, and FatFs mounted (settings flushed) over a volume the PC is writing. That means corrupt transfers and FAT damage.
2. **BUCK2 pull-down semantics.** If `BUCKCTRL0.BUCK2ENPULLDOWN` loads the output while BUCK2 is *on*, not only when it's disabled, the 3.3 V rail carries a constant extra load and less transient margin. The rail also feeds VDDUSB (the USB PHY) and the card, so a card insertion's inrush (its decoupling charging from the shared rail) could pull VDDUSB below the PHY's minimum and drop or corrupt the USB link. Check by measuring rail current with BUCK2 on, with the bit set and clear.
3. **Rail cycling with USB involved.** 2.6.6 cycled the shared rail at boot and up to three times on a failed wake. On a USB-power wake the SD-first wake with retries also delays `usb_app_vbus_replugged()`, so the nPM1300 stays on its ~100 mA start-up input limit longer while the card starts. Each cycle also takes VDDUSB, the panel and the TXS02612 card side down together.
4. **Blocking delays.** `power_rail_3v3(true)` gained a `HAL_Delay` of up to 110 ms (off time + settle). Anything calling it while USB is running stalls `tud_task()` for that long, which a host can treat as a timeout during enumeration or MSC transfers.
5. **Card-detect events during the new wake window.** The card-detect interrupt was re-enabled *before* the SD retries, so an insertion during that window queues a hot-plug that `player_power_poll()` later handles with its own `sdcard_init()`/`settings_mount()`, racing the wake path.
6. **"Unknown ID = same card".** After a swap where the new card's ID couldn't be read, the old library and resume state were applied to the new card: stale paths and errors that look like instability.

## 2.6.6 (beta) — 2026-11-06

2.6.5 plus a reworked sleep/wake power-up of the SD card, based on the V2 schematic and the TXS02612 datasheet (SCES682C). Fixes the music being lost after the player has slept for a while, which only a power cycle cured.

### What the schematic and datasheet show
- **One +3.3 V rail for everything.** It's nPM1300 BUCK2 (VOUT2) and feeds the SD card VDD, the TXS02612's VCCB0/VCCB1, the e-ink panel's VCI/VDDIO and its boost converter (L3/Q1), and the TXB0106's VCCB. Firmware switches it off in Stop 2. VCCA of both level shifters is +1.8 V (BUCK1), which never goes off.
- **TXS02612 start-up order** (datasheet "Power-up considerations": GND, then VCCA, SEL low for port B0, then VCCB0/VCCB1 after VCCA): **met** on every wake, since VCCA is always up and VCCB is the switched rail. SEL is strapped to GND (port B0 = the card) as required, and port B1 is unused with VCCB1 tied to +3.3 V. At cold boot both bucks start from the PMIC together; firmware now cycles the rail once at boot so VCCB always comes up after VCCA.
- **Why the card got stuck:**
  - With BUCK2 off, its output pull-down is off by default (`BUCKCTRL0`, reset 0x00), so the rail only decays through its loads.
  - The datasheet lets the TXS02612 source up to 12 µA *out of* its VCCB pins while VCCA is powered and VCCB is at 0 V (I_CCB = −12 µA).
  - So during a long sleep the rail can settle part-way up instead of at 0 V. The SD card then never gets a power-on reset (the SD spec wants VDD below 0.5 V for more than 1 ms), and doesn't answer on wake.
  - The e-ink panel survives the same thing because it has a hardware reset pin; the card doesn't.
  - A full power cycle also removes VCCA, which is why it always fixed it.
  - This is the most likely mechanism; a scope on the +3.3 V rail during sleep will confirm it.

### Changes
- **BUCK2 output pull-down on** (`BUCKCTRL0.BUCK2ENPULLDOWN`): the rail is actively discharged whenever it's switched off.
- **New rail timing.** The rail stays off for at least **100 ms** before being switched on again (only matters for retries and boot; sleep is always longer). Settle after switch-on is **10 ms** (was 3 ms), covering BUCK2's soft-start into ~35 µF and the card's inrush, before the HAL's own 1 ms + 74 clocks.
- **SD card before the panel on wake.** The card is started while the panel is still off, so the panel's boost converter isn't switching on the shared rail during the card's start-up, and a failed start can be followed by a **full rail power cycle** and another try (up to 3). The screen now appears after the card has started, typically 0.05–0.3 s later than before. A toast says when retries were needed ("SD card: 2 tries").
- **The paused track is kept if the card is late.**
  - "SD card not ready, retrying": the card is retried every second for up to 30 s.
  - The paused song, position and playlist are kept.
  - Play, skip and resume wait instead of discarding it.
  - Sleep is held off meanwhile.
  - If it gives up, it stops as before ("SD card not readable").
- **An unreadable card ID is no longer treated as a card swap.** Before, a failed ID read on either side of the sleep discarded the resume point; only a *different* ID does now.
- **Rail cycle at boot**, before the card and panel are touched. That gives the card a power-on reset after resets that don't remove power (watchdog, reboot chord, SD firmware update), and guarantees the TXS02612 order at cold boot.
- Image ≈ 425 KB of the 512 KB bank.

## 2.6.5 (beta) — 2026-11-06

2.6.4 plus Now Playing and status-bar changes. Charging, USB and audio are unchanged.

- **Volume indicator.** Pressing vol− or vol+ replaces the status-bar title with a speaker icon and a level bar (0–100). It uses a partial refresh of the status bar only, and disappears 3 s after the last button press of any kind, after which the title comes back. It works on every screen where the volume keys adjust volume.
- **Elapsed-time counter removed.** It changed on every progress redraw and left heavy ghosting. The track length stays, at the right of the bar, and only changes with the track.
- **Progress bar moved to the bottom.** It keeps its 12 px height and now sits 3 px from the bottom edge. It runs from the left edge (x = 4) up to the track length, using the space the elapsed time had: about 170 px instead of 124, so each pixel of progress is a shorter stretch of the song.
- **Even gaps.** The gap between the art frame, the song title and the top of the bar is now the same 3 px as between the status-bar rule and the top of the art.
  - The title is bottom-aligned above the bar.
  - At small text size, a title that doesn't fit on one line wraps at a space onto a second line, which then meets the art at exactly the same 3 px gap.
  - Short titles, and medium or large text size (one line, ".." if too long), leave the extra space above the title rather than between it and the bar.
- Image 434,608 bytes (≈ 424 KB of the 512 KB bank).

## 2.6.4 (beta) — 2026-11-04

2.6.3 plus the charging changes from 2.5.2 (stable), and the USB current limit is no longer rewritten every 2 seconds.

### USB input-current limit and VBUS polling
- **The input-current limit is written only when it can have changed:** on plug-in (PMIC interrupt), when the USB-C current advertisement changes, and on the first check after boot or sleep. 2.6.1–2.6.3 rewrote it on every 2 s check. That was a precaution against the USB-menu hang, which 2.6.2 traced to the register e-ink waveform instead.
- **VBUS is polled only while USB is plugged in.** The 2 s poll still catches removal and current-advertisement changes. With the cable out there is no polling at all; a plug-in is picked up by the nPM1300 interrupt on PC3, and a plug-in during sleep wakes the board and is checked straight away. Builds without the PC3 interrupt (`-DPC3_PMIC_IRQ=OFF`) still poll every 500 ms, since they have no other way to see a plug-in.

### Force charge and charger status (from 2.5.2)
- **Settings → Force charge: on** charges a battery with no thermistor:
  - Battery-temperature monitoring is turned off (`BCHGDISABLESET.DISABLENTC`, `ADCNTCRSEL = 0`).
  - Latched charger errors and the safety timer are cleared, and the charger is restarted.
  - Charge current is capped at **350 mA**: the Charge rate options stop there and the driver clamps anything higher.
  - Saved as `no_thermistor=1`. **Off** (default) leaves the charger as in 2.6.3.
- **Not covered with Force charge on:** charging is no longer stopped when the battery is too hot or too cold. Charge at room temperature. CC/CV to 4.20 V, the charger's die-temperature regulation and the pack's own protection circuit are unchanged.
- **Settings → Charger** shows the live state: "charging" (constant current), "topping up" (constant voltage, current tapering), "full", "trickle", "not charging", "no battery", "no USB", "too hot". Selecting the row refreshes it.

- Image 434,240 bytes (≈ 424 KB of the 512 KB bank).

## 2.6.3 (beta) — 2026-10-16

Based on 2.6.1, the version that fixed the USB-menu hang. 2.6.2 showed the register partial waveform was what broke it, so that code is now **removed** (it was only switched off in 2.6.1). Every e-ink update uses the panel's factory (OTP) waveforms again. On top of that, browsing menus should flash a lot less.

### Gentler menu refreshes (Settings → Menu refresh: **gentle**, the default)
- **Changing screen in a menu no longer does a full black/white flash.** The new screen is drawn with a quick refresh, then a second *reinforcing* pass drives every pixel once more towards its own colour: black pixels get pushed blacker, white ones whiter. That clears most of the ghost of the previous screen with no flash. Each screen change takes about 0.3–0.5 s longer.
- **When a full clean-up is due**, after the Anim speed budget of quick refreshes, menus use a **fast full refresh**. It's the panel's own hot-weather waveform (the controller is told it's 100 °C), which is shorter and has fewer black/white swings than the normal one.
  - The hot waveform under-drives a cold panel, so it only runs when the board is warm: the nPM1300 die reads at least 15 °C, or 30 °C while charging, since charging heats the chip. Otherwise the normal full refresh is used.
- Each reinforcing pass counts as two quick refreshes towards the budget. Anim speed still sets the budget: clean 8, normal 30, fast 120, so normal gives about 15 screen changes per full clean-up.
- **Now Playing is unchanged:** a normal full refresh on entry, on every track change (album art looks best that way) and when the budget runs out. Music is playing then, so the flash matters less.
- The contrast preview still uses a full refresh (fast when warm), so you see the real result.
- **Menu refresh: classic** gives the 2.6.1 behaviour: a normal full refresh on every screen change. Saved as `menu_refresh=` in the settings file.

### Other
- Removed: the register partial waveform (`EINK_REG_PARTIAL` build option, `eink_set_partial_frames`, the Anim-speed drive-length mapping). Anim speed is back to only setting the full-refresh budget.
- The USB input-current limit is still rewritten on every 2 s VBUS check (from 2.6.1).
- New: `npm1300_die_temp_c()` (one die-temperature ADC shot, read at most once a minute and only when a fast full is due).
- Image 433,256 bytes (≈ 423 KB of the 512 KB bank).

## 2.6.2 (beta) — 2026-10-16

2.6.1 fixed the USB-menu hang. This build puts the register partial waveform back but keeps the 2.6.1 USB charging-limit refresh, to prove which of the two caused the hang:
- **No hang:** the cause was the USB input-current limit (2.5.1 only set it on plug-in), and the partial waveform is cleared.
- **Hang returns:** the partial waveform is involved after all (2.6.1 stays the reference).

Changes from 2.6.1:
- **Register partial waveform back on**, as in 2.5.1/2.6.0. It holds unchanged pixels, and **Anim speed** again also sets the drive length (clean 15 / normal 12 / fast 10 frames) as well as the partials-per-full-refresh budget. `-DEINK_REG_PARTIAL=OFF` gives the 2.6.1 OTP behaviour.
- The USB input-current limit is still rewritten on every 2 s VBUS check (unchanged from 2.6.1).
- Image 432,976 bytes (≈ 423 KB of the 512 KB bank).

## 2.6.1 (beta) — 2026-10-16

Diagnostic build for the USB-menu hang in 2.5.1 and 2.6.0: choosing any option on the "USB connected" screen left the device unresponsive (a button press only shifted the display shade slightly). Every 2.6.0 feature is unchanged; only the two changes 2.5.1 introduced over 2.5.0 (stable) are backed out.

- **Register partial waveform removed.** Partial refreshes use the panel's built-in (OTP) waveform again, exactly as in 2.5.0. The code is compiled out (`-DEINK_REG_PARTIAL=ON` brings it back for testing). **Anim speed** keeps its 2.5.0 meaning: how many partial refreshes run before a full refresh. It no longer shortens the drive.
- **USB input-current limit is rewritten on every 2 s VBUS check again** (2.3.1–2.5.0 behaviour). 2.5.1 wrote it only on plug-in, to chase the suspected 2-second DAC crackle, which has since turned out not to be periodic. With no battery fitted the board runs entirely from VBUS. If the nPM1300 falls back to its ~100 mA start-up limit, it starves the board the moment USB storage or the DAC starts drawing current. That would explain the weak display updates too.
- Image 432,560 bytes (≈ 422 KB of the 512 KB bank), slightly smaller than 2.6.0.

## 2.6.0 (beta) — 2026-10-16

New features on top of 2.5.1 (test). Everything here builds cleanly and the DSP, library and UI code is host-tested, but none of it has run on the board yet.

**First install needs SWD.** USB DFU never worked on this board, so flash `eink_mp3_v2.6.0_beta.hex` with ST-Link once. After that, updates go through the SD card.

### Firmware update and rollback from the SD card
- Put a `.bin` in `/Firmware/`, then go to **Settings → Firmware → Install …**.
- The image is written to the *other* 512 KB flash bank and CRC-verified. Its vector table is written last, then the chip swaps banks (`SWAP_BANK`) and restarts.
- The running firmware is never touched, so an interrupted update changes nothing.
- **Automatic rollback:** a new firmware stays on trial until it has run for 20 s. Three restarts before that switch back to the previous bank.
- **Manual rollback:** **Previous: X.Y.Z** in the same menu, or install an older `.bin`.
- The firmware carries an ident block (version and channel), so the menu can show versions of the other bank and of files.
- The USB DFU menu entry and the play+vol−+vol+ DFU chord are removed (the chord is now a plain reboot).
- The linker script caps the image at 512 KB. 2.6.0 is 422 KB.

### Music library: Music / Artists / Albums
- Main menu: playlists, **Shuffle all**, **Music** (every song A–Z, replaces "Play all"), **Artists**, **Albums**, Settings.
- Playlists, artists and albums open as **Shuffle**, **Play**, a bold line, then the songs (an artist lists its albums).
- Choosing a song plays the list from there; back (play double-press or SW3 long) goes up one level, and Now Playing returns to the list it came from.
- The index is built in the background from the tags into `/.eplayer/`, with a progress screen; music keeps playing and the player won't sleep mid-build.
- It is rebuilt only when the file list changes; **Settings → Rebuild library** forces it.
- Artists use the album artist if tagged; "The" is ignored when sorting; case variants merge.
- Track and disc numbers order the albums.
- Playlist entries show the song title from the library (Windows-style paths match too).
- Limits: 4096 songs, 1024 artists, 1536 albums.
- Tags now also read album artist (TPE2 / ALBUMARTIST / aART) and track and disc numbers (TRCK/TPOS, TRACKNUMBER/DISCNUMBER, trkn/disk).

### Gapless playback (Settings → Gapless, default on)
- When a track ends, the next opens immediately and its audio follows in the same ring buffer, with no drain or flush.
- If the sample rate changes, the old tail plays out and the DAC restarts for the new rate.
- MP3: LAME delay/padding trimmed (dr_mp3).
- M4A: priming/padding trimmed from iTunSMPB or the edit list; seeks are sample-accurate.
- Cover art for the next track decodes while the audio pump keeps running (tags idle hook).
- M4A reports its real output rate from the first decoded frame (HE-AAC doubles the stored rate).

### 10-band EQ (Settings → EQ)
- Bands 31 Hz to 16 kHz, ±12 dB.
- Presets: Off, Bass, Warm, Bright, Vocal, Loudness, Custom. Editing any band creates Custom.
- Implementation: fixed-point RBJ peaking biquads, Q29 coefficients, 64-bit multiply-accumulate, noise-shaped requantisation.
- Measured arithmetic noise: −134 dBFS against a double-precision reference.
- Automatic pre-amp, computed from the real response, so boosts can't clip.
- Bit-perfect when Off. Also applies to USB-DAC audio.
- Bypassed above 96 kHz: all ten bands would need ~90% of the CPU at 192 kHz. They need ~21% at 44.1/48 kHz and ~46% at 96 kHz.
- EQ screen controls: next/prev = band, vol = gain, play = preset, back = exit.

### Highest-quality audio path
- **48 kHz family played natively:** the CS43131 PLL makes 24.576 MHz from the crystal (settings from the Linux cs43130 driver).
- Bit-perfect at 32, 44.1, 48, 88.2, 96, 176.4 and 192 kHz: no resampling for 48 k files, Opus or the USB DAC. The PLL runs only while a 48 k-family stream plays.
- If the PLL doesn't lock, 48 k-family streams fall back to sample-rate conversion onto the 44.1 k family.
- New resampler, only for odd rates (8–24 kHz) and that fallback: 64-tap Kaiser-windowed sinc, float, about −95 dB error and −92 dB aliasing.
- 352.8/384 kHz PCM goes through a dedicated 79-tap half-band decimator: −139 dB error, −126 dB stopband.
- MP3 now decodes in float (more than 16 bits of resolution).
- USB DAC offers 44.1/48/88.2/96 kHz (the full-speed limit), all native. The receive buffer is doubled. The USB-DAC screen shows the rate and whether the path is bit-perfect.

### Fuel gauge (Settings → Battery %, default off)
- Coulomb counting with the nPM1300's battery-current ADC (scaling per Nordic's Zephyr driver), sampled once a second while awake.
- Corrected to the open-circuit voltage at start and after ≥1 h of rest, set to 100% at charge complete, capped at 3% below 3.35 V.
- Sleep drain is timed with the RTC. The estimate survives resets (RTC backup register).
- With it on, the percentage appears next to the battery icon. Off by default because it costs a little power.
- `batt_mah` in `settings.txt` sets the capacity (default 700, NP-BJ1).

### Text size (Settings → Text size)
- **Small** (the 2.5 size, 6 rows), **Medium** (5 rows) and **Large** (4 rows).
- Applies to lists, settings and the Now Playing title.
- New 17 px and 21 px DejaVu Sans Condensed fonts.

### Other
- Settings row "Shuffle lists" removed (playlists now offer Shuffle and Play directly). "Firmware update (USB)" is replaced by **Firmware**.
- The main menu title is "e.player".
- Secondary text is drawn solid instead of dot-dithered gray, which was unreadable on the B/W panel.
- Includes 2.5.1: register-loaded partial waveform, and no more 2 s USB input-limit rewrite.

## 2.5.1 (test) — 2026-10-16

Test build on top of 2.5.0 (stable). The splash reads `v2.5.1 test`. If either change misbehaves, go back to `eink_mp3_v2.5.0_stable.hex`.

E-ink: register-loaded partial waveform (ideas from InkBoy)
- Partial refreshes no longer use the panel's factory (OTP) partial waveform. They use the Waveshare 1.54" V2 partial table (`WF_PARTIAL_1IN54_0`, as packaged in InkBoy, MIT licence), loaded into the controller's volatile LUT registers with command 0x32. The OTP programming command 0x30 is never used.
- **Unchanged pixels are held.** Black→black and white→white pixels get no drive; the stock table gives them an extra pulse on every update. Static parts of the screen should stop building up after many partials, so full refreshes are needed less often.
- **Shorter main drive, set by "Anim speed":**

  | Anim speed | Drive frames | Partials before a full clean |
  |---|---|---|
  | clean | 15 (stock length) | 8 |
  | normal (default) | 12 | 30 |
  | fast | 10 | 120 |

  Fewer frames make menu steps faster but can leave edges slightly lighter. If text looks washed out after a partial, use "clean".
- The table is resent after every full refresh, panel reset or contrast change. Partials run with update control `0xCC`: boosters on, no OTP reload. The boosters still switch off 1.5 s after the last partial.
- Fallback: build with `-DEINK_REG_PARTIAL=OFF` to get the 2.5.0 OTP partial back.

USB input limit (USB-DAC crackle suspect #1)
- The nPM1300 input-current limit (`VBUSINILIM0` + `TASKUPDATEILIM`) is no longer rewritten on every 2 s VBUS safety poll. It is applied only on:
  - a plug-in or PMIC interrupt,
  - a change in the USB-C current advertisement,
  - the first check after boot or sleep.

  A quick unplug/replug still raises the PMIC's VBUS-detected event, so the 2.3.1 fix (limit stuck at the 100 mA start-up value) still holds. Builds without the PC3 interrupt read that event on each poll.

## 2.5.0 (stable) — 2026-10-15

First stable release. The reboots seen through 2.3–2.4 were a hardware fault: a 3 Ω resistor had been fitted where SW2's 47 kΩ pull-up belongs. With that fixed the board runs normally on USB and on battery, so the diagnostic options added while hunting it are removed.

**Tested on hardware: MP3 and AAC (M4A).** FLAC, WAV, Opus and DSD/DoP are built in but untested.

Removed (diagnostics):
- Settings rows **Grayscale** and **Last reset**, and the Diagnostics screen.
- Splash reset lines (Reset / during / boot # / CSR / PMIC / CFSR). The splash shows `e.player` and `v2.5.0 stable`.
- `settings.txt` keys `codec_hp`, `grayscale`, `full_refresh`, `panel_sleep`. Old values are ignored and dropped on the next save. The headphone amp always powers up, cleaning full refreshes always happen, and the panel controller always deep-sleeps after 15 s idle.
- The register-loaded 4-gray e-ink LUT. The display is black and white with dithering: UI grays are 2×2 dot patterns and album art is 1-bit Floyd-Steinberg. Every refresh uses the panel's factory waveforms.
- The nPM1300 reset-cause read at boot.
- `/crashlog.txt` is written only after an abnormal restart (fault, init error, brownout, reset pin, watchdog), not on every boot. It still rotates at 32 KB.

Kept:
- MCU rail (BUCK1) at **1.9 V**, which gives more margin above the ~1.7 V brownout level. All 1.8 V parts are rated for it.
- USB input limit raised to 500 mA first thing at boot.
- Fault handlers that log and reset instead of hanging.

Menu responsiveness (ideas adapted from InkBoy):
- **No more queued auto-repeats.** A held key keeps at most one repeat waiting. Repeats left over after the key is released are dropped. Before, a held up/down key queued a step every 150 ms while the panel was busy (~0.4 s per refresh). They all ran afterwards, so the cursor lagged, jumped, and kept scrolling after the key was released.
- **Panel boosters stay on between partial refreshes.** Update control `0xFC` replaces `0xFF`, and the boosters switch off with `0x83` 1.5 s after the last partial. They are always switched off before deep sleep or rail power-down. Each menu step skips the booster power-up and power-down.
- **Lists scroll a page at a time.** Only one step in six redraws every row. The others just move the highlight, which means less ghosting and fewer cleaning full refreshes.

## 2.4.5 — 2026-10-15 · Fix 2.4.4 boot loop (BusFault in crash-log write)

2.4.4 stuck on the splash with `BusFault @080221E6`. That address is inside FatFs `f_printf()`, called from the crash-log writer that runs on every boot. Each fault reset, the next boot tried to log it, faulted again, and so on. The log was never closed, so nothing reached `/crashlog.txt`.

- FatFs `f_printf()` is no longer used. The crash-log line and `settings.txt` are each formatted with `snprintf` into a static buffer and written with one `f_write`. The `FIL` objects are static too, off the stack.
- Loop breaker: a new breadcrumb `crash-log write` marks the SD log write. If the previous run died there, the next boot skips the log instead of looping.
- `/crashlog.txt` rotates to `/crashlog.old` above 32 KB.
- The fault record now also keeps the faulting SP and stacked r0–r3/r12, and the log prints them.
- After a fault, the splash shows `CFSR xxxxxxxx  A xxxxxxxx` (fault status and fault address).
- Splash PMIC line: replaced the `strncat` build, which could overrun its 48-byte buffer when five or more reset-cause bits were set.
- A PMIC RSTCAUSE byte with bit 7 set is treated as a bad read and ignored.

## 2.4.4 — 2026-10-15 · Log the nPM1300's own reset cause

2.4.3 logs showed every reboot after leaving the USB menu as `Power on`, CSR 0C, boot #1: the MCU lost all RAM, so the 1.8 V rail went to ~0 V (rails switched off), not a brownout dip.
- At boot (before the PMIC is configured) the firmware reads the nPM1300 ERRLOG: `RSTCAUSE` (0x0E03) and `CHARGERERRREASON` (0x0E04), then clears the log (`TASKCLRERRLOG`, 0x0E00) so each boot shows only new events.
- Splash: `PMIC xx` plus a decoded line (ship exit / boot monitor / watchdog / SHPHLD long press / THERMAL / VSYS LOW / software reset). `/crashlog.txt`: `pmic_rst=` and `pmic_chgerr=`.

## 2.4.3 — 2026-10-14 · Diagnostic build for the "reboot after SW1 release" problem

Observed: holding SW1 does nothing; releasing it on any screen (USB prompt, main menu) reboots, with no crash record. SW2/SW3 (partial refreshes) and SW1-long (no full refresh) don't reboot. Every SW1-short action changes screen, i.e. triggers a full e-ink refresh, usually after the panel controller has gone into its 15 s idle deep sleep.
- **Every boot is logged and shown:** the splash always shows `Reset: <cause>`, `during: <step>` and `boot #n CSR xx`; `/crashlog.txt` gets one line per boot (including plain power-ons). CSR byte: 0C = power-on/brownout (BOR+PIN), 14 = software reset (SFT+PIN), 04 = reset pin only.
- **Finer breadcrumbs:** `panel re-init` (HW reset after deep sleep), `full waveform`, `partial waveform`.
- **Two test switches in `settings.txt`:** `full_refresh=0` (screen changes use partial refreshes only) and `panel_sleep=0` (no 15 s controller deep sleep, so no re-init before the next refresh). Both default to 1 (normal behaviour).

## 2.4.2 — 2026-10-14 · Grayscale off by default (fixes reboot when opening any menu)

- **Symptom:** after the splash and USB-prompt screens (pure black/white), choosing anything (a USB mode, Shuffle all, Play all, Settings) rebooted the player, with a visible dark/light flashing first and no crash log (a full power-on reset).
- **Cause:** every screen that rebooted contains gray (list separators, scrollbar, album art). Gray frames made the e-ink driver load its own register 4-gray waveform (`k_lut_4g`, marked "MUST be tuned on the actual panel" and never tuned) instead of the panel's built-in B/W waveform. Driving the panel with it took the supply down.
- **Fix:** new **Settings → Grayscale**, default **off**. With it off, light/dark gray are drawn as 25 % / 75 % dot patterns, album art is error-diffused straight to black/white, the gray plane stays empty, and every full refresh uses the panel's OTP B/W waveform, the same one the splash and USB prompt already used without trouble. `grayscale=1` in `settings.txt` (or the menu) brings 4-gray back for testing a tuned LUT.

## 2.4.1 — 2026-10-14 · Fix for the boot HardFault during the splash refresh

The crash logs from 2.3.0–2.4.0 were identical every time: `HardFault @00930010`, `lr=FFFFFFA8` (an EXC_RETURN value: the CPU was *entering an interrupt*), `cfsr=00000100` (instruction bus error), step "full refresh", ~817 ms after power-up. The vector table is correct and 0x00930010 appears nowhere in flash, so the CPU read a corrupted interrupt vector from flash, at the e-ink full refresh's current peak.
- **Flash stays powered in Sleep (WFI).** `power_early_init` used to set FLASH SLEEP_PD, so every interrupt woke the flash array and fetched its vector from it straight away, the most fragile read there is while the rails are sagging. Stop 2 still powers the flash down as before.
- **No WFI while the e-ink panel is busy.** The CPU stays awake through the refresh (the decode/USB idle hook keeps running), so there are no sleep/wake transitions during the board's biggest load event.
- **Instruction cache enabled** (8 KB). Most code and vector fetches now come from the cache, which is faster and puts far less load on the flash.
- **Crash log names the interrupt:** `exc=` (exception number being entered: 15 = SysTick, 16+n = IRQ n), `xpsr=` and `excret=` are added to `/crashlog.txt`, and "exc" to Settings → Last reset.

## 2.4.0 — 2026-10-14 · 1.9 V MCU rail, gentler headphone-amp start

- **BUCK1 (MCU 1.8 V rail) raised to 1.9 V at boot** in software (`BUCK1NORMVOUT` = 9, then `BUCKSWCTRLSEL` bit 0), right after the USB input limit. That gives 200 mV of margin above the STM32's BOR level (~1.7 V) instead of 100 mV. Not 2.0 V: the CS43131's 1.8 V supplies (VD/VL/VA/VCP) are specified up to 1.94 V and the nPM1300 steps in 100 mV. Settings → Last reset shows "MCU rail 1.9V" when the PMIC confirmed it.
- **Headphone amp soft start.** The serial port comes up first, the volume is forced to mute, then the HP stage (class-H charge pump + driver) is powered in the pop-free window with extra settle time, and the volume soft-ramps back up afterwards.
- **No amp restart between tracks.** When the next track has the same format (PCM rate / DSD speed) the running output is reused and only the buffer is flushed. 2.3 powered the HP stage down and up again (a fresh charge-pump inrush) on every track change and every auto-advance.
- **USB DAC powers the amp only when the computer starts streaming**, not at plug-in.
- **Diagnostic switch** `codec_hp=0` in `settings.txt`: everything runs (clocks, serial port, decoding, UI) but the headphone amp is never powered, so playback is silent. If the brownouts stop with it, the HP stage is the cause.

## 2.3.1 — 2026-10-13 · USB input limit raised at power-up

- **500 mA USB input limit is now the first thing set at boot** (`npm1300_init`), before the splash refresh, codec, SD and USB start. The nPM1300 starts with a low (~100 mA) input limit; with no battery fitted that starved VSYS during those load steps and the MCU's 1.8 V rail browned out (measured on hardware). 2.2/2.3.0 only raised it after the first USB poll.
- **The limit is re-asserted on every VBUS check** (~2 s, and at once on a PMIC plug interrupt) instead of only when the value changed, so an unplug/replug that the poll misses can't leave the PMIC on its start-up limit.
- No other behaviour changes. Image ≈ 368 KB.

## 2.3.0 — 2026-10-13 · Hardware-test fixes, reset diagnostics, state-machine review fixes

### From the first hardware test (USB power, no battery)
- **Battery icon shows a cross when no battery is fitted.** Detection uses the nPM1300 charger's `BATTERYDETECTED` flag plus the battery-pin voltage from the nPM1300's internal ADC (valid only between 2.5 and 4.5 V). The STM32's own ADC can't see the cell (its VBAT pin is on the 1.8 V rail). Two readings in a row are needed to change the icon.
- **USB question at power-up is now the first screen.** VBUS is read on the first superloop lap. In 2.2 the menu appeared first and the prompt popped up ~2 s later from the slow safety poll, which looked like the player switching modes on its own.
- **USB mode no longer re-triggers on a glitch.** A failed nPM1300 read used to count as "cable removed", tearing the mode down and asking again a moment later. Failed reads are now ignored, and a removal must be seen twice, 300 ms apart.
- **Restarts are now explained.** New `Core/Src/diag.c`. Fault handlers save PC, LR, CFSR, HFSR and the fault address in `.noinit` RAM, plus a "step" breadcrumb (what the firmware was doing). On the next boot the splash shows *Last reset: … / during: …*, **Settings → Last reset** shows the details, and `/crashlog.txt` gets one line. A reset with the BOR flag but intact RAM is reported as **Brownout (1.8 V dip)**, which separates supply problems from firmware bugs. The rebooting when choosing a USB mode or Shuffle all didn't trace to any single code path (charge-only does almost nothing in software), so this report is what will pin it down.
- **MCU rail hardening.** BUCK1 (1.8 V) is put in forced-PWM mode while awake (lower ripple, faster load-step response; BOR sits only ~100 mV under the rail) and back to auto before sleep.
- **E-ink partials after a gray screen.** After a 4-gray full refresh the controller is now hardware re-initialised and both RAMs re-seeded before the next partial. In 2.2 the register LUT stayed loaded and only one RAM was re-seeded, so moving the cursor on the main menu (which has gray separators) could leave the screen unchanged. The same full re-seed now follows every panel deep-sleep wake (a battery tick after 15 s idle could disturb the rest of the screen).
- **Stuck or floating keys can't reset-loop the player.** The vol−+vol+ reboot chord only arms after both keys have been released once since power-up, and a key held at power-up is ignored until released (and no longer blocks sleep).

### State-machine review fixes (F1–F21 in the state map)
- **F1 audio dropouts during screen refreshes.** The decoder and USB stack run from inside the e-ink BUSY wait (`eink_set_idle_hook`), so a 0.3–4 s refresh no longer drains the 186 ms ring.
- **F2 stuck "playing" with no audio.** End of stream with no next track now stops; starting a new playlist stops the old track first; PLAYING with no output, or an output that stops consuming for 1.5 s (no I²S clock / dead codec), stops with "Audio output error". Codec start functions now report I²C and crystal failures.
- **F3 USB modes on chargers.** Storage/DAC fall back to charge-only if no computer enumerates within 6 s; ejecting the drive on the computer hands the card back to the player.
- **F4 local playback during USB DAC/storage.** A "USB storage"/"USB DAC" screen replaces the menus; play, resume and firmware update are refused while USB owns the card or audio.
- **F5 stale Now Playing.** The UI now polls player/mount/USB change counters: a new track redraws title and cover, the end of a list or a removed card returns to the menu, a failed play stays on the menu with a message.
- **F6 lost wake events.** Flags are cleared at the start of sleep entry; a key press, headphone plug or USB plug during the ~2 s entry wakes the player straight back.
- **F7 SW3 double press removed.** Up/prev act immediately; two quick ups no longer mean "back". SW3 long = back on Now Playing, adjust, firmware-update and diagnostics screens. SW1 double window 350 → 300 ms.
- **F8 shuffle.** Menu launches no longer overwrite the Settings value (now "Shuffle lists", the default for playlists); the shuffle flag is saved with the resume point (`last_shuffle`); the status icon shows the actual order.
- **F9** Repeat-one applies only at the end of a track (Next skips); Prev on the first track wraps under repeat-all.
- **F10** Position subtracts the audio still in the buffer (pause/sleep no longer skip ahead); finishing a list resets the resume point to the start.
- **F11** Raw `.aac` (ADTS) uses the real sample rate (48 kHz files played ~9 % slow); ADTS and Opus can now seek (resume after sleep, Prev restart).
- **F12** Mounting a card (boot, insert, after USB storage) re-reads `settings.txt`, re-lists playlists and marks Play all stale; a card swapped during sleep is detected by its CID.
- **F13** Card-detect never mounts FatFs while USB storage owns the card.
- **F14** see e-ink fix above.
- **F15** New track = full refresh (cover keeps its grays); play/pause only refreshes the status bar.
- **F16** No events while two or more keys are held; chords save settings before resetting (the SysTick handler still resets if the main loop is hung); SW1 long is ignored on the USB and firmware-update screens.
- **F17** Firmware update is refused during USB storage; reboot chords disconnect USB cleanly first.
- **F18** Playlist list ignores hidden files and non-playlist extensions; Play all index rebuilt once per mount.
- **F19** Boot error ("No SD card", "Audio codec error") is a real screen; inserting a card moves on to the menu.
- **F20** Codec wake and start failures propagate.
- **F21** Paused for 30 s: DAC, headphone amp and SAI switch off (track stays open).

### Docs / comments
- Fixed: power.c header (BUCK2 is switched over I²C in the default build), usb_app.h ("any USB power", not "a host"), settings write timing (5 s after the first unsaved change), player.c pump description, eink.h partial-refresh rule, power_sleep_now comment, unused `SCR_MENU_PLAYLISTS` removed, SW1-double behaviour on the main menu.

### Files
- New: `Core/Inc/diag.h`, `Core/Src/diag.c`.
- Changed: `Core/Src/main.c`, `stm32u5xx_it.c`, `drivers/buttons.*`, `eink.*`, `gfx.*`, `npm1300.*`, `cs43131.*`, `sdcard.*`, `audio/audio_pipeline.*`, `decoder.c`, `ogg_min.*`, `app/player.*`, `ui.*`, `usb_app.*`, `power.*`, `settings.*`, `playlist.*`, `CMakeLists.txt` (`FW_VERSION`), docs.
- Image: ≈ 368 KB flash (+8.6 KB), RAM unchanged apart from 64 bytes of `.noinit`.

## 2.2.0 — 2026-10-12 · Firmware updates over USB

**Tooling (same firmware):**
- `BUILDING.md`: a step-by-step guide to building and flashing.
- `release\`: pre-built `.hex`/`.bin`/`.elf` files with SHA-256 sums.
- `CMakePresets.json`: `release` and `release-pc3-rail` presets.
- `tools\vscode\` (copy to `.vscode\`; `build_windows.ps1` does this on first run):
  - recommended extensions;
  - tasks for build, flash via ST-LINK (CubeProgrammer), flash via USB DFU, and flash via nanoDAP or clone ST-LINK (OpenOCD);
  - Cortex-Debug launch configurations.
- `tools\openocd-*.cfg`: SWD at 400 kHz, software reset.
- `cmake/arm-none-eabi.cmake` now finds the compiler in STM32CubeCLT, CubeIDE, Arm's installer or PlatformIO without PATH edits. Override with `ARM_TOOLCHAIN_DIR`.


- **New: Settings → Firmware update (USB).** Confirming with play does four things:
  - stops playback and saves settings;
  - draws on-screen instructions, which the e-ink keeps;
  - restarts into ST's ROM **USB DFU** bootloader;
  - leaves STM32CubeProgrammer (port USB) or `STM32_Programmer_CLI -c port=USB1` to program the board.

  No BOOT0 button or debug probe is needed after the first SWD flash.
- **Recovery chord:** hold play + vol− + vol+ for 5 s to enter the same mode when the UI can't be navigated. Vol− + vol+ alone still reboots.
- **Implementation** (`Core/Src/dfu_entry.c`):
  - The request survives the reset as a magic word in a new `.noinit` RAM section.
  - `main()` checks it before `HAL_Init()` and jumps to system memory (0x0BF90000) from a clean reset state.
  - VDDUSB is validated first (and, in the pin-control variant, the 3.3 V enable on PC3 is driven high again).
- **Docs:** `BRINGUP.md` section 5 covers USB updating and expected upload times.

## 2.1.0 — 2026-10-07 · Instant USB wake, longer sleep timeouts, NP-BJ1 charging

### Power input wakes instantly (no more 1 s polling)
- The PC3 ↔ nPM1300 GPIO0 wire now carries the **PMIC's interrupt** by default. GPIO0 is set to GPOIRQ (push-pull, active high) and the VBUS-detected and VBUS-removed events are enabled. PC3 is an EXTI3 rising-edge input.
- Plugging in USB raises PC3 and wakes the MCU straight out of Stop 2. The MCU then turns the 3.3 V rail on over I²C (`BUCK2ENASET`), so the rail-on path is the same for buttons, headphones and USB.
- The RTC wake-up timer and the 1 s polling are gone from this mode.
- While the player is asleep, the VBUS-removed interrupt is masked so unplugging doesn't wake it. It is re-enabled on wake.
- While awake, USB plug and unplug are also interrupt-driven. The old 2 Hz I²C polling is now a 2 s safety net.
- Why both chips can't drive the line: one wire can't be both the BUCK2 enable *input* and the interrupt *output*, and both chips driving it push-pull would fight. The previous behaviour is kept as a build option, `-DPC3_PMIC_IRQ=OFF` (PC3 drives the rail enable). That option now polls VBUS every **250 ms** (`PWR_VBUS_POLL_MS`) instead of every 1 s.
- Boot order is safe either way. The MCU never drives PC3 in IRQ mode, and BUCK2 is enabled in software *before* pin control is released, in case an earlier firmware left the PMIC in pin-control mode.

### Sleep timeouts
- Options are now **2 min / 5 min / 10 min (default) / 30 min / 1 hour / never**. The old options were 30 s to 10 min.
- Confirmed and documented: the player never sleeps while music plays. Only paused or stopped idle time counts.

### Charging for the Sony NP-BJ1
- Default charge current is **350 mA (0.5C for the 700 mAh cell)**, up from 300 mA. Termination stays at 4.2 V.
- New **Settings → Charge rate** (100 / 200 / 350 / 500 / 650 / 800 mA). It is saved as `charge_ma` in `settings.txt`, where any value from 32 to 800 is accepted. It is for fitting a different battery and is applied immediately; the charger is paused while ISET changes.
- The USB input-current limit is no longer 1.5 A. It is now charge current + 150 mA, rounded up and at least 500 mA, and it only goes above 500 mA when the charge rate needs it *and* the source advertises 1.5 A or 3 A. With the NP-BJ1 default it is 500 mA everywhere.

### Files
- `Core/Inc/board.h`: PC3 role option, NP-BJ1 constants.
- `drivers/npm1300.*`: I²C BUCK2 control, VBUS interrupt, charge-current setter, battery-sized input limit.
- `app/power.*`: IRQ or poll wake, new timeout table.
- `Core/Src/stm32u5xx_it.c`: `EXTI3_IRQHandler`.
- `app/usb_app.c`: interrupt-driven VBUS.
- `app/settings.*`, `app/ui.c`: Charge rate setting.
- `Core/Src/main.c`, `CMakeLists.txt`: `PC3_PMIC_IRQ` option.
- `README.md`.

## 2.0.0 — 2026-10-07 · Schematic V2 port, sleep/wake, build fixes

Target hardware: **Schematic1 V2** (MP3 mainboard V2, 2026-10-06).
Build: arm-none-eabi-gcc 13.2, zero warnings in project code. Image: 359 KB flash (34 %) and 591 KB RAM (75 %, including the 160 KB heap and 48 KB stack).

### Hardware V2 port (`Core/Inc/board.h` and drivers)

| Signal | V1 firmware | V2 schematic | Change |
|---|---|---|---|
| CS43131 INT | PB1 / EXTI1 | **PB10 / EXTI10** | IRQ handler and pin config moved |
| 3.3 V rail enable | PB10 drove the SD LDO_EN | **PC3 → nPM1300 GPIO0 → BUCK2 enable** | New `PWR_3V3_EN`. It is driven high before the PMIC is configured. |
| SD card power | separate TPS7A20 LDO | the switched +3.3 V rail | LDO control removed; SD pins parked in analog mode before the rail drops |
| E-ink level shifter OE | assumed tied high | **PA3** (330k pull-down) | Driven by the e-ink driver; low in sleep |
| Native DSD port (PB3/PB5/PC3) | used | **not connected** (PB3 = SWO, PC3 = rail enable) | DSD now goes as DoP over I²S. The V1 code would have toggled the 3.3 V rail on every DSD bit. |
| 32 kHz LSE | started at boot | **not fitted** (PC14/15 NC) | RTC moved to LSI. V1 would have hung or reset-looped in `HAL_RCC_OscConfig`. |
| Button / CD pull-ups | internal | external 47k / 330k | Internal pull-ups off (saves ~45 µA with a card inserted) |
| Unconnected pins | floating | PA15, PB1/2/4–7/14/15, PC1/6/7/13–15, PH0/1 | Parked in analog mode at boot |

### New: power management (`app/power.c`)

- The player stays on while music plays, and while USB storage or the USB DAC is active.
- There is a user setting **Settings → Sleep after** (30 s / 1 min / 2 min default / 5 min / 10 min / never), stored as `sleep_timeout` in `settings.txt`.
- On timeout the player:
  1. saves the resume state;
  2. turns the screen **completely white** (also in dark mode);
  3. puts the panel into deep sleep and drops OE;
  4. unmounts the SD card;
  5. powers down the codec headphone amp, crystal and CLKOUT;
  6. turns off VDDUSB;
  7. switches the **3.3 V rail off via PC3**;
  8. enters **Stop 2** with SRAM retained.
- Wake sources:
  - **button press** (EXTI);
  - **power input** — VBUS plug-in, polled once a second by an RTC wake-up because the PMIC has no IRQ line to the MCU;
  - **headphone plug-in** (CS43131 INT). Unplugging while asleep is masked and does not wake the player.
- On wake, the rail comes back, the panel is re-initialised with its "previous image" RAM seeded white, and the previous screen is drawn with a **partial refresh**. The screen is restored before the SD card and codec, so it appears in about 0.3 s.
- **The press that woke the device is swallowed.** Play pressed while asleep only shows the paused song at its saved position. A second press starts playback: the decoder is re-opened and seeked, and the DAC is powered up only at that point.
- Pausing with no output running is a new player state. `player_prepare_sleep()` and `player_after_wake()` close and re-open the FatFs handles around the SD power cycle. Tags and album art are not re-read because they are still in RAM.
- Playlist, settings and USB modules gained matching suspend/resume hooks. A "charge only" choice survives a button wake, and a real re-plug while asleep asks again.

### Dependencies and build (the V1 tree could not compile)

- **`third_party/fetch.sh` was rewritten:**
  - STM32CubeU5's HAL and CMSIS-device are git submodules, which V1 never initialised. Only those two are fetched now; a full recursive clone is about 2 GB.
  - FatFs now comes from ST's GitHub mirror of R0.15. elm-chan.org is blocked on many networks, and V1 ignored the failure.
  - `ffconf.h` is patched automatically: LFN, UTF-8, exFAT, string functions, 1 volume.
  - dr_libs, minimp4 and picojpeg are pinned to commits instead of `master`.
  - Helix AAC is copied with its utility headers, and its Cortex-M inline-asm path (SMULL/SMLAL/SSAT) is enabled.
  - libopus and TinyUSB source lists were fixed. TinyUSB 0.17 needs `dwc2_common.c`.
  - Re-running the script is safe.
- `ld/STM32U575xG.ld`:
  - V1 discarded all of libc, libm and libgcc, so the image could not link. That is removed.
  - Added `.init_array`/`.fini_array` and heap symbols.
  - Heap raised to 160 KB (dr_flac, Helix and minimp4 allocate). Stack raised to 48 KB (libopus VLAs).
- New `Core/Src/syscalls.c`: a bounded `_sbrk` (malloc returns NULL instead of overrunning the stack) and newlib stubs.
- `CMakeLists.txt`:
  - checks that `fetch.sh` has been run;
  - adds `power.c` and `syscalls.c`;
  - adds the missing HAL modules (exti, flash);
  - sets the libopus defines (`VAR_ARRAYS`, `HAVE_LRINT`);
  - builds the decode hot paths at `-O2`;
  - builds HAL/third-party with their own warning settings;
  - outputs `.elf` as the README says.
- API updates in `audio/decoder.c`:
  - dr_libs 0.7 (`drmp3_init`, `drflac_open` and `drwav_init` gained tell callbacks; seek-origin names changed);
  - minimp4 (`MINIMP4_IMPLEMENTATION`; DSI read from the track struct, `MP4D_read_dsi` doesn't exist);
  - picojpeg (`pjpeg_decode_init` signature, MCU position computed);
  - TinyUSB 0.17 (UAC2 descriptor macro is example-only, so it is vendored in `app/usb_descriptors.h`; IRQ entry is `dcd_int_handler`);
  - newlib-nano has no `memmem`.
- `system_clock.c`: U5 kernel-clock names fixed (`RCC_PERIPHCLK_ICLK`/`RCC_ICLK_CLKSOURCE_HSI48` for USB; there is no `RCC_PERIPHCLK_USB`). Added `PLLMBOOST`, LSI for the RTC, and wake from Stop on HSI16.
- New `tools/build_windows.ps1`. It finds or installs (winget) the Arm GNU toolchain, CMake, Ninja and Git, reusing PlatformIO, STM32CubeCLT or STM32CubeIDE copies if present. It then runs `fetch.sh` and builds.

### Bug fixes

- **SAI DMA ran once and stopped.** GPDMA in `DMA_NORMAL` mode does not loop, so audio would have played about 46 ms and then gone silent. It now uses a circular linked-list queue, the CubeMX pattern that the U5 SAI HAL recognises.
- **Settings were often never saved.** `settings_save()` skipped the write inside its 5 s throttle and never retried, so the last volume change or resume point before power-off was lost. Saves are now deferred and flushed by `settings_poll()`, and forced before sleep and before USB-storage hand-off.
- **E-ink partial refresh could show nothing.** After a panel deep-sleep or a 4-grey full refresh, the controller's "old image" RAM was re-seeded from the framebuffer, which already held the *new* frame. The next partial then diffed the frame against itself. The driver now tracks what is physically on the glass (`s_shown`).
- E-ink border waveform was frozen by the first partial and never restored; full refreshes now reset it.
- **Shuffle resume pointed at the wrong song.** Play used a time-based seed while resume used a fixed one. The seed is now stored in `settings.txt` with the resume point.
- **Ring overflow with low-rate sources.** 8/16/24 kHz Opus/AAC upsampled by up to 5.5× could overrun the PCM ring (the "≥ 700 frames free" check assumed 32 kHz). The decoder now asks the pipeline how many *input* frames fit (`pipe_max_input_frames()`), and the resampler output is bounded by free space.
- **Opus never opened.** The fixed-point decoder state is 26,580 B (measured), larger than the 26,500 B buffer. The buffer is now 28 KB.
- **Charging was capped at 100 mA.** The nPM1300 VBUS input limit was never raised from its power-on default. It is now set from the USB-C CC advertisement: 500 mA default, 1.5 A for 1.5 A/3 A sources.
- **USB DAC feedback was meaningless.** The RX callback drained TinyUSB's FIFO immediately, pinning it at empty. Audio is now pulled at the DAC's pace so FIFO-count feedback tracks the clock offset. Added clock and feature-unit (volume/mute) requests. Host volume is mapped onto the DAC.
- USB:
  - OTG pins now get AF10;
  - VDDUSB is re-validated each time the 3.3 V rail returns;
  - the stack is properly torn down on detach;
  - MSC detach invalidates the "Play all" cache (the host may have changed the music);
  - unsupported SCSI commands now return a sense code;
  - the serial number is now the chip's 96-bit UID.
- **I²C ran at about 200 kHz, not the stated 400 kHz.** The timing register now uses the RM0456 Fast-mode value for a 16 MHz kernel.
- Repeat-one (`repeat=2`) was accepted in settings but ignored by `player_next()`.
- Unplayable tracks (corrupt, missing, DSD256) are skipped instead of stopping playback. The skip is bounded so a playlist of nothing but bad files cannot spin.
- `playlist_set_shuffle()` underflowed on an empty list.
- `settings.txt` values above 2³¹ were parsed with `atoi`.
- The SD card-removal path left FatFs mounted.
- CS43131: MCLK is switched back to the internal RCO before the crystal is stopped.

### Optimisations

- **Album art decodes about 10× faster** for covers of 960 px and up. It uses picojpeg's DC-only "reduce" mode, which needs one sample per 8×8 block and still gives at least one sample per output pixel. The per-pixel counter array (28 KB RAM) was replaced by two 120-entry tables.
- **One audio ring instead of three.** PCM and DoP share the 128 KB ring, so the 64 KB DSD rings and SAI block B / DMA channel 1 are gone. The ring is copied with two `memcpy` segments instead of per-sample modulo indexing in the ISR.
- **Helix AAC uses ARM DSP instructions.** SMULL/SMLAL/SSAT inline asm on the Cortex-M33 replaces the portable C fallback.
- Decode hot paths are built at `-O2`. Less CPU time per frame means more time in WFI.
- The e-ink controller goes to deep sleep after 15 s without a refresh and wakes transparently on the next one.
- Flash is powered down during WFI sleep (`SLEEP_PD`). BOR/PVD run in ultra-low-power sampling mode in Stop.
- VBUS poll is 2 Hz instead of 4 Hz while awake, and runs once a second from the RTC while asleep.

### Needs verification on hardware

See the README bring-up checklist. The new items are:

- DoP register encoding and DSD128 at a 22.58 MHz I²S clock;
- headphone detection with the codec crystal stopped;
- nPM1300 BUCK2 GPIO control;
- partial refresh from white on the actual panel;
- the 500 mA / 1.5 A input limit;
- I²C rise time at 400 kHz.

### Files

- **Added:**
  - `app/power.c`, `app/power.h`
  - `app/usb_descriptors.h`
  - `Core/Src/syscalls.c`
  - `tools/build_windows.ps1`
  - `CHANGELOG.md`
- **Rewritten:**
  - `Core/Src/main.c`, `system_clock.c`, `stm32u5xx_it.c`
  - `drivers/sai_audio.*`
  - `audio/audio_pipeline.*`
  - `app/player.c`, `app/settings.c`, `app/usb_app.c`
  - `ld/STM32U575xG.ld`
  - `third_party/fetch.sh`
- **Modified:**
  - `Core/Inc/board.h`, `Core/Inc/tusb_config.h`
  - `drivers/cs43131.*`, `eink.*`, `npm1300.*`, `sdcard.*`, `buttons.*`, `i2c_bus.c`
  - `audio/decoder.c`, `dsd.*`, `tags.c`
  - `app/ui.*`, `playlist.*`, `settings.h`, `player.h`, `usb_app.h`, `usb_descriptors.c`
  - `CMakeLists.txt`
  - `README.md`
- **Unchanged:**
  - `assets/*`
  - `audio/resampler.*`, `ogg_min.*`, `tags.h`
  - `drivers/gfx.*`
  - `app/diskio_sd.c`
  - `cmake/arm-none-eabi.cmake`
  - `tools/gen_font.py`
  - `Core/Inc/stm32u5xx_hal_conf.h`
