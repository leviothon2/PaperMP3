# Display drive (2.7.0): where the code comes from and how to keep it in step

The player's panel code is a fork of the display driver of **InkBoy** (MIT, [github.com/kuslota/InkBoy](https://github.com/kuslota/InkBoy)), taken through the **display-test firmware** (`../display test firmware`, dt-0.2.1), which ported it to this board and measured it on the glass. Upstream InkBoy was checked again on 2026-11-12: its last commit is from 2026-10-22, before the display-test port, so there is nothing newer to pick up.

## File map

| Player file | Comes from | State |
|---|---|---|
| `drivers/ssd1681_fast/ssd1681_fast.c`, `.h` | display test `components/ssd1681_fast` (InkBoy + `PORT:` changes) | display-test file plus one marked addition: `ssd1681_otp_assume_shown()` |
| `drivers/ssd1681_fast/ssd1681_port_stm32.c`, `ssd1681_port.h` | display test | **identical** |
| `drivers/ssd1681_fast/ssd1681_vendor_tables.h`, `ssd1681_gray_waveform.h` | InkBoy | **identical** (Waveshare tables, see `THIRD_PARTY_NOTICES.md`) |
| `drivers/inkboy/fast_display.c`, `.h` | InkBoy `main/fast_display.c` | **dithered drive only**: the grayscale paths are removed and the pulse counters are a static object instead of a heap block. The remaining functions are InkBoy's, line for line |
| `drivers/inkboy/drive_counters.c`, `.h` | display test (InkBoy + edge halo) | halo scratch moved from three static 5 KB planes into the caller's mask buffers; otherwise identical |
| `drivers/inkboy/display_mode.h` | InkBoy | **identical** |
| `Core/esp_compat/*` | display test `components/esp_compat` | **identical** |
| `drivers/eink.c`, `.h` | new | the player's `eink_*` calls on top of the driver |
| `drivers/sdcard.c`, `.h` | display test `components/drivers` | **identical** |
| `drivers/buttons.c`, `.h` | display test | plus the SW2 + SW3 chord event and `buttons_press_mode()` |
| `app/flash_store.c`, `.h` | display test `main/flash_store.c` | **identical** (the player's records use layout id 0x2701, the display test's 0x0201, so each ignores the other's) |
| `Core/Src/diag.c` NMI handler | display test `components/board/src/diag.c` | same change |
| `tools/check_safety.py`, `tools/host_test/host_port.c` | display test | paths adapted; fault switches added to the fake panel |

Why grayscale is left out: InkBoy's planner allocates a 104 KB plan and a 120 KB history, plus 10 KB of follow-up masks. The player's static RAM is at 99.7 % with the audio buffers, decoders and library index it already has.

## Rules the front-end keeps (from the display test's DESIGN.md)

1. **One owner.** `drivers/eink.c` holds the only `ssd1681_handle_t`. The fast drive and the factory (OTP) refreshes are never mixed inside a session: switching closes the device (deep sleep, OE low) or goes through the driver's own reset.
2. **InkBoy's limits are not touched:** 2402 activations per power-on, a clean refresh every 2400 scans. `eink.c` renews the session (close, open, clean refresh) 96 scans before the limit when the UI asks for a clean refresh, and 24 scans before it in any case.
3. **Faults are faults.** Any driver error closes the device; `eink_service()` re-opens it from a hardware reset and draws with the factory waveform. Two failures ask `power_panel_service()` for one rail cycle.
4. **Known-good path first.** The boot screen is an OTP full refresh. After a fault / brownout / watchdog restart the fast drive stays off for that boot.
5. **USB guard.** While `usb_app_state()` is PROMPT, MSC or DAC the UI calls `eink_force_classic(true)`: a running burst is finished, the device is reset and only factory waveforms are used. This is the condition under which the register waveform hung 2.5.1–2.6.2; the display test (no USB stack) could not reproduce or clear it.
6. **No command outside the driver.** `eink.c` sends nothing itself; `tools/check_safety.py` enforces it together with InkBoy's command whitelist (0x30, the OTP-programming command, appears nowhere).
7. **Audio and USB keep running** from the driver's wait loops (BUSY waits and millisecond delays) through `eink_set_idle_hook()`, never from inside an SPI transfer.

## How a refresh runs in the fast drive

```
ui_poll()          draws into the framebuffer (1 = white, the driver's own format)
eink_refresh_partial()
    no session yet  ->  OTP partial (screen visible in ~0.4 s), session start queued
    session open    ->  fast_display_update(): ONE ~20 ms scan, returns
eink_service()     every main-loop lap: the next scan while pixels are pending
                   (8 pulses + 1 HOLD scan), boosters off 750 ms after the last
```

Keys, the decoder and USB are serviced between scans. A frame drawn while a burst is running just replaces the target; pixels that are mid-transition keep their count (InkBoy's drive counters).

## Taking a later InkBoy or display-test change

1. `ssd1681_fast.c`, the vendor tables, `drive_counters.c`: diff against the display-test copy and apply the hunks. Keep the two `PORT (player 2.7.0)` blocks.
2. `fast_display.c`: only `fast_display_full / update / finish / pending / set_dither_pulses` exist here; compare those functions with upstream.
3. Run `python3 tools/check_safety.py` and `tools/host_test/run.sh`.

## Things only the board can answer

- Whether the fast drive is stable with audio playing (the display test had no audio): watch **About → faults** and `/crashlog.txt`.
- Whether the fast drive can be allowed during USB modes. To try it, remove the `eink_force_classic()` call in `ui_poll()`.
- Ghosting between clean refreshes with real album art, and the best **Full refresh** setting.
- Battery cost per song change against the classic drive (the display test's NOW PLAYING TEST measures this per method).
