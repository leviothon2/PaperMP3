# Toolchain file: GNU Arm Embedded (arm-none-eabi-gcc >= 12)
#
# The compiler is looked up on PATH first, then in the usual install
# locations on Windows (STM32CubeCLT, STM32CubeIDE, Arm's installer,
# PlatformIO), so VS Code / CMake work without editing PATH. Override with
#   -DARM_TOOLCHAIN_DIR=C:/path/to/bin   (or env var ARM_TOOLCHAIN_DIR)
set(CMAKE_SYSTEM_NAME Generic)
set(CMAKE_SYSTEM_PROCESSOR cortex-m33)

if(NOT ARM_TOOLCHAIN_DIR AND DEFINED ENV{ARM_TOOLCHAIN_DIR})
    set(ARM_TOOLCHAIN_DIR "$ENV{ARM_TOOLCHAIN_DIR}")
endif()

set(_hints "")
if(ARM_TOOLCHAIN_DIR)
    list(APPEND _hints "${ARM_TOOLCHAIN_DIR}")
endif()
if(DEFINED ENV{STM32CLT_PATH})
    list(APPEND _hints "$ENV{STM32CLT_PATH}/GNU-tools-for-STM32/bin")
endif()
file(GLOB _globbed LIST_DIRECTORIES true
    "C:/ST/STM32CubeCLT*/GNU-tools-for-STM32/bin"
    "C:/ST/STM32CubeIDE*/STM32CubeIDE/plugins/*gnu-tools-for-stm32*/tools/bin"
    "C:/Program Files/Arm GNU Toolchain arm-none-eabi/*/bin"
    "C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/*/bin"
    "C:/Program Files (x86)/GNU Arm Embedded Toolchain/*/bin"
    "$ENV{USERPROFILE}/.platformio/packages/toolchain-gccarmnoneeabi*/bin")
list(SORT _globbed ORDER DESCENDING)            # newest version first
list(APPEND _hints ${_globbed})

find_program(ARM_GCC arm-none-eabi-gcc HINTS ${_hints} REQUIRED)
get_filename_component(_bin "${ARM_GCC}" DIRECTORY)
if(CMAKE_HOST_WIN32)
    set(_exe ".exe")
endif()
set(ARM_TOOLCHAIN_DIR "${_bin}" CACHE PATH "Arm GNU toolchain bin directory")

set(CMAKE_C_COMPILER   "${_bin}/arm-none-eabi-gcc${_exe}")
set(CMAKE_ASM_COMPILER "${_bin}/arm-none-eabi-gcc${_exe}")
set(CMAKE_OBJCOPY      "${_bin}/arm-none-eabi-objcopy${_exe}" CACHE FILEPATH "")
set(CMAKE_SIZE         "${_bin}/arm-none-eabi-size${_exe}"    CACHE FILEPATH "")

set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)

set(CPU_FLAGS "-mcpu=cortex-m33 -mthumb -mfpu=fpv5-sp-d16 -mfloat-abi=hard")
set(CMAKE_C_FLAGS_INIT   "${CPU_FLAGS} -ffunction-sections -fdata-sections -fno-common")
set(CMAKE_ASM_FLAGS_INIT "${CPU_FLAGS}")
set(CMAKE_EXE_LINKER_FLAGS_INIT
    "${CPU_FLAGS} -specs=nano.specs -Wl,--gc-sections -Wl,--print-memory-usage")
