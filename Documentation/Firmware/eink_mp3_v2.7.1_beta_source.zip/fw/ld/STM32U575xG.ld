/*
 * Linker script - STM32U575RGT6 (1 MB flash, 768 KB contiguous SRAM).
 * SRAM1 (192K) + SRAM2 (64K) + SRAM3 (512K) are contiguous at 0x20000000
 * on the U575; treated as one region. SRAM4 (16K, 0x28000000) is left for
 * future low-power use.
 *
 * v2 changes:
 *   - v1 discarded all of libc/libm/libgcc (/DISCARD/ : { libc.a(*) ... }),
 *     which made the image unlinkable (memcpy, snprintf, 64-bit division
 *     ...). Removed.
 *   - Added .preinit/.init/.fini_array (newlib's __libc_init_array needs
 *     the symbols) and the _sheap/_eheap symbols used by syscalls.c.
 *   - Heap 160 KB (dr_flac + Helix AAC + minimp4 allocate at track open),
 *     stack 48 KB (libopus uses C99 VLAs on the stack - VAR_ARRAYS).
 *   - Every RAM byte is retained in Stop 2, so sleep needs no special
 *     sections.
 */
ENTRY(Reset_Handler)

MEMORY
{
  /* 2.6.0: one 512 KB bank. The other bank holds the previous firmware
   * (SD-card update / rollback, app/fwupdate.c), so an image must never
   * be larger than a bank.                                              */
  /* 2.7.0: the bank's last 8 KB page (0x0807E000) holds the settings
   * log (app/flash_store.c), so the image may use 504 KB.               */
  FLASH (rx)  : ORIGIN = 0x08000000, LENGTH = 504K
  RAM   (xrw) : ORIGIN = 0x20000000, LENGTH = 768K
  SRAM4 (xrw) : ORIGIN = 0x28000000, LENGTH = 16K
}

_estack = ORIGIN(RAM) + LENGTH(RAM);
_Min_Heap_Size  = 0x28000;  /* 160K                                      */
_Min_Stack_Size = 0xC000;   /* 48K                                       */

SECTIONS
{
  .isr_vector : { . = ALIGN(8); KEEP(*(.isr_vector)) . = ALIGN(8); } >FLASH

  .text : {
    . = ALIGN(8);
    *(.text) *(.text*) *(.glue_7) *(.glue_7t) *(.eh_frame)
    KEEP(*(.init)) KEEP(*(.fini))
    . = ALIGN(8);
    _etext = .;
  } >FLASH

  .rodata : { . = ALIGN(8); *(.rodata) *(.rodata*) . = ALIGN(8); } >FLASH

  .ARM.extab : { *(.ARM.extab* .gnu.linkonce.armextab.*) } >FLASH
  .ARM : { __exidx_start = .; *(.ARM.exidx*) __exidx_end = .; } >FLASH

  .preinit_array : {
    PROVIDE_HIDDEN(__preinit_array_start = .);
    KEEP(*(.preinit_array*))
    PROVIDE_HIDDEN(__preinit_array_end = .);
  } >FLASH
  .init_array : {
    PROVIDE_HIDDEN(__init_array_start = .);
    KEEP(*(SORT(.init_array.*)))
    KEEP(*(.init_array*))
    PROVIDE_HIDDEN(__init_array_end = .);
  } >FLASH
  .fini_array : {
    PROVIDE_HIDDEN(__fini_array_start = .);
    KEEP(*(SORT(.fini_array.*)))
    KEEP(*(.fini_array*))
    PROVIDE_HIDDEN(__fini_array_end = .);
  } >FLASH

  _sidata = LOADADDR(.data);
  .data : {
    . = ALIGN(8);
    _sdata = .;
    *(.data) *(.data*)
    . = ALIGN(8);
    _edata = .;
  } >RAM AT> FLASH

  /* Survives a system reset; never zeroed (dfu_entry.c).               */
  .noinit (NOLOAD) : {
    . = ALIGN(8);
    *(.noinit) *(.noinit*)
    . = ALIGN(8);
  } >RAM

  .bss (NOLOAD) : {
    . = ALIGN(8);
    _sbss = .;
    __bss_start__ = _sbss;
    *(.bss) *(.bss*) *(COMMON)
    . = ALIGN(8);
    _ebss = .;
    __bss_end__ = _ebss;
  } >RAM

  ._user_heap_stack (NOLOAD) : {
    . = ALIGN(8);
    PROVIDE(end = .);
    PROVIDE(_end = .);
    _sheap = .;
    . = . + _Min_Heap_Size;
    _eheap = .;
    . = . + _Min_Stack_Size;
    . = ALIGN(8);
  } >RAM

  .ARM.attributes 0 : { *(.ARM.attributes) }
}
