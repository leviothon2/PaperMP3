/**
 * @file    eq.h
 * @brief   10-band graphic equaliser for the PCM path (2.6.0).
 *
 * Bands at the ISO octave centres 31 Hz ... 16 kHz, +-12 dB in 1 dB
 * steps, constant-Q (Q = 1.41, one octave) peaking filters designed per
 * the RBJ cookbook for the actual output rate.
 *
 * "Audiophile" details:
 *   - Fixed-point direct-form-I biquads: Q29 coefficients, 32x32 -> 64-bit
 *     multiply-accumulate (single-cycle SMLAL on the M33), 12 dB of
 *     internal headroom, and first-order error feedback ("fraction
 *     saving") on the requantisation. Measured against a double-precision
 *     reference with the same coefficients, the arithmetic noise is about
 *     -134 dBFS - below the CS43131's own ~130 dB dynamic range - and the
 *     low-frequency bands don't suffer float biquads' limit cycles.
 *   - Automatic pre-amp: the cascade's real magnitude response is
 *     evaluated when the curve changes and the input is attenuated by its
 *     peak, so boosts can never clip.
 *   - Bit-perfect bypass: with the EQ off (or every band at 0 dB) samples
 *     are passed through untouched.
 *   - Bands above 0.45 x the sample rate are skipped (no cramping).
 *   - CPU: ~620 instructions per stereo frame with all ten bands (~21 %
 *     of the core at 44.1/48 kHz, ~46 % at 96 kHz; only non-zero bands
 *     run). Streams above 96 kHz bypass the EQ (see EQ_MAX_RATE).
 * DSD/DoP streams never pass through the EQ.
 */
#ifndef EQ_H
#define EQ_H

#include <stdbool.h>
#include <stdint.h>

#define EQ_BANDS       10
#define EQ_GAIN_MAX    12
#define EQ_PRESET_COUNT 7         /* Off, 5 presets, Custom               */
#define EQ_PRESET_CUSTOM 6
/* Above this output rate the EQ is bypassed (176.4/192 kHz would need
 * ~90 % of the CPU with all ten bands); those streams stay bit-perfect. */
#define EQ_MAX_RATE    96000u

extern const uint16_t eq_band_hz[EQ_BANDS];

const char   *eq_preset_name(uint8_t preset);
const int8_t *eq_preset_gains(uint8_t preset);   /* NULL for Custom      */

/* Configure the curve (gains in dB, clamped to +-12). enabled = false or
 * an all-zero curve = bypass. Safe to call any time from thread context. */
void eq_configure(bool enabled, const int8_t gains[EQ_BANDS]);
/* Output sample rate changed (new stream). Clears the filter state.      */
void eq_set_rate(uint32_t fs);
void eq_reset(void);
bool eq_active(void);
bool eq_rate_limited(void);    /* on, but bypassed: stream above 96 kHz   */
/* Pre-amp currently applied, in tenths of a dB (<= 0).                   */
int  eq_preamp_tenths(void);

/* In-place on interleaved stereo int32 frames.                           */
void eq_process(int32_t *frames, uint32_t n);

#endif /* EQ_H */
