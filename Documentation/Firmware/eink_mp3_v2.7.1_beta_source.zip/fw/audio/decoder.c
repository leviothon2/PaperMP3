/**
 * @file    decoder.c
 * @brief   Codec dispatch and format glue.
 *
 * Static (no-malloc where possible) instantiation of each backend; only
 * one decoder is live at a time so their state shares a union. dr_libs
 * are configured with DR_MP3_NO_STDIO etc. and read through FatFs.
 */
#include "decoder.h"
#include "ff.h"                     /* FatFs                              */

/* 2.6.0: minimp3 synthesises in float; take that directly instead of the
 * 16-bit rounded output (MP3 carries more than 16 bits of resolution).  */
#define DR_MP3_FLOAT_OUTPUT
#define DR_MP3_IMPLEMENTATION
#include "dr_mp3.h"
#define DR_FLAC_IMPLEMENTATION
#include "dr_flac.h"
#define DR_WAV_IMPLEMENTATION
#include "dr_wav.h"

#include "aacdec.h"                 /* Helix AAC                          */
#define MINIMP4_IMPLEMENTATION
#include "minimp4.h"
#include "opus.h"
#include "ogg_min.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

/* Helix AAC (arduino-libhelix) allocates through these hooks.            */
void *helix_malloc(int size) { return malloc((size_t)size); }
void  helix_free(void *ptr)  { free(ptr); }

/* ---- shared file plumbing ---------------------------------------------- */

static FIL        s_fil;
static bool       s_fil_open;
static dec_info_t s_info;

static size_t file_read(void *user, void *buf, size_t n)
{
    (void)user;
    UINT br = 0;
    if (f_read(&s_fil, buf, (UINT)n, &br) != FR_OK) return 0;
    return br;
}

/* One seek/tell pair serves all three dr_libs (their origin enums share
 * the SET=0 / CUR=1 / END=2 layout).                                     */
/* Skip forward (Ogg page payloads while seeking).                        */
static bool file_skip(void *user, uint32_t n)
{
    (void)user;
    return f_lseek(&s_fil, f_tell(&s_fil) + n) == FR_OK;
}

static int file_seek(int off, int origin)
{
    FSIZE_t base = (origin == 1) ? f_tell(&s_fil)
                 : (origin == 2) ? f_size(&s_fil) : 0;
    int64_t pos = (int64_t)base + off;
    if (pos < 0) return 0;
    return f_lseek(&s_fil, (FSIZE_t)pos) == FR_OK;
}

static drmp3_bool32 mp3_seek(void *user, int off, drmp3_seek_origin origin)
{ (void)user; return (drmp3_bool32)file_seek(off, (int)origin); }
static drmp3_bool32 mp3_tell(void *user, drmp3_int64 *cur)
{ (void)user; *cur = (drmp3_int64)f_tell(&s_fil); return 1; }

static drflac_bool32 flac_seek(void *user, int off, drflac_seek_origin origin)
{ (void)user; return (drflac_bool32)file_seek(off, (int)origin); }
static drflac_bool32 flac_tell(void *user, drflac_int64 *cur)
{ (void)user; *cur = (drflac_int64)f_tell(&s_fil); return 1; }

static drwav_bool32 wav_seek(void *user, int off, drwav_seek_origin origin)
{ (void)user; return (drwav_bool32)file_seek(off, (int)origin); }
static drwav_bool32 wav_tell(void *user, drwav_int64 *cur)
{ (void)user; *cur = (drwav_int64)f_tell(&s_fil); return 1; }

_Static_assert(DRMP3_SEEK_CUR == 1 && DRFLAC_SEEK_CUR == 1 && DRWAV_SEEK_CUR == 1,
               "dr_libs seek-origin layout changed");

/* ---- backend state ------------------------------------------------------- */

/* AAC frame feeding */
typedef struct {
    HAACDecoder hdec;
    uint8_t     inbuf[2048];        /* >= max ADTS/raw AAC frame          */
    int         in_fill;
    /* m4a only: */
    bool        is_m4a;
    MP4D_demux_t mp4;
    unsigned    track, sample_idx, sample_count;
    int16_t     pcmbuf[2048];       /* one AAC frame: 1024 x 2ch          */
    int         pcm_avail, pcm_pos;
} aac_state_t;

typedef struct {
    OpusDecoder *dec;               /* opus_decoder_create -> static pool */
    /* opus_decoder_get_size(2) = 26580 B for the 1.5.2 fixed-point build
     * on a 64-bit host (v1 reserved 26500 - every Opus file failed to
     * open). 28 KB leaves margin; checked at runtime below.              */
    uint8_t      dec_mem[28672] __attribute__((aligned(8)));
    ogg_min_t    ogg;
    int16_t      pcmbuf[5760 * 2];  /* max opus frame 120 ms @ 48 k       */
    int          pcm_avail, pcm_pos;
    uint16_t     preskip;
    uint16_t     preskip_orig;      /* from OpusHead, for seek maths     */
} opus_state_t;

static union {
    drmp3        mp3;
    drflac      *flac;
    drwav        wav;
    aac_state_t  aac;
    opus_state_t opus;
} u;

static uint64_t s_frames_out;        /* decoded frames, for dec_tell_ms   */

/* Gapless trimming for M4A (2.6.0). MP3 is trimmed inside dr_mp3 (LAME
 * header delay/padding). For AAC in MP4 the encoder priming and the
 * end padding come from iTunes' iTunSMPB tag or, failing that, the
 * track's edit list (elst media_time / segment_duration).              */
static uint32_t s_trim_delay;        /* frames to drop at the start       */
static uint64_t s_trim_total;        /* playable frames, 0 = unknown      */
static uint64_t s_abs_frame;         /* decoded frames incl. the delay    */

static bool aac_next_frame(void);

/* ---- helpers --------------------------------------------------------------- */

dec_format_t dec_format_from_path(const char *path)
{
    const char *dot = strrchr(path, '.');
    if (!dot) return DEC_FMT_UNKNOWN;
    dot++;
    if (!strcasecmp(dot, "mp3"))  return DEC_FMT_MP3;
    if (!strcasecmp(dot, "flac")) return DEC_FMT_FLAC;
    if (!strcasecmp(dot, "wav"))  return DEC_FMT_WAV;
    if (!strcasecmp(dot, "m4a") || !strcasecmp(dot, "mp4"))
                                  return DEC_FMT_M4A;
    if (!strcasecmp(dot, "aac"))  return DEC_FMT_AAC;
    if (!strcasecmp(dot, "opus") || !strcasecmp(dot, "ogg"))
                                  return DEC_FMT_OPUS;
    if (!strcasecmp(dot, "dsf") || !strcasecmp(dot, "dff"))
                                  return DEC_FMT_DSD;
    return DEC_FMT_UNKNOWN;
}

/* s16 -> 32-bit slot (audio in top 24 bits), mono upmix                    */
static uint32_t emit_s16(int32_t *dst, const int16_t *src,
                         uint32_t frames, uint8_t ch)
{
    for (uint32_t i = 0; i < frames; i++) {
        int32_t l = src[i * ch] << 16;
        int32_t r = (ch >= 2 ? src[i * ch + 1] : src[i * ch]) << 16;
        *dst++ = l;
        *dst++ = r;
    }
    return frames;
}

static inline int32_t f32_to_s32(float v)
{
    v *= 2147483648.0f;
    if (v >=  2147483520.0f) return 0x7FFFFF80;
    if (v <= -2147483648.0f) return (int32_t)0x80000000;
    return (int32_t)lrintf(v);
}

/* ---- MP4 demux read callback (minimp4) ------------------------------------- */

static int mp4_read_cb(int64_t offset, void *buf, size_t size, void *token)
{
    (void)token;
    UINT br;
    if (f_lseek(&s_fil, (FSIZE_t)offset) != FR_OK) return 1;
    if (f_read(&s_fil, buf, (UINT)size, &br) != FR_OK || br != size) return 1;
    return 0;
}

/* ---- MP4 gapless info ----------------------------------------------------- */

static bool rd_abs(uint64_t off, void *buf, uint32_t n)
{
    UINT br;
    if (f_lseek(&s_fil, (FSIZE_t)off) != FR_OK) return false;
    return f_read(&s_fil, buf, n, &br) == FR_OK && br == n;
}
static uint32_t be32p(const uint8_t *p)
{ return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]; }

static uint32_t hexval(const char *s, int n)
{
    uint32_t v = 0;
    for (int i = 0; i < n && s[i]; i++) {
        char c = s[i];
        int d = (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10
              : (c >= 'A' && c <= 'F') ? c - 'A' + 10 : -1;
        if (d < 0) break;
        v = (v << 4) | (uint32_t)d;
    }
    return v;
}

/* Find child box `type` inside [start, end); returns payload offset/size. */
static bool mp4_find(uint64_t start, uint64_t end, const char *type,
                     uint64_t *pay, uint64_t *pay_end)
{
    uint64_t pos = start;
    while (pos + 8 <= end) {
        uint8_t h[16];
        if (!rd_abs(pos, h, 8)) return false;
        uint64_t size = be32p(h), hdr = 8;
        if (size == 1) {                                 /* 64-bit size    */
            if (!rd_abs(pos + 8, h + 8, 8)) return false;
            size = ((uint64_t)be32p(h + 8) << 32) | be32p(h + 12);
            hdr = 16;
        } else if (size == 0) size = end - pos;
        if (size < hdr) return false;
        if (!memcmp(h + 4, type, 4)) { *pay = pos + hdr; *pay_end = pos + size; return true; }
        pos += size;
    }
    return false;
}

/* iTunSMPB: " 00000000 PPPPPPPP EEEEEEEE LLLLLLLLLLLLLLLL ..." (hex):
 * priming (delay), end padding, original sample count.                  */
static void mp4_gapless_info(unsigned trk, uint32_t out_rate)
{
    uint64_t fsize = f_size(&s_fil), moov, moov_end, p, pe, q, qe;
    s_trim_delay = 0;
    s_trim_total = 0;
    if (!mp4_find(0, fsize, "moov", &moov, &moov_end)) return;

    if (mp4_find(moov, moov_end, "udta", &p, &pe) &&
        mp4_find(p, pe, "meta", &q, &qe) &&
        mp4_find(q + 4, qe, "ilst", &p, &pe)) {
        uint64_t pos = p;
        while (pos + 8 <= pe) {
            uint8_t h[8];
            if (!rd_abs(pos, h, 8)) break;
            uint32_t size = be32p(h);
            if (size < 8) break;
            if (!memcmp(h + 4, "----", 4)) {
                uint64_t n0, n1, d0, d1;
                char name[12] = { 0 };
                if (mp4_find(pos + 8, pos + size, "name", &n0, &n1) && n1 - n0 >= 12 &&
                    rd_abs(n0 + 4, name, 8) && !memcmp(name, "iTunSMPB", 8) &&
                    mp4_find(pos + 8, pos + size, "data", &d0, &d1) && d1 - d0 > 8) {
                    char txt[96] = { 0 };
                    uint32_t n = (uint32_t)(d1 - d0 - 8);
                    if (n > sizeof txt - 1) n = sizeof txt - 1;
                    if (rd_abs(d0 + 8, txt, n)) {
                        /* fields after the leading space, 9 chars apart   */
                        const char *t = txt;
                        while (*t == ' ') t++;
                        uint32_t delay = hexval(t + 9, 8);
                        uint64_t total = ((uint64_t)hexval(t + 27, 8) << 32) |
                                         hexval(t + 35, 8);
                        if (delay < 20000 && total) {
                            s_trim_delay = delay;
                            s_trim_total = total;
                            return;
                        }
                    }
                }
            }
            pos += size;
        }
    }

    /* Edit list of the audio track: media_time = priming, segment
     * duration (movie timescale) = playable length.                      */
    uint64_t pos = moov;
    unsigned t = 0;
    while (mp4_find(pos, moov_end, "trak", &p, &pe)) {
        if (t++ == trk) {
            uint64_t m0, m1, e0, e1;
            uint8_t mh[24];
            uint32_t movie_ts = 0;
            if (mp4_find(moov, moov_end, "mvhd", &m0, &m1) && rd_abs(m0, mh, 24))
                movie_ts = (mh[0] == 1) ? 0 : be32p(mh + 12);
            if (mp4_find(p, pe, "edts", &q, &qe) && mp4_find(q, qe, "elst", &e0, &e1)) {
                uint8_t eh[20];
                if (rd_abs(e0, eh, 20) && eh[0] == 0 && be32p(eh + 4) >= 1) {
                    uint32_t seg = be32p(eh + 8);
                    int32_t  mt  = (int32_t)be32p(eh + 12);
                    uint32_t media_ts = u.aac.mp4.track[trk].timescale;
                    if (mt > 0 && media_ts) {
                        uint64_t d = (uint64_t)mt * out_rate / media_ts;
                        if (d < 20000) s_trim_delay = (uint32_t)d;
                    }
                    if (movie_ts && seg)
                        s_trim_total = (uint64_t)seg * out_rate / movie_ts;
                }
            }
            return;
        }
        pos = pe;
    }
}

/* ---- open ------------------------------------------------------------------- */

bool dec_open(const char *path, dec_info_t *info)
{
    memset(&s_info, 0, sizeof s_info);
    s_frames_out = 0;
    s_trim_delay = 0;
    s_trim_total = 0;
    s_abs_frame  = 0;

    s_info.format = dec_format_from_path(path);
    if (s_info.format == DEC_FMT_UNKNOWN || s_info.format == DEC_FMT_DSD)
        return false;                       /* DSD goes through dsd.c     */

    if (f_open(&s_fil, path, FA_READ) != FR_OK) return false;
    s_fil_open = true;

    switch (s_info.format) {
    case DEC_FMT_MP3: {
        if (!drmp3_init(&u.mp3, (drmp3_read_proc)file_read, mp3_seek,
                        mp3_tell, NULL, NULL, NULL))
            goto fail;
        s_info.sample_rate = u.mp3.sampleRate;
        s_info.channels    = (uint8_t)u.mp3.channels;
        drmp3_uint64 nf = drmp3_get_pcm_frame_count(&u.mp3);
        if (nf && u.mp3.sampleRate)
            s_info.duration_ms = (uint32_t)(nf * 1000u / u.mp3.sampleRate);
        break;
    }
    case DEC_FMT_FLAC:
        u.flac = drflac_open((drflac_read_proc)file_read, flac_seek,
                             flac_tell, NULL, NULL);
        if (!u.flac) goto fail;
        s_info.sample_rate = u.flac->sampleRate;
        s_info.channels    = u.flac->channels;
        if (u.flac->totalPCMFrameCount)
            s_info.duration_ms = (uint32_t)(u.flac->totalPCMFrameCount *
                                            1000u / u.flac->sampleRate);
        break;

    case DEC_FMT_WAV:
        if (!drwav_init(&u.wav, (drwav_read_proc)file_read, wav_seek,
                        wav_tell, NULL, NULL))
            goto fail;
        s_info.sample_rate = u.wav.sampleRate;
        s_info.channels    = (uint8_t)u.wav.channels;
        if (u.wav.totalPCMFrameCount)
            s_info.duration_ms = (uint32_t)(u.wav.totalPCMFrameCount *
                                            1000u / u.wav.sampleRate);
        break;

    case DEC_FMT_M4A: {
        memset(&u.aac, 0, sizeof u.aac);
        u.aac.is_m4a = true;
        FSIZE_t fsize = f_size(&s_fil);
        if (!MP4D_open(&u.aac.mp4, mp4_read_cb, NULL, (int64_t)fsize))
            goto fail;
        /* pick the first AAC audio track                                */
        int trk = -1;
        for (unsigned t = 0; t < u.aac.mp4.track_count; t++)
            if (u.aac.mp4.track[t].handler_type == MP4D_HANDLER_TYPE_SOUN)
                { trk = (int)t; break; }
        if (trk < 0) goto fail;
        u.aac.track        = (unsigned)trk;
        u.aac.sample_count = u.aac.mp4.track[trk].sample_count;
        u.aac.hdec = AACInitDecoder();
        if (!u.aac.hdec) goto fail;
        /* Configure raw-block decoding from the DSI (AudioSpecificConfig:
         * 5 bit object type, 4 bit rate index, 4 bit channel config). The
         * DSI carries the *core* rate - for HE-AAC the stsd rate may
         * already be the doubled SBR rate.                               */
        static const int k_aac_rates[13] = { 96000, 88200, 64000, 48000,
            44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350 };
        const MP4D_track_t *tr = &u.aac.mp4.track[trk];
        AACFrameInfo fi = { 0 };
        fi.sampRateCore = (int)tr->SampleDescription.audio.samplerate_hz;
        fi.nChans       = (int)tr->SampleDescription.audio.channelcount;
        fi.profile      = AAC_PROFILE_LC;
        fi.bitsPerSample = 16;
        if (tr->dsi && tr->dsi_bytes >= 2) {
            unsigned idx = ((tr->dsi[0] & 0x07u) << 1) | (tr->dsi[1] >> 7);
            unsigned chc = (tr->dsi[1] >> 3) & 0x0Fu;
            if (idx < 13) fi.sampRateCore = k_aac_rates[idx];
            if (chc >= 1 && chc <= 2) fi.nChans = (int)chc;
        }
        if (AACSetRawBlockParams(u.aac.hdec, 0, &fi) != 0) goto fail;
        s_info.sample_rate =
            u.aac.mp4.track[trk].SampleDescription.audio.samplerate_hz;
        s_info.channels =
            (uint8_t)u.aac.mp4.track[trk].SampleDescription.audio.channelcount;
        /* 2.6.0: decode the first frame now so the reported rate is the
         * real output rate (HE-AAC/SBR doubles the stsd/core rate); its
         * PCM stays buffered for the first dec_read().                   */
        if (!aac_next_frame()) goto fail;
        if (u.aac.mp4.track[trk].timescale)
            s_info.duration_ms = (uint32_t)((uint64_t)
                u.aac.mp4.track[trk].duration_lo * 1000u /
                u.aac.mp4.track[trk].timescale);
        mp4_gapless_info(u.aac.track, s_info.sample_rate);
        if (s_trim_total && s_info.sample_rate)
            s_info.duration_ms = (uint32_t)(s_trim_total * 1000u / s_info.sample_rate);
        break;
    }
    case DEC_FMT_AAC:                       /* raw ADTS stream            */
        memset(&u.aac, 0, sizeof u.aac);
        u.aac.hdec = AACInitDecoder();
        if (!u.aac.hdec) goto fail;
        /* v2.3: decode the first frame now. v2.2 reported a placeholder
         * 44.1 kHz here and the player configured the DAC with it, so a
         * 48 kHz ADTS file played ~9 % slow. The decoded PCM stays in
         * pcmbuf and is the first thing dec_read() returns.              */
        s_info.channels = 2;
        if (!aac_next_frame()) goto fail;
        break;

    case DEC_FMT_OPUS: {
        memset(&u.opus, 0, sizeof u.opus);
        if (!ogg_min_open(&u.opus.ogg, file_read, NULL)) goto fail;
        /* OpusHead: channel count @9, preskip @10-11 (LE)               */
        const uint8_t *head; uint32_t head_len;
        if (!ogg_min_first_packet(&u.opus.ogg, &head, &head_len) ||
            head_len < 19 || memcmp(head, "OpusHead", 8) != 0)
            goto fail;
        uint8_t ch = head[9];
        u.opus.preskip = (uint16_t)(head[10] | (head[11] << 8));
        u.opus.preskip_orig = u.opus.preskip;
        ogg_min_set_skip(&u.opus.ogg, file_skip);
        if (opus_decoder_get_size(2) > (int)sizeof u.opus.dec_mem) goto fail;
        u.opus.dec = (OpusDecoder *)u.opus.dec_mem;
        if (opus_decoder_init(u.opus.dec, 48000, ch >= 2 ? 2 : 1) != OPUS_OK)
            goto fail;
        ogg_min_skip_packet(&u.opus.ogg);   /* OpusTags                   */
        s_info.sample_rate = 48000;         /* opus always decodes @48 k  */
        s_info.channels    = ch >= 2 ? 2 : 1;
        s_info.duration_ms = ogg_min_duration_ms(&u.opus.ogg, 48000);
        break;
    }
    default:
        goto fail;
    }

    *info = s_info;
    return true;

fail:
    dec_close();
    return false;
}

/* ---- read ------------------------------------------------------------------- */

/* Decode the next AAC frame into pcmbuf (updates rate/channels from the
 * frame header). false = end of stream.                                  */
static bool aac_next_frame(void)
{
    for (int tries = 0; tries < 1024; tries++) {
        /* refill the compressed buffer                                   */
        if (u.aac.is_m4a) {
            if (u.aac.sample_idx >= u.aac.sample_count) return false;
            unsigned sz = 0, dur = 0;
            MP4D_file_offset_t off = MP4D_frame_offset(&u.aac.mp4,
                u.aac.track, u.aac.sample_idx, &sz, NULL, &dur);
            if (!off || sz > sizeof u.aac.inbuf) return false;
            UINT br;
            f_lseek(&s_fil, (FSIZE_t)off);
            f_read(&s_fil, u.aac.inbuf, sz, &br);
            if (br != sz) return false;
            u.aac.in_fill = (int)sz;
            u.aac.sample_idx++;
        } else {
            /* ADTS: keep the buffer topped up, let Helix find sync       */
            int space = (int)sizeof u.aac.inbuf - u.aac.in_fill;
            if (space > 0) {
                UINT br = 0;
                f_read(&s_fil, u.aac.inbuf + u.aac.in_fill, (UINT)space, &br);
                u.aac.in_fill += (int)br;
            }
            if (u.aac.in_fill == 0) return false;
        }
        uint8_t *inptr = u.aac.inbuf;
        int      left  = u.aac.in_fill;
        int err = AACDecode(u.aac.hdec, &inptr, &left, u.aac.pcmbuf);
        if (err) {
            if (!u.aac.is_m4a) u.aac.in_fill = 0;   /* resync on next fill  */
            continue;                               /* m4a: drop the sample */
        }
        memmove(u.aac.inbuf, inptr, (size_t)left);
        u.aac.in_fill = left;

        AACFrameInfo fi;
        AACGetLastFrameInfo(u.aac.hdec, &fi);
        if (fi.sampRateOut > 0) s_info.sample_rate = (uint32_t)fi.sampRateOut;
        if (fi.nChans > 0)      s_info.channels    = (uint8_t)fi.nChans;
        u.aac.pcm_avail    = fi.outputSamps;
        u.aac.pcm_pos      = 0;
        return true;
    }
    return false;
}

static uint32_t read_aac(int32_t *pcm, uint32_t max_frames)
{
    uint32_t done = 0;
    while (done < max_frames) {
        /* drain decoded PCM first                                        */
        if (u.aac.pcm_avail > u.aac.pcm_pos) {
            uint8_t ch = s_info.channels ? s_info.channels : 2;
            uint32_t have = (uint32_t)(u.aac.pcm_avail - u.aac.pcm_pos) / ch;
            uint32_t take = (max_frames - done) < have
                          ? (max_frames - done) : have;
            emit_s16(pcm + done * 2, &u.aac.pcmbuf[u.aac.pcm_pos], take, ch);
            u.aac.pcm_pos += (int)(take * ch);
            done += take;
            if (!take) u.aac.pcm_pos = u.aac.pcm_avail;
            continue;
        }
        if (!aac_next_frame()) break;
    }
    return done;
}

/* ADTS has no index: walk the 7-byte frame headers from the start of the
 * file (cheap - no decoding) until the requested time is reached.       */
static bool adts_seek_ms(uint32_t ms, uint64_t *frame_out)
{
    static const uint32_t k_rates[13] = { 96000, 88200, 64000, 48000, 44100,
        32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350 };
    uint8_t h[10];
    UINT br;
    FSIZE_t pos = 0, size = f_size(&s_fil);
    if (f_lseek(&s_fil, 0) != FR_OK) return false;
    if (f_read(&s_fil, h, 10, &br) == FR_OK && br == 10 && !memcmp(h, "ID3", 3))
        pos = 10u + (((uint32_t)(h[6] & 0x7F) << 21) | ((h[7] & 0x7F) << 14) |
                     ((h[8] & 0x7F) << 7) | (h[9] & 0x7F));
    const uint64_t target_us = (uint64_t)ms * 1000u;
    uint64_t elapsed_us = 0;
    uint32_t resync = 0;
    while (elapsed_us < target_us && pos + 7u <= size) {
        if (f_lseek(&s_fil, pos) != FR_OK) return false;
        if (f_read(&s_fil, h, 7, &br) != FR_OK || br < 7) break;
        unsigned sfi = (h[2] >> 2) & 0x0Fu;
        unsigned len = ((unsigned)(h[3] & 0x03) << 11) | ((unsigned)h[4] << 3) | (h[5] >> 5);
        if (h[0] != 0xFF || (h[1] & 0xF0) != 0xF0 || sfi >= 13 || len < 7) {
            if (++resync > 65536u) return false;   /* not ADTS after all   */
            pos++;
            continue;
        }
        unsigned blocks = (h[6] & 0x03u) + 1u;
        elapsed_us += (uint64_t)1024u * blocks * 1000000u / k_rates[sfi];
        pos += len;
    }
    if (f_lseek(&s_fil, pos) != FR_OK) return false;
    u.aac.in_fill = 0;
    u.aac.pcm_avail = u.aac.pcm_pos = 0;
    *frame_out = elapsed_us * s_info.sample_rate / 1000000u;
    return true;
}

/* M4A with gapless trimming: drop the priming frames, stop at the
 * original length.                                                       */
static uint32_t read_m4a_trimmed(int32_t *pcm, uint32_t max_frames)
{
    uint32_t done = 0;
    while (done < max_frames) {
        if (s_trim_total && s_abs_frame >= (uint64_t)s_trim_delay + s_trim_total)
            break;                                       /* end padding    */
        uint32_t want = max_frames - done;
        uint32_t got = read_aac(pcm + done * 2, want);
        if (!got) break;
        uint64_t a0 = s_abs_frame;
        s_abs_frame += got;
        /* leading priming                                                */
        uint32_t skip = 0;
        if (a0 < s_trim_delay) {
            uint64_t d = s_trim_delay - a0;
            skip = d >= got ? got : (uint32_t)d;
        }
        /* trailing padding                                               */
        uint32_t keep_end = got;
        if (s_trim_total) {
            uint64_t end = (uint64_t)s_trim_delay + s_trim_total;
            if (a0 + got > end) keep_end = end > a0 ? (uint32_t)(end - a0) : 0;
        }
        if (keep_end <= skip) continue;
        uint32_t keep = keep_end - skip;
        if (skip) memmove(pcm + done * 2, pcm + (done + skip) * 2,
                          keep * 2 * sizeof(int32_t));
        done += keep;
    }
    return done;
}

static uint32_t read_opus(int32_t *pcm, uint32_t max_frames)
{
    uint32_t done = 0;
    uint8_t  ch = s_info.channels;
    while (done < max_frames) {
        if (u.opus.pcm_avail > u.opus.pcm_pos) {
            uint32_t have = (uint32_t)(u.opus.pcm_avail - u.opus.pcm_pos) / ch;
            uint32_t take = (max_frames - done) < have
                          ? (max_frames - done) : have;
            emit_s16(pcm + done * 2, &u.opus.pcmbuf[u.opus.pcm_pos], take, ch);
            u.opus.pcm_pos += (int)(take * ch);
            done += take;
            continue;
        }
        const uint8_t *pkt; uint32_t pkt_len;
        if (!ogg_min_next_packet(&u.opus.ogg, &pkt, &pkt_len)) break;
        int n = opus_decode(u.opus.dec, pkt, (opus_int32)pkt_len,
                            u.opus.pcmbuf, 5760, 0);
        if (n <= 0) continue;
        int skip = 0;
        if (u.opus.preskip) {              /* drop encoder priming        */
            skip = (n < u.opus.preskip) ? n : u.opus.preskip;
            u.opus.preskip = (uint16_t)(u.opus.preskip - skip);
        }
        u.opus.pcm_pos   = skip * ch;
        u.opus.pcm_avail = n * ch;
    }
    return done;
}

uint32_t dec_read(int32_t *pcm, uint32_t max_frames)
{
    uint32_t n = 0;
    switch (s_info.format) {
    case DEC_FMT_MP3: {
        /* dr_mp3 float -> 32-bit slots, rounded, saturated               */
        static float tmp[1152 * 2];
        const uint8_t ch = (uint8_t)u.mp3.channels;
        while (n < max_frames) {
            uint32_t want = max_frames - n;
            if (want > 1152) want = 1152;
            drmp3_uint64 got = drmp3_read_pcm_frames_f32(&u.mp3, want, tmp);
            if (!got) break;
            for (uint32_t i = 0; i < got; i++) {
                float l = tmp[i * ch], r = (ch >= 2) ? tmp[i * ch + 1] : l;
                pcm[(n + i) * 2]     = f32_to_s32(l);
                pcm[(n + i) * 2 + 1] = f32_to_s32(r);
            }
            n += (uint32_t)got;
        }
        break;
    }
    case DEC_FMT_FLAC: {
        static drflac_int32 tmp[1024 * 2];
        while (n < max_frames) {
            uint32_t want = max_frames - n;
            if (want > 1024) want = 1024;
            drflac_uint64 got =
                drflac_read_pcm_frames_s32(u.flac, want, tmp);
            if (!got) break;
            /* dr_flac s32 output is already left-justified 32-bit        */
            for (uint32_t i = 0; i < got; i++) {
                int32_t l = tmp[i * u.flac->channels];
                int32_t r = (u.flac->channels >= 2)
                          ? tmp[i * u.flac->channels + 1] : l;
                pcm[(n + i) * 2]     = l;
                pcm[(n + i) * 2 + 1] = r;
            }
            n += (uint32_t)got;
        }
        break;
    }
    case DEC_FMT_WAV: {
        static drwav_int32 tmp[1024 * 2];
        while (n < max_frames) {
            uint32_t want = max_frames - n;
            if (want > 1024) want = 1024;
            drwav_uint64 got = drwav_read_pcm_frames_s32(&u.wav, want, tmp);
            if (!got) break;
            for (uint32_t i = 0; i < got; i++) {
                int32_t l = tmp[i * u.wav.channels];
                int32_t r = (u.wav.channels >= 2)
                          ? tmp[i * u.wav.channels + 1] : l;
                pcm[(n + i) * 2]     = l;
                pcm[(n + i) * 2 + 1] = r;
            }
            n += (uint32_t)got;
        }
        break;
    }
    case DEC_FMT_M4A:
        n = read_m4a_trimmed(pcm, max_frames);
        break;
    case DEC_FMT_AAC:  n = read_aac(pcm, max_frames);  break;
    case DEC_FMT_OPUS: n = read_opus(pcm, max_frames); break;
    default: break;
    }
    s_frames_out += n;
    return n;
}

/* ---- seek / tell -------------------------------------------------------------- */

bool dec_seek_ms(uint32_t ms)
{
    uint64_t frame = (uint64_t)ms * s_info.sample_rate / 1000u;
    bool ok = false;
    switch (s_info.format) {
    case DEC_FMT_MP3:  ok = drmp3_seek_to_pcm_frame(&u.mp3, frame);      break;
    case DEC_FMT_FLAC: ok = drflac_seek_to_pcm_frame(u.flac, frame);     break;
    case DEC_FMT_WAV:  ok = drwav_seek_to_pcm_frame(&u.wav, frame);      break;
    case DEC_FMT_M4A: {
        /* frame -> sample index (1024 PCM frames per AAC sample, 2048 for
         * HE-AAC whose output rate is twice the core rate). The priming
         * offset is added; whole frames below the target are decoded and
         * dropped so the seek is sample-accurate.                        */
        uint32_t spf = 1024u;
        if (u.aac.mp4.track[u.aac.track].timescale &&
            s_info.sample_rate >= 2u * u.aac.mp4.track[u.aac.track].timescale)
            spf = 2048u;
        uint64_t absf = frame + s_trim_delay;
        u.aac.sample_idx = (unsigned)(absf / spf);
        if (u.aac.sample_idx > u.aac.sample_count)
            u.aac.sample_idx = u.aac.sample_count;
        u.aac.pcm_avail = u.aac.pcm_pos = 0;
        s_abs_frame = (uint64_t)u.aac.sample_idx * spf;
        /* skip to the exact frame: treat (absf - s_abs_frame) as priming */
        if (absf > s_abs_frame) {
            static int32_t junk[256 * 2];
            uint64_t left = absf - s_abs_frame;
            while (left) {
                uint32_t k = left > 256 ? 256 : (uint32_t)left;
                uint32_t got = read_aac(junk, k);
                if (!got) break;
                s_abs_frame += got;
                left -= got;
            }
        }
        ok = true;
        break;
    }
    case DEC_FMT_AAC:
        ok = adts_seek_ms(ms, &frame);
        break;
    case DEC_FMT_OPUS: {
        /* Re-read from the start (Ogg has no index), jump page by page to
         * the target granule, reset the decoder state.                   */
        if (f_lseek(&s_fil, 0) != FR_OK) break;
        if (!ogg_min_open(&u.opus.ogg, file_read, NULL)) break;
        ogg_min_set_skip(&u.opus.ogg, file_skip);
        ogg_min_skip_packet(&u.opus.ogg);      /* OpusHead                */
        ogg_min_skip_packet(&u.opus.ogg);      /* OpusTags                */
        uint64_t start = 0;
        if (!ogg_min_seek_granule(&u.opus.ogg, frame + u.opus.preskip_orig, &start))
            break;
        opus_decoder_ctl(u.opus.dec, OPUS_RESET_STATE);
        u.opus.pcm_avail = u.opus.pcm_pos = 0;
        u.opus.preskip = 0;
        frame = start > u.opus.preskip_orig ? start - u.opus.preskip_orig : 0;
        ok = true;
        break;
    }
    default: break;
    }
    if (ok) s_frames_out = frame;
    return ok;
}

uint32_t dec_tell_ms(void)
{
    if (!s_info.sample_rate) return 0;
    return (uint32_t)(s_frames_out * 1000u / s_info.sample_rate);
}

void dec_close(void)
{
    switch (s_info.format) {
    case DEC_FMT_MP3:  drmp3_uninit(&u.mp3);                     break;
    case DEC_FMT_FLAC: if (u.flac) drflac_close(u.flac);         break;
    case DEC_FMT_WAV:  drwav_uninit(&u.wav);                     break;
    case DEC_FMT_M4A:  MP4D_close(&u.aac.mp4);                   /* falls through */
    case DEC_FMT_AAC:  if (u.aac.hdec) AACFreeDecoder(u.aac.hdec); break;
    case DEC_FMT_OPUS: ogg_min_close(&u.opus.ogg);               break;
    default: break;
    }
    if (s_fil_open) { f_close(&s_fil); s_fil_open = false; }
    s_info.format = DEC_FMT_UNKNOWN;
}
