/**
 * @file    resampler.h
 * @brief   Windowed-sinc sample-rate converter (stereo, int32 samples).
 *
 * 2.6.0: the DAC now plays both rate families natively (44.1 k from the
 * crystal, 48 k via the CS43131 PLL), so 32/44.1/48/88.2/96/176.4/192 kHz
 * are bit-perfect and never pass through here. The converter is only
 * used for
 *   - odd source rates (8/11.025/12/16/22.05/24 kHz ...), raised to the
 *     nearest native rate of the same family,
 *   - 352.8/384 kHz PCM, halved to 176.4/192 kHz by a dedicated 79-tap
 *     half-band decimator (21 multiplies per output instead of 128),
 *   - a fallback should the DAC's PLL ever fail to lock (48 k family is
 *     then converted to the 44.1 k family instead of not playing).
 *
 * Algorithm: band-limited interpolation (Smith's method) with a 64-tap
 * Kaiser-windowed sinc (beta 8.6, ~80 dB stop band, pass band to 0.91 x
 * the lower Nyquist), looked up from a 128x oversampled table with
 * linear interpolation; arithmetic in single-precision float (24-bit
 * mantissa = ~144 dB, far below the DAC's noise floor). Arbitrary ratios,
 * no drift: the input position is a 32.32 fixed-point accumulator.
 */
#ifndef RESAMPLER_H
#define RESAMPLER_H

#include <stdbool.h>
#include <stdint.h>

#define RS_HALF       32                 /* kernel half width (zero xings) */
#define RS_OS         128                /* table oversampling             */
#define RS_TABLE_LEN  (RS_HALF * RS_OS + 1)
#define RS_BUF        512                /* input history, power of two    */

extern const float g_sinc_table[RS_TABLE_LEN];
#define RS_HB_ODD     20                 /* half-band: odd taps per side   */
extern const float g_hb_center;
extern const float g_hb_odd[RS_HB_ODD];

typedef struct {
    bool     active;
    bool     halfband;                   /* exact 2:1 decimation path      */
    uint32_t in_rate, out_rate;
    float    buf[2][RS_BUF];             /* input history per channel      */
    uint32_t wpos;                       /* input frames written (total)   */
    uint64_t t;                          /* next output time, 32.32 input  */
    uint64_t step;                       /* in/out ratio, 32.32            */
    float    scale;                      /* min(1, out/in)                 */
    int      half;                       /* taps each side, input samples  */
} resampler_t;

/* Native DAC rate for a source rate (== in_rate when no conversion is
 * needed). fam44_only: the 48 k family is unavailable (PLL fallback).   */
uint32_t resampler_target_rate(uint32_t in_rate, bool fam44_only);

/* Set up in_rate -> out_rate (out_rate == in_rate = passthrough).        */
void resampler_init(resampler_t *r, uint32_t in_rate, uint32_t out_rate);

/* Consumes up to in_frames stereo int32 frames, produces up to max_out.
 * *consumed reports input frames eaten. Returns output frame count.      */
uint32_t resampler_process(resampler_t *r,
                           const int32_t *in, uint32_t in_frames,
                           int32_t *out, uint32_t max_out,
                           uint32_t *consumed);

#endif /* RESAMPLER_H */
