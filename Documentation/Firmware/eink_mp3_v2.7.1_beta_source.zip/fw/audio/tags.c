/**
 * @file    tags.c
 * @brief   Compact tag parsers (ID3v2, FLAC, MP4 ilst, OpusTags) and JPEG
 *          album-art decode via picojpeg.
 */
#include "tags.h"
#include "decoder.h"
#include "ff.h"
#include "picojpeg.h"

#include <string.h>
#include <stdlib.h>

static FIL s_f;
static void (*s_idle_hook)(void);

void tags_set_idle_hook(void (*hook)(void)) { s_idle_hook = hook; }

/* ---- helpers ---------------------------------------------------------- */

static bool rd_at(uint64_t off, void *buf, uint32_t n)
{
    UINT br;
    if (f_lseek(&s_f, (FSIZE_t)off) != FR_OK) return false;
    bool ok = f_read(&s_f, buf, n, &br) == FR_OK && br == n;
    /* Between two FatFs calls: safe to let the player refill its ring.  */
    if (s_idle_hook) s_idle_hook();
    return ok;
}

static uint32_t be32(const uint8_t *p) { return ((uint32_t)p[0]<<24)|(p[1]<<16)|(p[2]<<8)|p[3]; }
static uint32_t le32(const uint8_t *p) { return (uint32_t)p[0]|(p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24); }
static uint32_t syncsafe(const uint8_t *p) { return ((uint32_t)(p[0]&0x7F)<<21)|((p[1]&0x7F)<<14)|((p[2]&0x7F)<<7)|(p[3]&0x7F); }

/* Copy text into out[], reducing UTF-16/UTF-8 to ASCII ('?' for the rest) */
static void put_text(char *out, const uint8_t *src, uint32_t len, uint8_t enc)
{
    uint32_t o = 0;
    if (enc == 1 || enc == 2) {                 /* UTF-16 (with/out BOM)  */
        uint32_t i = 0;
        bool le = true;
        if (len >= 2 && src[0] == 0xFF && src[1] == 0xFE) { i = 2; }
        else if (len >= 2 && src[0] == 0xFE && src[1] == 0xFF) { i = 2; le = false; }
        for (; i + 1 < len && o < TAG_STR_MAX - 1; i += 2) {
            uint16_t c = le ? (uint16_t)(src[i] | (src[i+1] << 8))
                            : (uint16_t)((src[i] << 8) | src[i+1]);
            if (!c) break;
            out[o++] = (c >= 0x20 && c < 0x7F) ? (char)c : '?';
        }
    } else {                                    /* ISO-8859-1 / UTF-8     */
        for (uint32_t i = 0; i < len && o < TAG_STR_MAX - 1; i++) {
            uint8_t c = src[i];
            if (!c) break;
            if (c >= 0x20 && c < 0x7F)      out[o++] = (char)c;
            else if (c >= 0xC0)             out[o++] = '?';  /* UTF-8 lead */
            /* continuation bytes dropped                                  */
        }
    }
    out[o] = '\0';
}

/* Leading decimal number of a "3/12"-style field.                        */
static uint16_t lead_num(const char *s)
{
    uint32_t v = 0;
    while (*s == ' ') s++;
    while (*s >= '0' && *s <= '9' && v < 10000) v = v * 10 + (uint32_t)(*s++ - '0');
    return (uint16_t)v;
}

/* ---- JPEG album art (picojpeg) ------------------------------------------ */

typedef struct { uint64_t off, end; } jpeg_src_t;
static jpeg_src_t s_jsrc;

static unsigned char pjpeg_need_bytes(unsigned char *buf, unsigned char req,
                                      unsigned char *got, void *user)
{
    (void)user;
    uint32_t left = (uint32_t)(s_jsrc.end - s_jsrc.off);
    uint8_t  n = req < left ? req : (uint8_t)left;
    if (!n) { *got = 0; return PJPG_NO_MORE_BLOCKS; }
    if (!rd_at(s_jsrc.off, buf, n)) return PJPG_STREAM_READ_ERROR;
    s_jsrc.off += n;
    *got = n;
    return 0;
}

/* Decode JPEG at [off,end) in the open file; box-scale to ART_SIZE^2
 * gray. Art that is >= 8x the target (typical 1000-1500 px covers) is
 * decoded in picojpeg's "reduce" mode: only each 8x8 block's DC term is
 * computed (no AC dequant / IDCT / chroma upsampling) - roughly 10x
 * faster and still 1 sample per target pixel or better.                 */
static bool decode_art(uint64_t off, uint64_t end, uint8_t *art)
{
    pjpeg_image_info_t ii;
    s_jsrc.off = off; s_jsrc.end = end;

    /* Peek at the size with a cheap header parse, then decide the mode.  */
    if (pjpeg_decode_init(&ii, pjpeg_need_bytes, NULL, 0) != 0) return false;
    if (!ii.m_width || !ii.m_height) return false;
    bool reduce = ii.m_width >= 8 * ART_SIZE && ii.m_height >= 8 * ART_SIZE;
    if (reduce) {
        s_jsrc.off = off;
        if (pjpeg_decode_init(&ii, pjpeg_need_bytes, NULL, 1) != 0) return false;
    }
    const int sh = reduce ? 3 : 0;               /* pixel = block in reduce */
    const int img_w = (ii.m_width  + (1 << sh) - 1) >> sh;
    const int img_h = (ii.m_height + (1 << sh) - 1) >> sh;
    const int step  = reduce ? 8 : 1;            /* sample stride in block  */
    const int bpx   = reduce ? 1 : 8;            /* output px per block row */

    /* Sum per target pixel; the sample count is separable (rows x cols
     * mapping to it), so only two 120-entry tables are needed instead of
     * v1's 28 KB per-pixel counter.                                      */
    static uint32_t acc[ART_SIZE * ART_SIZE];
    static uint16_t cnt_x[ART_SIZE], cnt_y[ART_SIZE];
    memset(acc, 0, sizeof acc);
    memset(cnt_x, 0, sizeof cnt_x);
    memset(cnt_y, 0, sizeof cnt_y);
    for (int px = 0; px < img_w; px++) cnt_x[px * ART_SIZE / img_w]++;
    for (int py = 0; py < img_h; py++) cnt_y[py * ART_SIZE / img_h]++;

    const int mcu_w = ii.m_MCUWidth >> sh, mcu_h = ii.m_MCUHeight >> sh;
    for (int mcu = 0; ; mcu++) {
        int rc = pjpeg_decode_mcu();
        if (rc == PJPG_NO_MORE_BLOCKS) break;
        if (rc) return false;

        int mcu_x0 = (mcu % ii.m_MCUSPerRow) * mcu_w;
        int mcu_y0 = (mcu / ii.m_MCUSPerRow) * mcu_h;

        for (int by = 0; by < ii.m_MCUHeight; by += 8) {
            for (int bx = 0; bx < ii.m_MCUWidth; bx += 8) {
                int boff = (bx / 8) * 64 + (by / 8) * 64 * (ii.m_MCUWidth / 8);
                for (int y = 0; y < bpx; y++) {
                    int py = mcu_y0 + (by >> sh) + y;
                    if (py >= img_h) break;
                    int ty = py * ART_SIZE / img_h;
                    for (int x = 0; x < bpx; x++) {
                        int px = mcu_x0 + (bx >> sh) + x;
                        if (px >= img_w) break;
                        int tx = px * ART_SIZE / img_w;
                        int i = boff + (y * 8 + x) * step;
                        /* luminance: R/G/B blocks or gray plane           */
                        uint8_t g;
                        if (ii.m_scanType == PJPG_GRAYSCALE)
                            g = ii.m_pMCUBufR[i];
                        else
                            g = (uint8_t)((ii.m_pMCUBufR[i] * 77 +
                                           ii.m_pMCUBufG[i] * 150 +
                                           ii.m_pMCUBufB[i] * 29) >> 8);
                        acc[ty * ART_SIZE + tx] += g;
                    }
                }
            }
        }
    }
    for (int ty = 0; ty < ART_SIZE; ty++)
        for (int tx = 0; tx < ART_SIZE; tx++) {
            uint32_t n = (uint32_t)cnt_x[tx] * cnt_y[ty];
            int i = ty * ART_SIZE + tx;
            art[i] = n ? (uint8_t)(acc[i] / n) : 0xFF;
        }
    return true;
}

/* Case-sensitive substring test (newlib-nano has no memmem).             */
static bool has_sub(const uint8_t *buf, uint32_t n, const char *needle)
{
    uint32_t k = (uint32_t)strlen(needle);
    for (uint32_t i = 0; i + k <= n; i++)
        if (!memcmp(buf + i, needle, k)) return true;
    return false;
}

/* ---- ID3v2 -------------------------------------------------------------- */

static bool parse_id3v2(track_tags_t *t, uint8_t *art)
{
    uint8_t h[10];
    if (!rd_at(0, h, 10) || memcmp(h, "ID3", 3)) return false;
    uint8_t ver = h[3];
    uint32_t size = syncsafe(h + 6);
    uint64_t pos = 10, end = 10 + size;

    while (pos + 10 < end) {
        uint8_t fh[10];
        if (!rd_at(pos, fh, 10)) break;
        if (!fh[0]) break;                       /* padding               */
        uint32_t flen = (ver >= 4) ? syncsafe(fh + 4) : be32(fh + 4);
        if (!flen || pos + 10 + flen > end) break;

        char *dst = NULL;
        char num[16];
        int  numf = 0;                           /* 1 track, 2 disc       */
        if (!memcmp(fh, "TIT2", 4)) dst = t->title;
        if (!memcmp(fh, "TPE1", 4)) dst = t->artist;
        if (!memcmp(fh, "TALB", 4)) dst = t->album;
        if (!memcmp(fh, "TPE2", 4)) dst = t->albumartist;
        if (!memcmp(fh, "TRCK", 4)) { dst = num; numf = 1; }
        if (!memcmp(fh, "TPOS", 4)) { dst = num; numf = 2; }

        if (dst) {
            uint8_t buf[TAG_STR_MAX * 2 + 4];
            uint32_t n = flen < sizeof buf ? flen : sizeof buf;
            if (numf && n > 30) n = 30;
            char tmp[TAG_STR_MAX];
            if (rd_at(pos + 10, buf, n) && n > 1)
                put_text(numf ? tmp : dst, buf + 1, n - 1, buf[0]);
            else
                tmp[0] = '\0';
            if (numf == 1) t->track = lead_num(tmp);
            if (numf == 2) t->disc  = (uint8_t)lead_num(tmp);
        } else if (!memcmp(fh, "APIC", 4) && art && !t->has_art) {
            /* enc(1) mime\0 type(1) desc\0 data                          */
            uint8_t buf[96];
            uint32_t n = flen < sizeof buf ? flen : sizeof buf;
            if (rd_at(pos + 10, buf, n)) {
                uint32_t i = 1;
                bool jpeg = false;
                while (i < n && buf[i]) i++;     /* mime                  */
                jpeg = has_sub(buf + 1, i - 1, "jpeg") ||
                       has_sub(buf + 1, i - 1, "jpg");
                i++;                             /* skip NUL              */
                i++;                             /* picture type          */
                while (i < n && buf[i]) i++;     /* description           */
                i++;
                if (jpeg && i < flen &&
                    decode_art(pos + 10 + i, pos + 10 + flen, art))
                    t->has_art = true;
            }
        }
        pos += 10 + flen;
    }
    return true;
}

/* ---- FLAC ---------------------------------------------------------------- */

static void vorbis_kv(track_tags_t *t, const uint8_t *kv, uint32_t len)
{
    if (len > 7 && !strncasecmp((const char *)kv, "TITLE=", 6))
        put_text(t->title, kv + 6, len - 6, 3);
    else if (len > 8 && !strncasecmp((const char *)kv, "ARTIST=", 7))
        put_text(t->artist, kv + 7, len - 7, 3);
    else if (len > 7 && !strncasecmp((const char *)kv, "ALBUM=", 6))
        put_text(t->album, kv + 6, len - 6, 3);
    else if (len > 12 && !strncasecmp((const char *)kv, "ALBUMARTIST=", 12))
        put_text(t->albumartist, kv + 12, len - 12, 3);
    else if (len > 13 && !strncasecmp((const char *)kv, "ALBUM ARTIST=", 13))
        put_text(t->albumartist, kv + 13, len - 13, 3);
    else if (len > 12 && !strncasecmp((const char *)kv, "TRACKNUMBER=", 12)) {
        char tmp[TAG_STR_MAX];
        put_text(tmp, kv + 12, len - 12 > 20 ? 20 : len - 12, 3);
        t->track = lead_num(tmp);
    } else if (len > 11 && !strncasecmp((const char *)kv, "DISCNUMBER=", 11)) {
        char tmp[TAG_STR_MAX];
        put_text(tmp, kv + 11, len - 11 > 20 ? 20 : len - 11, 3);
        t->disc = (uint8_t)lead_num(tmp);
    }
}

static bool parse_flac(track_tags_t *t, uint8_t *art)
{
    uint8_t h[4];
    if (!rd_at(0, h, 4) || memcmp(h, "fLaC", 4)) return false;
    uint64_t pos = 4;
    for (;;) {
        uint8_t bh[4];
        if (!rd_at(pos, bh, 4)) return false;
        bool last = bh[0] & 0x80;
        uint8_t type = bh[0] & 0x7F;
        uint32_t len = ((uint32_t)bh[1] << 16) | (bh[2] << 8) | bh[3];
        pos += 4;

        if (type == 4) {                          /* VORBIS_COMMENT        */
            uint8_t b[4];
            uint64_t p = pos;
            if (!rd_at(p, b, 4)) return false;
            p += 4 + le32(b);                     /* skip vendor           */
            if (!rd_at(p, b, 4)) return false;
            uint32_t count = le32(b);
            p += 4;
            for (uint32_t i = 0; i < count; i++) {
                if (!rd_at(p, b, 4)) return false;
                uint32_t kl = le32(b);
                p += 4;
                uint8_t kv[TAG_STR_MAX * 2];
                uint32_t n = kl < sizeof kv ? kl : sizeof kv;
                if (rd_at(p, kv, n)) vorbis_kv(t, kv, n);
                p += kl;
            }
        } else if (type == 6 && art && !t->has_art) {  /* PICTURE          */
            uint8_t b[8];
            uint64_t p = pos;
            if (!rd_at(p, b, 8)) return false;
            uint32_t mlen = be32(b + 4);
            p += 8;
            char mime[32] = { 0 };
            if (mlen < sizeof mime && rd_at(p, mime, mlen)) { }
            p += mlen;
            if (!rd_at(p, b, 4)) return false;
            uint32_t dlen = be32(b);              /* description           */
            p += 4 + dlen + 16;                   /* +w/h/depth/colors     */
            if (!rd_at(p, b, 4)) return false;
            uint32_t plen = be32(b);
            p += 4;
            if (strstr(mime, "jpeg") || strstr(mime, "jpg"))
                if (decode_art(p, p + plen, art)) t->has_art = true;
        }
        pos += len;
        if (last) break;
    }
    return true;
}

/* ---- MP4 ilst -------------------------------------------------------------- */

static bool parse_mp4(track_tags_t *t, uint8_t *art)
{
    /* Walk moov.udta.meta.ilst; boxes are (be32 size)(4cc).              */
    uint64_t pos = 0, fsize = f_size(&s_f);
    uint64_t stack_end[8] = { fsize };
    int depth = 0;
    static const char *path[] = { "moov", "udta", "meta", "ilst" };

    while (pos + 8 <= stack_end[depth]) {
        uint8_t bh[8];
        if (!rd_at(pos, bh, 8)) break;
        uint64_t size = be32(bh);
        if (size < 8) break;

        if (depth < 4 && !memcmp(bh + 4, path[depth], 4)) {
            depth++;
            stack_end[depth] = pos + size;
            pos += 8;
            if (depth == 3) pos += 4;             /* meta has version word */
            continue;
        }
        if (depth == 4) {
            /* ilst entry: contains a 'data' box at +8                    */
            uint8_t dh[16];
            if (rd_at(pos + 8, dh, 16) && !memcmp(dh + 4, "data", 4)) {
                uint32_t dlen = be32(dh) - 16;
                uint64_t doff = pos + 8 + 16;
                char *dst = NULL;
                if (!memcmp(bh + 4, "\xA9nam", 4)) dst = t->title;
                if (!memcmp(bh + 4, "\xA9""ART", 4)) dst = t->artist;
                if (!memcmp(bh + 4, "\xA9""alb", 4)) dst = t->album;
                if (!memcmp(bh + 4, "aART", 4)) dst = t->albumartist;
                if (!memcmp(bh + 4, "trkn", 4) || !memcmp(bh + 4, "disk", 4)) {
                    uint8_t nb[6];
                    if (dlen >= 6 && rd_at(doff, nb, 6)) {
                        uint16_t v = (uint16_t)((nb[2] << 8) | nb[3]);
                        if (bh[4] == 't') t->track = v; else t->disc = (uint8_t)v;
                    }
                } else if (dst) {
                    uint8_t buf[TAG_STR_MAX * 2];
                    uint32_t n = dlen < sizeof buf ? dlen : sizeof buf;
                    if (rd_at(doff, buf, n)) put_text(dst, buf, n, 3);
                } else if (!memcmp(bh + 4, "covr", 4) && art && !t->has_art) {
                    uint32_t fmt = be32(dh + 8);   /* 13=jpeg, 14=png      */
                    if (fmt == 13 && decode_art(doff, doff + dlen, art))
                        t->has_art = true;
                }
            }
        }
        pos += size;
        while (depth && pos >= stack_end[depth]) depth--;
    }
    return true;
}

/* ---- OpusTags ----------------------------------------------------------------- */

static bool parse_opus(track_tags_t *t)
{
    /* Cheap scan of the first 64 KB for the OpusTags packet.             */
    static uint8_t buf[4096];
    UINT br;
    uint64_t off = 0;
    f_lseek(&s_f, 0);
    while (off < 65536) {
        if (f_read(&s_f, buf, sizeof buf, &br) != FR_OK || br < 16) break;
        for (uint32_t i = 0; i + 8 < br; i++) {
            if (!memcmp(buf + i, "OpusTags", 8)) {
                uint64_t p = off + i + 8;
                uint8_t b[4];
                if (!rd_at(p, b, 4)) return true;
                p += 4 + le32(b);
                if (!rd_at(p, b, 4)) return true;
                uint32_t count = le32(b);
                p += 4;
                for (uint32_t k = 0; k < count && k < 32; k++) {
                    if (!rd_at(p, b, 4)) return true;
                    uint32_t kl = le32(b);
                    p += 4;
                    uint8_t kv[TAG_STR_MAX * 2];
                    uint32_t n = kl < sizeof kv ? kl : sizeof kv;
                    if (rd_at(p, kv, n)) vorbis_kv(t, kv, n);
                    p += kl;
                }
                return true;
            }
        }
        off += br - 8;
        f_lseek(&s_f, (FSIZE_t)off);
    }
    return true;
}

/* ---- entry -------------------------------------------------------------------- */

bool tags_read(const char *path, track_tags_t *tags, uint8_t *art_buf)
{
    memset(tags, 0, sizeof *tags);

    if (f_open(&s_f, path, FA_READ) != FR_OK) return false;

    switch (dec_format_from_path(path)) {
    case DEC_FMT_MP3:
    case DEC_FMT_AAC:  parse_id3v2(tags, art_buf); break;
    case DEC_FMT_FLAC: parse_flac(tags, art_buf);  break;
    case DEC_FMT_M4A:  parse_mp4(tags, art_buf);   break;
    case DEC_FMT_OPUS: parse_opus(tags);           break;
    case DEC_FMT_DSD:  parse_id3v2(tags, art_buf); break;  /* DSF ID3 at end: try head anyway */
    default: break;
    }
    f_close(&s_f);

    /* Fallback: filename as title.                                       */
    if (!tags->title[0]) {
        const char *base = strrchr(path, '/');
        base = base ? base + 1 : path;
        uint32_t n = 0;
        while (base[n] && base[n] != '.' && n < TAG_STR_MAX - 1) {
            tags->title[n] = base[n];
            n++;
        }
        tags->title[n] = '\0';
    }
    return true;
}
