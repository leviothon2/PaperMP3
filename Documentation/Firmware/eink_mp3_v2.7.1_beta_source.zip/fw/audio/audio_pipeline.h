/**
 * @file    audio_pipeline.h
 * @brief   Decode -> ring buffer -> SAI DMA plumbing (PCM and DoP).
 *
 * Producer: player_poll() in thread context (decodes from SD).
 * Consumer: SAI DMA half/complete callbacks in IRQ context.
 * Lock-free SPSC ring of stereo int32 frames; underruns emit silence and
 * are counted.
 *
 * DSD (V2 hardware) is carried as DoP: the producer pushes frames whose
 * bits [23:8] hold 16 DSD bits per channel; the consumer stamps the
 * alternating 0x05/0xFA DoP marker into bits [31:24]. Doing the marker in
 * the consumer guarantees strict alternation across underruns / pauses
 * (which are filled with DoP-encoded DSD silence, not PCM zeros - the DAC
 * would otherwise drop out of DoP mode and click).
 */
#ifndef AUDIO_PIPELINE_H
#define AUDIO_PIPELINE_H

#include <stdbool.h>
#include <stdint.h>
#include "dsd.h"

typedef enum { PIPE_IDLE, PIPE_PCM, PIPE_DOP } pipe_mode_t;

bool pipe_start_pcm(uint32_t src_rate);   /* configures DAC+SAI+resampler */
uint32_t pipe_out_rate(void);             /* DAC frame rate, 0 = idle     */
bool pipe_bit_perfect(void);              /* PCM, no conversion, no EQ    */
bool pipe_start_dop(dsd_rate_t rate);
void pipe_stop(void);
void pipe_pause(bool paused);             /* keeps clocks, feeds silence  */
bool pipe_paused(void);
pipe_mode_t pipe_mode(void);

/* Producer side.                                                          */
uint32_t pipe_writable_frames(void);      /* free ring space, out frames  */
uint32_t pipe_fill_frames(void);          /* frames queued for the DAC    */
/* Max *input* frames that can be pushed now without overflowing the ring
 * once resampling (up to 8 k -> 48 k = x6) is accounted for.             */
uint32_t pipe_max_input_frames(void);
void     pipe_push_pcm(const int32_t *frames, uint32_t n);
void     pipe_push_dop(const int32_t *frames, uint32_t n);  /* no resample */
uint32_t pipe_underruns(void);
bool     pipe_hungry(void);               /* below half-full watermark    */

/* Audio queued but not yet heard (ring + DMA buffer), in ms. Position
 * reporting subtracts this from the decoder position.                    */
uint32_t pipe_buffered_ms(void);
/* Frames handed to the DAC so far (free-running): stops moving if the
 * SAI loses its bit clock - the player's stall detector watches it.      */
uint32_t pipe_consumed(void);
/* Drop everything queued (after a seek). Safe against the DMA ISR.       */
void     pipe_flush(void);

#endif /* AUDIO_PIPELINE_H */
