/**
 * @file    timestretch.h
 * @brief   Speech-rate change without a pitch change (podcast speed).
 *
 * Time-domain overlap-add with a similarity search (SOLA): the input is
 * cut into 20 ms segments taken every 20 ms x speed; each new segment is
 * slid by up to 12 ms to where it best continues the previous one and
 * joined with an 8 ms cross-fade. Voices keep their pitch from 0.8x to
 * 2.0x; music is not what this is for (the player only uses it in the
 * Podcasts list, and bypasses it completely at 1.0x).
 *
 * Works on 16-bit stereo internally (the top 16 bits of the pipeline's
 * 32-bit frames) at 8-48 kHz. Its buffers (about 12 KB at 48 kHz) come
 * from the heap only while a podcast plays at a speed other than 1.0x.
 */
#ifndef TIMESTRETCH_H
#define TIMESTRETCH_H

#include <stdbool.h>
#include <stdint.h>

#define TS_MAX_RATE 48000u

/* false: rate not supported or no memory (caller then plays at 1.0x).    */
bool ts_begin(uint32_t sample_rate, uint16_t speed_x100);
void ts_end(void);
bool ts_active(void);
void ts_set_speed(uint16_t speed_x100);
void ts_reset(void);                     /* after a seek: drop history    */

/* Input frames that can be pushed right now.                              */
uint32_t ts_room(void);
void     ts_push(const int32_t *frames, uint32_t n);
/* Up to max_frames of stretched audio; 0 = push more input first.         */
uint32_t ts_pull(int32_t *frames, uint32_t max_frames);
/* Input frames held inside (for position reporting).                      */
uint32_t ts_pending_in(void);

#endif /* TIMESTRETCH_H */
