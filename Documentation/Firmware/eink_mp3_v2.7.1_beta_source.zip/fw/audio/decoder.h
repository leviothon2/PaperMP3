/**
 * @file    decoder.h
 * @brief   Unified pull-model decoder front-end.
 *
 * Formats (software configuration.txt): MP3, M4A/AAC, FLAC, WAV, Opus,
 * AAC(ADTS) - plus DSD (DSF/DFF), which bypasses PCM decode entirely and
 * is handled by audio/dsd.c.
 *
 * Backends (third_party/, see README):
 *   .mp3          dr_mp3
 *   .flac         dr_flac
 *   .wav          dr_wav
 *   .m4a/.mp4     minimp4 demux + Helix AAC
 *   .aac          Helix AAC (ADTS)
 *   .opus/.ogg    minimal Ogg page demux (ogg_min.c) + libopus
 *
 * Output is always interleaved stereo int32_t, 24-bit audio in the top
 * bits (matching the SAI 32-bit slot / CS43131 32-bit channel config).
 * Mono sources are upmixed. Sample rate is the *source* rate; the
 * pipeline resamples non-44.1-family rates (audio/resampler.c).
 */
#ifndef DECODER_H
#define DECODER_H

#include <stdbool.h>
#include <stdint.h>

typedef enum {
    DEC_FMT_UNKNOWN, DEC_FMT_MP3, DEC_FMT_FLAC, DEC_FMT_WAV,
    DEC_FMT_M4A, DEC_FMT_AAC, DEC_FMT_OPUS, DEC_FMT_DSD,
} dec_format_t;

typedef struct {
    dec_format_t format;
    uint32_t     sample_rate;
    uint8_t      channels;        /* source channels (output always 2)    */
    uint32_t     duration_ms;     /* 0 if unknown                         */
    uint32_t     bitrate_kbps;    /* 0 if unknown                         */
} dec_info_t;

dec_format_t dec_format_from_path(const char *path);

bool dec_open(const char *path, dec_info_t *info);
/* Returns frames produced (stereo pairs); 0 = end of stream.             */
uint32_t dec_read(int32_t *pcm, uint32_t max_frames);
bool dec_seek_ms(uint32_t ms);
uint32_t dec_tell_ms(void);
void dec_close(void);

#endif /* DECODER_H */
