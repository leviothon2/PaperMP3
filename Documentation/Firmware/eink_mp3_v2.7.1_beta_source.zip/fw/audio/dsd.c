/**
 * @file    dsd.c
 * @brief   DSF / DFF container parsing + DSD bitstream packing.
 *
 * DSF layout: "DSD " chunk (28 B) -> "fmt " chunk (52 B: version, format,
 * channel type/num, sample rate, bits/sample, sample count, block size)
 * -> "data" chunk with channel-interleaved blocks of `block_size` bytes
 * (typically 4096) per channel.
 *
 * DFF (DSDIFF) layout: "FRM8"/"DSD " form; "FVER", "PROP" ("FS  " sample
 * rate, "CHNL" channels), then "DSD " sound chunk with byte-interleaved
 * channels (L R L R ...), each byte MSB-first in time.
 */
#include "dsd.h"
#include "ff.h"
#include <string.h>

typedef enum { CONT_DSF, CONT_DFF } container_t;

static struct {
    FIL         fil;
    bool        open;
    container_t cont;
    dsd_info_t  info;
    uint32_t    sample_rate_hz;    /* 2822400 * (1/2/4)                   */
    uint64_t    data_start, data_len, data_pos;
    /* DSF block deinterleave state                                       */
    uint32_t    block_size;        /* per channel, bytes                  */
    uint8_t     blk[2][4096];
    uint32_t    blk_pos, blk_fill;
} s;

/* Bit-reverse table for DSF's LSB-first bytes.                           */
static const uint8_t rev8[256] = {
#define R2(n) n, n + 2*64, n + 1*64, n + 3*64
#define R4(n) R2(n), R2(n + 2*16), R2(n + 1*16), R2(n + 3*16)
#define R6(n) R4(n), R4(n + 2*4),  R4(n + 1*4),  R4(n + 3*4)
    R6(0), R6(2), R6(1), R6(3)
#undef R2
#undef R4
#undef R6
};

static uint32_t rd_le32(const uint8_t *p) { return (uint32_t)p[0] | (p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24); }
static uint64_t rd_le64(const uint8_t *p) { return (uint64_t)rd_le32(p) | ((uint64_t)rd_le32(p+4) << 32); }
static uint32_t rd_be32(const uint8_t *p) { return ((uint32_t)p[0]<<24) | (p[1]<<16) | (p[2]<<8) | p[3]; }
static uint64_t rd_be64(const uint8_t *p) { return ((uint64_t)rd_be32(p) << 32) | rd_be32(p+4); }

static bool rd(void *buf, uint32_t n)
{
    UINT br;
    return f_read(&s.fil, buf, n, &br) == FR_OK && br == n;
}

/* ---- DSF ------------------------------------------------------------------ */

static bool open_dsf(void)
{
    uint8_t h[80];

    if (!rd(h, 28) || memcmp(h, "DSD ", 4)) return false;
    if (!rd(h, 12) || memcmp(h, "fmt ", 4))  return false;
    uint64_t fmt_len = rd_le64(h + 4);
    if (fmt_len < 52 || !rd(h, (uint32_t)fmt_len - 12)) return false;

    uint32_t channels    = rd_le32(h + 12);   /* channel num              */
    s.sample_rate_hz     = rd_le32(h + 16);
    uint32_t bits        = rd_le32(h + 20);
    uint64_t samples     = rd_le64(h + 24);
    s.block_size         = rd_le32(h + 32);
    if (bits != 1 || channels < 1 || channels > 2) return false;
    if (s.block_size > sizeof s.blk[0]) return false;

    uint8_t dh[12];
    if (!rd(dh, 12) || memcmp(dh, "data", 4)) return false;
    s.data_len   = rd_le64(dh + 4) - 12;
    s.data_start = f_tell(&s.fil);
    s.info.channels = (uint8_t)channels;
    if (s.sample_rate_hz)
        s.info.duration_ms = (uint32_t)(samples / (s.sample_rate_hz / 1000u));
    s.cont = CONT_DSF;
    return true;
}

/* ---- DFF ------------------------------------------------------------------ */

static bool open_dff(void)
{
    uint8_t h[16];

    f_lseek(&s.fil, 0);
    if (!rd(h, 16) || memcmp(h, "FRM8", 4) || memcmp(h + 12, "DSD ", 4))
        return false;

    s.info.channels  = 2;
    s.sample_rate_hz = 2822400;

    /* Walk chunks until the "DSD " sound data chunk.                     */
    for (;;) {
        uint8_t ch[12];
        if (!rd(ch, 12)) return false;
        uint64_t len = rd_be64(ch + 4);
        if (!memcmp(ch, "PROP", 4)) {
            /* descend: PROP payload starts with "SND " then sub-chunks   */
            uint8_t kind[4];
            if (!rd(kind, 4)) return false;
            uint64_t left = len - 4;
            while (left >= 12) {
                uint8_t sc[12];
                if (!rd(sc, 12)) return false;
                uint64_t sl = rd_be64(sc + 4);
                if (!memcmp(sc, "FS  ", 4) && sl >= 4) {
                    uint8_t fs[4];
                    if (!rd(fs, 4)) return false;
                    s.sample_rate_hz = rd_be32(fs);
                    f_lseek(&s.fil, f_tell(&s.fil) + (sl - 4 + (sl & 1)));
                } else if (!memcmp(sc, "CHNL", 4) && sl >= 2) {
                    uint8_t cn[2];
                    if (!rd(cn, 2)) return false;
                    s.info.channels = cn[1] ? cn[1] : 2;
                    f_lseek(&s.fil, f_tell(&s.fil) + (sl - 2 + (sl & 1)));
                } else {
                    f_lseek(&s.fil, f_tell(&s.fil) + sl + (sl & 1));
                }
                left -= 12 + sl + (sl & 1);
            }
        } else if (!memcmp(ch, "DSD ", 4)) {
            s.data_start = f_tell(&s.fil);
            s.data_len   = len;
            break;
        } else {
            f_lseek(&s.fil, f_tell(&s.fil) + len + (len & 1));
        }
    }
    if (s.info.channels > 2) return false;
    if (s.sample_rate_hz)
        s.info.duration_ms = (uint32_t)((s.data_len * 8u / s.info.channels)
                                        / (s.sample_rate_hz / 1000u));
    s.cont = CONT_DFF;
    return true;
}

/* ---- public ----------------------------------------------------------------- */

bool dsd_open(const char *path, dsd_info_t *info)
{
    memset(&s, 0, sizeof s);
    if (f_open(&s.fil, path, FA_READ) != FR_OK) return false;
    s.open = true;

    const char *dot = strrchr(path, '.');
    bool ok = (dot && !strcmp(dot, ".dff")) ? open_dff() : open_dsf();
    if (!ok) { dsd_close(); return false; }

    switch (s.sample_rate_hz) {
    case 2822400:  s.info.rate = DSD_64;  break;
    case 5644800:  s.info.rate = DSD_128; break;
    case 11289600: s.info.rate = DSD_256; break;
    default: dsd_close(); return false;    /* 48 k-family DSD unsupported */
    }
    f_lseek(&s.fil, (FSIZE_t)s.data_start);
    *info = s.info;
    return true;
}

/* Fetch the next DSF block pair (or DFF interleaved run) into s.blk.     */
static bool fetch_block(void)
{
    if (s.data_pos >= s.data_len) return false;

    if (s.cont == CONT_DSF) {
        uint32_t n = s.block_size;
        if (!rd(s.blk[0], n)) return false;
        if (s.info.channels == 2) {
            if (!rd(s.blk[1], n)) return false;
            s.data_pos += 2ull * n;
        } else {
            memcpy(s.blk[1], s.blk[0], n);
            s.data_pos += n;
        }
        /* DSF: LSB-first bytes -> reverse to MSB-first time order.       */
        for (uint32_t i = 0; i < n; i++) {
            s.blk[0][i] = rev8[s.blk[0][i]];
            s.blk[1][i] = rev8[s.blk[1][i]];
        }
        s.blk_fill = n;
    } else {
        /* DFF: byte-interleaved L R L R, already MSB-first.              */
        uint8_t tmp[512];
        uint32_t want = sizeof tmp;
        if ((uint64_t)want > s.data_len - s.data_pos)
            want = (uint32_t)(s.data_len - s.data_pos);
        want &= ~1u;
        if (!want || !rd(tmp, want)) return false;
        s.data_pos += want;
        if (s.info.channels == 2) {
            for (uint32_t i = 0; i < want / 2; i++) {
                s.blk[0][i] = tmp[i * 2];
                s.blk[1][i] = tmp[i * 2 + 1];
            }
            s.blk_fill = want / 2;
        } else {
            memcpy(s.blk[0], tmp, want);
            memcpy(s.blk[1], tmp, want);
            s.blk_fill = want;
        }
    }
    s.blk_pos = 0;
    return true;
}

uint32_t dsd_read_dop(int32_t *frames, uint32_t max_frames)
{
    uint32_t done = 0;
    while (done < max_frames) {
        if (s.blk_pos + 2 > s.blk_fill) {
            if (!fetch_block()) break;
            if (s.blk_fill < 2) break;
        }
        /* 16 DSD bits per channel per DoP frame, older byte in [23:16].   */
        const uint8_t *l = &s.blk[0][s.blk_pos];
        const uint8_t *r = &s.blk[1][s.blk_pos];
        frames[done * 2]     = (int32_t)(((uint32_t)l[0] << 16) | ((uint32_t)l[1] << 8));
        frames[done * 2 + 1] = (int32_t)(((uint32_t)r[0] << 16) | ((uint32_t)r[1] << 8));
        s.blk_pos += 2;
        done++;
    }
    return done;
}

uint32_t dsd_tell_ms(void)
{
    if (!s.sample_rate_hz) return 0;
    uint64_t bits_per_ch = s.data_pos * 8u / s.info.channels;
    return (uint32_t)(bits_per_ch / (s.sample_rate_hz / 1000u));
}

bool dsd_seek_ms(uint32_t ms)
{
    if (!s.open || !s.sample_rate_hz) return false;
    /* bytes per channel for `ms`, then round down to the container unit */
    uint64_t per_ch = (uint64_t)ms * (s.sample_rate_hz / 8u) / 1000u;
    uint64_t pos;
    if (s.cont == CONT_DSF) {
        uint64_t blocks = per_ch / s.block_size;
        pos = blocks * s.block_size * s.info.channels;
    } else {
        pos = (per_ch * s.info.channels) & ~1ull;
    }
    if (pos > s.data_len) pos = s.data_len;
    if (f_lseek(&s.fil, (FSIZE_t)(s.data_start + pos)) != FR_OK) return false;
    s.data_pos = pos;
    s.blk_pos = s.blk_fill = 0;
    return true;
}

void dsd_close(void)
{
    if (s.open) f_close(&s.fil);
    s.open = false;
}
