/**
 * @file    tags.h
 * @brief   Metadata extraction: title/artist/album + embedded album art.
 *
 * Parsers: ID3v2.3/2.4 (mp3/aac), FLAC VORBIS_COMMENT + PICTURE, MP4
 * ilst (m4a), OpusTags. Strings are cut to ASCII (font covers 0x20-0x7E;
 * non-ASCII code points render as '?').
 *
 * Album art (software configuration.txt asked for a decision): YES -
 * embedded JPEG art is decoded with picojpeg, box-filtered to 120x120
 * grayscale and Floyd-Steinberg dithered (4-gray) on the e-ink. It looks
 * good on the panel and costs ~6 KB flash + RAM scratch buffers. PNG art
 * is skipped (a PNG inflater costs more flash than it is worth here).
 */
#ifndef TAGS_H
#define TAGS_H

#include <stdbool.h>
#include <stdint.h>

#define TAG_STR_MAX  96
#define ART_SIZE     120          /* 120x120 grayscale (fills the panel
                                     between status bar and title row)    */

typedef struct {
    char title [TAG_STR_MAX];
    char artist[TAG_STR_MAX];
    char album [TAG_STR_MAX];
    char albumartist[TAG_STR_MAX];   /* 2.6.0: library grouping          */
    uint16_t track;                  /* track number, 0 = unknown        */
    uint8_t  disc;                   /* disc number, 0 = unknown         */
    bool has_art;
} track_tags_t;

/* Reads tags; if art_buf is non-NULL (ART_SIZE*ART_SIZE bytes) and the
 * file embeds JPEG art, decodes+scales it and sets has_art.              */
bool tags_read(const char *path, track_tags_t *tags, uint8_t *art_buf);

/* Called between file reads while tags/art are parsed (2.6.0 gapless:
 * keeps the audio ring topped up during a slow cover-art decode). The
 * hook may read other files but must not touch this one. NULL = none.   */
void tags_set_idle_hook(void (*hook)(void));

#endif /* TAGS_H */
