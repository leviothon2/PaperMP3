/**
 * @file    dsd.h
 * @brief   DSF / DFF (DSDIFF) container parsing and DoP packing.
 *
 * DSD is a passthrough (flash_budget.md §2): no decoding, just container
 * parsing plus bit-order handling:
 *   - DSF stores each byte LSB-first in time -> bit-reverse per byte.
 *   - DFF stores MSB-first -> pass through.
 * Output (V2 board, no native DSD port): DoP frames - per channel, 16 DSD
 * bits (older byte first) in bits [23:8] of a 32-bit I2S slot. The DoP
 * marker byte [31:24] is added by audio_pipeline.c.
 *
 * Rates: DSD64 -> 176.4 kHz DoP, DSD128 -> 352.8 kHz DoP. DSD256 would
 * need 705.6 kHz DoP, beyond the CS43131 serial port: such files are
 * rejected by player.c (skipped).
 */
#ifndef DSD_H
#define DSD_H

#include <stdbool.h>
#include <stdint.h>

typedef enum { DSD_64, DSD_128, DSD_256 } dsd_rate_t;

typedef struct {
    dsd_rate_t rate;
    uint8_t    channels;
    uint32_t   duration_ms;
} dsd_info_t;

bool dsd_open(const char *path, dsd_info_t *info);
/* Fill interleaved stereo DoP payload frames; returns frames filled
 * (0 = EOF).                                                              */
uint32_t dsd_read_dop(int32_t *frames, uint32_t max_frames);
uint32_t dsd_tell_ms(void);
bool dsd_seek_ms(uint32_t ms);       /* block-granular (resume)          */
void dsd_close(void);

#endif /* DSD_H */
