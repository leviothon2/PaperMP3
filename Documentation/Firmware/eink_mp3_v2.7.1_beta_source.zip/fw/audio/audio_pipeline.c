/**
 * @file    audio_pipeline.c
 * @brief   Ring buffer between decode (thread) and SAI DMA (IRQ).
 */
#include "audio_pipeline.h"
#include "resampler.h"
#include "eq.h"
#include "../drivers/sai_audio.h"
#include "../drivers/cs43131.h"

#include "stm32u5xx_hal.h"
#include <string.h>

/* PCM ring: 16 K stereo frames = 128 KB = ~370 ms @ 44.1 k (93 ms of
 * DoP64). One ring now serves PCM and DSD: v1's separate 64 KB DSD rings
 * are gone with the native DSD port.                                     */
#define RING_FRAMES  16384u                 /* power of two               */
#define RING_MASK    (RING_FRAMES - 1u)
static int32_t  s_ring[RING_FRAMES * 2];
static volatile uint32_t s_w, s_r;         /* free-running frame indices */

static volatile uint32_t s_underruns;
static volatile bool     s_paused;
static volatile pipe_mode_t s_mode = PIPE_IDLE;
static resampler_t       s_rs;
static uint32_t          s_rs_num = 1, s_rs_den = 1;  /* out/in ratio     */
static uint32_t          s_dop_marker;      /* 0x05 / 0xFA toggle         */
static uint32_t          s_out_rate = 44100;/* frame rate on the I2S link */
static uint32_t          s_src_rate = 44100;/* what the decoder delivers  */
static volatile bool     s_flush_req;       /* thread -> ISR              */
static volatile uint32_t s_consumed;        /* frames sent (incl. silence)*/

#define DMA_FRAMES_AHEAD  768u              /* ~1.5 DMA halves in flight  */

#define DOP_M0          0x05u
#define DOP_M1          0xFAu
#define DSD_SILENCE16   0x6969u             /* alternating pattern = 0 V  */

/* ---- consumer (IRQ context) --------------------------------------------- */

/* Copy up to `frames` from the ring into dst (two memcpy segments).      */
static uint32_t ring_take(uint32_t *dst, uint32_t frames)
{
    if (s_flush_req) { s_r = s_w; s_flush_req = false; }
    s_consumed += frames;
    uint32_t avail = s_w - s_r;
    if (s_paused) avail = 0;
    uint32_t take = frames < avail ? frames : avail;
    uint32_t r = s_r & RING_MASK;
    uint32_t first = RING_FRAMES - r;
    if (first > take) first = take;
    memcpy(dst, &s_ring[r * 2], first * 2 * sizeof(int32_t));
    if (take > first)
        memcpy(dst + first * 2, &s_ring[0], (take - first) * 2 * sizeof(int32_t));
    s_r += take;
    return take;
}

static void cb_pcm(uint32_t *dst, uint32_t nwords)
{
    uint32_t frames = nwords / 2;
    uint32_t take = ring_take(dst, frames);
    if (take < frames) {
        if (!s_paused) s_underruns++;
        memset(dst + take * 2, 0, (frames - take) * 2 * sizeof(uint32_t));
    }
}

static void cb_dop(uint32_t *dst, uint32_t nwords)
{
    uint32_t frames = nwords / 2;
    uint32_t take = ring_take(dst, frames);
    if (take < frames && !s_paused) s_underruns++;

    uint32_t m = s_dop_marker;
    for (uint32_t i = 0; i < frames; i++) {
        uint32_t mk = (m ? DOP_M1 : DOP_M0) << 24;
        if (i < take) {
            dst[i * 2]     = (dst[i * 2]     & 0x00FFFF00u) | mk;
            dst[i * 2 + 1] = (dst[i * 2 + 1] & 0x00FFFF00u) | mk;
        } else {
            dst[i * 2] = dst[i * 2 + 1] = mk | (DSD_SILENCE16 << 8);
        }
        m ^= 1u;
    }
    s_dop_marker = m;
}

/* ---- control -------------------------------------------------------------- */

static void reset_ring(void)
{
    s_flush_req = false;
    s_w = s_r = 0;
    s_underruns = 0;
    s_paused = false;
    s_dop_marker = 0;
}

/* 2.6.0: native playback of both rate families. The source rate goes to
 * the DAC unchanged whenever it is one of 32/44.1/48/88.2/96/176.4/192 k
 * (bit-perfect); only odd or >192 k rates are converted. If the DAC's PLL
 * won't lock, 48 k-family sources fall back to conversion onto the
 * crystal's 44.1 k family rather than failing to play.                  */
bool pipe_start_pcm(uint32_t src_rate)
{
    pipe_stop();
    if (!src_rate) src_rate = 44100;
    s_src_rate = src_rate;

    uint32_t hw = resampler_target_rate(src_rate, false);
    reset_ring();
    if (!cs43131_start_pcm(hw)) {
        uint32_t hw44 = resampler_target_rate(src_rate, true);
        if (hw44 == hw || !cs43131_start_pcm(hw44)) return false;
        hw = hw44;
    }
    resampler_init(&s_rs, src_rate, hw);
    s_rs_num = hw;
    s_rs_den = src_rate;
    s_out_rate = hw;
    eq_set_rate(hw);

    s_mode = PIPE_PCM;
    if (!sai_start(cb_pcm)) { pipe_stop(); return false; }
    return true;
}

uint32_t pipe_out_rate(void) { return s_mode == PIPE_IDLE ? 0 : s_out_rate; }
bool     pipe_bit_perfect(void)
{
    return s_mode == PIPE_PCM && !s_rs.active && !eq_active();
}

bool pipe_start_dop(dsd_rate_t rate)
{
    pipe_stop();
    if (rate != DSD_64 && rate != DSD_128) return false;   /* no DoP256  */

    s_rs_num = s_rs_den = 1;
    s_out_rate = (rate == DSD_128) ? 352800 : 176400;
    reset_ring();
    if (!cs43131_start_dop(rate == DSD_128 ? CS_DSD_128 : CS_DSD_64))
        return false;
    s_mode = PIPE_DOP;
    if (!sai_start(cb_dop)) { pipe_stop(); return false; }
    return true;
}

void pipe_stop(void)
{
    if (s_mode == PIPE_IDLE) return;
    /* Mute + pop-free HP power-down first, while the SAI still clocks
     * silence, then stop the DMA.                                         */
    s_paused = true;
    cs43131_stop();
    sai_stop();
    s_mode = PIPE_IDLE;
}

void pipe_pause(bool paused)
{
    s_paused = paused;
    cs43131_mute(paused);
}

bool pipe_paused(void) { return s_paused; }
pipe_mode_t pipe_mode(void) { return s_mode; }
uint32_t pipe_underruns(void) { return s_underruns; }

/* ---- producer -------------------------------------------------------------- */

uint32_t pipe_writable_frames(void)
{
    if (s_mode == PIPE_IDLE) return 0;
    return RING_FRAMES - 1u - (s_w - s_r);
}

uint32_t pipe_fill_frames(void) { return s_w - s_r; }

uint32_t pipe_buffered_ms(void)
{
    if (s_mode == PIPE_IDLE || !s_out_rate) return 0;
    uint32_t frames = (s_w - s_r) + DMA_FRAMES_AHEAD;
    return (uint32_t)(((uint64_t)frames * 1000u) / s_out_rate);
}

uint32_t pipe_consumed(void) { return s_consumed; }

void pipe_flush(void)
{
    if (s_mode == PIPE_IDLE) return;
    s_flush_req = true;
    /* The DMA half-transfer ISR acknowledges within one half buffer
     * (<= 11.6 ms at 44.1 kHz; it keeps running while paused).          */
    uint32_t t0 = HAL_GetTick();
    while (s_flush_req && HAL_GetTick() - t0 < 50u) { }
    if (s_flush_req) {                         /* SAI not clocking        */
        __disable_irq();
        s_r = s_w;
        s_flush_req = false;
        __enable_irq();
    }
}

uint32_t pipe_max_input_frames(void)
{
    uint32_t space = pipe_writable_frames();
    if (space < 8) return 0;
    /* in <= (space - 4) * den / num, resampler phase slack included.     */
    return (uint32_t)(((uint64_t)(space - 4u) * s_rs_den) / s_rs_num);
}

bool pipe_hungry(void)
{
    if (s_mode == PIPE_IDLE) return false;
    return (s_w - s_r) < RING_FRAMES / 2;
}

static void ring_put(const int32_t *frames, uint32_t n)
{
    uint32_t w = s_w & RING_MASK;
    uint32_t first = RING_FRAMES - w;
    if (first > n) first = n;
    memcpy(&s_ring[w * 2], frames, first * 2 * sizeof(int32_t));
    if (n > first)
        memcpy(&s_ring[0], frames + first * 2, (n - first) * 2 * sizeof(int32_t));
    __DMB();                                   /* data before index        */
    s_w += n;
}

void pipe_push_pcm(const int32_t *frames, uint32_t n)
{
    static int32_t rs_out[1024 * 2];
    if (!s_rs.active) {                        /* native rate             */
        uint32_t room = pipe_writable_frames();
        if (n > room) n = room;
        if (!eq_active()) { ring_put(frames, n); return; }   /* bit-perfect */
        while (n) {
            uint32_t k = n < 1024 ? n : 1024;
            memcpy(rs_out, frames, k * 2 * sizeof(int32_t));
            eq_process(rs_out, k);
            ring_put(rs_out, k);
            frames += k * 2;
            n -= k;
        }
        return;
    }
    while (n) {
        uint32_t consumed = 0;
        uint32_t room = pipe_writable_frames();
        if (!room) break;
        uint32_t out = resampler_process(&s_rs, frames, n, rs_out,
                                         room < 1024 ? room : 1024,
                                         &consumed);
        eq_process(rs_out, out);
        ring_put(rs_out, out);
        frames += consumed * 2;
        n      -= consumed;
        if (!consumed && !out) break;           /* safety                 */
    }
}

void pipe_push_dop(const int32_t *frames, uint32_t n)
{
    uint32_t room = pipe_writable_frames();
    ring_put(frames, n < room ? n : room);
}
