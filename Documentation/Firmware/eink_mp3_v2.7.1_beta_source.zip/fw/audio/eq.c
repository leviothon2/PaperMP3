/**
 * @file    eq.c
 * @brief   10-band fixed-point graphic EQ (see eq.h).
 */
#include "eq.h"
#include <math.h>
#include <string.h>

#define COEF_SHIFT  29                     /* Q29: range +-4               */
#define HEADROOM    3                      /* bits (18 dB) inside the EQ   */
#define EQ_Q        1.41f

const uint16_t eq_band_hz[EQ_BANDS] = {
    31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000
};

static const char *const k_names[EQ_PRESET_COUNT] = {
    "Off", "Bass", "Warm", "Bright", "Vocal", "Loudness", "Custom"
};
static const int8_t k_presets[EQ_PRESET_COUNT - 1][EQ_BANDS] = {
    {  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },   /* Off (flat)           */
    {  6,  5,  3,  1,  0,  0,  0,  0,  0,  0 },   /* Bass                 */
    {  3,  3,  2,  1,  0,  0, -1, -1, -2, -2 },   /* Warm                 */
    {  0,  0,  0,  0,  0,  1,  2,  3,  4,  4 },   /* Bright               */
    { -2, -2, -1,  0,  2,  3,  3,  2,  0, -1 },   /* Vocal                */
    {  5,  4,  2,  0, -1, -1,  0,  2,  4,  5 },   /* Loudness             */
};

const char *eq_preset_name(uint8_t p)
{
    return p < EQ_PRESET_COUNT ? k_names[p] : "?";
}

const int8_t *eq_preset_gains(uint8_t p)
{
    return p < EQ_PRESET_CUSTOM ? k_presets[p] : NULL;
}

/* ---- state ---------------------------------------------------------------- */

typedef struct { int32_t b0, b1, b2, a1, a2; } biquad_t;   /* Q29, a0 = 1 */
typedef struct { int32_t x1, x2, y1, y2; uint32_t frac; } bqstate_t;

typedef struct {
    uint8_t  n;                            /* active sections              */
    biquad_t c[EQ_BANDS];
    int32_t  pre;                          /* pre-amp, Q30 (<= 1.0)        */
    int      pre_tenths;
} eqset_t;

static eqset_t   s_set[2];                 /* double buffer                */
static volatile uint8_t s_cur;             /* index in use by eq_process   */
static bqstate_t s_st[EQ_BANDS][2];
static uint32_t  s_fs = 44100;
static bool      s_enabled;
static int8_t    s_gain[EQ_BANDS];

/* ---- design ------------------------------------------------------------------ */

typedef struct { double b0, b1, b2, a1, a2; } bqf_t;

static bqf_t design_peak(double f0, double gain_db, double fs)
{
    double A  = pow(10.0, gain_db / 40.0);
    double w0 = 2.0 * M_PI * f0 / fs;
    double cw = cos(w0), sw = sin(w0);
    double al = sw / (2.0 * EQ_Q);
    double a0 = 1.0 + al / A;
    bqf_t r = {
        (1.0 + al * A) / a0, (-2.0 * cw) / a0, (1.0 - al * A) / a0,
        (-2.0 * cw) / a0,    (1.0 - al / A) / a0,
    };
    return r;
}

/* |H(e^jw)|^2 of one section, trig terms precomputed by the caller.     */
static double mag2(const bqf_t *q, double c1, double s1, double c2, double s2)
{
    double nr = q->b0 + q->b1 * c1 + q->b2 * c2, ni = -(q->b1 * s1 + q->b2 * s2);
    double dr = 1.0 + q->a1 * c1 + q->a2 * c2,  di = -(q->a1 * s1 + q->a2 * s2);
    return (nr * nr + ni * ni) / (dr * dr + di * di);
}

static int32_t q29(double v)
{
    double s = v * (double)(1u << COEF_SHIFT);
    if (s >  2147483647.0) s =  2147483647.0;
    if (s < -2147483648.0) s = -2147483648.0;
    return (int32_t)lrint(s);
}

static void rebuild(void)
{
    uint8_t nxt = (uint8_t)(s_cur ^ 1u);
    eqset_t *e = &s_set[nxt];
    memset(e, 0, sizeof *e);
    e->pre = 1 << 30;

    bqf_t f[EQ_BANDS];
    uint8_t n = 0;
    if (s_enabled && s_fs <= EQ_MAX_RATE) {
        for (int b = 0; b < EQ_BANDS; b++) {
            if (!s_gain[b]) continue;
            if (eq_band_hz[b] >= 0.45 * s_fs) continue;
            f[n] = design_peak(eq_band_hz[b], s_gain[b], s_fs);
            n++;
        }
    }
    if (n) {
        /* Peak of the cascade over 20 Hz .. min(20 kHz, 0.45 fs), 96
         * log-spaced points plus every band centre.                       */
        double fmax = 20000.0 < 0.45 * s_fs ? 20000.0 : 0.45 * s_fs;
        double peak = 1.0;
        for (int i = 0; i < 96 + EQ_BANDS; i++) {
            double hz = (i < 96) ? 20.0 * pow(fmax / 20.0, i / 95.0)
                                 : (double)eq_band_hz[i - 96];
            if (hz > fmax) continue;
            double w = 2.0 * M_PI * hz / s_fs, m = 1.0;
            double c1 = cos(w), s1 = sin(w), c2 = cos(2 * w), s2 = sin(2 * w);
            for (int k = 0; k < n; k++) m *= mag2(&f[k], c1, s1, c2, s2);
            if (m > peak) peak = m;
        }
        double pre = 1.0 / sqrt(peak);           /* linear, <= 1           */
        e->pre = (int32_t)lrint(pre * (double)(1u << 30));
        e->pre_tenths = (int)lrint(20.0 * log10(pre) * 10.0);
        for (int k = 0; k < n; k++) {
            e->c[k].b0 = q29(f[k].b0); e->c[k].b1 = q29(f[k].b1);
            e->c[k].b2 = q29(f[k].b2); e->c[k].a1 = q29(f[k].a1);
            e->c[k].a2 = q29(f[k].a2);
        }
    }
    bool layout_changed = (n != s_set[s_cur].n);
    e->n = n;
    __asm volatile ("" ::: "memory");
    s_cur = nxt;                               /* atomic byte store       */
    if (layout_changed) memset(s_st, 0, sizeof s_st);
}

void eq_configure(bool enabled, const int8_t gains[EQ_BANDS])
{
    s_enabled = enabled;
    for (int b = 0; b < EQ_BANDS; b++) {
        int g = gains ? gains[b] : 0;
        if (g >  EQ_GAIN_MAX) g =  EQ_GAIN_MAX;
        if (g < -EQ_GAIN_MAX) g = -EQ_GAIN_MAX;
        s_gain[b] = (int8_t)g;
    }
    rebuild();
}

void eq_set_rate(uint32_t fs)
{
    if (fs) s_fs = fs;
    memset(s_st, 0, sizeof s_st);
    rebuild();
}

void eq_reset(void) { memset(s_st, 0, sizeof s_st); }
bool eq_active(void) { return s_set[s_cur].n != 0; }
bool eq_rate_limited(void) { return s_enabled && s_fs > EQ_MAX_RATE; }
int  eq_preamp_tenths(void) { return s_set[s_cur].pre_tenths; }

/* ---- processing -------------------------------------------------------------- */

static inline int32_t sat32(int64_t v)
{
    if (v >  2147483647LL) return 2147483647;
    if (v < -2147483648LL) return (int32_t)0x80000000;
    return (int32_t)v;
}

/* Both channels per coefficient fetch. The 18 dB of internal headroom
 * covers any intermediate boost of one section that a later section
 * takes back (the pre-amp normalises the whole cascade), so only the
 * final output is saturated. The requantisation remainder ("fraction",
 * always 0..2^29-1 with an arithmetic shift) is fed into the next sample
 * of the same section: first-order noise shaping at no extra cost.       */
static inline int32_t section(const biquad_t *c, bqstate_t *st, int32_t x)
{
    int64_t acc = (int64_t)st->frac;
    acc += (int64_t)c->b0 * x;
    acc += (int64_t)c->b1 * st->x1;
    acc += (int64_t)c->b2 * st->x2;
    acc -= (int64_t)c->a1 * st->y1;
    acc -= (int64_t)c->a2 * st->y2;
    int32_t y = (int32_t)(acc >> COEF_SHIFT);
    st->frac = (uint32_t)acc & ((1u << COEF_SHIFT) - 1u);
    st->x2 = st->x1; st->x1 = x;
    st->y2 = st->y1; st->y1 = y;
    return y;
}

void eq_process(int32_t *frames, uint32_t n)
{
    const eqset_t *e = &s_set[s_cur];
    const uint8_t ns = e->n;
    if (!ns) return;                           /* bit-perfect bypass      */
    const int32_t pre = e->pre;

    for (uint32_t i = 0; i < n; i++, frames += 2) {
        int32_t l = (int32_t)(((int64_t)frames[0] * pre) >> (30 + HEADROOM));
        int32_t r = (int32_t)(((int64_t)frames[1] * pre) >> (30 + HEADROOM));
        for (uint8_t k = 0; k < ns; k++) {
            l = section(&e->c[k], &s_st[k][0], l);
            r = section(&e->c[k], &s_st[k][1], r);
        }
        frames[0] = sat32((int64_t)l << HEADROOM);
        frames[1] = sat32((int64_t)r << HEADROOM);
    }
}
