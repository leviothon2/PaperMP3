/**
 * @file    resampler.c
 * @brief   Band-limited (windowed-sinc) rational/arbitrary resampler.
 */
#include "resampler.h"
#include <math.h>
#include <string.h>

static bool native(uint32_t f, bool fam44_only)
{
    switch (f) {
    case 44100: case 88200: case 176400:          return true;
    case 32000: case 48000: case 96000: case 192000: return !fam44_only;
    default:                                      return false;
    }
}

uint32_t resampler_target_rate(uint32_t in, bool fam44_only)
{
    if (native(in, fam44_only)) return in;
    bool fam44 = (in % 11025u) == 0;               /* 11.025/22.05/352.8  */
    if (fam44_only) fam44 = true;
    if (in > 192000) return fam44 ? 176400 : 192000;  /* 352.8 / 384 k    */
    if (fam44_only) {
        /* PLL fallback: 32/48 -> 44.1, 96 -> 88.2, 192 -> 176.4          */
        if (in >= 176400) return 176400;
        if (in >= 88200)  return 88200;
        return 44100;
    }
    /* Low/odd rates: up to the base rate of their family.                */
    return fam44 ? 44100 : 48000;
}

void resampler_init(resampler_t *r, uint32_t in_rate, uint32_t out_rate)
{
    memset(r, 0, sizeof *r);
    r->in_rate  = in_rate;
    r->out_rate = out_rate;
    if (!in_rate || !out_rate || in_rate == out_rate) return;
    r->active = true;
    if (in_rate == 2u * out_rate) { r->halfband = true; return; }
    r->step   = ((uint64_t)in_rate << 32) / out_rate;
    r->scale  = (out_rate < in_rate) ? (float)out_rate / (float)in_rate : 1.0f;
    r->half   = (int)ceilf((float)RS_HALF / r->scale);
    if (r->half > RS_BUF / 2 - 4) r->half = RS_BUF / 2 - 4;
    /* Start the output clock half a kernel in: the first outputs see a
     * history of zeros (silence) rather than unwritten memory.          */
    r->t = 0;
}

/* Kernel value at distance x (input samples, already scaled).           */
static inline float kern(float x)
{
    if (x < 0) x = -x;
    float p = x * (float)RS_OS;
    int   i = (int)p;
    if (i >= RS_TABLE_LEN - 1) return 0.0f;
    float f = p - (float)i;
    return g_sinc_table[i] + f * (g_sinc_table[i + 1] - g_sinc_table[i]);
}

static inline int32_t to_s32(float v)
{
    v *= 2147483648.0f;
    if (v >=  2147483520.0f) return 0x7FFFFF80;
    if (v <= -2147483648.0f) return (int32_t)0x80000000;
    return (int32_t)lrintf(v);
}

uint32_t resampler_process(resampler_t *r,
                           const int32_t *in, uint32_t in_frames,
                           int32_t *out, uint32_t max_out,
                           uint32_t *consumed)
{
    if (!r->active) {
        uint32_t n = in_frames < max_out ? in_frames : max_out;
        memcpy(out, in, n * 2 * sizeof(int32_t));
        *consumed = n;
        return n;
    }

    const float k_in = 1.0f / 2147483648.0f;
    uint32_t used = 0, produced = 0;

    if (r->halfband) {
        /* Output k is centred on input 2k + 39 and needs inputs up to
         * 2k + 78 (79-tap window): produce whenever wpos reaches the next
         * threshold (kept in t: 79, 81, 83, ...).                         */
        if (!r->t) r->t = 79u;
        while (produced < max_out) {
            if (r->wpos < (uint32_t)r->t) {
                if (used >= in_frames) break;
                uint32_t w = r->wpos & (RS_BUF - 1);
                r->buf[0][w] = (float)in[used * 2]     * k_in;
                r->buf[1][w] = (float)in[used * 2 + 1] * k_in;
                r->wpos++;
                used++;
                continue;
            }
            uint32_t c = r->wpos - 40u;                 /* centre index    */
            float a0 = g_hb_center * r->buf[0][c & (RS_BUF - 1)];
            float a1 = g_hb_center * r->buf[1][c & (RS_BUF - 1)];
            for (int k = 0; k < RS_HB_ODD; k++) {
                uint32_t lo = (c - 1u - 2u * (uint32_t)k) & (RS_BUF - 1);
                uint32_t hi = (c + 1u + 2u * (uint32_t)k) & (RS_BUF - 1);
                a0 += g_hb_odd[k] * (r->buf[0][lo] + r->buf[0][hi]);
                a1 += g_hb_odd[k] * (r->buf[1][lo] + r->buf[1][hi]);
            }
            out[produced * 2]     = to_s32(a0);
            out[produced * 2 + 1] = to_s32(a1);
            produced++;
            r->t += 2u;
        }
        *consumed = used;
        return produced;
    }
    const int half = r->half;

    while (produced < max_out) {
        uint32_t ti = (uint32_t)(r->t >> 32);         /* floor(t)          */
        /* Need input up to ti + half before this output can be made.     */
        if (ti + (uint32_t)half >= r->wpos) {
            if (used >= in_frames) break;
            uint32_t w = r->wpos & (RS_BUF - 1);
            r->buf[0][w] = (float)in[used * 2]     * k_in;
            r->buf[1][w] = (float)in[used * 2 + 1] * k_in;
            r->wpos++;
            used++;
            continue;
        }
        float frac = (float)(uint32_t)r->t * (1.0f / 4294967296.0f);
        float acc0 = 0.0f, acc1 = 0.0f;
        for (int k = -half + 1; k <= half; k++) {
            int32_t idx = (int32_t)ti + k;
            if (idx < 0) continue;                    /* before the start  */
            float c = kern(((float)k - frac) * r->scale);
            uint32_t b = (uint32_t)idx & (RS_BUF - 1);
            acc0 += c * r->buf[0][b];
            acc1 += c * r->buf[1][b];
        }
        out[produced * 2]     = to_s32(acc0 * r->scale);
        out[produced * 2 + 1] = to_s32(acc1 * r->scale);
        produced++;
        r->t += r->step;
    }
    *consumed = used;
    return produced;
}
