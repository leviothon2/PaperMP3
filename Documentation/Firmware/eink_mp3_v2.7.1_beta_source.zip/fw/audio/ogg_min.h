/**
 * @file    ogg_min.h
 * @brief   Minimal read-only Ogg page/packet demuxer - just enough for a
 *          single-stream Opus file, so we don't need libogg/opusfile
 *          (saves ~20 KB flash and their allocator requirements).
 *
 * Limitations (fine for .opus music files):
 *   - single logical bitstream (first BOS wins)
 *   - packets larger than OGG_MIN_PKT_MAX are truncated
 *   - no CRC verification (we trust the SD card + FatFs)
 */
#ifndef OGG_MIN_H
#define OGG_MIN_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define OGG_MIN_PKT_MAX  4096u

typedef size_t (*ogg_read_fn)(void *user, void *buf, size_t n);
/* Optional: skip n bytes forward (file seek). Used to jump over page
 * payloads while seeking; without it the payload is read and dropped.   */
typedef bool   (*ogg_skip_fn)(void *user, uint32_t n);

typedef struct {
    ogg_read_fn read;
    void       *user;
    uint32_t    serial;
    bool        have_serial;
    /* current page */
    uint8_t     seg_table[255];
    uint8_t     nsegs, seg_idx;
    /* packet assembly */
    uint8_t     pkt[OGG_MIN_PKT_MAX];
    uint64_t    granule;         /* last page granule position            */
    uint64_t    last_granule;    /* from the final page (duration)        */
    bool        eos;
    bool        page_cont;       /* page starts with a continued packet   */
    ogg_skip_fn skip;
} ogg_min_t;

bool ogg_min_open(ogg_min_t *o, ogg_read_fn read, void *user);
bool ogg_min_first_packet(ogg_min_t *o, const uint8_t **pkt, uint32_t *len);
bool ogg_min_next_packet(ogg_min_t *o, const uint8_t **pkt, uint32_t *len);
void ogg_min_skip_packet(ogg_min_t *o);
uint32_t ogg_min_duration_ms(ogg_min_t *o, uint32_t rate);
void ogg_min_set_skip(ogg_min_t *o, ogg_skip_fn skip);
/* Advance to the first page whose granule position is >= target and
 * position the packet cursor at the first packet that STARTS on it.
 * *page_granule = granule where decoding resumes (end of the previous
 * page). false = past the end.                                           */
bool ogg_min_seek_granule(ogg_min_t *o, uint64_t target, uint64_t *page_granule);
void ogg_min_close(ogg_min_t *o);

#endif /* OGG_MIN_H */
