/**
 * @file    ogg_min.c
 * @brief   Minimal Ogg demuxer (see ogg_min.h for scope).
 */
#include "ogg_min.h"
#include <string.h>

/* Read one page header; position the segment cursor at its first segment.
 * Returns false on EOF / lost sync.                                      */
static bool next_page(ogg_min_t *o)
{
    uint8_t hdr[27];

    for (;;) {
        if (o->read(o->user, hdr, 4) != 4) return false;
        /* resync scan for "OggS"                                         */
        while (memcmp(hdr, "OggS", 4) != 0) {
            memmove(hdr, hdr + 1, 3);
            if (o->read(o->user, hdr + 3, 1) != 1) return false;
        }
        if (o->read(o->user, hdr + 4, 23) != 23) return false;

        uint8_t  type    = hdr[5];
        uint64_t granule = 0;
        for (int i = 7; i >= 0; i--) granule = (granule << 8) | hdr[6 + i];
        uint32_t serial = (uint32_t)hdr[14] | ((uint32_t)hdr[15] << 8) |
                          ((uint32_t)hdr[16] << 16) | ((uint32_t)hdr[17] << 24);
        o->nsegs = hdr[26];
        if (o->read(o->user, o->seg_table, o->nsegs) != o->nsegs)
            return false;

        if (!o->have_serial) { o->serial = serial; o->have_serial = true; }
        if (serial != o->serial) {
            /* foreign stream: skip its payload                            */
            uint32_t skip = 0;
            for (uint8_t i = 0; i < o->nsegs; i++) skip += o->seg_table[i];
            uint8_t sink[64];
            while (skip) {
                size_t n = skip > sizeof sink ? sizeof sink : skip;
                if (o->read(o->user, sink, n) != n) return false;
                skip -= (uint32_t)n;
            }
            continue;
        }
        if (granule != (uint64_t)-1) o->granule = granule;
        if (type & 0x04) o->eos = true;
        o->page_cont = (type & 0x01) != 0;
        o->seg_idx = 0;
        return true;
    }
}

bool ogg_min_open(ogg_min_t *o, ogg_read_fn read, void *user)
{
    memset(o, 0, sizeof *o);
    o->read = read;
    o->user = user;
    return next_page(o);
}

bool ogg_min_next_packet(ogg_min_t *o, const uint8_t **pkt, uint32_t *len)
{
    uint32_t fill = 0;
    for (;;) {
        if (o->seg_idx >= o->nsegs) {
            if (o->eos) return false;
            if (!next_page(o)) return false;
        }
        uint8_t seg = o->seg_table[o->seg_idx++];
        uint32_t room = OGG_MIN_PKT_MAX - fill;
        uint32_t take = seg > room ? room : seg;
        if (o->read(o->user, o->pkt + fill, take) != take) return false;
        if (seg > take) {                       /* truncate oversize      */
            uint8_t sink[64];
            uint32_t rest = seg - take;
            while (rest) {
                size_t n = rest > sizeof sink ? sizeof sink : rest;
                if (o->read(o->user, sink, n) != n) return false;
                rest -= (uint32_t)n;
            }
        }
        fill += take;
        if (seg < 255) {                        /* packet complete        */
            *pkt = o->pkt;
            *len = fill;
            return true;
        }
    }
}

bool ogg_min_first_packet(ogg_min_t *o, const uint8_t **pkt, uint32_t *len)
{
    return ogg_min_next_packet(o, pkt, len);
}

void ogg_min_skip_packet(ogg_min_t *o)
{
    const uint8_t *p; uint32_t l;
    (void)ogg_min_next_packet(o, &p, &l);
}

uint32_t ogg_min_duration_ms(ogg_min_t *o, uint32_t rate)
{
    /* Proper duration needs the last page's granule; scanning the file
     * end would need a second file handle. We instead update o->granule
     * as pages stream by - callers can re-ask at EOF. Return 0 (unknown)
     * up front.                                                          */
    (void)o; (void)rate;
    return 0;
}

void ogg_min_close(ogg_min_t *o) { memset(o, 0, sizeof *o); }

void ogg_min_set_skip(ogg_min_t *o, ogg_skip_fn skip) { o->skip = skip; }

static bool skip_bytes(ogg_min_t *o, uint32_t n)
{
    if (!n) return true;
    if (o->skip) return o->skip(o->user, n);
    uint8_t sink[128];
    while (n) {
        size_t k = n > sizeof sink ? sizeof sink : n;
        if (o->read(o->user, sink, k) != k) return false;
        n -= (uint32_t)k;
    }
    return true;
}

bool ogg_min_seek_granule(ogg_min_t *o, uint64_t target, uint64_t *page_granule)
{
    /* Finish the current page.                                           */
    uint32_t rest = 0;
    for (uint8_t i = o->seg_idx; i < o->nsegs; i++) rest += o->seg_table[i];
    o->seg_idx = o->nsegs;
    if (!skip_bytes(o, rest)) return false;

    uint64_t start = o->granule;               /* granule where this page's
                                                  packets begin            */
    for (;;) {
        if (o->eos) return false;
        uint64_t prev = o->granule;
        if (!next_page(o)) return false;
        start = prev;
        if (o->granule >= target) break;
        uint32_t body = 0;
        for (uint8_t i = 0; i < o->nsegs; i++) body += o->seg_table[i];
        o->seg_idx = o->nsegs;
        if (!skip_bytes(o, body)) return false;
    }
    /* Drop the tail of a packet continued from the previous page.        */
    if (o->page_cont) {
        while (o->seg_idx < o->nsegs) {
            uint8_t seg = o->seg_table[o->seg_idx++];
            if (!skip_bytes(o, seg)) return false;
            if (seg < 255) break;
        }
    }
    if (page_granule) *page_granule = start;
    return true;
}
