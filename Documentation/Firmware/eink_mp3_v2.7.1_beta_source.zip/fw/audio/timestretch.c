/**
 * @file    timestretch.c
 * @brief   SOLA time-scale modification (see timestretch.h).
 */
#include "timestretch.h"

#include <stdlib.h>
#include <string.h>

/* Segment geometry in milliseconds (scaled by the sample rate).          */
#define HOP_MS      20u      /* output per segment                         */
#define OVERLAP_MS   8u      /* cross-fade                                 */
#define SEARCH_MS   12u      /* similarity search range (one pitch period
                                of a low male voice)                       */
#define CORR_STEP    2u      /* search / correlation decimation            */

static int16_t *s_in;        /* input FIFO, stereo, s_cap frames            */
static int16_t *s_tail;      /* natural continuation of the last segment    */
static uint32_t s_cap, s_fill;
static uint32_t s_hop, s_ovl, s_search;
static uint32_t s_speed;     /* x100                                        */
static uint32_t s_adv_frac;  /* fractional input advance, 1/100 frame       */
static bool     s_have_tail;
/* One synthesised segment waits here until the caller has pulled it.      */
static int16_t *s_out;
static uint32_t s_out_n, s_out_pos;

bool ts_active(void) { return s_in != NULL; }

void ts_end(void)
{
    free(s_in);  free(s_tail);  free(s_out);
    s_in = s_tail = s_out = NULL;
    s_fill = s_out_n = s_out_pos = 0;
    s_have_tail = false;
}

void ts_set_speed(uint16_t speed_x100)
{
    if (speed_x100 < 50) speed_x100 = 50;
    if (speed_x100 > 200) speed_x100 = 200;
    s_speed = speed_x100;
}

void ts_reset(void)
{
    s_fill = s_out_n = s_out_pos = 0;
    s_adv_frac = 0;
    s_have_tail = false;
}

bool ts_begin(uint32_t rate, uint16_t speed_x100)
{
    ts_end();
    if (rate < 8000u || rate > TS_MAX_RATE) return false;
    s_hop    = rate * HOP_MS / 1000u;
    s_ovl    = rate * OVERLAP_MS / 1000u;
    s_search = rate * SEARCH_MS / 1000u;
    /* One segment needs search + hop + overlap frames ahead of the read
     * point; 512 more so a decoder chunk always fits.                     */
    s_cap = s_search + s_hop + s_ovl + 512u;
    s_in   = malloc(s_cap * 2u * sizeof(int16_t));
    s_tail = malloc(s_ovl * 2u * sizeof(int16_t));
    s_out  = malloc(s_hop * 2u * sizeof(int16_t));
    if (!s_in || !s_tail || !s_out) { ts_end(); return false; }
    ts_set_speed(speed_x100);
    ts_reset();
    return true;
}

uint32_t ts_room(void)       { return s_in ? s_cap - s_fill : 0; }
uint32_t ts_pending_in(void) { return s_fill; }

void ts_push(const int32_t *f, uint32_t n)
{
    if (!s_in) return;
    if (n > s_cap - s_fill) n = s_cap - s_fill;
    int16_t *d = s_in + s_fill * 2u;
    for (uint32_t i = 0; i < n * 2u; i++) d[i] = (int16_t)(f[i] >> 16);
    s_fill += n;
}

/* Offset (0..s_search) at which the input best continues s_tail:
 * normalised cross-correlation of the mono sum, every CORR_STEP-th sample. */
static uint32_t best_offset(void)
{
    float best = -1e30f;
    uint32_t best_d = 0;
    for (uint32_t d = 0; d <= s_search; d += CORR_STEP) {
        const int16_t *x = s_in + d * 2u;
        int64_t corr = 0, energy = 1;
        for (uint32_t i = 0; i < s_ovl; i += CORR_STEP) {
            int32_t a = (int32_t)s_tail[i * 2u] + s_tail[i * 2u + 1u];
            int32_t b = (int32_t)x[i * 2u] + x[i * 2u + 1u];
            corr   += (int64_t)a * b;
            energy += (int64_t)b * b;
        }
        /* corr / sqrt(energy), compared without the square root:
         * sign(corr) * corr^2 / energy.                                   */
        float c = (float)corr;
        float score = c * (c < 0 ? -c : c) / (float)energy;
        if (score > best) { best = score; best_d = d; }
    }
    return best_d;
}

/* Build the next s_hop output frames into s_out. Needs
 * s_search + s_hop + s_ovl input frames.                                  */
static bool synth(void)
{
    if (s_fill < s_search + s_hop + s_ovl) return false;
    uint32_t d = s_have_tail ? best_offset() : 0;
    const int16_t *x = s_in + d * 2u;

    uint32_t o = 0;
    if (s_have_tail) {
        for (uint32_t i = 0; i < s_ovl; i++) {       /* linear cross-fade   */
            int32_t w = (int32_t)((i * 256u) / s_ovl);
            for (int ch = 0; ch < 2; ch++) {
                int32_t a = s_tail[i * 2u + ch], b = x[i * 2u + ch];
                s_out[o++] = (int16_t)((a * (256 - w) + b * w) >> 8);
            }
        }
    } else {
        memcpy(s_out, x, s_ovl * 2u * sizeof(int16_t));
        o = s_ovl * 2u;
    }
    memcpy(s_out + o, x + s_ovl * 2u, (s_hop - s_ovl) * 2u * sizeof(int16_t));
    /* What would have come next: the cross-fade partner of the next segment. */
    memcpy(s_tail, x + s_hop * 2u, s_ovl * 2u * sizeof(int16_t));
    s_have_tail = true;
    s_out_n = s_hop;
    s_out_pos = 0;

    /* Advance the read point by hop x speed (fraction carried over).      */
    uint32_t adv100 = s_hop * s_speed + s_adv_frac;
    uint32_t adv = adv100 / 100u;
    s_adv_frac = adv100 % 100u;
    if (adv > s_fill) adv = s_fill;
    memmove(s_in, s_in + adv * 2u, (s_fill - adv) * 2u * sizeof(int16_t));
    s_fill -= adv;
    return true;
}

uint32_t ts_pull(int32_t *f, uint32_t max)
{
    if (!s_in) return 0;
    uint32_t done = 0;
    while (done < max) {
        if (s_out_pos >= s_out_n && !synth()) break;
        uint32_t n = s_out_n - s_out_pos;
        if (n > max - done) n = max - done;
        const int16_t *s = s_out + s_out_pos * 2u;
        for (uint32_t i = 0; i < n * 2u; i++) f[done * 2u + i] = (int32_t)s[i] * 65536;
        s_out_pos += n;
        done += n;
    }
    return done;
}
