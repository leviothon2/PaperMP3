/**
 * @file    sai_audio.c
 * @brief   SAI1-A slave transmitter with circular (linked-list) GPDMA.
 *
 * The SAI kernel clock is AUDIOCLK: the CS43131's CLKOUT (11.2896 MHz,
 * crystal/2) entering PA0 (AF13, SAI1_EXTCLK). RCC selection is done in
 * system_clock.c (RCC_SAI1CLKSOURCE_PIN).
 *
 * v1 used GPDMA in DMA_NORMAL mode, which stops after one pass: audio
 * would have played ~46 ms and then gone silent. STM32U5 GPDMA only loops
 * through a linked-list queue, so a single self-linked node is built here
 * (the same structure STM32CubeMX generates for "circular" SAI DMA); the
 * U5 HAL SAI driver recognises a linked-list handle and patches the node's
 * source/size on HAL_SAI_Transmit_DMA().
 */
#include "sai_audio.h"
#include "board.h"
#include "stm32u5xx_hal.h"

#include <string.h>

/* Two half-buffers of 1024 words: at 44.1 k stereo that is ~11.6 ms per
 * half - ample against SD read latency spikes; at DoP128 (352.8 k) it is
 * still 1.45 ms of ISR slack.                                            */
#define DMA_WORDS      2048u

static SAI_HandleTypeDef     s_sai;
static DMA_HandleTypeDef     s_dma;
static DMA_QListTypeDef      s_dma_q;
static DMA_NodeTypeDef       s_dma_node __attribute__((aligned(32)));
static bool                  s_dma_ready;

static uint32_t s_buf[DMA_WORDS] __attribute__((aligned(32)));

static sai_need_data_cb s_cb;
static volatile bool    s_running;

/* ---- GPIO ---------------------------------------------------------------- */

static void pins_mode(uint32_t mode)
{
    GPIO_InitTypeDef g = { 0 };
    g.Mode      = mode;
    g.Pull      = GPIO_NOPULL;
    g.Speed     = GPIO_SPEED_FREQ_HIGH;
    g.Alternate = CODEC_SAI_AF;
    g.Pin       = CODEC_BCLK_PIN | CODEC_LRCK_PIN | CODEC_SDOUT_PIN;
    HAL_GPIO_Init(GPIOA, &g);
}

void sai_pins_park(void)
{
    pins_mode(GPIO_MODE_ANALOG);              /* lowest leakage, hi-Z     */
}

/* ---- DMA: one circular linked-list node ------------------------------------ */

static bool dma_setup(void)
{
    if (s_dma_ready) return true;

    DMA_NodeConfTypeDef n = { 0 };
    n.NodeType                     = DMA_GPDMA_LINEAR_NODE;
    n.Init.Request                 = GPDMA1_REQUEST_SAI1_A;
    n.Init.BlkHWRequest            = DMA_BREQ_SINGLE_BURST;
    n.Init.Direction               = DMA_MEMORY_TO_PERIPH;
    n.Init.SrcInc                  = DMA_SINC_INCREMENTED;
    n.Init.DestInc                 = DMA_DINC_FIXED;
    n.Init.SrcDataWidth            = DMA_SRC_DATAWIDTH_WORD;
    n.Init.DestDataWidth           = DMA_DEST_DATAWIDTH_WORD;
    n.Init.SrcBurstLength          = 1;
    n.Init.DestBurstLength         = 1;
    n.Init.TransferAllocatedPort   = DMA_SRC_ALLOCATED_PORT0 | DMA_DEST_ALLOCATED_PORT1;
    n.Init.TransferEventMode       = DMA_TCEM_BLOCK_TRANSFER;
    n.Init.Mode                    = DMA_NORMAL;
    n.TriggerConfig.TriggerPolarity       = DMA_TRIG_POLARITY_MASKED;
    n.DataHandlingConfig.DataExchange     = DMA_EXCHANGE_NONE;
    n.DataHandlingConfig.DataAlignment    = DMA_DATA_RIGHTALIGN_ZEROPADDED;
    n.SrcAddress = (uint32_t)s_buf;
    n.DstAddress = (uint32_t)&CODEC_SAI_BLOCK_A->DR;
    n.DataSize   = DMA_WORDS * 4u;

    if (HAL_DMAEx_List_BuildNode(&n, &s_dma_node) != HAL_OK)          return false;
    if (HAL_DMAEx_List_InsertNode(&s_dma_q, NULL, &s_dma_node) != HAL_OK) return false;
    if (HAL_DMAEx_List_SetCircularMode(&s_dma_q) != HAL_OK)            return false;

    s_dma.Instance                         = GPDMA1_Channel0;
    s_dma.InitLinkedList.Priority          = DMA_HIGH_PRIORITY;
    s_dma.InitLinkedList.LinkStepMode      = DMA_LSM_FULL_EXECUTION;
    s_dma.InitLinkedList.LinkAllocatedPort = DMA_LINK_ALLOCATED_PORT0;
    s_dma.InitLinkedList.TransferEventMode = DMA_TCEM_LAST_LL_ITEM_TRANSFER;
    s_dma.InitLinkedList.LinkedListMode    = DMA_LINKEDLIST_CIRCULAR;
    if (HAL_DMAEx_List_Init(&s_dma) != HAL_OK)                         return false;
    if (HAL_DMAEx_List_LinkQ(&s_dma, &s_dma_q) != HAL_OK)              return false;

    s_dma_ready = true;
    return true;
}

void sai_clock_pin(bool on)
{
    GPIO_InitTypeDef g = { 0 };
    g.Mode      = on ? GPIO_MODE_AF_PP : GPIO_MODE_ANALOG;
    g.Pull      = GPIO_NOPULL;
    g.Speed     = GPIO_SPEED_FREQ_HIGH;
    g.Alternate = CODEC_SAI_AF;
    g.Pin       = CODEC_CLKOUT_PIN;
    HAL_GPIO_Init(CODEC_CLKOUT_PORT, &g);
}

bool sai_audio_init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_SAI1_CLK_ENABLE();
    __HAL_RCC_GPDMA1_CLK_ENABLE();

    /* AUDIOCLK input from CS43131 CLKOUT.                                */
    sai_clock_pin(true);

    sai_pins_park();                           /* until a stream starts   */

    HAL_NVIC_SetPriority(GPDMA1_Channel0_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(GPDMA1_Channel0_IRQn);
    return dma_setup();
}

/* ---- callbacks (IRQ context) ---------------------------------------------- */

void HAL_SAI_TxHalfCpltCallback(SAI_HandleTypeDef *sai)
{
    (void)sai;
    if (s_cb) s_cb(s_buf, DMA_WORDS / 2);
}

void HAL_SAI_TxCpltCallback(SAI_HandleTypeDef *sai)
{
    (void)sai;
    if (s_cb) s_cb(s_buf + DMA_WORDS / 2, DMA_WORDS / 2);
}

/* ---- start / stop --------------------------------------------------------- */

bool sai_start(sai_need_data_cb cb)
{
    sai_stop();
    if (!dma_setup()) return false;

    pins_mode(GPIO_MODE_AF_PP);

    s_sai.Instance             = CODEC_SAI_BLOCK_A;
    HAL_SAI_DeInit(&s_sai);
    s_sai.Init.AudioMode       = SAI_MODESLAVE_TX;
    s_sai.Init.Synchro         = SAI_ASYNCHRONOUS;
    s_sai.Init.SynchroExt      = SAI_SYNCEXT_DISABLE;
    s_sai.Init.OutputDrive     = SAI_OUTPUTDRIVE_ENABLE;
    s_sai.Init.FIFOThreshold   = SAI_FIFOTHRESHOLD_1QF;
    s_sai.Init.MonoStereoMode  = SAI_STEREOMODE;
    s_sai.Init.CompandingMode  = SAI_NOCOMPANDING;
    s_sai.Init.TriState        = SAI_OUTPUT_NOTRELEASED;
    s_sai.Init.Protocol        = SAI_FREE_PROTOCOL;
    s_sai.Init.DataSize        = SAI_DATASIZE_32;
    s_sai.Init.FirstBit        = SAI_FIRSTBIT_MSB;
    s_sai.Init.ClockStrobing   = SAI_CLOCKSTROBING_FALLINGEDGE;

    s_sai.FrameInit.FrameLength       = 64;    /* 2 x 32-bit slots        */
    s_sai.FrameInit.ActiveFrameLength = 32;
    s_sai.FrameInit.FSDefinition      = SAI_FS_CHANNEL_IDENTIFICATION;
    s_sai.FrameInit.FSPolarity        = SAI_FS_ACTIVE_LOW;   /* I2S       */
    s_sai.FrameInit.FSOffset          = SAI_FS_BEFOREFIRSTBIT;

    s_sai.SlotInit.FirstBitOffset = 0;
    s_sai.SlotInit.SlotSize       = SAI_SLOTSIZE_32B;
    s_sai.SlotInit.SlotNumber     = 2;
    s_sai.SlotInit.SlotActive     = SAI_SLOTACTIVE_0 | SAI_SLOTACTIVE_1;

    __HAL_LINKDMA(&s_sai, hdmatx, s_dma);
    if (HAL_SAI_Init(&s_sai) != HAL_OK) return false;

    s_cb = cb;
    cb(s_buf, DMA_WORDS);                      /* prime both halves       */

    if (HAL_SAI_Transmit_DMA(&s_sai, (uint8_t *)s_buf, DMA_WORDS) != HAL_OK) {
        s_cb = NULL;
        return false;
    }
    s_running = true;
    return true;
}

void sai_stop(void)
{
    if (!s_running) return;
    s_cb = NULL;
    HAL_SAI_DMAStop(&s_sai);
    HAL_SAI_DeInit(&s_sai);
    sai_pins_park();
    s_running = false;
}

bool sai_running(void) { return s_running; }

/* DMA IRQ trampoline (referenced from stm32u5xx_it.c).                    */
void sai_dma_irq(void) { HAL_DMA_IRQHandler(&s_dma); }
