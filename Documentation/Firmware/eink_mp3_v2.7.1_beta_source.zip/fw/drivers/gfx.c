/**
 * @file    gfx.c
 * @brief   Software renderer over the e-ink framebuffer.
 *
 * 2.7.0: one 1-bpp plane in the SSD1681's own polarity (1 = white), so
 * the InkBoy driver takes the buffer as it is. The four gfx colours stay:
 * LIGHT and DARK are 25 % / 75 % ordered dot patterns, as since 2.5.0.
 * The second ("gray") plane that 2.5.0 left empty is gone (5 KB of RAM).
 */
#include "gfx.h"
#include "eink.h"

#include <string.h>

#define W 200
#define H 200
#define STRIDE (W / 8)

static bool s_invert;                        /* dark mode                  */

static inline uint8_t *bw(void) { return eink_framebuffer(); }   /* 1 = white */

void gfx_set_invert(bool on) { s_invert = on; }
bool gfx_invert(void)        { return s_invert; }

/* B/W stand-in for a gray level at (x, y): 2x2 ordered pattern.          */
static inline gfx_color_t bw_dither(int x, int y, gfx_color_t m)
{
    bool odd = (x & 1) && (y & 1);               /* 1 pixel in 4            */
    if (m == GFX_LIGHT) return odd ? GFX_BLACK : GFX_WHITE;   /* 25 % ink  */
    if (m == GFX_DARK)  return odd ? GFX_WHITE : GFX_BLACK;   /* 75 % ink  */
    return m;
}

static inline gfx_color_t map(gfx_color_t c)
{
    return s_invert ? (gfx_color_t)(3 - c) : c;
}

void gfx_clear(gfx_color_t c)
{
    gfx_color_t m = map(c);
    if (m == GFX_LIGHT || m == GFX_DARK) {
        /* ink at odd x on odd rows (LIGHT) or everywhere else (DARK)     */
        uint8_t odd_row  = (m == GFX_LIGHT) ? 0xAA : 0x55;  /* 1 = white  */
        uint8_t even_row = (m == GFX_LIGHT) ? 0xFF : 0x00;
        for (int y = 0; y < H; y++)
            memset(bw() + y * STRIDE, (y & 1) ? odd_row : even_row, STRIDE);
        return;
    }
    memset(bw(), (m >= GFX_DARK) ? 0x00 : 0xFF, EINK_FB_SIZE);
}

static inline void px_raw(int x, int y, gfx_color_t m)
{
    m = bw_dither(x, y, m);
    uint32_t o = (uint32_t)y * STRIDE + (uint32_t)(x >> 3);
    uint8_t  b = 0x80u >> (x & 7);
    if (m >= GFX_DARK) bw()[o] &= (uint8_t)~b; else bw()[o] |= b;
}

void gfx_pixel(int x, int y, gfx_color_t c)
{
    if ((unsigned)x >= W || (unsigned)y >= H) return;
    px_raw(x, y, map(c));
}

gfx_color_t gfx_get_pixel(int x, int y)
{
    if ((unsigned)x >= W || (unsigned)y >= H) return GFX_WHITE;
    uint32_t o = (uint32_t)y * STRIDE + (uint32_t)(x >> 3);
    uint8_t  b = 0x80u >> (x & 7);
    gfx_color_t m = (bw()[o] & b) ? GFX_WHITE : GFX_BLACK;
    return s_invert ? (gfx_color_t)(3 - m) : m;   /* undo mapping         */
}

void gfx_hline(int x, int y, int w, gfx_color_t c)
{
    for (int i = 0; i < w; i++) gfx_pixel(x + i, y, c);
}

void gfx_vline(int x, int y, int h, gfx_color_t c)
{
    for (int i = 0; i < h; i++) gfx_pixel(x, y + i, c);
}

void gfx_rect(int x, int y, int w, int h, gfx_color_t c)
{
    gfx_hline(x, y, w, c);
    gfx_hline(x, y + h - 1, w, c);
    gfx_vline(x, y, h, c);
    gfx_vline(x + w - 1, y, h, c);
}

void gfx_fill_rect(int x, int y, int w, int h, gfx_color_t c)
{
    for (int j = 0; j < h; j++) gfx_hline(x, y + j, w, c);
}

void gfx_invert_rect(int x, int y, int w, int h)
{
    /* black <-> white                                                    */
    for (int j = 0; j < h; j++)
        for (int i = 0; i < w; i++) {
            int px = x + i, py = y + j;
            if ((unsigned)px >= W || (unsigned)py >= H) continue;
            bw()[py * STRIDE + (px >> 3)] ^= 0x80u >> (px & 7);
        }
}

/* ---- text ------------------------------------------------------------- */

static const font_glyph_t *glyph(const font_t *f, char ch)
{
    uint8_t c = (uint8_t)ch;
    if (c < f->first || c > f->last) c = '?';
    return &f->glyphs[c - f->first];
}

int gfx_text(const font_t *f, int x, int y, const char *s, gfx_color_t c)
{
    /* 2.6.0: on the B/W panel a dot-dithered gray glyph loses a quarter of
     * its pixels and becomes unreadable; secondary text is drawn solid.  */
    if (c == GFX_DARK) c = GFX_BLACK;
    int x0 = x;
    for (; *s; s++) {
        const font_glyph_t *g = glyph(f, *s);
        int stride = (g->width + 7) / 8;
        const uint8_t *bm = &f->bitmaps[g->offset];
        for (int row = 0; row < f->height; row++)
            for (int col = 0; col < g->width; col++)
                if (bm[row * stride + (col >> 3)] & (0x80u >> (col & 7)))
                    gfx_pixel(x + col, y + row, c);
        x += g->advance;
    }
    return x - x0;
}

int gfx_text_width(const font_t *f, const char *s)
{
    int w = 0;
    for (; *s; s++) w += glyph(f, *s)->advance;
    return w;
}

void gfx_text_ellipsis(const font_t *f, int x, int y, int max_w,
                       const char *s, gfx_color_t c)
{
    if (gfx_text_width(f, s) <= max_w) {
        gfx_text(f, x, y, s, c);
        return;
    }
    int dots = gfx_text_width(f, "..");
    char buf[64];
    int  n = 0, w = 0;
    for (; s[n] && n < (int)sizeof buf - 1; n++) {
        int a = glyph(f, s[n])->advance;
        if (w + a > max_w - dots) break;
        w += a;
        buf[n] = s[n];
    }
    buf[n] = '\0';
    x += gfx_text(f, x, y, buf, c);
    gfx_text(f, x, y, "..", c);
}

/* ---- bitmaps ---------------------------------------------------------- */

void gfx_blit(int x, int y, int w, int h, const uint8_t *bits, gfx_color_t c)
{
    int stride = (w + 7) / 8;
    for (int j = 0; j < h; j++)
        for (int i = 0; i < w; i++)
            if (bits[j * stride + (i >> 3)] & (0x80u >> (i & 7)))
                gfx_pixel(x + i, y + j, c);
}

void gfx_blit_gray_dither(int x, int y, int w, int h, const uint8_t *gray)
{
    /* Floyd-Steinberg quantised to the panel's 4 levels (0/85/170/255).
     * With 4 output levels the residual error is small, so art keeps
     * smooth midtones instead of the salt-and-pepper of 1-bit dither.
     * Single-row error buffer (w <= 200).                                */
    static const gfx_color_t lvl[4] = { GFX_BLACK, GFX_DARK, GFX_LIGHT, GFX_WHITE };
    int16_t err[204] = { 0 };
    int16_t next[204];
    for (int j = 0; j < h; j++) {
        memset(next, 0, sizeof next);
        int16_t carry = 0;
        for (int i = 0; i < w; i++) {
            int v = gray[j * w + i] + err[i + 1] + carry;
            carry = 0;
            if (v < 0) v = 0;
            if (v > 255) v = 255;
            int q, e;
            q = (v >= 128) ? 3 : 0;                 /* plain 1-bit F-S     */
            e = v - (q ? 255 : 0);
            gfx_pixel(x + i, y + j, lvl[q]);
            carry        = (int16_t)((e * 7) / 16); /* right               */
            next[i]     += (int16_t)((e * 3) / 16); /* down-left           */
            next[i + 1] += (int16_t)((e * 5) / 16); /* down                */
            next[i + 2] += (int16_t)((e * 1) / 16); /* down-right          */
        }
        memcpy(err, next, sizeof err);
    }
}

/* ---- widgets ----------------------------------------------------------- */

int gfx_battery_fill_px(uint8_t percent)
{
    if (percent > 100) percent = 100;
    return (percent * GFX_BATT_INNER_W) / 100;      /* 0..18 columns       */
}

void gfx_battery_icon(int x, int y, uint8_t percent, bool charging, bool absent)
{
    /* Same 22x10 + nub footprint as the old 4-bar icon; the interior is
     * now a continuous 18-px fill (each column ~5.5 %). The column past
     * the fill edge goes GFX_DARK when the remainder is >= half a column:
     * on full refreshes that reads as a finer edge; a partial refresh
     * simply rounds it to black - no extra waveform, no battery cost.    */
    if (percent > 100) percent = 100;
    gfx_rect(x, y, GFX_BATT_W, GFX_BATT_H, GFX_BLACK);
    gfx_fill_rect(x + GFX_BATT_W, y + 3, 2, 4, GFX_BLACK);

    if (absent) {
        /* No cell (USB power only): clear interior + bolt strip, then a
         * cross in the middle of the shell.                              */
        gfx_fill_rect(x + 1, y + 1, GFX_BATT_W - 2, GFX_BATT_H - 2, GFX_WHITE);
        gfx_fill_rect(x - GFX_BATT_BOLT_W, y - 1, GFX_BATT_BOLT_W, GFX_BATT_H + 2,
                      GFX_WHITE);
        /* 6x6 X centred in the 18x6 interior, 2 px wide strokes.       */
        const int ih = GFX_BATT_H - 4;                       /* 6 rows  */
        const int x0 = x + 2 + (GFX_BATT_INNER_W - ih - 1) / 2;
        for (int i = 0; i < ih; i++) {
            gfx_fill_rect(x0 + i,          y + 2 + i, 2, 1, GFX_BLACK);
            gfx_fill_rect(x0 + ih - 1 - i, y + 2 + i, 2, 1, GFX_BLACK);
        }
        return;
    }

    int fill = gfx_battery_fill_px(percent);
    int rem  = (percent * GFX_BATT_INNER_W) % 100;  /* remainder, 0..99    */

    gfx_fill_rect(x + 2, y + 2, fill, GFX_BATT_H - 4, GFX_BLACK);
    if (rem >= 50 && fill < GFX_BATT_INNER_W) {     /* half-step edge      */
        gfx_fill_rect(x + 2 + fill, y + 2, 1, GFX_BATT_H - 4, GFX_DARK);
        gfx_fill_rect(x + 3 + fill, y + 2,
                      GFX_BATT_INNER_W - fill - 1, GFX_BATT_H - 4, GFX_WHITE);
    } else {
        gfx_fill_rect(x + 2 + fill, y + 2,
                      GFX_BATT_INNER_W - fill, GFX_BATT_H - 4, GFX_WHITE);
    }

    /* Charging bolt sits beside the shell (left), never over the fill.
     * Always paint the strip so a windowed partial can remove a stale
     * bolt after unplug.                                                 */
    gfx_fill_rect(x - GFX_BATT_BOLT_W, y - 1, GFX_BATT_BOLT_W, GFX_BATT_H + 2,
                  GFX_WHITE);
    if (charging) {
        int bx = x - GFX_BATT_BOLT_W + 1;        /* 7-px-wide bolt         */
        /* top stroke \ */
        gfx_hline(bx + 3, y,     3, GFX_BLACK);
        gfx_hline(bx + 2, y + 1, 3, GFX_BLACK);
        gfx_hline(bx + 1, y + 2, 3, GFX_BLACK);
        /* cross bar     */
        gfx_hline(bx,     y + 3, 7, GFX_BLACK);
        gfx_hline(bx,     y + 4, 7, GFX_BLACK);
        /* bottom stroke \ */
        gfx_hline(bx + 3, y + 5, 3, GFX_BLACK);
        gfx_hline(bx + 2, y + 6, 3, GFX_BLACK);
        gfx_hline(bx + 1, y + 7, 3, GFX_BLACK);
    }
}

void gfx_shuffle_icon(int x, int y, gfx_color_t c)
{
    /* Two crossing arrows, 13x10.                                        */
    gfx_hline(x, y + 1, 3, c);                   /* upper-left inlet       */
    gfx_hline(x, y + 8, 3, c);                   /* lower-left inlet       */
    /* diagonals crossing in the middle                                   */
    for (int i = 0; i < 6; i++) {
        gfx_pixel(x + 3 + i, y + 2 + i, c);      /* down-right             */
        gfx_pixel(x + 3 + i, y + 7 - i, c);      /* up-right               */
    }
    gfx_hline(x + 9, y + 1, 2, c);               /* upper-right outlet     */
    gfx_hline(x + 9, y + 8, 2, c);               /* lower-right outlet     */
    /* arrow heads                                                        */
    gfx_vline(x + 11, y,     3, c);
    gfx_pixel(x + 12, y + 1, c);
    gfx_vline(x + 11, y + 7, 3, c);
    gfx_pixel(x + 12, y + 8, c);
}

int gfx_progress_fill_px(int w, uint32_t num, uint32_t den)
{
    if (den == 0) return 0;
    if (num > den) num = den;
    return (int)((uint64_t)(w - 4) * num / den);
}

void gfx_progress_bar(int x, int y, int w, int h, uint32_t num, uint32_t den)
{
    gfx_rect(x, y, w, h, GFX_BLACK);
    if (den == 0) return;
    int fill = gfx_progress_fill_px(w, num, den);
    int inner = w - 4;
    /* Half-pixel leading edge, same scheme as the battery icon.          */
    bool half = den && (((uint64_t)inner * num * 2 / den) & 1u) && fill < inner;

    gfx_fill_rect(x + 2, y + 2, fill, h - 4, GFX_BLACK);
    if (half) {
        gfx_fill_rect(x + 2 + fill, y + 2, 1, h - 4, GFX_DARK);
        gfx_fill_rect(x + 3 + fill, y + 2, inner - fill - 1, h - 4, GFX_WHITE);
    } else {
        /* Clear the remainder so partial refreshes erase old fill.       */
        gfx_fill_rect(x + 2 + fill, y + 2, inner - fill, h - 4, GFX_WHITE);
    }
}
