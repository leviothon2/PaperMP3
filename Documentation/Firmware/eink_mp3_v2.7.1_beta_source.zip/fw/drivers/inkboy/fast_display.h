#pragma once
#include "display_mode.h"
#include "ssd1681_fast.h"

/* InkBoy main/fast_display.h, reduced to the dithered drive.
 *
 * PORT (player 2.7.0): the grayscale planner (gray_plan*, 104 KB plan + 120 KB history on the heap,
 * 10 KB of follow-up masks) is not built into the player - it has 29 KB of RAM to spare, the planner
 * needs more than 230 KB. The dithered drive below is InkBoy's, line for line (compare with
 * `display test firmware/main/fast_display.c`, which keeps the whole file). The function names and
 * semantics are unchanged, so the grayscale half can be put back from the display-test tree if a
 * later board has the memory. */

#define DITHER_PULSES_DEFAULT 8u
#define DITHER_PULSES_MAX 8u

/* A 30 ms lower bound tolerates small per-slot preparation differences without accumulating drift. */
static inline unsigned fast_display_drive_period_us(display_mode_t mode) { (void)mode; return 30000; }

esp_err_t fast_display_set_dither_pulses(unsigned black, unsigned white);
/* Nonzero while work remains: the pending pixel count, or 1 when only the
 * HOLD ending remains. Zero when settled or context invalid. */
unsigned fast_display_pending(ssd1681_handle_t d);

/* One task/display owner shared by every screen. */
esp_err_t fast_display_full(ssd1681_handle_t d, const uint8_t *frame, display_mode_t mode);
/* Final cleaning only: invalidate the fast context without preparing more scans. */
esp_err_t fast_display_finish(ssd1681_handle_t d, const uint8_t *frame);
esp_err_t fast_display_update(ssd1681_handle_t d, const uint8_t *frame);
/* PORT: forget the owner (the device was destroyed or used for an OTP refresh). */
void fast_display_release(void);
