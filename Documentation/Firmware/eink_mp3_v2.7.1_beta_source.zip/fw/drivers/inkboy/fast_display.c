#include "fast_display.h"
#include "drive_counters.h"
#include "esp_attr.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>
#include <inttypes.h>

/* InkBoy main/fast_display.c - dithered drive only (see fast_display.h for why).
 * PORT changes against upstream, each marked:
 *   - grayscale paths removed;
 *   - the drive counters are a static object instead of a heap block (the player's heap belongs
 *     to the audio decoders; a 25 KB block that never moves would fragment it);
 *   - fast_display_release(). */

/* PORT: static instead of heap_caps_calloc(). */
static drive_counters_t drive_counters_store;
static drive_counters_t *drive_counters;
static unsigned dither_black = DITHER_PULSES_DEFAULT, dither_white = DITHER_PULSES_DEFAULT;

esp_err_t fast_display_set_dither_pulses(unsigned black_pulses, unsigned white_pulses)
{
    if (!black_pulses || black_pulses > DITHER_PULSES_MAX || !white_pulses || white_pulses > DITHER_PULSES_MAX)
        return ESP_ERR_INVALID_ARG;
    dither_black = black_pulses; dither_white = white_pulses;
    return ESP_OK;
}

static DMA_ATTR uint8_t previous[SSD1681_FRAME_BYTES];
static DMA_ATTR uint8_t black[SSD1681_FRAME_BYTES], white[SSD1681_FRAME_BYTES];
static ssd1681_handle_t owner;
static display_mode_t selected;
static unsigned updates;
static bool prepared;
static int64_t last_start;
static bool hold_end_pending;

void fast_display_release(void) { owner = NULL; prepared = false; hold_end_pending = false; }

unsigned fast_display_pending(ssd1681_handle_t d)
{
    if (!d || d != owner) return 0;
    if (!drive_counters) return 0;
    if (hold_end_pending && !drive_counters->pending_pixels)
        return 1; /* Physical HOLD ending still needs delivery. */
    return drive_counters->pending_pixels;
}

esp_err_t fast_display_full(ssd1681_handle_t d, const uint8_t *frame, display_mode_t mode)
{
    if (!d || !frame || mode != DISPLAY_DITHERED) return ESP_ERR_INVALID_ARG;
    owner = NULL; prepared = false;
    hold_end_pending = false;
    drive_counters = &drive_counters_store;                 /* PORT */
    ssd1681_timing_t timing;
    esp_err_t error = ssd1681_vendor_full(d, frame, SSD1681_FRAME_BYTES, &timing);
    if (!error) error = ssd1681_vendor_enable_mixed(d);
    if (!error) error = ssd1681_vendor_set_mixed_frames(d, 1);
    if (!error) error = ssd1681_vendor_set_fast_transport(d, true);
    if (error) return error;
    drive_counters_seed(drive_counters, frame);
    memcpy(previous, frame, sizeof(previous));
    owner = d; selected = mode; updates = 0; last_start = 0;
    ESP_LOGI("fast_display", "PLAYER_DISPLAY_FULL,mode,%u,busy_us,%" PRId64, mode, timing.busy_us);
    return ESP_OK;
}

esp_err_t fast_display_finish(ssd1681_handle_t d, const uint8_t *frame)
{
    if (!d || !frame) return ESP_ERR_INVALID_ARG;
    owner = NULL; prepared = false;
    hold_end_pending = false;
    /* The final full refresh is reserved by the lifetime cap, so preparing another fast waveform
     * can be rejected here even though cleaning succeeded. */
    ssd1681_timing_t timing = {0};
    esp_err_t error = ssd1681_vendor_full(d, frame, SSD1681_FRAME_BYTES, &timing);
    ESP_LOGI("fast_display", "PLAYER_DISPLAY_FINISH,busy_us,%" PRId64 ",error,%d", timing.busy_us, error);
    return error;
}

esp_err_t fast_display_update(ssd1681_handle_t d, const uint8_t *frame)
{
    if (!d || !frame) return ESP_ERR_INVALID_ARG;
    if (d != owner) return ESP_ERR_INVALID_STATE;
    if (!hold_end_pending && !drive_counters->pending_pixels &&
        !memcmp(previous, frame, sizeof(previous))) return ESP_OK;
    const int64_t remaining = last_start + fast_display_drive_period_us(selected) - esp_timer_get_time();
    if (last_start && remaining > 0)
        vTaskDelay(pdMS_TO_TICKS((remaining + 999) / 1000));
    const int64_t start = esp_timer_get_time();
    ssd1681_timing_t timing;
    esp_err_t error = ESP_OK;
    /* No-op if already powered; after idle, resuming does not reset RAM. */
    if (prepared) error = ssd1681_vendor_mixed_resume(d, &timing);
    /* Anchor cadence after an idle power startup, so its time cannot shorten
     * the interval between the resumed image and the following image. */
    const int64_t activation_start = esp_timer_get_time();
    const int64_t gap = last_start ? activation_start - last_start : 0;
    unsigned driven = drive_counters_prepare(drive_counters, frame, dither_black, dither_white, black, white);
    if (!error) error = ssd1681_vendor_mixed_scan(d, black, white, sizeof(previous), &timing);
    if (error) { owner = NULL; return error; }
    drive_counters_complete(drive_counters, black, white);
    /* Keep a successor pending until an all-HOLD mask is delivered.
     * Fresh target changes produce active masks and defer this ending. */
    hold_end_pending = driven != 0;
    memcpy(previous, frame, sizeof(previous));
    prepared = true; last_start = activation_start; ++updates;
    ESP_LOGI("fast_display", "PLAYER_DISPLAY_UPDATE,mode,%u,n,%u,driven,%u,gap_us,%" PRId64
             ",busy_us,%" PRId64 ",total_us,%" PRId64,
             selected, updates, driven, gap, timing.busy_us, esp_timer_get_time() - start);
    return ESP_OK;
}
