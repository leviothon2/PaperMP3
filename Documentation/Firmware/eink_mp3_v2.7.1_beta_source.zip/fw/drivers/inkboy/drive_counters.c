#include "drive_counters.h"
#include <string.h>

_Static_assert(SSD1681_FRAME_BYTES % sizeof(uint32_t) == 0, "whole mask words");

/* PORT (dt-0.2.0): edge halo, off by default.
 *
 * dt-0.1.0 testing showed discoloured pixels along sharp edges after fast updates: the particles of
 * a pixel that was not driven are pulled by the fringe field of a neighbour that was (the TFT
 * backplane has no guard between pixels). InkBoy only drives pixels whose target changed. With a
 * halo, unchanged pixels within `radius` of a changed one also get `pulses` pulses toward their own
 * colour in the same scans - the same "re-assert" that a partial refresh gives every pixel, but only
 * around what moved. Pixels that still have a pending count keep it (no restart of a running
 * transition). Cost: more driven pixels per scan, no extra scans unless pulses > the changed ones.
 * Off (radius 0) the code path is InkBoy's, bit for bit.                                          */
static unsigned s_halo_radius, s_halo_pulses;

void drive_counters_set_halo(unsigned radius, unsigned pulses)
{
    s_halo_radius = radius > 2 ? 2 : radius;
    s_halo_pulses = pulses > 8 ? 8 : pulses;
}

unsigned drive_counters_halo_radius(void) { return s_halo_radius; }
unsigned drive_counters_halo_pulses(void) { return s_halo_pulses; }

#define ROW_BYTES (SSD1681_WIDTH / 8)

/* Changed mask -> pixels within `radius` (Chebyshev) of a changed pixel, minus the changed ones.
 * Byte domain, MSB = leftmost pixel, 25 bytes per row. Result in s_grow.
 * PORT (player 2.7.0): the display-test build keeps three 5 KB work planes for this; the player has
 * no RAM for them, so the caller's output masks serve as scratch: the ring is built in `black`
 * (prepare() reads ring word i before it writes black word i) and `white` is the temporary. */
static void halo_mask(const uint8_t *target, const uint32_t *old_target, uint8_t *s_grow, uint8_t *s_tmp)
{
    const uint8_t *old = (const uint8_t *)old_target;
    for (unsigned i = 0; i < SSD1681_FRAME_BYTES; ++i) s_grow[i] = target[i] ^ old[i];
    for (unsigned r = 0; r < s_halo_radius; ++r) {
        for (unsigned y = 0; y < SSD1681_HEIGHT; ++y) {                 /* horizontal            */
            const uint8_t *row = s_grow + y * ROW_BYTES;
            for (unsigned x = 0; x < ROW_BYTES; ++x) {
                uint8_t c = row[x];
                uint8_t left = x ? (uint8_t)(row[x - 1] << 7) : 0;    /* left byte's last px   */
                uint8_t right = x + 1 < ROW_BYTES ? (uint8_t)(row[x + 1] >> 7) : 0;
                s_tmp[y * ROW_BYTES + x] = (uint8_t)(c | c << 1 | c >> 1 | left | right);
            }
        }
        for (unsigned i = 0; i < SSD1681_FRAME_BYTES; ++i) {           /* vertical              */
            uint8_t v = s_tmp[i];
            if (i >= ROW_BYTES) v |= s_tmp[i - ROW_BYTES];
            if (i + ROW_BYTES < SSD1681_FRAME_BYTES) v |= s_tmp[i + ROW_BYTES];
            s_grow[i] = v;
        }
    }
    for (unsigned i = 0; i < SSD1681_FRAME_BYTES; ++i) s_grow[i] &= (uint8_t)~(target[i] ^ old[i]);
}

void drive_counters_seed(drive_counters_t *c, const uint8_t *clean)
{
    memcpy(c->target, clean, SSD1681_FRAME_BYTES);
    memset(c->count, 0, sizeof(c->count));
    c->pending_pixels = 0;
}

unsigned drive_counters_prepare(drive_counters_t *c, const uint8_t *target,
                               unsigned black_pulses, unsigned white_pulses,
                               uint8_t *black, uint8_t *white)
{
    unsigned pending = 0;
    const bool halo = s_halo_radius && s_halo_pulses;
    const uint8_t *s_grow = black;                          /* PORT: see halo_mask() */
    if (halo) halo_mask(target, c->target, black, white);
    for (unsigned i = 0; i < DRIVE_WORDS; ++i) {
        uint32_t next;
        memcpy(&next, target + i * sizeof(next), sizeof(next));
        const uint32_t changed = next ^ c->target[i];
        uint32_t ring = 0;
        if (halo) {
            memcpy(&ring, s_grow + i * sizeof(ring), sizeof(ring));
            uint32_t idle = 0;
            for (unsigned plane = 0; plane < 4; ++plane) idle |= c->count[plane][i];
            ring &= ~idle;                       /* running transitions keep their count       */
        }
        uint32_t active = 0;
        for (unsigned plane = 0; plane < 4; ++plane) {
            uint32_t value = c->count[plane][i];
            if (changed) {
                const uint32_t budget = ((black_pulses & (1u << plane)) ? ~next : 0) |
                                        ((white_pulses & (1u << plane)) ? next : 0);
                value = (value & ~changed) | (budget & changed);
            }
            if (ring) value = (value & ~ring) | ((s_halo_pulses & (1u << plane)) ? ring : 0);
            c->count[plane][i] = value;
            active |= value;
        }
        c->target[i] = next;
        uint32_t b = active & ~next, w = active & next;
        memcpy(black + i * sizeof(b), &b, sizeof(b));
        memcpy(white + i * sizeof(w), &w, sizeof(w));
        pending += __builtin_popcount(active);
    }
    c->pending_pixels = pending;
    return pending;
}

void drive_counters_complete(drive_counters_t *c, const uint8_t *black, const uint8_t *white)
{
    unsigned pending = 0;
    for (unsigned i = 0; i < DRIVE_WORDS; ++i) {
        uint32_t b, w;
        memcpy(&b, black + i * sizeof(b), sizeof(b));
        memcpy(&w, white + i * sizeof(w), sizeof(w));
        uint32_t active = 0;
        for (unsigned plane = 0; plane < 4; ++plane) active |= c->count[plane][i];
        /* Subtract only from delivered, matching counters; an inactive pixel would wrap from 0 to 15. */
        uint32_t borrow = active & ((b & ~c->target[i]) | (w & c->target[i]));
        active = 0;
        for (unsigned plane = 0; plane < 4; ++plane) {
            uint32_t old = c->count[plane][i];
            c->count[plane][i] = old ^ borrow;
            borrow &= ~old;
            active |= c->count[plane][i];
        }
        pending += __builtin_popcount(active);
    }
    c->pending_pixels = pending;
}
