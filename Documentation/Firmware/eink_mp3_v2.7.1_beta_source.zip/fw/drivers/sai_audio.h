/**
 * @file    sai_audio.h
 * @brief   SAI1 block A: I2S slave transmitter to the CS43131 ASP.
 *
 * The CS43131 ASP is the master: SAI1 Block A is a slave transmitter on
 * PA8 (SCK) / PA9 (FS) / PA10 (SD). 32-bit slots, 2 slots/frame. The same
 * link carries PCM and DoP (DSD-over-PCM) - V2 has no native DSD wiring.
 *
 * Data flow: audio_pipeline.c owns a ring buffer; this driver drains it
 * with a circular GPDMA linked-list transfer (one node looping on a
 * double buffer) and half/full-complete callbacks.
 */
#ifndef SAI_AUDIO_H
#define SAI_AUDIO_H

#include <stdbool.h>
#include <stdint.h>
#include "cs43131.h"

typedef void (*sai_need_data_cb)(uint32_t *dst, uint32_t nwords);

bool sai_audio_init(void);

/* Interleaved L/R, 32-bit words (24-bit audio / DoP left-justified).     */
bool sai_start(sai_need_data_cb cb);

void sai_stop(void);
bool sai_running(void);

/* Park the I2S pads in analog mode.                                      */
void sai_pins_park(void);
/* System sleep: AUDIOCLK input (PA0) hi-Z while CLKOUT is off / back.    */
void sai_clock_pin(bool on);

#endif /* SAI_AUDIO_H */
