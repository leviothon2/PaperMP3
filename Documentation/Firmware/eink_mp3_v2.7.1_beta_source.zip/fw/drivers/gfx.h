/**
 * @file    gfx.h
 * @brief   Minimal 2-bpp (4-gray) renderer for the 200x200 e-ink panel.
 *
 * Deliberately not LVGL: a custom renderer costs ~15-25 KB total versus
 * LVGL's 100 KB+ (flash_budget.md §6), and e-ink UIs are static enough
 * that immediate-mode drawing is simpler and lighter. See
 * software_design_decisions.md §"Why not LVGL".
 *
 * Grays: GFX_LIGHT/GFX_DARK render on full refreshes via the panel's
 * 4-gray LUT; partial refreshes see only the B/W plane (light->white,
 * dark->black), so keep partial-refresh widgets to WHITE/BLACK plus at
 * most a DARK leading edge (degrades gracefully to black).
 *
 * Dark mode: gfx_set_invert(true) flips every level (0<->3, 1<->2) at
 * pixel-write time. Free at runtime - no extra buffer, no extra pass.
 */
#ifndef GFX_H
#define GFX_H

#include <stdbool.h>
#include <stdint.h>
#include "../assets/font.h"

typedef enum {
    GFX_WHITE = 0, GFX_LIGHT = 1, GFX_DARK = 2, GFX_BLACK = 3,
} gfx_color_t;

/* Dark mode (inverted colours). Applies to all subsequent drawing.       */
void gfx_set_invert(bool on);
bool gfx_invert(void);

/* LIGHT and DARK are drawn as 25 % / 75 % ordered black-and-white dot
 * patterns; album art is 1-bit Floyd-Steinberg dithered. Every refresh
 * uses the panel's factory B/W waveforms.                                */

void gfx_clear(gfx_color_t c);
void gfx_pixel(int x, int y, gfx_color_t c);
gfx_color_t gfx_get_pixel(int x, int y);
void gfx_hline(int x, int y, int w, gfx_color_t c);
void gfx_vline(int x, int y, int h, gfx_color_t c);
void gfx_rect(int x, int y, int w, int h, gfx_color_t c);
void gfx_fill_rect(int x, int y, int w, int h, gfx_color_t c);
void gfx_invert_rect(int x, int y, int w, int h);   /* level -> 3-level    */

/* Text. Returns advance in pixels. Clips at framebuffer edges.           */
int  gfx_text(const font_t *f, int x, int y, const char *s, gfx_color_t c);
int  gfx_text_width(const font_t *f, const char *s);
/* Truncates with ".." if wider than max_w. */
void gfx_text_ellipsis(const font_t *f, int x, int y, int max_w,
                       const char *s, gfx_color_t c);

/* 1-bpp bitmap blit (row-major, MSB first, stride = ceil(w/8)).          */
void gfx_blit(int x, int y, int w, int h, const uint8_t *bits, gfx_color_t c);

/* 8-bit grayscale -> 2-bpp Floyd-Steinberg dither blit (album art).      */
void gfx_blit_gray_dither(int x, int y, int w, int h, const uint8_t *gray);

/* ---- widgets used across screens --------------------------------------
 * Battery: 22x10 shell + nub (same footprint as ever), interior is an
 * 18-px continuous fill - each column ~5.5 % of charge. The leading
 * column renders GFX_DARK when the remainder is a half-step (visible on
 * full refreshes; partials round it to black - costs nothing).
 * gfx_battery_fill_px() maps percent -> fill columns so the UI can detect
 * "a new column threshold was crossed" and issue a windowed partial.
 * When charging, a small lightning bolt is drawn just LEFT of the shell
 * (x-9..x-2) - beside, not inside, so it stays visible over a full fill.
 * That strip is cleared when not charging, so windowed partials of the
 * icon area add/remove the bolt cleanly.                                 */
#define GFX_BATT_W        22
#define GFX_BATT_H        10
#define GFX_BATT_INNER_W  18
#define GFX_BATT_BOLT_W   10          /* reserved strip left of the shell  */
int  gfx_battery_fill_px(uint8_t percent);           /* 0..18              */
/* absent = no battery detected (running from USB only): empty shell with
 * a cross through the interior, no bolt.                                 */
void gfx_battery_icon(int x, int y, uint8_t percent, bool charging, bool absent);

/* Shuffle: 13x10 crossed-arrows glyph (status bar, right-aligned next to
 * the battery).                                                          */
#define GFX_SHUF_W        13
#define GFX_SHUF_H        10
void gfx_shuffle_icon(int x, int y, gfx_color_t c);

/* Progress bar: same threshold logic - gfx_progress_fill_px() tells the
 * UI when the fill has advanced by >= 1 px. Leading edge dark-gray.      */
int  gfx_progress_fill_px(int w, uint32_t num, uint32_t den);
void gfx_progress_bar(int x, int y, int w, int h, uint32_t num, uint32_t den);

#endif /* GFX_H */
