/**
 * @file    buttons.c
 * @brief   Debounced button engine (SysTick-sampled, EXTI only for wake).
 */
#include "buttons.h"
#include "board.h"
#include "diag.h"
#include "stm32u5xx_hal.h"

/* dt-0.2.0: timing is a runtime setting (buttons_set_timing); the player's
 * constants are the defaults (BTN_TIMING_DEFAULT).                        */
static btn_timing_t s_tm = BTN_TIMING_DEFAULT;
#define DEBOUNCE_MS      ((uint8_t)s_tm.debounce_ms)
#define LONG_MS          ((uint32_t)s_tm.long_ms)
#define DOUBLE_GAP_MS    ((uint32_t)s_tm.double_gap_ms)
#define REPEAT_DELAY_MS  ((uint32_t)s_tm.repeat_delay_ms)
#define REPEAT_RATE_MS   ((uint32_t)s_tm.repeat_rate_ms)
#define REBOOT_CHORD_MS 5000u
#define REBOOT_GRACE_MS 1500u   /* main loop gets this long to act        */

typedef struct {
    GPIO_TypeDef *port;
    uint16_t      pin;
    bool          allow_double;    /* only SW1 has double-press semantics */
    bool          allow_repeat;    /* SW2..SW5 auto-repeat while held     */
} btn_cfg_t;

/* v2.3: SW3 lost its double press. It delayed every "up"/"prev" by the
 * double-click window and two quick "up" presses turned into "back".     */
static const btn_cfg_t s_cfg[BTN_COUNT] = {
    [BTN_SW1] = { 0, 0, true,  false },  /* ports filled in at init (see  */
    [BTN_SW2] = { 0, 0, false, true  },  /*  buttons_init) so board.h     */
    [BTN_SW3] = { 0, 0, false, true  },  /*  macros stay the only source  */
    [BTN_SW4] = { 0, 0, false, true  },
    [BTN_SW5] = { 0, 0, false, true  },
};
static btn_cfg_t s_rt[BTN_COUNT];

typedef struct {
    uint8_t  integrator;       /* debounce integrator 0..DEBOUNCE_MS      */
    bool     stable;           /* debounced state, true = pressed         */
    bool     long_fired;
    uint32_t t_press;          /* tick when press became stable           */
    uint32_t t_release;        /* tick of last release (double detect)    */
    uint32_t t_repeat;
    uint32_t t_origin;         /* dt-0.2.0: physical press / repeat tick  */
    bool     short_pending;    /* waiting to see if a double follows      */
    bool     ignore;           /* swallow until released (wake press)     */
    bool     chord;            /* part of a multi-key hold: stay silent   */
    bool     on_press;         /* 2.7.0: SHORT already sent on the press  */
} btn_state_t;

static volatile btn_state_t s_st[BTN_COUNT];

/* Tiny lock-free FIFO: producer = SysTick, consumer = main loop.         */
#define EVQ_LEN 16u
static btn_event_t   s_evq[EVQ_LEN];
static volatile uint8_t s_evq_w, s_evq_r;

static uint32_t s_chord_start;   /* SW4+SW5 reboot chord timer            */
static uint32_t s_nav_chord_start; /* SW2+SW3 quick-menu chord timer      */
static bool     s_nav_chord_fired;
static uint32_t s_ignore_since;  /* tick of buttons_ignore_until_release  */
static uint8_t  s_seen_released; /* bit per key: released since boot      */
static volatile uint8_t s_rep_queued; /* bit per key: a REPEAT is queued */
static volatile btn_reboot_t s_reboot_req;
static uint32_t s_reboot_req_t;
#define IGNORE_MIN_MS     60u    /* contact bounce right after wake-up    */

void buttons_set_timing(const btn_timing_t *t)
{
    btn_timing_t v = *t;
    if (v.debounce_ms < 2) v.debounce_ms = 2;
    if (v.debounce_ms > 50) v.debounce_ms = 50;
    if (v.long_ms < 200) v.long_ms = 200;
    if (v.double_gap_ms < 100) v.double_gap_ms = 100;
    if (v.repeat_delay_ms < 100) v.repeat_delay_ms = 100;
    if (v.repeat_rate_ms < 30) v.repeat_rate_ms = 30;
    if (v.chord_ms < 150) v.chord_ms = 150;
    if (v.chord_ms > 2000) v.chord_ms = 2000;
    __disable_irq();
    s_tm = v;
    s_rt[BTN_SW1].allow_double = v.sw1_double;
    for (int b = 0; b < BTN_COUNT; b++)
        if (s_st[b].integrator > v.debounce_ms) s_st[b].integrator = v.debounce_ms;
    __enable_irq();
}

const btn_timing_t *buttons_timing(void) { return &s_tm; }

/* Keys that act on press when nav_on_press is set: the navigation keys.  */
static volatile bool s_press_mode = true;
void buttons_press_mode(bool allow_on_press) { s_press_mode = allow_on_press; }

static bool acts_on_press(btn_id_t b)
{
    return s_tm.nav_on_press && s_press_mode &&
           (b == BTN_SW2 || b == BTN_SW3 || b == BTN_SW4 || b == BTN_SW5);
}

static void push_event(btn_id_t id, btn_event_type_t type)
{
    if (s_st[id].ignore || s_st[id].chord) return;
    /* 2.5.0: at most one auto-repeat per key waits in the queue. While
     * the main loop is stuck in an e-ink refresh (~0.3-0.5 s) a held key
     * used to queue a repeat every 150 ms; they all ran afterwards, so
     * the cursor lagged, jumped, and kept going after the key was let go.
     * Now the list moves one step per refresh and stops on release.     */
    uint8_t bit = (uint8_t)(1u << id);
    if (type == BTN_EV_REPEAT && (s_rep_queued & bit)) return;
    uint8_t next = (uint8_t)((s_evq_w + 1) % EVQ_LEN);
    if (next == s_evq_r) return;               /* full: drop newest       */
    s_evq[s_evq_w] = (btn_event_t){ id, type, s_st[id].t_origin };
    if (type == BTN_EV_REPEAT) s_rep_queued |= bit;
    s_evq_w = next;
}

bool buttons_get_event(btn_event_t *ev)
{
    for (;;) {
        if (s_evq_r == s_evq_w) return false;
        *ev = s_evq[s_evq_r];
        s_evq_r = (uint8_t)((s_evq_r + 1) % EVQ_LEN);
        if (ev->type != BTN_EV_REPEAT) return true;
        __disable_irq();                        /* shared with SysTick     */
        s_rep_queued &= (uint8_t)~(1u << ev->id);
        __enable_irq();
        /* A repeat whose key is already released is stale: drop it.     */
        if (s_st[ev->id].stable) return true;
    }
}

static bool raw_pressed(btn_id_t b)
{
    /* Active low with pull-up. */
    return HAL_GPIO_ReadPin(s_rt[b].port, s_rt[b].pin) == GPIO_PIN_RESET;
}

void buttons_ignore_until_release(void)
{
    __disable_irq();
    for (int b = 0; b < BTN_COUNT; b++) {
        s_st[b].ignore        = true;
        s_st[b].short_pending = false;
        s_st[b].integrator    = 0;
        s_st[b].stable        = false;
        s_st[b].chord         = false;
    }
    s_evq_r = s_evq_w;
    s_rep_queued = 0;
    s_chord_start = 0;
    s_nav_chord_start = 0;
    s_ignore_since = HAL_GetTick();
    __enable_irq();
}

bool buttons_any_pressed(void)
{
    /* Ignored keys (held through a wake, or stuck since boot) don't
     * count: a stuck key must not keep the player awake forever.         */
    for (int b = 0; b < BTN_COUNT; b++)
        if (s_st[b].stable && !s_st[b].ignore) return true;
    return false;
}

btn_reboot_t buttons_reboot_request(void) { return s_reboot_req; }

void buttons_init(void)
{
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    for (int i = 0; i < BTN_COUNT; i++) s_rt[i] = s_cfg[i];
    s_rt[BTN_SW1].port = BTN_SW1_PORT; s_rt[BTN_SW1].pin = BTN_SW1_PIN;
    s_rt[BTN_SW2].port = BTN_SW2_PORT; s_rt[BTN_SW2].pin = BTN_SW2_PIN;
    s_rt[BTN_SW3].port = BTN_SW3_PORT; s_rt[BTN_SW3].pin = BTN_SW3_PIN;
    s_rt[BTN_SW4].port = BTN_SW4_PORT; s_rt[BTN_SW4].pin = BTN_SW4_PIN;
    s_rt[BTN_SW5].port = BTN_SW5_PORT; s_rt[BTN_SW5].pin = BTN_SW5_PIN;

    GPIO_InitTypeDef g = { 0 };
    g.Mode = GPIO_MODE_IT_RISING_FALLING;     /* EXTI both edges = wake    */
    g.Pull = GPIO_NOPULL;                     /* external 47k pull-ups (V2) */
    for (int b = 0; b < BTN_COUNT; b++) {
        g.Pin = s_rt[b].pin;
        HAL_GPIO_Init(s_rt[b].port, &g);
    }

    /* Unique EXTI lines: 12, 13, 2, 0, 4 (see board.h).                  */
    HAL_NVIC_SetPriority(EXTI0_IRQn,  8, 0); HAL_NVIC_EnableIRQ(EXTI0_IRQn);
    HAL_NVIC_SetPriority(EXTI2_IRQn,  8, 0); HAL_NVIC_EnableIRQ(EXTI2_IRQn);
    HAL_NVIC_SetPriority(EXTI4_IRQn,  8, 0); HAL_NVIC_EnableIRQ(EXTI4_IRQn);
    HAL_NVIC_SetPriority(EXTI12_IRQn, 8, 0); HAL_NVIC_EnableIRQ(EXTI12_IRQn);
    HAL_NVIC_SetPriority(EXTI13_IRQn, 8, 0); HAL_NVIC_EnableIRQ(EXTI13_IRQn);

    /* A key held (or stuck low) at power-up is ignored until released.   */
    buttons_ignore_until_release();
}

void buttons_tick_1ms(void)
{
    uint32_t now = HAL_GetTick();
    int held = 0;

    for (int b = 0; b < BTN_COUNT; b++) {
        volatile btn_state_t *st = &s_st[b];

        /* --- debounce integrator ------------------------------------- */
        if (raw_pressed((btn_id_t)b)) {
            if (st->integrator < DEBOUNCE_MS) st->integrator++;
        } else if (st->integrator > 0) {
            st->integrator--;
        }

        bool was = st->stable;
        if (st->integrator == DEBOUNCE_MS) st->stable = true;
        else if (st->integrator == 0)      st->stable = false;

        if (!st->stable && st->integrator == 0) s_seen_released |= (uint8_t)(1u << b);
        if (st->stable) held++;

        /* Wake-press swallowing: re-arm once fully released.            */
        if (st->ignore && !st->stable && st->integrator == 0 &&
            now - s_ignore_since >= IGNORE_MIN_MS) {
            st->ignore = false;
            continue;
        }

        /* --- edge handling -------------------------------------------- */
        if (st->stable && !was) {                       /* press           */
            st->t_press    = now;
            /* The physical press began DEBOUNCE_MS earlier: that is the latency origin.         */
            st->t_origin   = now - DEBOUNCE_MS;
            st->long_fired = false;
            st->t_repeat   = now + REPEAT_DELAY_MS;
            st->on_press   = acts_on_press((btn_id_t)b);
            if (st->on_press) push_event((btn_id_t)b, BTN_EV_SHORT);
        }
        if (!st->stable && was) {                       /* release         */
            if (st->chord) {
                st->chord = false;                      /* silent release  */
                st->short_pending = false;
            } else if (st->on_press) {
                /* already reported on press */
            } else if (!st->long_fired) {
                /* Release-acting keys: the latency origin is the (physical) release.          */
                st->t_origin = now - DEBOUNCE_MS;
                if (s_rt[b].allow_double) {
                    if (st->short_pending &&
                        (now - st->t_release) <= DOUBLE_GAP_MS) {
                        st->short_pending = false;
                        push_event((btn_id_t)b, BTN_EV_DOUBLE);
                    } else {
                        st->short_pending = true;       /* defer decision  */
                        st->t_release = now;
                    }
                } else {
                    push_event((btn_id_t)b, BTN_EV_SHORT);
                }
            }
        }

        /* --- deferred short (no second click arrived) ------------------ */
        if (st->short_pending && !st->stable &&
            (now - st->t_release) > DOUBLE_GAP_MS) {
            st->short_pending = false;
            push_event((btn_id_t)b, BTN_EV_SHORT);
        }

        /* --- long press ------------------------------------------------ */
        if (st->stable && !st->long_fired &&
            (now - st->t_press) >= LONG_MS) {
            st->long_fired = true;
            st->short_pending = false;
            st->t_origin = now;
            /* Volume keys use repeat, not long. */
            if (b == BTN_SW1 || b == BTN_SW2 || b == BTN_SW3)
                push_event((btn_id_t)b, BTN_EV_LONG);
        }

        /* --- auto-repeat ------------------------------------------------ */
        if (st->stable && s_rt[b].allow_repeat &&
            (int32_t)(now - st->t_repeat) >= 0) {
            st->t_repeat = now + REPEAT_RATE_MS;
            st->t_origin = now;                 /* latency origin of this repeat          */
            push_event((btn_id_t)b, BTN_EV_REPEAT);
        }
    }

    /* --- chords: two or more keys down = every held key goes silent ---- */
    if (held >= 2) {
        for (int b = 0; b < BTN_COUNT; b++)
            if (s_st[b].stable) { s_st[b].chord = true; s_st[b].short_pending = false; }
    }

    /* --- 2.7.0: SW2 + SW3 (and nothing else) held for chord_ms = one
     *     BTN_EV_CHORD. Goes straight into the queue: push_event() drops
     *     everything from keys that are part of a chord.                  */
    if (held == 2 && s_st[BTN_SW2].stable && s_st[BTN_SW3].stable &&
        !s_st[BTN_SW2].ignore && !s_st[BTN_SW3].ignore) {
        if (s_nav_chord_start == 0) {
            s_nav_chord_start = now ? now : 1;
            s_nav_chord_fired = false;
        } else if (!s_nav_chord_fired && now - s_nav_chord_start >= s_tm.chord_ms) {
            s_nav_chord_fired = true;
            uint8_t next = (uint8_t)((s_evq_w + 1) % EVQ_LEN);
            if (next != s_evq_r) {
                s_evq[s_evq_w] = (btn_event_t){ BTN_SW2, BTN_EV_CHORD, s_nav_chord_start };
                s_evq_w = next;
            }
        }
    } else {
        s_nav_chord_start = 0;
    }

    /* --- SW4+SW5 held 5 s => reboot; with SW1 (play) also held =>
     *     reboot into the USB firmware-update bootloader. Armed only after
     *     both keys have been released once since boot.                  */
    const uint8_t vol_mask = (uint8_t)((1u << BTN_SW4) | (1u << BTN_SW5));
    if ((s_seen_released & vol_mask) == vol_mask &&
        s_st[BTN_SW4].stable && s_st[BTN_SW5].stable &&
        !s_st[BTN_SW4].ignore && !s_st[BTN_SW5].ignore) {
        if (s_chord_start == 0) s_chord_start = now ? now : 1;
        else if (now - s_chord_start >= REBOOT_CHORD_MS && !s_reboot_req) {
            s_reboot_req   = s_st[BTN_SW1].stable ? BTN_REBOOT_DFU : BTN_REBOOT_RESET;
            s_reboot_req_t = now;
        }
    } else {
        s_chord_start = 0;
    }

    /* Main loop didn't act (hung): reset from here.                      */
    if (s_reboot_req && now - s_reboot_req_t >= REBOOT_GRACE_MS) {
        diag_note_reset(DIAG_RESET_CHORD);      /* 2.6.0: DFU chord = reset */
        NVIC_SystemReset();
    }
}
