/**
 * @file    sdcard.c
 * @brief   SDMMC1 driver (HAL-based) - player 2.6.7 driver, extended for the
 *          display-test firmware dt-0.2.0 (see sdcard.h).
 *
 * Electrical notes (V2 schematic, TXS02612 datasheet SCES682C):
 *   - The TXS02612's internal R1/R2 pull up every CMD/DAT line on both
 *     sides (4k when high, 40k when low). MCU pulls stay off.
 *   - SEL strapped low = port B0 = the card. VCCA = 1.8 V (always on),
 *     VCCB0/VCCB1 = switched +3.3 V (also feeds the panel and its booster).
 *   - Translator delays at VCCA 1.8 / VCCB 3.3 (max): CLKA->CLKB 4.5 ns,
 *     DATB->DATA 6.3 ns, CMDB->CMDA 6.0 ns. In default-speed mode the card
 *     may take up to 14 ns after its falling clock edge, and the SDMMC
 *     samples on the next rising edge: the round trip (24.8 ns + pads)
 *     doesn't fit the 20.8 ns half-period at 24 MHz. Hence the
 *     configurable clock (dt default 12 MHz).
 *   - Card detect: switch to GND, external 330k pull-up to 1.8 V.
 *
 * Changes from the player driver (all marked "dt:"):
 *   - configurable bus parameters (sdcard_set_config);
 *   - HAL_SD_Init split into its steps so a failure names its stage;
 *   - forced SDMMC1 reset + cleared handle before every attempt, full
 *     HAL_SD_DeInit after a failed one;
 *   - CMD12 + wait-for-TRANSFER recovery after a failed read/write;
 *   - optional IDMA transfers with an aligned bounce buffer;
 *   - sdcard_probe(): identification one command at a time.
 */
#include "sdcard.h"
#include "board.h"
#include "stm32u5xx_hal.h"
#include <stdio.h>
#include <string.h>

static SD_HandleTypeDef s_sd;
static bool s_ready;
static sdcard_cfg_t s_cfg = SDCARD_CFG_DEFAULT;
static sdcard_report_t s_rep;
static sdcard_stats_t s_stats;
static sdcard_fail_t s_fail;

const sdcard_fail_t *sdcard_last_fail(void) { return &s_fail; }

static uint8_t pin_levels(void)
{
    uint32_t c = GPIOC->IDR, d = GPIOD->IDR;
    return (uint8_t)(((c & SD_D0_PIN) ? 1u : 0u) | ((c & SD_D1_PIN) ? 2u : 0u) |
                     ((c & SD_D2_PIN) ? 4u : 0u) | ((c & SD_D3_PIN) ? 8u : 0u) |
                     ((d & SD_CMD_PIN) ? 16u : 0u) | ((c & SD_CLK_PIN) ? 32u : 0u));
}

static uint8_t dat_low(uint32_t idr)
{
    return (uint8_t)(((idr & SD_D0_PIN) ? 0u : 1u) | ((idr & SD_D1_PIN) ? 0u : 2u) |
                     ((idr & SD_D2_PIN) ? 0u : 4u) | ((idr & SD_D3_PIN) ? 0u : 8u));
}

/* ---- configuration ------------------------------------------------------------ */

void sdcard_set_config(const sdcard_cfg_t *cfg)
{
    s_cfg = *cfg;
    if (!s_cfg.clock_div) s_cfg.clock_div = 1;   /* 0 = bypass (48 MHz): never */
    if (s_cfg.pin_speed > 3) s_cfg.pin_speed = 3;
}
const sdcard_cfg_t *sdcard_config(void) { return &s_cfg; }
uint32_t sdcard_clock_hz(void) { return 48000000u / (2u * s_cfg.clock_div); }

const sdcard_report_t *sdcard_last_report(void) { return &s_rep; }
const sdcard_stats_t *sdcard_stats(void) { return &s_stats; }
void sdcard_stats_reset(void) { memset(&s_stats, 0, sizeof s_stats); }

const char *sdcard_stage_name(sdcard_stage_t s)
{
    static const char *const n[] = {
        "NONE", "NO CARD", "NO CLOCK", "IDENTIFY", "SD STATUS", "BUS WIDTH",
        "TRANSFER", "READY",
    };
    return (unsigned)s < sizeof n / sizeof n[0] ? n[s] : "?";
}

void sdcard_err_text(uint32_t err, char *buf, size_t n)
{
    static const struct { uint32_t bit; const char *t; } k[] = {
        { SDMMC_ERROR_CMD_CRC_FAIL, "CCRC" },     { SDMMC_ERROR_DATA_CRC_FAIL, "DCRC" },
        { SDMMC_ERROR_CMD_RSP_TIMEOUT, "CTIMEOUT" }, { SDMMC_ERROR_DATA_TIMEOUT, "DTIMEOUT" },
        { SDMMC_ERROR_TX_UNDERRUN, "TXUNDR" },    { SDMMC_ERROR_RX_OVERRUN, "RXOVR" },
        { SDMMC_ERROR_ADDR_MISALIGNED, "ALIGN" }, { SDMMC_ERROR_BLOCK_LEN_ERR, "BLKLEN" },
        { SDMMC_ERROR_COM_CRC_FAILED, "COMCRC" }, { SDMMC_ERROR_ILLEGAL_CMD, "ILLCMD" },
        { SDMMC_ERROR_CARD_ECC_FAILED, "ECC" },   { SDMMC_ERROR_CC_ERR, "CCERR" },
        { SDMMC_ERROR_GENERAL_UNKNOWN_ERR, "GEN" }, { SDMMC_ERROR_INVALID_VOLTRANGE, "VOLT" },
        { SDMMC_ERROR_ADDR_OUT_OF_RANGE, "RANGE" }, { SDMMC_ERROR_REQUEST_NOT_APPLICABLE, "N/A" },
        { SDMMC_ERROR_INVALID_PARAMETER, "PARAM" }, { SDMMC_ERROR_UNSUPPORTED_FEATURE, "UNSUP" },
        { SDMMC_ERROR_BUSY, "BUSY" },             { SDMMC_ERROR_DMA, "DMA" },
        { SDMMC_ERROR_TIMEOUT, "TIMEOUT" },
    };
    size_t used = 0;
    buf[0] = '\0';
    if (!err) { snprintf(buf, n, "OK"); return; }
    for (unsigned i = 0; i < sizeof k / sizeof k[0] && used + 1 < n; ++i) {
        if (!(err & k[i].bit)) continue;
        int w = snprintf(buf + used, n - used, "%s%s", used ? "+" : "", k[i].t);
        if (w < 0) break;
        used += (size_t)w;
    }
    if (!used) snprintf(buf, n, "0X%08lX", (unsigned long)err);
}

/* ---- pins ----------------------------------------------------------------------- */

bool sdcard_present(void)
{
    /* Mechanical switch closes to GND when a card is inserted.           */
    return HAL_GPIO_ReadPin(SD_CD_PORT, SD_CD_PIN) == GPIO_PIN_RESET;
}

static void cd_gpio_init(void)
{
    static bool done;
    if (done) return;
    done = true;
    GPIO_InitTypeDef g = { 0 };
    __HAL_RCC_GPIOC_CLK_ENABLE();
    g.Mode = GPIO_MODE_IT_RISING_FALLING;       /* external 330k pull-up  */
    g.Pull = GPIO_NOPULL;
    g.Pin  = SD_CD_PIN;
    HAL_GPIO_Init(SD_CD_PORT, &g);
    HAL_NVIC_SetPriority(SD_CD_EXTI_IRQn, 10, 0);
    HAL_NVIC_EnableIRQ(SD_CD_EXTI_IRQn);
}

static void bus_pins(bool active)
{
    static const uint32_t speeds[4] = {
        GPIO_SPEED_FREQ_LOW, GPIO_SPEED_FREQ_MEDIUM, GPIO_SPEED_FREQ_HIGH, GPIO_SPEED_FREQ_VERY_HIGH,
    };
    GPIO_InitTypeDef g = { 0 };
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    g.Mode      = active ? GPIO_MODE_AF_PP : GPIO_MODE_ANALOG;
    g.Pull      = GPIO_NOPULL;
    g.Speed     = speeds[s_cfg.pin_speed & 3u];     /* dt: configurable    */
    g.Alternate = SD_AF;
    g.Pin = SD_D0_PIN | SD_D1_PIN | SD_D2_PIN | SD_D3_PIN | SD_CLK_PIN;
    HAL_GPIO_Init(GPIOC, &g);
    g.Pin = SD_CMD_PIN;
    HAL_GPIO_Init(GPIOD, &g);
}

/* dt: a clean slate for every attempt - whatever a failed attempt left in the
 * peripheral (power state, error flags, IDMA, CLKCR) and in the handle.   */
static void peripheral_reset(void)
{
    __HAL_RCC_SDMMC1_CLK_ENABLE();
    __HAL_RCC_SDMMC1_FORCE_RESET();
    __HAL_RCC_SDMMC1_RELEASE_RESET();
    memset(&s_sd, 0, sizeof s_sd);
}

/* ---- init ------------------------------------------------------------------------ */

static bool fail(sdcard_stage_t stage, uint32_t err, uint32_t t0)
{
    s_rep.stage = stage;
    s_rep.hal_err = err;
    s_rep.ms = HAL_GetTick() - t0;
    HAL_SD_DeInit(&s_sd);                        /* dt: always, even if never READY */
    __HAL_RCC_SDMMC1_CLK_DISABLE();
    s_ready = false;
    return false;
}

bool sdcard_init(void)
{
    cd_gpio_init();
    if (s_ready) return true;
    uint32_t t0 = HAL_GetTick();
    memset(&s_rep, 0, sizeof s_rep);
    s_rep.clock_hz = sdcard_clock_hz();
    if (!sdcard_present()) { s_rep.stage = SD_STAGE_DETECT; return false; }
    /* SDMMC kernel clock = HSI48. Off after Stop 2 until SystemClock_Config(). */
    if (!(RCC->CR & RCC_CR_HSI48RDY)) { s_rep.stage = SD_STAGE_CLOCK; return false; }

    peripheral_reset();
    bus_pins(true);
    HAL_Delay(2);                       /* card VDD ramp + 1 ms           */

    s_sd.Instance                 = SDMMC1;
    s_sd.Init.ClockEdge           = s_cfg.falling_edge ? SDMMC_CLOCK_EDGE_FALLING : SDMMC_CLOCK_EDGE_RISING;
    s_sd.Init.ClockPowerSave      = s_cfg.power_save ? SDMMC_CLOCK_POWER_SAVE_ENABLE : SDMMC_CLOCK_POWER_SAVE_DISABLE;
    s_sd.Init.BusWide             = s_cfg.bus_4bit ? SDMMC_BUS_WIDE_4B : SDMMC_BUS_WIDE_1B;
    s_sd.Init.HardwareFlowControl = s_cfg.hw_flow ? SDMMC_HARDWARE_FLOW_CONTROL_ENABLE : SDMMC_HARDWARE_FLOW_CONTROL_DISABLE;
    s_sd.Init.ClockDiv            = s_cfg.clock_div;

    /* HAL_SD_Init(), step by step (same order and state handling). */
    s_sd.Lock  = HAL_UNLOCKED;
    s_sd.State = HAL_SD_STATE_PROGRAMMING;
    if (HAL_SD_InitCard(&s_sd) != HAL_OK) return fail(SD_STAGE_IDENT, s_sd.ErrorCode, t0);

    HAL_SD_CardStatusTypeDef cs;
    if (HAL_SD_GetCardStatus(&s_sd, &cs) != HAL_OK) return fail(SD_STAGE_STATUS, s_sd.ErrorCode, t0);
    if (s_sd.SdCard.CardType == CARD_SDHC_SDXC && (cs.UhsSpeedGrade || cs.UhsAllocationUnitSize))
        s_sd.SdCard.CardSpeed = CARD_ULTRA_HIGH_SPEED;
    else
        s_sd.SdCard.CardSpeed = s_sd.SdCard.CardType == CARD_SDHC_SDXC ? CARD_HIGH_SPEED : CARD_NORMAL_SPEED;

    if (HAL_SD_ConfigWideBusOperation(&s_sd, s_sd.Init.BusWide) != HAL_OK)
        return fail(SD_STAGE_WIDEBUS, s_sd.ErrorCode, t0);

    uint32_t t1 = HAL_GetTick();
    while (HAL_SD_GetCardState(&s_sd) != HAL_SD_CARD_TRANSFER) {
        if (HAL_GetTick() - t1 >= SDMMC_SWDATATIMEOUT)
            return fail(SD_STAGE_TRANSFER, s_sd.ErrorCode | SDMMC_ERROR_TIMEOUT, t0);
    }
    s_sd.ErrorCode = HAL_SD_ERROR_NONE;
    s_sd.Context   = SD_CONTEXT_NONE;
    s_sd.State     = HAL_SD_STATE_READY;

    if (s_cfg.use_dma) {
        HAL_NVIC_SetPriority(SDMMC1_IRQn, 6, 0);
        HAL_NVIC_EnableIRQ(SDMMC1_IRQn);
    }
    s_rep.stage      = SD_STAGE_READY;
    s_rep.ms         = HAL_GetTick() - t0;
    s_rep.card_type  = s_sd.SdCard.CardType == CARD_SDHC_SDXC ? 1 : 0;
    s_rep.card_speed = s_sd.SdCard.CardSpeed == CARD_ULTRA_HIGH_SPEED ? 2 :
                       s_sd.SdCard.CardSpeed == CARD_HIGH_SPEED ? 1 : 0;
    s_rep.blocks     = s_sd.SdCard.LogBlockNbr;
    s_ready = true;
    return true;
}

void sdcard_deinit(void)
{
    HAL_NVIC_DisableIRQ(SDMMC1_IRQn);
    if (s_ready) HAL_SD_DeInit(&s_sd);
    s_ready = false;
}

void sdcard_power_off(void)
{
    sdcard_deinit();
    __HAL_RCC_SDMMC1_CLK_DISABLE();
    bus_pins(false);
}

/* 2.6.7: card left powered, bus stopped, CLK held low (TXS02612 CLKA never
 * floats); sdcard_init() starts again from CMD0.                          */
void sdcard_idle(void)
{
    sdcard_deinit();
    __HAL_RCC_SDMMC1_CLK_DISABLE();
    bus_pins(false);
    GPIO_InitTypeDef g = { 0 };
    HAL_GPIO_WritePin(GPIOC, SD_CLK_PIN, GPIO_PIN_RESET);
    g.Mode  = GPIO_MODE_OUTPUT_PP;
    g.Pull  = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Pin   = SD_CLK_PIN;
    HAL_GPIO_Init(GPIOC, &g);
}

bool sdcard_ready(void) { return s_ready; }

uint32_t sdcard_card_id(void)
{
    HAL_SD_CardCIDTypeDef cid;
    if (!s_ready || HAL_SD_GetCardCID(&s_sd, &cid) != HAL_OK) return 0;
    uint32_t h = 2166136261u;                   /* FNV-1a over the fields  */
    const uint32_t f[6] = { cid.ManufacturerID, cid.OEM_AppliID, cid.ProdName1,
                            cid.ProdName2, cid.ProdSN, cid.ManufactDate };
    for (int i = 0; i < 6; i++) { h ^= f[i]; h *= 16777619u; }
    return h ? h : 1u;
}

uint32_t sdcard_block_count(void)
{
    HAL_SD_CardInfoTypeDef ci;
    if (!s_ready || HAL_SD_GetCardInfo(&s_sd, &ci) != HAL_OK) return 0;
    return ci.LogBlockNbr;
}

uint32_t sdcard_block_size(void) { return 512u; }

/* ---- I/O ---------------------------------------------------------------------------- */

static bool wait_transfer_done(uint32_t timeout_ms)
{
    uint32_t t0 = HAL_GetTick();
    while (HAL_SD_GetCardState(&s_sd) != HAL_SD_CARD_TRANSFER) {
        if (HAL_GetTick() - t0 > timeout_ms) return false;
    }
    return true;
}

/* dt: after a failed transfer the card may still be in data state: stop it
 * and wait for TRANSFER, so the next command isn't refused.               */
static void recover(void)
{
    /* dt-0.2.1: the HAL's polled-read timeout leaves CMDTRANS set and the DPSM waiting; clear
     * them and let CMD12 (CMDSTOP) abort the data path, as HAL_SD_Abort does.                    */
    __SDMMC_CMDTRANS_DISABLE(s_sd.Instance);
    (void)SDMMC_CmdStopTransfer(s_sd.Instance);
    s_sd.Instance->DCTRL = SDMMC_DCTRL_FIFORST;
    s_sd.Instance->DCTRL = 0;
    __HAL_SD_CLEAR_FLAG(&s_sd, SDMMC_STATIC_FLAGS);
    s_sd.State = HAL_SD_STATE_READY;
    s_sd.Context = SD_CONTEXT_NONE;
    (void)wait_transfer_done(200);
}

/* IDMA path: completion flags set by the HAL callbacks below. */
static volatile bool s_dma_done, s_dma_err;
static uint8_t s_bounce[8 * 512] __attribute__((aligned(32)));

void SDMMC1_IRQHandler(void) { HAL_SD_IRQHandler(&s_sd); }
void HAL_SD_RxCpltCallback(SD_HandleTypeDef *hsd) { (void)hsd; s_dma_done = true; }
void HAL_SD_TxCpltCallback(SD_HandleTypeDef *hsd) { (void)hsd; s_dma_done = true; }
void HAL_SD_ErrorCallback(SD_HandleTypeDef *hsd)  { (void)hsd; s_dma_err = true; s_dma_done = true; }

static bool dma_xfer(bool write, uint8_t *buf, uint32_t lba, uint32_t nblk, uint32_t timeout)
{
    s_dma_done = s_dma_err = false;
    HAL_StatusTypeDef st = write ? HAL_SD_WriteBlocks_DMA(&s_sd, buf, lba, nblk)
                                 : HAL_SD_ReadBlocks_DMA(&s_sd, buf, lba, nblk);
    if (st != HAL_OK) return false;
    uint32_t t0 = HAL_GetTick();
    while (!s_dma_done) {
        if (HAL_GetTick() - t0 > timeout) { (void)HAL_SD_Abort(&s_sd); return false; }
    }
    return !s_dma_err;
}

static bool xfer(bool write, uint8_t *buf, uint32_t lba, uint32_t nblk)
{
    /* dt-0.2.1: reads 250 ms (spec: 100 ms max for SDHC/SDXC), writes 500 ms (spec 250 ms x2).
     * dt-0.2.0 used 1 s / 2 s, which made a mount on a silent bus take 3 s.                   */
    const uint32_t timeout = write ? 500u : 250u;
    const uint32_t t_start = HAL_GetTick();
    bool ok;
    if (!s_cfg.use_dma) {
        ok = (write ? HAL_SD_WriteBlocks(&s_sd, buf, lba, nblk, timeout)
                    : HAL_SD_ReadBlocks(&s_sd, buf, lba, nblk, timeout)) == HAL_OK;
    } else if (((uintptr_t)buf & 3u) == 0) {
        ok = dma_xfer(write, buf, lba, nblk, timeout);
    } else {
        /* IDMA needs word-aligned buffers; FatFs can hand any pointer.     */
        ok = true;
        while (nblk && ok) {
            uint32_t n = nblk > 8u ? 8u : nblk;
            if (write) memcpy(s_bounce, buf, n * 512u);
            ok = dma_xfer(write, s_bounce, lba, n, timeout);
            if (ok && !write) memcpy(buf, s_bounce, n * 512u);
            buf += n * 512u; lba += n; nblk -= n;
        }
    }
    if (ok) ok = wait_transfer_done(timeout);
    if (!ok) {
        /* Dynamic STA bits (DPSMACT, BUSYD0), DCOUNT and the pins survive the HAL's flag clear. */
        s_fail = (sdcard_fail_t){ true, s_sd.Instance->STA, s_sd.Instance->DCOUNT,
                                  s_sd.Instance->DCTRL, s_sd.Instance->CLKCR, pin_levels(),
                                  HAL_GetTick() - t_start };
        s_stats.last_err = s_sd.ErrorCode ? s_sd.ErrorCode : SDMMC_ERROR_TIMEOUT;
        if (write) s_stats.write_errs++; else s_stats.read_errs++;
        recover();
    }
    return ok;
}

bool sdcard_read(uint8_t *buf, uint32_t lba, uint32_t nblk)
{
    if (!s_ready) return false;
    s_stats.reads++;
    return xfer(false, buf, lba, nblk);
}

bool sdcard_write(const uint8_t *buf, uint32_t lba, uint32_t nblk)
{
    if (!s_ready) return false;
    s_stats.writes++;
    return xfer(true, (uint8_t *)buf, lba, nblk);
}

/* ---- data line check (dt-0.2.1) ------------------------------------------------------------------ */

bool sdcard_line_check(uint32_t lba, sdcard_linecheck_t *r)
{
    memset(r, 0, sizeof *r);
    if (!s_ready) return false;
    SDMMC_TypeDef *S = s_sd.Instance;
    S->DCTRL = 0;
    __HAL_SD_CLEAR_FLAG(&s_sd, SDMMC_STATIC_FLAGS);
    SDMMC_DataInitTypeDef c = {
        .DataTimeOut   = sdcard_clock_hz() / 10u,          /* 100 ms in card clocks         */
        .DataLength    = 512u,
        .DataBlockSize = SDMMC_DATABLOCK_SIZE_512B,
        .TransferDir   = SDMMC_TRANSFER_DIR_TO_SDMMC,
        .TransferMode  = SDMMC_TRANSFER_MODE_BLOCK,
        .DPSM          = SDMMC_DPSM_DISABLE,
    };
    (void)SDMMC_ConfigData(S, &c);
    __SDMMC_CMDTRANS_ENABLE(S);
    r->cmd_err = SDMMC_CmdReadSingleBlock(S, s_sd.SdCard.CardType == CARD_SDHC_SDXC ? lba : lba * 512u);
    uint8_t low = 0;
    if (!r->cmd_err) {
        uint32_t t0 = HAL_GetTick();
        while (HAL_GetTick() - t0 < 150u) {
            low |= dat_low(GPIOC->IDR);
            uint32_t sta = S->STA;
            if (!(sta & SDMMC_STA_RXFIFOE)) { (void)S->FIFO; r->bytes += 4u; continue; }
            if (sta & (SDMMC_STA_DATAEND | SDMMC_STA_DCRCFAIL | SDMMC_STA_DTIMEOUT | SDMMC_STA_RXOVERR)) break;
        }
        while (!(S->STA & SDMMC_STA_RXFIFOE) && r->bytes < 1024u) { (void)S->FIFO; r->bytes += 4u; }
    }
    uint32_t sta = S->STA;
    r->low_seen = low;
    r->dataend = (sta & SDMMC_STA_DATAEND) != 0;
    r->dcrc = (sta & SDMMC_STA_DCRCFAIL) != 0;
    r->dtimeout = (sta & SDMMC_STA_DTIMEOUT) != 0;
    r->rxovr = (sta & SDMMC_STA_RXOVERR) != 0;
    r->dpsm_active = (sta & SDMMC_STA_DPSMACT) != 0;
    r->dcount = S->DCOUNT;
    __SDMMC_CMDTRANS_DISABLE(S);
    if (r->dpsm_active) (void)SDMMC_CmdStopTransfer(S);
    S->DCTRL = SDMMC_DCTRL_FIFORST;
    S->DCTRL = 0;
    __HAL_SD_CLEAR_FLAG(&s_sd, SDMMC_STATIC_FLAGS);
    s_sd.State = HAL_SD_STATE_READY;
    s_sd.Context = SD_CONTEXT_NONE;
    (void)wait_transfer_done(200);
    return r->dataend && !r->dcrc;
}

/* ---- step-by-step identification ------------------------------------------------- */

bool sdcard_probe(sdcard_probe_t *p)
{
    memset(p, 0, sizeof *p);
    cd_gpio_init();
    sdcard_deinit();
    if (!sdcard_present() || !(RCC->CR & RCC_CR_HSI48RDY)) return false;
    peripheral_reset();
    bus_pins(true);
    HAL_Delay(2);

    SDMMC_InitTypeDef in = { 0 };
    in.ClockEdge           = SDMMC_CLOCK_EDGE_RISING;
    in.ClockPowerSave      = SDMMC_CLOCK_POWER_SAVE_DISABLE;
    in.BusWide             = SDMMC_BUS_WIDE_1B;
    in.HardwareFlowControl = SDMMC_HARDWARE_FLOW_CONTROL_DISABLE;
    in.ClockDiv            = 48000000u / (2u * 400000u);          /* 400 kHz */
    (void)SDMMC_Init(SDMMC1, in);
    (void)SDMMC_PowerState_ON(SDMMC1);
    HAL_Delay(2);                                /* >= 74 clocks          */

    bool ok = false;
    p->last_step = 1;
    if ((p->cmd0 = SDMMC_CmdGoIdleState(SDMMC1)) != 0) goto out;
    p->last_step = 2;
    p->cmd8 = SDMMC_CmdOperCond(SDMMC1);
    p->v2 = p->cmd8 == 0;
    if (!p->v2) (void)SDMMC_CmdGoIdleState(SDMMC1);   /* v1 card: CMD8 is illegal */
    p->last_step = 3;
    uint32_t t0 = HAL_GetTick();
    do {
        p->acmd41_tries++;
        if ((p->acmd41 = SDMMC_CmdAppCommand(SDMMC1, 0)) != 0) break;
        if ((p->acmd41 = SDMMC_CmdAppOperCommand(SDMMC1, SDMMC_VOLTAGE_WINDOW_SD |
                          (p->v2 ? SDMMC_HIGH_CAPACITY : 0u))) != 0) break;
        p->ocr = SDMMC_GetResponse(SDMMC1, SDMMC_RESP1);
    } while (!(p->ocr & 0x80000000u) && HAL_GetTick() - t0 < 1500u);
    p->acmd41_ms = HAL_GetTick() - t0;
    if (p->acmd41 || !(p->ocr & 0x80000000u)) {
        if (!p->acmd41) p->acmd41 = SDMMC_ERROR_TIMEOUT;
        goto out;
    }
    p->last_step = 4;
    if ((p->cmd2 = SDMMC_CmdSendCID(SDMMC1)) != 0) goto out;
    for (int i = 0; i < 4; i++) p->cid[i] = SDMMC_GetResponse(SDMMC1, SDMMC_RESP1 + 4u * (uint32_t)i);
    p->last_step = 5;
    if ((p->cmd3 = SDMMC_CmdSetRelAdd(SDMMC1, &p->rca)) != 0) goto out;
    p->last_step = 6;
    if ((p->cmd9 = SDMMC_CmdSendCSD(SDMMC1, (uint32_t)p->rca << 16)) != 0) goto out;
    for (int i = 0; i < 4; i++) p->csd[i] = SDMMC_GetResponse(SDMMC1, SDMMC_RESP1 + 4u * (uint32_t)i);
    if ((p->csd[0] >> 30) == 1u) {               /* CSD 2.0: (C_SIZE+1) x 512 KB */
        uint32_t c_size = ((p->csd[1] & 0x3Fu) << 16) | (p->csd[2] >> 16);
        p->blocks = (c_size + 1u) * 1024u;
    } else {                                     /* CSD 1.0                      */
        uint32_t read_bl_len = (p->csd[1] >> 16) & 0xFu;
        uint32_t c_size = ((p->csd[1] & 0x3FFu) << 2) | (p->csd[2] >> 30);
        uint32_t mult = (p->csd[2] >> 15) & 0x7u;
        p->blocks = ((c_size + 1u) << (mult + 2u)) << read_bl_len >> 9;
    }
    p->last_step = 7;
    if ((p->cmd7 = SDMMC_CmdSelDesel(SDMMC1, (uint32_t)p->rca << 16)) != 0) goto out;
    (void)SDMMC_CmdSelDesel(SDMMC1, 0);          /* deselect again               */
    ok = true;
out:
    (void)SDMMC_PowerState_OFF(SDMMC1);
    __HAL_RCC_SDMMC1_CLK_DISABLE();
    return ok;
}
