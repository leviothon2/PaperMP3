/**
 * @file    npm1300.c
 * @brief   nPM1300 register-level driver.
 *
 * Peripheral bases (datasheet "Instances"): MAIN 0x00, VBUSIN 0x02,
 * BCHARGER 0x03, BUCK 0x04, ADC 0x05, GPIOS 0x06, LDSW 0x08, SHIP 0x0B.
 *
 * V2 board: BUCK1 = 1.8 V (always on, VSET1 47k), BUCK2 = 3.3 V (VSET2
 * 330k), LDO1/LDO2 unused. GPIO0 <-> MCU PC3 is either the PMIC's VBUS
 * interrupt output (BUCK2 then switched over I2C) or the BUCK2 enable
 * input - see BOARD_PC3_PMIC_IRQ in board.h.
 *
 * Register encodings cross-checked against Zephyr's nPM1300 MFD /
 * regulator / charger drivers (events: +0 SET, +1 CLR, +2 INTENSET,
 * +3 INTENCLR; BUCKENCTRL BUCK2 pin select in [5:3], invert bit 7).
 */
#include "npm1300.h"
#include "i2c_bus.h"
#include "board.h"
#include "stm32u5xx_hal.h"

/* ---- register addresses (base<<8 | offset) ----------------------------- */
#define REG_TASKSWRESET          0x0001u  /* MAIN.TASKSWRESET              */
#define REG_EVENTSVBUSIN0CLR     0x0017u  /* VBUS detected/removed events  */
#define REG_INTENVBUSIN0SET      0x0018u
#define REG_INTENVBUSIN0CLR      0x0019u
#define REG_BUCK2ENASET          0x0402u  /* BUCK2 software enable (task)  */
#define REG_BUCK2ENACLR          0x0403u
#define REG_BUCK1PWMSET          0x0404u  /* BUCK1 forced PWM (task)       */
#define REG_BUCK1PWMCLR          0x0405u
#define REG_VBUSINILIM0          0x0201u  /* VBUSIN input current limit    */
#define REG_TASKUPDATEILIM       0x0200u  /* VBUSIN.TASKUPDATEILIMSW       */
#define REG_BUCK1NORMVOUT        0x0408u  /* BUCK1 software voltage: 1.0 V
                                             + 0.1 V x code (0..23)      */
#define REG_BUCKENCTRL           0x040Cu  /* BUCK1/2 enable pin selection  */
#define REG_BUCKSWCTRLSEL        0x040Fu  /* bit0: BUCK1 uses NORMVOUT    */
#define REG_GPIOMODE0            0x0600u  /* GPIOMODE[n] = 0x0600 + n      */
#define REG_GPIOPDEN0            0x060Fu  /* GPIOPDEN[n] = 0x060F + n      */
#define REG_GPIOOPENDRAIN0       0x0614u  /* GPIOOPENDRAIN[n]              */
#define GPIOMODE_GPIINPUT        0u
#define GPIOMODE_GPOIRQ          5u       /* interrupt output, active high */
#define BUCKENCTRL_BUCK2_MASK    0xB8u    /* pin select [5:3] + invert [7] */
#define REG_USBCDETECTSTATUS     0x0205u  /* CC comparator status          */
#define REG_VBUSINSTATUS         0x0207u  /* VBUSINPRESENT etc.            */
#define REG_TASKRELEASEERR       0x0300u  /* charger: leave the error state */
#define REG_TASKCLEARCHGERR      0x0301u  /* charger: clear error registers */
#define REG_TASKCLEARSAFETYTIMER 0x0302u
#define REG_BCHGENABLESET        0x0304u  /* charger enable (W1S)          */
#define REG_BCHGDISABLESET       0x0306u  /* [1] DISABLENTC, [0] DISABLERECHARGE */
#define REG_BCHGDISABLECLR       0x0307u
#define BCHGDISABLE_NTC          0x02u
#define REG_ADCNTCRSEL           0x050Au  /* 0 none, 1 10k, 2 47k, 3 100k  */
#define REG_BCHGENABLECLR        0x0305u
#define REG_BCHGISETMSB          0x0308u  /* ICHG[8:1], 2 mA/LSB overall   */
#define REG_BCHGISETLSB          0x0309u
#define REG_BCHGVTERM            0x030Cu  /* normal-temp termination       */
#define REG_BCHGCHARGESTATUS     0x0334u  /* charging status flags         */
#define REG_TASKVBATMEASURE      0x0500u  /* ADC single-shot VBAT          */
#define REG_ADCCONFIG            0x0509u
#define REG_ADCVBATRESULTMSB     0x0511u
#define REG_ADCGP0RESULTLSBS     0x0515u
#define REG_ADCIBATMEASSTATUS    0x0510u  /* start of the result block     */
#define REG_ADCIBATMEASEN        0x0524u  /* IBAT measured with each VBAT  */
#define REG_TASKDIETEMPMEASURE   0x0502u  /* ADC single-shot die temp      */
#define REG_ADCDIETEMPRESULTMSB  0x0513u
#define REG_BCHGISETDISCHARGEMSB 0x030Au  /* discharge current limit       */
#define REG_BCHGISETDISCHARGELSB 0x030Bu
#define REG_TASKCLRERRLOG        0x0E00u  /* ERRLOG: clear the log         */
#define REG_RSTCAUSE             0x0E03u  /* why the PMIC last reset       */
#define REG_CHARGERERRREASON     0x0E04u

static bool wr8(uint16_t reg, uint8_t val)
{
    uint8_t buf[3] = { (uint8_t)(reg >> 8), (uint8_t)reg, val };
    return i2c_write(NPM1300_I2C_ADDR, buf, sizeof buf);
}

static bool rd8(uint16_t reg, uint8_t *val)
{
    uint8_t a[2] = { (uint8_t)(reg >> 8), (uint8_t)reg };
    return i2c_write_read(NPM1300_I2C_ADDR, a, 2, val, 1);
}

static uint16_t s_charge_ma = BATT_CHARGE_MA_DEFAULT;

static bool write_iset(uint16_t charge_ma)
{
    /* BCHGISET in 2 mA units: MSB holds bits [8:1], LSB bit 0.           */
    uint16_t iset = charge_ma / 2;
    return wr8(REG_BCHGISETMSB, (uint8_t)(iset >> 1)) &&
           wr8(REG_BCHGISETLSB, (uint8_t)(iset & 1));
}

static bool s_no_ntc;                  /* 2.6.4: charging without NTC    */

static uint16_t clamp_charge(uint16_t ma)
{
    if (ma < 32)  ma = 32;                     /* nPM1300 range 32..800  */
    if (ma > 800) ma = 800;
    /* With no temperature monitoring, never above 0.5C of the 700 mAh
     * NP-BJ1 (350 mA).                                                  */
    if (s_no_ntc && ma > BATT_CHARGE_MA_NO_NTC_MAX) ma = BATT_CHARGE_MA_NO_NTC_MAX;
    return ma;
}

/* VBUSINILIM0 = code (5..15 = 500..1500 mA), then TASKUPDATEILIMSW moves
 * the input stage from its low start-up limit onto it.                  */
static bool set_ilim(uint8_t code)
{
    return wr8(REG_VBUSINILIM0, code) && wr8(REG_TASKUPDATEILIM, 0x01);
}

bool npm1300_init(uint16_t charge_ma, uint16_t vterm_mv)
{
    /* v2.3.1: FIRST thing - lift the USB input limit from the nPM1300's
     * start-up default (~100 mA) to 500 mA. With no battery fitted every
     * milliamp comes through VBUS; at 100 mA the splash refresh, codec
     * start, SD init and USB enumeration pulled VSYS down until BUCK1
     * (MCU 1.8 V) dropped below the BOR level. v2.2 only raised it after
     * the first USB poll, i.e. after all of those had already run.
     * 500 mA is what every USB port and USB-C source must supply.        */
    (void)set_ilim(5);

    /* v2.4: MCU rail 1.8 -> 1.9 V before anything heavy starts (see
     * BOARD_VDD_BOOST_MV): 200 mV of margin above the BOR instead of 100. */
    (void)npm1300_buck1_set_mv(BOARD_VDD_BOOST_MV);

    s_charge_ma = clamp_charge(charge_ma);
    if (!wr8(REG_BCHGENABLECLR, 0x01))                  return false;
    if (!write_iset(s_charge_ma))                       return false;

    /* Termination voltage: code 0..3 = 3.50..3.65 V, 4..13 = 4.00..4.45 V
     * in 50 mV steps (datasheet 6.2.14.12).                              */
    uint8_t code;
    if      (vterm_mv <= 3650) code = (uint8_t)((vterm_mv - 3500) / 50);
    else if (vterm_mv <  4000) code = 3;
    else                       code = (uint8_t)(4 + (vterm_mv - 4000) / 50);
    if (code > 13) code = 13;
    if (!wr8(REG_BCHGVTERM, code))                      return false;

    if (!wr8(REG_BCHGENABLESET, 0x01))                  return false;

    /* ADC: single-shot VBAT measurements on demand (no auto mode).       */
    if (!wr8(REG_ADCCONFIG, 0x00))                      return false;

    uint8_t en = 0;
    if (!rd8(REG_BUCKENCTRL, &en))                      return false;
    const uint16_t mode = (uint16_t)(REG_GPIOMODE0 + NPM_GPIO_PC3);
#if BOARD_PC3_PMIC_IRQ
    /* BUCK2 on by software FIRST, then release it from any pin control
     * (an earlier firmware may have left GPIO0 in charge), then turn
     * GPIO0 into the push-pull, active-high interrupt output.            */
    if (!wr8(REG_BUCK2ENASET, 0x01))                    return false;
    if (!wr8(REG_BUCKENCTRL, (uint8_t)(en & ~BUCKENCTRL_BUCK2_MASK))) return false;
    if (!wr8((uint16_t)(REG_GPIOPDEN0 + NPM_GPIO_PC3), 0x00))       return false;
    if (!wr8((uint16_t)(REG_GPIOOPENDRAIN0 + NPM_GPIO_PC3), 0x00))  return false;
    if (!wr8(mode, GPIOMODE_GPOIRQ))                    return false;
    (void)npm1300_take_vbus_events();
    npm1300_vbus_irq_enable(true, true);
#else
    /* BUCK2 enable <- GPIO0 (MCU PC3, push-pull, held through Stop 2):
     * plain input, internal pull-down off.                               */
    if (!wr8(mode, GPIOMODE_GPIINPUT))                  return false;
    if (!wr8((uint16_t)(REG_GPIOPDEN0 + NPM_GPIO_PC3), 0x00)) return false;
    en = (uint8_t)((en & ~BUCKENCTRL_BUCK2_MASK) | ((NPM_GPIO_PC3 + 1u) << 3));
    if (!wr8(REG_BUCKENCTRL, en))                       return false;
#endif
    return true;
}

/* 2.5.2 / 2.6.4. The charger normally refuses to start (or stops) when the NTC
 * input says the battery is outside its temperature window - which is
 * what it says when no thermistor is fitted. With no_ntc set:
 *   - DISABLENTC: temperature monitoring off, charging in the "normal"
 *     region (ICHG, VTERM 4.20 V) regardless of the NTC pin;
 *   - ADCNTCRSEL = 0: the ADC stops measuring the (unconnected) pin;
 *   - the charge current is capped at BATT_CHARGE_MA_NO_NTC_MAX;
 *   - any latched charger error (e.g. an NTC fault while the board ran
 *     without a battery) and the safety timer are cleared.
 * no_ntc = false restores the start-up behaviour (2.5.0): monitoring on,
 * ADCNTCRSEL back to whatever it was before. Registers per the nPM1300
 * datasheet BCHARGER/ADC chapters and Zephyr's npm13xx_charger driver.  */
bool npm1300_set_no_ntc(bool no_ntc)
{
    static bool    have_orig;
    static uint8_t orig_rsel;
    if (!have_orig && rd8(REG_ADCNTCRSEL, &orig_rsel)) have_orig = true;

    s_no_ntc = no_ntc;
    uint16_t ma = clamp_charge(s_charge_ma);
    bool ok = wr8(REG_BCHGENABLECLR, 0x01);
    if (no_ntc) {
        ok = wr8(REG_BCHGDISABLESET, BCHGDISABLE_NTC) && ok;
        ok = wr8(REG_ADCNTCRSEL, 0x00) && ok;
    } else {
        ok = wr8(REG_BCHGDISABLECLR, BCHGDISABLE_NTC) && ok;
        if (have_orig) ok = wr8(REG_ADCNTCRSEL, orig_rsel) && ok;
    }
    if (ma != s_charge_ma && write_iset(ma)) s_charge_ma = ma;
    ok = wr8(REG_TASKRELEASEERR, 0x01) && ok;
    ok = wr8(REG_TASKCLEARCHGERR, 0x01) && ok;
    ok = wr8(REG_TASKCLEARSAFETYTIMER, 0x01) && ok;
    ok = wr8(REG_BCHGENABLESET, 0x01) && ok;
    npm1300_apply_vbus_limit(npm1300_vbus_status());
    return ok;
}

bool npm1300_no_ntc(void) { return s_no_ntc; }

/* BCHGCHARGESTATUS: [0] battery detected, [1] completed, [2] trickle,
 * [3] constant current, [4] constant voltage, [5] recharge, [6] die
 * temperature high, [7] supplement active.                              */
const char *npm1300_charger_state(void)
{
    uint8_t st = 0;
    if (npm1300_vbus_status() == NPM_VBUS_NONE) return "no USB";
    if (!rd8(REG_BCHGCHARGESTATUS, &st))       return "?";
    if (!(st & 0x01u)) return "no battery";
    if (st & 0x40u)    return "too hot";
    if (st & 0x08u)    return "charging";
    if (st & 0x10u)    return "topping up";
    if (st & 0x04u)    return "trickle";
    if (st & 0x02u)    return "full";
    return "not charging";
}

bool npm1300_set_charge_current(uint16_t charge_ma)
{
    charge_ma = clamp_charge(charge_ma);
    if (charge_ma == s_charge_ma) return true;
    /* ISET may only change with the charger disabled.                    */
    bool ok = wr8(REG_BCHGENABLECLR, 0x01) && write_iset(charge_ma);
    ok = wr8(REG_BCHGENABLESET, 0x01) && ok;
    if (ok) {
        s_charge_ma = charge_ma;
        npm1300_apply_vbus_limit(npm1300_vbus_status());
    }
    return ok;
}

uint16_t npm1300_charge_current(void) { return s_charge_ma; }

void npm1300_apply_vbus_limit(npm_vbus_t status)
{
    /* VBUSINILIM0 codes: 5..15 = 500..1500 mA (100 mA/LSB). The limit is
     * sized to the battery, not to the charger: charge current + system
     * headroom, rounded up, >= 500 mA (USB 2.0 / USB-C default power),
     * and only above 500 mA if the source advertises 1.5 A or 3 A. With
     * the NP-BJ1 default (350 mA) that is 500 mA on any source.
     *
     * Written on every call. 2.6.4: usb_app.c calls it on plug-in /
     * PMIC interrupt, a CC change, or the first check after boot/sleep. */
    if (status == NPM_VBUS_NONE) return;

    uint32_t want = s_charge_ma + BATT_SYSTEM_HEADROOM_MA;
    uint32_t code = (want + 99u) / 100u;
    if (code < 5) code = 5;
    if (status != NPM_VBUS_1500MA && code > 5) code = 5;
    if (code > 15) code = 15;
    (void)set_ilim((uint8_t)code);
}

bool npm1300_buck2(bool on)
{
    return wr8(on ? REG_BUCK2ENASET : REG_BUCK2ENACLR, 0x01);
}

void npm1300_vbus_irq_enable(bool detected, bool removed)
{
    uint8_t set = (uint8_t)((detected ? NPM_EV_VBUS_DETECTED : 0) |
                            (removed  ? NPM_EV_VBUS_REMOVED  : 0));
    uint8_t clr = (uint8_t)((NPM_EV_VBUS_DETECTED | NPM_EV_VBUS_REMOVED) & ~set);
    if (clr) (void)wr8(REG_INTENVBUSIN0CLR, clr);
    if (set) (void)wr8(REG_INTENVBUSIN0SET, set);
}

uint8_t npm1300_take_vbus_events(void)
{
    uint8_t ev = 0;
    if (!rd8((uint16_t)(REG_EVENTSVBUSIN0CLR - 1u), &ev)) return 0;   /* SET reg reads the flags */
    ev &= NPM_EV_VBUS_DETECTED | NPM_EV_VBUS_REMOVED;
    if (ev) (void)wr8(REG_EVENTSVBUSIN0CLR, ev);   /* W1C - drops the IRQ */
    return ev;
}

npm_vbus_t npm1300_vbus_status(void)
{
    npm_vbus_t v = NPM_VBUS_NONE;
    (void)npm1300_vbus_read(&v);
    return v;
}

bool npm1300_vbus_read(npm_vbus_t *out)
{
    uint8_t vs = 0, cc = 0;
    if (!rd8(REG_VBUSINSTATUS, &vs)) return false;
    if (!(vs & 0x01)) { *out = NPM_VBUS_NONE; return true; }  /* VBUSINPRESENT clear */

    /* USBCDETECTSTATUS: CC1[1:0] / CC2[3:2] comparator codes:
     * 00 none, 01 default, 10 1.5 A, 11 3 A (we cap at 1.5 A).           */
    (void)rd8(REG_USBCDETECTSTATUS, &cc);
    uint8_t c1 = cc & 0x03, c2 = (cc >> 2) & 0x03;
    uint8_t c  = (c1 > c2) ? c1 : c2;
    switch (c) {
        case 2:
        case 3:  *out = NPM_VBUS_1500MA; break;
        case 1:  *out = NPM_VBUS_500MA;  break;
        default: *out = NPM_VBUS_100MA;  break;
    }
    return true;
}

bool npm1300_charge_status(uint8_t *st)
{
    return rd8(REG_BCHGCHARGESTATUS, st);
}

bool npm1300_battery_present(void)
{
    if (npm1300_vbus_status() == NPM_VBUS_NONE) return true;  /* we're running on it */
    uint8_t st = 0;
    if (!rd8(REG_BCHGCHARGESTATUS, &st)) return true;          /* unknown: don't alarm */
    if (!(st & 0x01u)) return false;                            /* BATTERYDETECTED clear */
    uint16_t mv;
    if (npm1300_vbat_mv(&mv) && (mv < 2500u || mv > 4500u)) return false;
    return true;
}

static uint16_t s_buck1_mv;            /* 0 = still on the VSET resistor */
uint16_t npm1300_buck1_mv(void) { return s_buck1_mv; }

bool npm1300_buck1_set_mv(uint16_t mv)
{
    if (mv < 1000u) mv = 1000u;
    if (mv > 3300u) mv = 3300u;
    uint8_t code = (uint8_t)((mv - 1000u + 50u) / 100u);
    uint8_t sel = 0;
    if (!wr8(REG_BUCK1NORMVOUT, code))       return false;
    if (!rd8(REG_BUCKSWCTRLSEL, &sel))       return false;
    if (!wr8(REG_BUCKSWCTRLSEL, (uint8_t)(sel | 0x01u))) return false;
    uint8_t back = 0xFF;
    if (!rd8(REG_BUCK1NORMVOUT, &back) || back != code) return false;
    s_buck1_mv = (uint16_t)(1000u + 100u * code);
    return true;
}

bool npm1300_buck1_pwm(bool forced)
{
    return wr8(forced ? REG_BUCK1PWMSET : REG_BUCK1PWMCLR, 0x01);
}

bool npm1300_charging(void)
{
    uint8_t st = 0;
    if (!rd8(REG_BCHGCHARGESTATUS, &st)) return false;
    /* Bits: constant-current / constant-voltage / trickle phases.        */
    return (st & 0x1C) != 0;
}

bool npm1300_vbat_mv(uint16_t *mv)
{
    if (!wr8(REG_TASKVBATMEASURE, 0x01)) return false;
    HAL_Delay(1);                              /* conversion ~250 us      */

    uint8_t msb = 0, lsbs = 0;
    if (!rd8(REG_ADCVBATRESULTMSB, &msb))    return false;
    if (!rd8(REG_ADCGP0RESULTLSBS, &lsbs))   return false;
    uint16_t raw = (uint16_t)((msb << 2) | (lsbs & 0x03));   /* 10 bits   */
    /* Full scale 5.0 V (datasheet: VBAT measurement range 2.3-4.45 V,
     * VFS = 5 V).                                                        */
    *mv = (uint16_t)(((uint32_t)raw * 5000u) / 1023u);
    return true;
}

uint8_t npm1300_battery_level(void)
{
    /* Bucketed - the UI shows an icon, never a percentage, and updates
     * slowly (e-ink). Thresholds ~ Li-ion OCV under light load.          */
    uint16_t mv;
    if (!npm1300_vbat_mv(&mv)) return 2;       /* unknown: middle         */
    if (mv >= 4000) return 4;
    if (mv >= 3800) return 3;
    if (mv >= 3650) return 2;
    if (mv >= 3520) return 1;
    return 0;
}

uint8_t npm1300_battery_percent(void)
{
    /* Piecewise-linear OCV->SoC (light load). Good to ~5 %, which is
     * finer than one fill column of the 18-px-wide icon interior.        */
    static const struct { uint16_t mv; uint8_t pct; } tab[] = {
        { 4180, 100 }, { 4060, 90 }, { 3980, 80 }, { 3900, 70 },
        { 3820,  60 }, { 3770, 50 }, { 3720, 40 }, { 3680, 30 },
        { 3630,  20 }, { 3560, 10 }, { 3480,  5 }, { 3300,  0 },
    };
    uint16_t mv;
    if (!npm1300_vbat_mv(&mv)) return 50;       /* unknown: middle         */
    if (mv >= tab[0].mv) return 100;
    for (unsigned i = 1; i < sizeof tab / sizeof tab[0]; i++) {
        if (mv >= tab[i].mv) {
            uint16_t span_mv = tab[i - 1].mv - tab[i].mv;
            uint8_t  span_pc = tab[i - 1].pct - tab[i].pct;
            return (uint8_t)(tab[i].pct +
                   (uint32_t)(mv - tab[i].mv) * span_pc / span_mv);
        }
    }
    return 0;
}

/* ---- fuel-gauge measurements (2.6.0) ----------------------------------
 * Per Nordic's Zephyr npm13xx_charger driver: with ADCIBATMEASEN set, a
 * VBAT measurement also samples IBAT. Result block at 0x0510: [0] IBAT
 * status, [1] VBAT msb, [5] lsbs A (VBAT bits 1:0), [8] IBAT msb, [10] lsbs
 * B (IBAT bits 5:4). Full scale: discharge = 1.12 x discharge limit,
 * charge = 1.25 x charge current.                                        */
#define IBAT_STAT_DISCHARGE   0x04u
#define IBAT_STAT_TRICKLE     0x0Cu
#define IBAT_STAT_COOL        0x0Du
#define IBAT_STAT_NORMAL      0x0Fu
#define DISCHARGE_LIMIT_MA    1000u             /* code 415                */

bool npm1300_fg_setup(void)
{
    /* Discharge limit 1000 mA (code 415 = MSB 207, LSB 1): a known full
     * scale for the current measurement.                                 */
    return wr8(REG_BCHGISETDISCHARGEMSB, 207) &&
           wr8(REG_BCHGISETDISCHARGELSB, 1) &&
           wr8(REG_ADCIBATMEASEN, 1);
}

bool npm1300_fg_sample(uint16_t *mv, int32_t *ma_x10)
{
    if (!wr8(REG_TASKVBATMEASURE, 0x01)) return false;
    HAL_Delay(1);                              /* VBAT + IBAT ~500 us     */
    uint8_t a[2] = { (uint8_t)(REG_ADCIBATMEASSTATUS >> 8),
                     (uint8_t)REG_ADCIBATMEASSTATUS };
    uint8_t r[11];
    if (!i2c_write_read(NPM1300_I2C_ADDR, a, 2, r, sizeof r)) return false;
    uint16_t vraw = (uint16_t)((r[1] << 2) | (r[5] & 0x03));
    uint16_t iraw = (uint16_t)((r[8] << 2) | ((r[10] >> 4) & 0x03));
    *mv = (uint16_t)(((uint32_t)vraw * 5000u) / 1023u);
    int32_t fs_x10;                            /* full scale, 0.1 mA      */
    switch (r[0]) {
    case IBAT_STAT_DISCHARGE: fs_x10 = -(int32_t)DISCHARGE_LIMIT_MA * 112 / 10; break;
    case IBAT_STAT_TRICKLE:
    case IBAT_STAT_COOL:
    case IBAT_STAT_NORMAL:    fs_x10 = (int32_t)s_charge_ma * 125 / 10;        break;
    default:                  fs_x10 = 0;                                     break;
    }
    *ma_x10 = (int32_t)iraw * fs_x10 / 1023;
    return true;
}

/* Die temperature (2.6.3, e-ink fast-refresh gate). Result: MSB at
 * 0x0513, 2 LSBs in ADCGP0RESULTLSBS[5:4] (same layout as the Zephyr
 * npm13xx_charger driver); T = 394.67 - 0.7926 x code deg C.            */
bool npm1300_die_temp_c(int16_t *deg_c)
{
    if (!wr8(REG_TASKDIETEMPMEASURE, 0x01)) return false;
    HAL_Delay(2);
    uint8_t a[2] = { (uint8_t)(REG_ADCDIETEMPRESULTMSB >> 8),
                     (uint8_t)REG_ADCDIETEMPRESULTMSB };
    uint8_t r[3];                              /* 0x0513 die, 0x0514, LSBs */
    if (!i2c_write_read(NPM1300_I2C_ADDR, a, 2, r, sizeof r)) return false;
    int32_t raw  = (int32_t)((r[0] << 2) | ((r[2] >> 4) & 0x03));
    int32_t mdeg = 394670 - raw * 7926 / 10;
    if (mdeg < -40000 || mdeg > 125000) return false;   /* implausible     */
    *deg_c = (int16_t)(mdeg / 1000);
    return true;
}

uint8_t npm1300_soc_from_ocv(uint16_t mv)
{
    static const struct { uint16_t mv; uint8_t pct; } tab[] = {
        { 4180, 100 }, { 4060, 90 }, { 3980, 80 }, { 3900, 70 },
        { 3820,  60 }, { 3770, 50 }, { 3720, 40 }, { 3680, 30 },
        { 3630,  20 }, { 3560, 10 }, { 3480,  5 }, { 3300,  0 },
    };
    if (mv >= tab[0].mv) return 100;
    for (unsigned i = 1; i < sizeof tab / sizeof tab[0]; i++) {
        if (mv >= tab[i].mv) {
            uint16_t span_mv = tab[i - 1].mv - tab[i].mv;
            uint8_t  span_pc = tab[i - 1].pct - tab[i].pct;
            return (uint8_t)(tab[i].pct +
                   (uint32_t)(mv - tab[i].mv) * span_pc / span_mv);
        }
    }
    return 0;
}

bool npm1300_reset_cause(uint8_t *rstcause, uint8_t *chg_err)
{
    return rd8(REG_RSTCAUSE, rstcause) && rd8(REG_CHARGERERRREASON, chg_err);
}

void npm1300_clear_errlog(void)
{
    (void)wr8(REG_TASKCLRERRLOG, 0x01);
}

void npm1300_full_reset(void)
{
    (void)wr8(REG_TASKSWRESET, 0x01);          /* power-cycles all rails  */
    for (;;) { __NOP(); }                      /* rails drop momentarily  */
}
