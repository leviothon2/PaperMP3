/**
 * @file    cs43131.c
 * @brief   CS43131 register-level driver.
 *
 * All register addresses/values are from Cirrus DS1155F2:
 *   - power-up & XTAL start:   Example 5-14 / §5.13
 *   - pop-free HP power up:    Example 5-5
 *   - pop-free HP power down:  §5.8.1
 *   - register map:            §7
 *
 * I2C protocol (DS §4.13): each transaction sends a 3-byte MAP (register
 * address, MSB first) followed by a control byte (bit0 INCR), then data.
 *
 * DoP (V2): DSD_PATH_CTL_2 DSD_SRC[6:5] = 2 (ASP) feeds the DSD processor
 * from the I2S port; field encoding as in the Linux cs43130 driver (which
 * covers the CS43131). Marked for hardware verification in the README.
 */
#include "cs43131.h"
#include "board.h"
#include "i2c_bus.h"
#include "stm32u5xx_hal.h"

/* ---- register map (DS1155F2 §7) --------------------------------------- */
#define R_DEVID_AB          0x010000u  /* reads 0x43 0x11 0x31 ...        */
#define R_SYS_CLK_CTL       0x010006u  /* MCLK_INT / MCLK_SRC_SEL         */
#define R_SP_RATE           0x01000Bu  /* ASP_SPRATE                      */
#define R_SP_BITSIZE        0x01000Cu  /* XSP/ASP sample bit size         */
#define R_PAD_IF_CFG        0x01000Du  /* xSP_3ST clock-driver tristate   */
#define R_POPFREE_A         0x010010u  /* undocumented pop-free helper    */
#define R_PWR_DOWN          0x020000u  /* PDN_* bits                      */
/* PLL (2.6.0): 22.5792 MHz crystal -> 24.576 MHz MCLK for the 48 kHz
 * family. Register addresses and the 22579200 -> 24576000 entry of
 * pll_ratio_table (prediv 3, int 0x44, frac 0x06F700, mode 0, divout 8,
 * cal ratio 139) are from the Linux cs43130 driver, which covers the
 * CS43131.                                                               */
#define R_PLL_SET_1         0x030001u  /* bit0 PLL_START                  */
#define R_PLL_SET_2         0x030002u  /* PLL_DIV_FRAC[7:0]               */
#define R_PLL_SET_3         0x030003u  /* PLL_DIV_FRAC[15:8]              */
#define R_PLL_SET_4         0x030004u  /* PLL_DIV_FRAC[23:16]             */
#define R_PLL_SET_5         0x030005u  /* PLL_DIV_INT                     */
#define R_PLL_SET_6         0x030008u  /* PLL_DIVOUT                      */
#define R_PLL_SET_7         0x03000Au  /* PLL_CAL_RATIO                   */
#define R_PLL_SET_8         0x03001Bu  /* bit1 PLL_MODE                   */
#define R_PLL_SET_9         0x040002u  /* PLL reference pre-divider       */
#define R_XTAL_SET          0x020052u  /* XTAL_IBIAS                      */
#define R_CLKOUT_CTL        0x040004u  /* CLKOUT_DIV / CLKOUT_SEL         */
#define R_ASP_NUM1          0x040010u
#define R_ASP_NUM2          0x040011u
#define R_ASP_DEN1          0x040012u
#define R_ASP_DEN2          0x040013u
#define R_ASP_LCHI1         0x040014u
#define R_ASP_LCHI2         0x040015u
#define R_ASP_LCPR1         0x040016u
#define R_ASP_LCPR2         0x040017u
#define R_ASP_CLK_CFG       0x040018u  /* M/S, clock polarities           */
#define R_ASP_FRM_CFG       0x040019u  /* I2S framing                     */
#define R_ASP_CH1_LOC       0x050000u
#define R_ASP_CH2_LOC       0x050001u
#define R_ASP_CH1_SZEN      0x05000Au
#define R_ASP_CH2_SZEN      0x05000Bu
#define R_DSD_VOL_B         0x070000u
#define R_DSD_VOL_A         0x070001u
#define R_DSD_PATH1         0x070002u
#define R_DSD_IF_CFG        0x070003u  /* DSD_M/SB                        */
#define R_DSD_PATH2         0x070004u  /* DSD_SRC / DSD_EN / DSD_SPEED    */
#define DSD_SRC_ASP         (2u << 5)  /* DoP arriving on the ASP         */
#define DSD_EN              (1u << 4)
#define R_HP_OUT_CTL1       0x080000u  /* OUT_FS full-scale               */
#define R_POPFREE_B         0x080032u  /* undocumented pop-free helper    */
#define R_POPFREE_C         0x080046u  /* pop-free power-down helper      */
#define R_PCM_FILT_OPT      0x090000u
#define R_PCM_VOL_B         0x090001u  /* 0.5 dB steps, 0xFF = mute       */
#define R_PCM_VOL_A         0x090002u
#define R_PCM_PATH1         0x090003u
#define R_PCM_PATH2         0x090004u
#define R_CLASSH_CTL        0x0B0000u
#define R_HP_DETECT         0x0D0000u
#define R_HP_STATUS         0x0D0001u
#define R_INT_STATUS1       0x0F0000u
#define R_INT_STATUS2       0x0F0001u
#define R_INT_MASK1         0x0F0010u
#define R_INT_MASK2         0x0F0011u

/* R_PWR_DOWN bits */
#define PDN_XSP     (1u << 7)
#define PDN_ASP     (1u << 6)
#define PDN_DSDIF   (1u << 5)
#define PDN_HP      (1u << 4)
#define PDN_XTAL    (1u << 3)
#define PDN_PLL     (1u << 2)
#define PDN_CLKOUT  (1u << 1)

/* R_INT_STATUS1 bits (same layout as mask1) */
#define INT1_XTAL_READY       (1u << 4)
#define INT1_PLL_READY        (1u << 2)
#define INT1_HPDETECT_PLUG    (1u << 6)
#define INT1_HPDETECT_UNPLUG  (1u << 5)
#define INT1_HP_FLAGS         (INT1_HPDETECT_PLUG | INT1_HPDETECT_UNPLUG)

/* R_HP_STATUS (0xD0001): debounced level of the detect pin (DS 7.5.12).
 * The datasheet's wording leaves the polarity open, so it is only used
 * after a plug/unplug event flag (unambiguous) has agreed with it once;
 * if it ever disagrees it is ignored for good and the flags alone count. */
#define HPST_PLUG_DBC         (1u << 6)
#define HPST_UNPLUG_DBC       (1u << 5)

/* R_HP_DETECT (0xD0000), DS 7.5.11. The detect pin falls when a plug goes
 * in and rises when it comes out, so:
 *   RISE_DBC (bits 4:3) = UNPLUG debounce -> 00 = 0 ms
 *   FALL_DBC (bits 2:1) = PLUG debounce   -> 10 = 500 ms
 * (2.7.0's comment had these the other way round; the value 0xC4 itself
 * is the datasheet's and is unchanged.)                                  */
#define HPDET_CTRL_ON         (3u << 6)
#define HPDET_INV             (1u << 5)
#define HPDET_RISE_0MS        (0u << 3)
#define HPDET_FALL_500MS      (2u << 1)
#define HPDET_CFG             (HPDET_RISE_0MS | HPDET_FALL_500MS | \
                               (BOARD_HPDETECT_INVERT ? HPDET_INV : 0u))
#define HP_SETTLE_MS          600u     /* > 500 ms plug debounce          */
#define HP_POLL_MS            500u     /* HP_STATUS backstop poll period  */

/* R_SYS_CLK_CTL values: MCLK_INT=1 (22.5792 MHz family) | MCLK_SRC_SEL   */
#define SYSCLK_XTAL           0x04u    /* SRC = crystal                    */
#define SYSCLK_RCO            0x06u    /* SRC = internal RCO (reset value) */
#define SYSCLK_PLL_24M        0x01u    /* MCLK_INT=0 (24.576 MHz) | SRC=PLL */
static uint8_t s_pdn_shadow = 0xFE;    /* reset default: everything down  */
static bool    s_hp_present = true;    /* assume present until told else  */
static uint8_t s_vol_code   = 0x14;    /* -10 dB power-on default         */
static uint8_t s_mask1_awake = 0x9F;   /* INT_MASK1 with plug+unplug open */
static bool    s_hp_ready;             /* detect configured (init done)   */
static cs_hp_event_t s_hp_pending = CS_HP_EVENT_NONE; /* not yet reported */
static uint32_t s_hp_poll_t;           /* last HP_STATUS poll (HAL tick)  */
static bool    s_hpst_ok;              /* HP_STATUS polarity confirmed    */
static bool    s_hpst_bad;             /* ... or contradicted: never used */

/* ---- raw I2C ----------------------------------------------------------- */

bool cs43131_wr(uint32_t reg, uint8_t val)
{
    uint8_t buf[5] = {
        (uint8_t)(reg >> 16), (uint8_t)(reg >> 8), (uint8_t)reg,
        0x00,                               /* control: 8-bit, no INCR    */
        val
    };
    return i2c_write(CS43131_I2C_ADDR, buf, sizeof buf);
}

bool cs43131_rd(uint32_t reg, uint8_t *val)
{
    uint8_t map[4] = {
        (uint8_t)(reg >> 16), (uint8_t)(reg >> 8), (uint8_t)reg, 0x00
    };
    return i2c_write_read(CS43131_I2C_ADDR, map, sizeof map, val, 1);
}

static bool wr_pdn(uint8_t val)
{
    s_pdn_shadow = val;
    return cs43131_wr(R_PWR_DOWN, val);
}

/* ---- headphone state ------------------------------------------------------
 * 2.7.1: the state comes from HP_STATUS (the debounced pin level), not from
 * the sticky plug/unplug flags alone. Whoever reads INT_STATUS1 passes the
 * value here, so a flag consumed by a clock-start poll or by sleep/wake is
 * never lost, and a missed INT edge is caught by the next poll.          */
static cs_hp_event_t hp_update(uint8_t st1)
{
    bool now = s_hp_present;
    uint8_t hs = 0;
    uint8_t fl = (uint8_t)(st1 & INT1_HP_FLAGS);
    bool hs_rd = cs43131_rd(R_HP_STATUS, &hs);
    uint8_t lv = (uint8_t)(hs & (HPST_PLUG_DBC | HPST_UNPLUG_DBC));
    bool lv_ok = hs_rd && (lv == HPST_PLUG_DBC || lv == HPST_UNPLUG_DBC);

    /* Learn HP_STATUS polarity from a single, unambiguous event flag.   */
    if (lv_ok && !s_hpst_bad &&
        (fl == INT1_HPDETECT_PLUG || fl == INT1_HPDETECT_UNPLUG)) {
        bool agree = (fl == INT1_HPDETECT_PLUG) == (lv == HPST_PLUG_DBC);
        s_hpst_ok  = agree;
        s_hpst_bad = !agree;
    }

    /* Both flags latched (e.g. unplug masked during sleep, then a plug
     * raised INT): the plug that fired the interrupt is the newest.     */
    if (fl) now = (fl & INT1_HPDETECT_PLUG) != 0;
    if (s_hpst_ok && lv_ok) now = (lv == HPST_PLUG_DBC);   /* pin level wins */

    cs_hp_event_t ev = CS_HP_EVENT_NONE;
    if (now != s_hp_present) ev = now ? CS_HP_EVENT_PLUG : CS_HP_EVENT_UNPLUG;
    else if (now && (fl & INT1_HPDETECT_PLUG)) ev = CS_HP_EVENT_PLUG; /* out+in */
    s_hp_present = now;
    if (ev != CS_HP_EVENT_NONE) s_hp_pending = ev;
    return ev;
}

/* For INT_STATUS1 reads made for other reasons (XTAL/PLL ready polls).   */
static inline void hp_note(uint8_t st1)
{
    if (s_hp_ready && (st1 & INT1_HP_FLAGS)) (void)hp_update(st1);
}

static cs_hp_event_t hp_take(void)
{
    cs_hp_event_t ev = s_hp_pending;
    s_hp_pending = CS_HP_EVENT_NONE;
    return ev;
}

/* Write-and-remember-failure for the multi-register start sequences.    */
static bool s_seq_ok;
static void sw(uint32_t reg, uint8_t val) { if (!cs43131_wr(reg, val)) s_seq_ok = false; }
static bool s_xtal_ok;          /* crystal + CLKOUT confirmed running     */
static bool s_mclk_48k;         /* MCLK = PLL 24.576 MHz (48 k family)    */

/* Crystal on, MCLK <- crystal, CLKOUT (XTAL/2) on. Used at boot and on
 * every wake from system sleep (CLKOUT is the SAI1 kernel clock).        */
static bool xtal_clkout_start(void)
{
    uint8_t st = 0;
    /* Crystal bias for the SX3B/ABM10W 22.5792 MHz part (Table 5-1).     */
    if (!cs43131_wr(R_XTAL_SET, 0x04)) return false;      /* 12.5 uA bias */
    if (cs43131_rd(R_INT_STATUS1, &st)) hp_note(st);      /* clear sticky */
    wr_pdn((uint8_t)(s_pdn_shadow & (uint8_t)~PDN_XTAL)); /* XTAL on      */

    /* Wait for XTAL_READY (DS max startup 6.5 ms).                       */
    uint32_t t0 = HAL_GetTick();
    s_xtal_ok = false;
    do {
        if (!cs43131_rd(R_INT_STATUS1, &st)) return false;
        hp_note(st);
        if (st & INT1_XTAL_READY) break;
    } while (HAL_GetTick() - t0 < 20);
    hp_note(st);
    if (!(st & INT1_XTAL_READY)) return false;  /* no AUDIOCLK for the SAI */

    /* MCLK <- crystal, 22.5792 MHz family.                                */
    if (!cs43131_wr(R_SYS_CLK_CTL, SYSCLK_XTAL)) return false;
    s_mclk_48k = false;
    HAL_Delay(1);                                          /* >=150 us     */

    /* CLKOUT = XTAL/2 = 11.2896 MHz -> STM32 AUDIOCLK.                    */
    if (!cs43131_wr(R_CLKOUT_CTL, 0x00)) return false;    /* div2, XTAL   */
    if (!wr_pdn((uint8_t)(s_pdn_shadow & (uint8_t)~PDN_CLKOUT))) return false;
    s_xtal_ok = true;
    return true;
}

/* ---- init --------------------------------------------------------------- */

bool cs43131_init(void)
{
    GPIO_InitTypeDef g = { 0 };

    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* RESET# out (held low since power-up by pull-down), INT in (EXTI10). */
    g.Mode = GPIO_MODE_OUTPUT_PP;
    g.Pin  = CODEC_RST_PIN;
    HAL_GPIO_WritePin(CODEC_RST_PORT, CODEC_RST_PIN, GPIO_PIN_RESET);
    HAL_GPIO_Init(CODEC_RST_PORT, &g);

    /* INT# is open drain, active low. V2 has no external pull-up on the
     * net (2.7.0 assumed one), so after the first event the line was left
     * floating low and no further falling edge ever arrived: the boot
     * state stuck. 2.7.1 uses the STM32's internal pull-up (~40 k to
     * 1.8 V; draws ~45 uA only while the codec holds INT low).          */
    g.Mode = GPIO_MODE_IT_FALLING;
    g.Pull = GPIO_PULLUP;
    g.Pin  = CODEC_INT_PIN;
    HAL_GPIO_Init(CODEC_INT_PORT, &g);
    HAL_NVIC_SetPriority(CODEC_INT_EXTI_IRQn, 9, 0);
    HAL_NVIC_EnableIRQ(CODEC_INT_EXTI_IRQn);

    /* Release reset; DS: ADR strap is sensed after RESET deasserts and
     * I2C ignores us until tPUD (~4 ms) later.                           */
    HAL_Delay(2);
    HAL_GPIO_WritePin(CODEC_RST_PORT, CODEC_RST_PIN, GPIO_PIN_SET);
    HAL_Delay(10);

    /* Sanity: device ID reads "43131" packed BCD (0x43 0x11 0x31).       */
    uint8_t id = 0;
    if (!cs43131_rd(R_DEVID_AB, &id) || id != 0x43) return false;

    if (!xtal_clkout_start()) return false;

    /* Full-scale output 1.41 V: sensible for IEMs/portable (OUT_FS=10).
     * Update only while PDN_HP is set - which it still is here.          */
    if (!cs43131_wr(R_HP_OUT_CTL1, 0x20)) return false;

    /* Class-H adaptive supply tracking (Example 5-14 step 23).           */
    if (!cs43131_wr(R_CLASSH_CTL, 0x1E)) return false;

    /* Headphone detect in the datasheet's order (DS 4.5.1.4): clear the
     * sticky status, unmask plug/unplug, set the debounce with detect off,
     * then enable. 2.7.0 enabled first and then read-and-discarded the
     * status, throwing away the first (0 ms) unplug event.               */
    (void)cs43131_rd(R_INT_STATUS1, &id);
    (void)cs43131_rd(R_INT_STATUS2, &id);
    uint8_t m1;
    if (!cs43131_rd(R_INT_MASK1, &m1)) return false;
    s_mask1_awake = (uint8_t)(m1 & (uint8_t)~INT1_HP_FLAGS);
    if (!cs43131_wr(R_INT_MASK1, s_mask1_awake)) return false;
    if (!cs43131_wr(R_HP_DETECT, HPDET_CFG)) return false;
    if (!cs43131_wr(R_HP_DETECT, (uint8_t)(HPDET_CTRL_ON | HPDET_CFG))) return false;

    /* Seed the state from the first event instead of assuming "present"
     * (enabling detect reports the current state as a plug or unplug).
     * No plug: at once (0 ms debounce); plug: after its 500 ms debounce. */
    uint32_t t0 = HAL_GetTick();
    uint8_t st = 0;
    do {
        if (cs43131_rd(R_INT_STATUS1, &st) && (st & INT1_HP_FLAGS)) break;
        st = 0;
        HAL_Delay(10);
    } while (HAL_GetTick() - t0 < HP_SETTLE_MS);
    (void)hp_update(st);
    s_hp_ready = true;
    s_hp_pending = CS_HP_EVENT_NONE;       /* boot state, not an event    */
    s_hp_poll_t = HAL_GetTick();

    return true;
}

/* ---- PCM / DoP ------------------------------------------------------------ */

static bool s_running;

/* Frame rate -> SP_SRATE code, MCLK family and SCLK divider.
 * SCLK = 64 * Fs (two 32-bit slots) = MCLK * 1 / den.
 *   22.5792 MHz: 44.1 k /8, 88.2 k /4, 176.4 k /2, 352.8 k /1 (DoP128)
 *   24.576  MHz: 32 k /12, 48 k /8, 96 k /4, 192 k /2
 * SP_SRATE codes from the Linux cs43130 driver (32 k = 0 ... 384 k = 8). */
typedef struct { uint32_t fs; uint8_t sprate, den; bool fam48; } asp_rate_t;
static const asp_rate_t k_rates[] = {
    {  32000, 0x00, 12, true  },
    {  44100, 0x01,  8, false },
    {  48000, 0x02,  8, true  },
    {  88200, 0x03,  4, false },
    {  96000, 0x04,  4, true  },
    { 176400, 0x05,  2, false },
    { 192000, 0x06,  2, true  },
    { 352800, 0x07,  1, false },
};

static const asp_rate_t *find_rate(uint32_t fs)
{
    for (unsigned i = 0; i < sizeof k_rates / sizeof k_rates[0]; i++)
        if (k_rates[i].fs == fs) return &k_rates[i];
    return NULL;
}

bool cs43131_rate_supported(uint32_t fs)
{
    return fs != 352800 && find_rate(fs) != NULL;   /* 352.8 k: DoP only  */
}

/* Switch MCLK between the crystal (22.5792 MHz) and the PLL (24.576 MHz).
 * Only called with the serial port and HP stage powered down (start_*()
 * runs cs43131_stop() first). CLKOUT keeps coming from the crystal, so
 * the STM32's SAI kernel clock never changes.                            */
static bool mclk_select(bool fam48)
{
    if (fam48 == s_mclk_48k) return true;
    uint8_t v = 0, st = 0;
    if (fam48) {
        bool ok = true;
        ok &= cs43131_wr(R_PLL_SET_2, 0x00);           /* frac 0x06F700   */
        ok &= cs43131_wr(R_PLL_SET_3, 0xF7);
        ok &= cs43131_wr(R_PLL_SET_4, 0x06);
        ok &= cs43131_wr(R_PLL_SET_5, 0x44);           /* int             */
        ok &= cs43131_wr(R_PLL_SET_6, 0x08);           /* divout          */
        ok &= cs43131_wr(R_PLL_SET_7, 139);            /* cal ratio       */
        ok &= cs43131_rd(R_PLL_SET_8, &v);
        ok &= cs43131_wr(R_PLL_SET_8, (uint8_t)(v & ~0x02u));   /* mode 0  */
        ok &= cs43131_wr(R_PLL_SET_9, 0x03);           /* prediv          */
        ok &= cs43131_rd(R_PLL_SET_1, &v);
        ok &= cs43131_wr(R_PLL_SET_1, (uint8_t)(v | 0x01u));    /* start   */
        if (!ok) return false;
        if (cs43131_rd(R_INT_STATUS1, &st)) hp_note(st); /* clear sticky   */
        if (!wr_pdn((uint8_t)(s_pdn_shadow & (uint8_t)~PDN_PLL))) return false;
        uint32_t t0 = HAL_GetTick();
        do {
            if (!cs43131_rd(R_INT_STATUS1, &st)) return false;
            hp_note(st);
            if (st & INT1_PLL_READY) break;
        } while (HAL_GetTick() - t0 < 100);
        if (!(st & INT1_PLL_READY)) {                   /* no lock: back off */
            wr_pdn((uint8_t)(s_pdn_shadow | PDN_PLL));
            return false;
        }
        if (!cs43131_wr(R_SYS_CLK_CTL, SYSCLK_PLL_24M)) return false;
        HAL_Delay(1);                                   /* >= 150 us       */
        s_mclk_48k = true;
    } else {
        if (!cs43131_wr(R_SYS_CLK_CTL, SYSCLK_XTAL)) return false;
        HAL_Delay(1);
        wr_pdn((uint8_t)(s_pdn_shadow | PDN_PLL));
        if (cs43131_rd(R_PLL_SET_1, &v)) cs43131_wr(R_PLL_SET_1, (uint8_t)(v & ~0x01u));
        s_mclk_48k = false;
    }
    return true;
}

/* ASP (I2S master) setup, 64-bit frames (2 x 32-bit slots).              */
static void asp_config(const asp_rate_t *r)
{
    sw(R_SP_RATE,    r->sprate);
    sw(R_SP_BITSIZE, 0x04);            /* ASP 32-bit slots        */

    /* Fractional divider MCLK -> SCLK (Example 5-14 steps 9-12).         */
    sw(R_ASP_NUM1, 0x01); sw(R_ASP_NUM2, 0x00);
    sw(R_ASP_DEN1, r->den); sw(R_ASP_DEN2, 0x00);
    sw(R_ASP_LCHI1, 0x1F); sw(R_ASP_LCHI2, 0x00); /* 32   */
    sw(R_ASP_LCPR1, 0x3F); sw(R_ASP_LCPR2, 0x00); /* 64   */

    /* ASP master (drives SCLK1/LRCK1 to the SAI), I2S clock polarity.    */
    sw(R_ASP_CLK_CFG, 0x1C);           /* M/S=1 | SCPOL 11        */
    sw(R_ASP_FRM_CFG, 0x0A);           /* I2S: 50/50, FSD=010     */
    sw(R_ASP_CH1_LOC, 0x00);
    sw(R_ASP_CH2_LOC, 0x00);
    sw(R_ASP_CH1_SZEN, 0x07);          /* ch1 en, 32-bit          */
    sw(R_ASP_CH2_SZEN, 0x0F);          /* ch2 en, 32-bit, phase B */

    /* Enable ASP master clock drivers (xSP_3ST: ASP active).             */
    sw(R_PAD_IF_CFG, 0x02);
}

/* Pop-free HP power-up (Example 5-5) with the ASP powered.               */
/* v2.4 "soft start": the HP stage (class-H charge pump + output driver)
 * is the largest load step on the 1.8 V rail. Spread it out:
 *   1. serial port (ASP) first, let its clocks settle on their own;
 *   2. volume forced to mute, so the amp comes up driving silence;
 *   3. PDN_HP cleared inside the datasheet's pop-free window;
 *   4. extra settle time before the caller restores the volume, which
 *      the DAC's soft-ramp then brings up gradually (PCM_PATH1 0xEC).  */
static void hp_power_up(void)
{
    if (!wr_pdn((uint8_t)(s_pdn_shadow & (uint8_t)~PDN_ASP))) s_seq_ok = false;
    HAL_Delay(5);
    sw(R_PCM_VOL_A, 0xFF);                 /* mute while the amp starts   */
    sw(R_DSD_VOL_A, 0xFF);
    sw(R_DSD_VOL_B, 0xFF);
    sw(R_POPFREE_A, 0x99);
    sw(R_POPFREE_B, 0x20);
    if (!wr_pdn((uint8_t)(s_pdn_shadow & (uint8_t)~PDN_HP))) s_seq_ok = false;
    HAL_Delay(12);
    sw(R_POPFREE_B, 0x00);
    sw(R_POPFREE_A, 0x00);
    HAL_Delay(10);                          /* charge pump settled         */
    s_running = true;
}

bool cs43131_start_pcm(uint32_t rate)
{
    cs43131_stop();                            /* defined starting point  */
    if (!s_xtal_ok) return false;              /* no crystal = no clocks  */
    const asp_rate_t *r = find_rate(rate);
    if (!r || rate == 352800) return false;
    if (!mclk_select(r->fam48)) return false;  /* PLL did not lock        */
    s_seq_ok = true;
    asp_config(r);

    sw(R_DSD_PATH2, 0x00);                     /* DSD processor off       */

    /* PCM path: HPF on, soft-ramped linked volume (steps 18-21).         */
    sw(R_PCM_FILT_OPT, 0x02);
    sw(R_PCM_PATH1, 0xEC);                     /* VOL_BEQA | soft ramp    */
    sw(R_PCM_PATH2, 0x00);
    sw(R_PCM_VOL_A, s_vol_code);
    if (!s_seq_ok) return false;

    hp_power_up();
    sw(R_PCM_VOL_A, s_vol_code);               /* soft-ramps up from mute */
    return s_seq_ok;
}

bool cs43131_start_dop(cs_dsd_speed_t speed)
{
    cs43131_stop();
    if (!s_xtal_ok) return false;
    if (!mclk_select(false)) return false;     /* DSD: crystal family     */
    s_seq_ok = true;
    /* DoP frame rate = DSD bit rate / 16: DSD64 -> 176.4 k, DSD128 ->
     * 352.8 k (the latter puts SCLK at 22.58 MHz - see README).          */
    asp_config(find_rate(speed == CS_DSD_128 ? 352800 : 176400));

    sw(R_DSD_IF_CFG, 0x00);
    sw(R_DSD_PATH1, 0x00);
    /* DSD_SRC = ASP (DoP) | DSD_EN | DSD_SPEED | static-DSD detect.       */
    sw(R_DSD_PATH2, (uint8_t)(DSD_SRC_ASP | DSD_EN |
                              ((uint8_t)speed << 2) | 0x02u));
    sw(R_DSD_VOL_A, s_vol_code);
    sw(R_DSD_VOL_B, s_vol_code);
    if (!s_seq_ok) return false;

    hp_power_up();
    sw(R_DSD_VOL_A, s_vol_code);
    sw(R_DSD_VOL_B, s_vol_code);
    return s_seq_ok;
}

bool cs43131_running(void) { return s_running; }

/* ---- stop / volume ------------------------------------------------------ */

bool cs43131_stop(void)
{
    if (!(s_pdn_shadow & PDN_HP)) {
        /* Pop-free power-down (§5.8.1): mute, wait, PDN_HP, then ports.  */
        cs43131_wr(R_POPFREE_A, 0x99);
        cs43131_wr(R_POPFREE_C, 0x21);
        uint8_t p1;
        if (cs43131_rd(R_PCM_PATH1, &p1))
            cs43131_wr(R_PCM_PATH1, (uint8_t)(p1 | 0x03));   /* mute A+B  */
        HAL_Delay(150);
        wr_pdn((uint8_t)(s_pdn_shadow | PDN_HP));
        HAL_Delay(12);
        cs43131_wr(R_POPFREE_C, 0x00);
        cs43131_wr(R_POPFREE_A, 0x00);
    }
    /* Interfaces off; keep XTAL + CLKOUT running (SAI kernel needs it).  */
    wr_pdn((uint8_t)(s_pdn_shadow | PDN_ASP | PDN_XSP | PDN_DSDIF));
    s_running = false;
    return true;
}

/* ---- system sleep ------------------------------------------------------------ */

cs_hp_event_t cs43131_sleep(void)
{
    uint8_t st = 0, st2;
    cs43131_stop();
    cs43131_wr(R_DSD_PATH2, 0x00);

    /* Only "headphones plugged" may raise INT while the system sleeps.   */
    cs43131_wr(R_INT_MASK1, (uint8_t)(s_mask1_awake | INT1_HPDETECT_UNPLUG));
    (void)cs43131_rd(R_INT_STATUS1, &st);      /* release INT             */
    (void)cs43131_rd(R_INT_STATUS2, &st2);
    (void)hp_update(st);
    cs_hp_event_t ev = hp_take();

    /* MCLK back to the internal RCO before the crystal stops, then
     * PLL, CLKOUT + XTAL off (~1 mA saved). HP-detect keeps running.     */
    cs43131_wr(R_SYS_CLK_CTL, SYSCLK_RCO);
    HAL_Delay(1);
    if (s_mclk_48k) {
        wr_pdn((uint8_t)(s_pdn_shadow | PDN_PLL));
        uint8_t v;
        if (cs43131_rd(R_PLL_SET_1, &v)) cs43131_wr(R_PLL_SET_1, (uint8_t)(v & ~0x01u));
        s_mclk_48k = false;
    }
    wr_pdn((uint8_t)(s_pdn_shadow | PDN_CLKOUT));
    wr_pdn((uint8_t)(s_pdn_shadow | PDN_XTAL));
    s_xtal_ok = false;
    return ev;
}

bool cs43131_wake(void)
{
    uint8_t st;
    bool ok = xtal_clkout_start();
    uint8_t st2;
    if (!cs43131_rd(R_INT_STATUS1, &st)) st = 0;
    (void)cs43131_rd(R_INT_STATUS2, &st2);
    /* 2.7.0 discarded this: an unplug during sleep (masked, but latched)
     * was lost and the player kept "headphones in". Now the state is
     * re-read and any change is left pending for player_power_poll().    */
    (void)hp_update(st);
    cs43131_wr(R_INT_MASK1, s_mask1_awake);
    s_hp_poll_t = HAL_GetTick();
    return ok;
}

bool cs43131_set_volume(uint8_t vol)
{
    /* 100 -> 0 dB, 1 -> -63.5 dB (in 0.5 dB DAC steps), 0 -> mute.       */
    if (vol > 100) vol = 100;
    s_vol_code = (vol == 0) ? 0xFF : (uint8_t)((100 - vol) * 127 / 100);
    cs43131_wr(R_DSD_VOL_A, s_vol_code);
    cs43131_wr(R_DSD_VOL_B, s_vol_code);
    return cs43131_wr(R_PCM_VOL_A, s_vol_code);  /* B linked via VOL_BEQA */
}

bool cs43131_mute(bool on)
{
    uint8_t p1;
    if (!cs43131_rd(R_PCM_PATH1, &p1)) return false;
    return cs43131_wr(R_PCM_PATH1,
                      on ? (uint8_t)(p1 | 0x03) : (uint8_t)(p1 & ~0x03u));
}

/* ---- interrupts ---------------------------------------------------------- */

cs_hp_event_t cs43131_service_irq_event(void)
{
    uint8_t st1 = 0, st2 = 0;
    if (!s_hp_ready) return CS_HP_EVENT_NONE;
    if (!cs43131_rd(R_INT_STATUS1, &st1)) st1 = 0;   /* read-to-clear      */
    (void)cs43131_rd(R_INT_STATUS2, &st2);
    (void)hp_update(st1);
    return hp_take();
}

cs_hp_event_t cs43131_hp_poll(bool irq)
{
    if (!s_hp_ready) return CS_HP_EVENT_NONE;
    uint32_t now = HAL_GetTick();
    /* Serve INT by its level too: a falling edge that was missed (or
     * that arrived while the flag was being cleared) can't wedge it.     */
    if (irq || HAL_GPIO_ReadPin(CODEC_INT_PORT, CODEC_INT_PIN) == GPIO_PIN_RESET) {
        s_hp_poll_t = now;
        return cs43131_service_irq_event();
    }
    if (s_hpst_ok && now - s_hp_poll_t >= HP_POLL_MS) {  /* pin level   */
        s_hp_poll_t = now;
        (void)hp_update(0);
    }
    return hp_take();
}

bool cs43131_headphones_present(void) { return s_hp_present; }
