/**
 * @file    npm1300.h
 * @brief   nPM1300 PMIC driver: charger setup, VBUS/CC detection, fuel
 *          reading for the battery icon.
 *
 * The nPM1300 owns USB-C CC sensing (no STM32 UCPD) and battery charging.
 * Registers are addressed as (peripheral base << 8 | offset), transferred
 * as a 16-bit big-endian address (nPM1300 datasheet "Addressing").
 */
#ifndef NPM1300_H
#define NPM1300_H

#include <stdbool.h>
#include <stdint.h>

#define NPM1300_I2C_ADDR   0x6Bu

typedef enum {
    NPM_VBUS_NONE,          /* unplugged                                  */
    NPM_VBUS_100MA,         /* default USB                                */
    NPM_VBUS_500MA,
    NPM_VBUS_1500MA,        /* USB-C 1.5 A advertisement                  */
} npm_vbus_t;

/* Charger, BUCK2 (+3.3 V) control and the PC3 wire role (board.h
 * BOARD_PC3_PMIC_IRQ):
 *   IRQ role:  BUCK2 switched by I2C, GPIO0 = interrupt output for VBUS
 *              plug/unplug. PC3 must be an INPUT before this runs.
 *   Pin role:  BUCK2 enable = GPIO0 <- PC3; power.c must already drive PC3
 *              HIGH or the rail drops the moment control is switched.   */
bool npm1300_init(uint16_t charge_ma, uint16_t vterm_mv);

/* Battery charge current (32..800 mA, 2 mA steps). The charger is briefly
 * disabled while the setting changes. Also re-derives the VBUS limit.    */
bool npm1300_set_charge_current(uint16_t charge_ma);
/* 2.5.2: charge without a battery thermistor (NTC monitoring off, charge
 * current capped at BATT_CHARGE_MA_NO_NTC_MAX, charger errors cleared). */
bool npm1300_set_no_ntc(bool no_ntc);
bool npm1300_no_ntc(void);
/* Short charger state for the UI ("charging", "topping up", "full",
 * "not charging", "no battery", "no USB", ...).                         */
const char *npm1300_charger_state(void);
uint16_t npm1300_charge_current(void);

/* Program the VBUS input-current limit: charge current + system headroom,
 * at least 500 mA, at most what the USB-C CC advertisement allows. Only
 * writes when something changed.                                          */
void npm1300_apply_vbus_limit(npm_vbus_t status);

/* BUCK2 (+3.3 V rail) on/off over I2C (IRQ role).                         */
bool npm1300_buck2(bool on);

/* VBUS interrupt (IRQ role): choose which edges assert GPIO0, and read +
 * clear the latched events (returns NPM_EV_* bits).                      */
#define NPM_EV_VBUS_DETECTED   0x01u
#define NPM_EV_VBUS_REMOVED    0x02u
void    npm1300_vbus_irq_enable(bool detected, bool removed);
uint8_t npm1300_take_vbus_events(void);

npm_vbus_t npm1300_vbus_status(void);       /* CC comparators + VBUS      */
/* Same, but tells a failed I2C read apart from "no VBUS" (returns false;
 * *out untouched) - USB mode changes must not follow a bus hiccup.       */
bool       npm1300_vbus_read(npm_vbus_t *out);
bool       npm1300_charging(void);

/* Raw BCHGCHARGESTATUS (bit0 BATTERYDETECTED, bit1 COMPLETED, bit2
 * TRICKLE, bit3 CC, bit4 CV, ...). false if the I2C read failed.         */
bool       npm1300_charge_status(uint8_t *st);

/* Is a cell connected? With USB power present the answer comes from the
 * charger's own BATTERYDETECTED flag plus a sanity check of the battery
 * pin voltage measured by the nPM1300's internal ADC (2.5-4.5 V). On
 * battery power alone the answer is trivially yes.                       */
bool       npm1300_battery_present(void);

/* BUCK1 (MCU 1.8 V) forced-PWM while awake: lower ripple and a faster
 * load-step response than the default auto (PFM) mode. The MCU's BOR sits
 * at ~1.7 V, only ~100 mV under the rail. Back to auto before Stop 2.    */
bool       npm1300_buck1_pwm(bool forced);

/* BUCK1 output by software (1000..3300 mV, 100 mV steps), overriding the
 * VSET1 resistor. Voltage is written first, then BUCKSWCTRLSEL hands
 * control to it. Returns false if the PMIC didn't take it.              */
bool       npm1300_buck1_set_mv(uint16_t mv);
uint16_t   npm1300_buck1_mv(void);          /* confirmed setting, 0 = VSET */

/* Battery voltage in mV via the PMIC's SAADC (blocking, ~250 us).        */
bool npm1300_vbat_mv(uint16_t *mv);

/* Map VBAT to the 5-level battery icon (0..4), Li-ion discharge curve.   */
uint8_t npm1300_battery_level(void);

/* Estimated state of charge 0..100 % (piecewise-linear Li-ion OCV map).
 * Only used to place the fill edge inside the battery icon - never shown
 * as a number. Accuracy of a few % is plenty for a ~6 px resolution icon. */
uint8_t npm1300_battery_percent(void);

/* ERRLOG.RSTCAUSE: why the nPM1300 last power-cycled the rails (read at
 * boot; sticky until TASKCLRERRLOG). Bits as documented in the datasheet
 * ERRLOG chapter: 0 ship-mode exit, 1 boot monitor timeout, 2 watchdog,
 * 3 SHPHLD long press, 4 thermal shutdown, 5 VSYS low, 6 software reset.
 * Also returns CHARGERERRREASON. false if the reads failed.             */
bool npm1300_reset_cause(uint8_t *rstcause, uint8_t *chg_err);
void npm1300_clear_errlog(void);

/* Fuel gauge (2.6.0): enable IBAT sampling (and a 1 A discharge limit as
 * its full scale), then read VBAT + battery current in one conversion.
 * ma_x10: 0.1 mA units, negative = discharging.                          */
bool    npm1300_fg_setup(void);
bool    npm1300_fg_sample(uint16_t *mv, int32_t *ma_x10);
/* Li-ion open-circuit voltage -> state of charge (0..100).               */
uint8_t npm1300_soc_from_ocv(uint16_t mv);

/* Full power-cycle reset of the whole board (TASKSWRESET).               */
void npm1300_full_reset(void);

/* nPM1300 die temperature in deg C (single ADC shot, ~2 ms).          */
bool npm1300_die_temp_c(int16_t *deg_c);

#endif /* NPM1300_H */
