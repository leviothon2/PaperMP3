/**
 * @file    i2c_bus.c
 * @brief   I2C1 @ 400 kHz Fast Mode. Kept static outside transactions to
 *          avoid coupling noise into the codec (CS43131 DS §4.13).
 */
#include "i2c_bus.h"
#include "board.h"
#include "stm32u5xx_hal.h"

static I2C_HandleTypeDef s_i2c;

void i2c_bus_init(void)
{
    GPIO_InitTypeDef g = { 0 };

    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_I2C1_CLK_ENABLE();

    g.Mode      = GPIO_MODE_AF_OD;         /* external pull-ups to 1.8 V  */
    g.Pull      = GPIO_NOPULL;
    g.Speed     = GPIO_SPEED_FREQ_MEDIUM;
    g.Alternate = CTRL_I2C_AF;
    g.Pin       = CTRL_SCL_PIN | CTRL_SDA_PIN;
    HAL_GPIO_Init(GPIOB, &g);

    s_i2c.Instance = CTRL_I2C;
    /* 400 kHz Fast-mode from the 16 MHz HSI kernel clock - RM0456 timing
     * example table (PRESC=1, SCLDEL=3, SDADEL=2, SCLH=3, SCLL=9). v1's
     * 0x00300F38 actually produced ~200 kHz (SCLL = 57 x 62.5 ns).        */
    s_i2c.Init.Timing          = 0x10320309u;
    s_i2c.Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
    s_i2c.Init.NoStretchMode   = I2C_NOSTRETCH_DISABLE;
    s_i2c.Init.OwnAddress1     = 0;
    s_i2c.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    s_i2c.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    HAL_I2C_Init(&s_i2c);
    /* Analog filter on (default) - the bus runs next to the class-H amp. */
}

bool i2c_write(uint8_t addr7, const uint8_t *data, uint16_t len)
{
    return HAL_I2C_Master_Transmit(&s_i2c, (uint16_t)(addr7 << 1),
                                   (uint8_t *)data, len, 100) == HAL_OK;
}

bool i2c_write_read(uint8_t addr7, const uint8_t *wr, uint16_t wr_len,
                    uint8_t *rd, uint16_t rd_len)
{
    if (HAL_I2C_Master_Transmit(&s_i2c, (uint16_t)(addr7 << 1),
                                (uint8_t *)wr, wr_len, 100) != HAL_OK)
        return false;
    return HAL_I2C_Master_Receive(&s_i2c, (uint16_t)(addr7 << 1),
                                  rd, rd_len, 100) == HAL_OK;
}
