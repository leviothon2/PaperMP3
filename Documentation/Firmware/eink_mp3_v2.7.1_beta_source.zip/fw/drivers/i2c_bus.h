/**
 * @file    i2c_bus.h
 * @brief   Shared I2C1 control bus (CS43131 @ 0x30, nPM1300 @ 0x6B), 1.8 V.
 */
#ifndef I2C_BUS_H
#define I2C_BUS_H

#include <stdbool.h>
#include <stdint.h>

void i2c_bus_init(void);

/* Plain register-style transfers (nPM1300: 16-bit register address).     */
bool i2c_write(uint8_t addr7, const uint8_t *data, uint16_t len);
bool i2c_write_read(uint8_t addr7, const uint8_t *wr, uint16_t wr_len,
                    uint8_t *rd, uint16_t rd_len);

#endif /* I2C_BUS_H */
