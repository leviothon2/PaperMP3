/**
 * @file    eink.c
 * @brief   The player's panel calls on top of the InkBoy driver fork.
 *
 * One ssd1681 device, one owner (this file). Two drives share it and are
 * never mixed inside a session (display test DESIGN.md §4 "two display
 * paths, never at once"):
 *
 *   fast     fast_display_full() once (InkBoy's vendor full refresh: reset,
 *            register LUT + EOPT/gate/source/VCOM, both RAMs, 0xC7), then
 *            fast_display_update() scans. The driver's own rules apply
 *            unchanged: at most 2402 activations per power-on and a clean
 *            refresh every 2400 scans; this file renews the session (close,
 *            open, clean refresh) before either limit is reached.
 *   classic  ssd1681_otp_full() / ssd1681_otp_partial(): the factory
 *            waveforms, the player's refreshes up to 2.6.7.
 *
 * Lessons taken over from the display-test firmware:
 *   - a BUSY timeout or SPI error is a fault, not "fail soft": the device
 *     is closed (deep sleep attempt, OE low, pins low) and re-opened from a
 *     hardware reset a few seconds later; after two failed attempts the
 *     +3.3 V rail is cycled by power.c when nothing else needs it;
 *   - the boot screen is an OTP full refresh: wiring, level shifter, booster
 *     and BUSY are proven by the factory path before a register LUT is
 *     loaded;
 *   - the audio pump and USB stack run from the driver's wait loops
 *     (BUSY waits and millisecond delays), never from inside an SPI
 *     transfer.
 */
#include "eink.h"
#include "board.h"
#include "diag.h"
#include "ssd1681_fast/ssd1681_fast.h"
#include "ssd1681_fast/ssd1681_port.h"
#include "inkboy/fast_display.h"
#include "inkboy/drive_counters.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "stm32u5xx_hal.h"

#include <string.h>

#define FB_BYTES  SSD1681_FRAME_BYTES
_Static_assert(EINK_FB_SIZE == SSD1681_FRAME_BYTES, "framebuffer = one SSD1681 plane");

/* Renew the session this many activations before the driver refuses. A
 * screen change is at most 8 pulses + 1 HOLD scan (+ halo), so 24 leaves
 * room for the burst that is running when the limit comes into view.    */
#define SESSION_RESERVE      24u
#define FAST_ANALOG_IDLE_MS  750u     /* InkBoy screen_service()          */
#define OTP_ANALOG_IDLE_MS   1500u    /* player 2.6.x                     */
#define FAULT_RETRY_MS       3000u
#define FAULT_SLOW_RETRY_MS  30000u   /* after two failed attempts        */
#define HALO_PULSES          2u       /* display test default             */

static const char *TAG = "eink";

static uint8_t s_fb[FB_BYTES] __attribute__((aligned(4)));     /* gfx target        */
static uint8_t s_shown[FB_BYTES] __attribute__((aligned(4)));  /* classic: on glass */

static ssd1681_handle_t s_dev;
static bool     s_rail_ok = true;     /* false between power_off/power_on  */
static bool     s_fast_session;       /* fast_display owns s_dev           */
static bool     s_otp_ready;          /* classic partials allowed          */
static bool     s_session_due;        /* fast session to start in service  */
static bool     s_analog;             /* boosters left on by a partial     */
static uint32_t s_analog_t;
static bool     s_idle_closed;        /* classic: closed by eink_sleep()   */

static eink_drive_t s_drive = EINK_DRIVE_FAST;
static bool     s_force_classic;      /* USB guard                         */
static bool     s_safe_classic;       /* this boot follows a fault         */
static uint8_t  s_ink = DITHER_PULSES_DEFAULT;

static bool     s_failed;
static bool     s_rail_tried;         /* one rail cycle per fault episode  */
static uint8_t  s_fail_tries;
static uint32_t s_fail_t;
static eink_stats_t s_stats;

static void (*s_hook)(void);
static bool   s_in_hook;

/* ---- hooks ------------------------------------------------------------------ */

static void hook_trampoline(void)
{
    if (!s_hook || s_in_hook) return;
    uint32_t step = g_diag_step;
    s_in_hook = true;
    s_hook();
    s_in_hook = false;
    g_diag_step = step;
}

void eink_set_idle_hook(void (*hook)(void))
{
    s_hook = hook;
    ssd1681_port_set_busy_hook(hook ? hook_trampoline : NULL);
    port_set_idle_hook(hook ? hook_trampoline : NULL);
}

/* ---- device ----------------------------------------------------------------- */

static bool want_fast(void)
{
    return s_drive == EINK_DRIVE_FAST && !s_force_classic && !s_safe_classic;
}

static void note_timing(bool full)
{
    s_stats.last_busy_ms = (uint32_t)(ssd1681_last_timing.busy_us / 1000);
    if (full) s_stats.last_full_ms = s_stats.last_busy_ms;
    s_stats.scans = ssd1681_update_count(s_dev);
    s_stats.since_clean = ssd1681_since_clean(s_dev);
}

static void dev_close(void)
{
    fast_display_release();
    if (s_dev) (void)ssd1681_destroy(s_dev);    /* deep sleep, OE low, pins low */
    s_dev = NULL;
    s_fast_session = s_otp_ready = s_analog = s_session_due = false;
}

static void fault(esp_err_t err, const char *what)
{
    ESP_LOGE(TAG, "PANEL_FAULT,%s,%s", what, esp_err_to_name(err));
    dev_close();
    s_failed = true;
    s_fail_t = HAL_GetTick();
    s_stats.faults++;
}

static bool dev_open(void)
{
    if (s_dev) return true;
    if (!s_rail_ok || s_failed) return false;
    uint32_t step = g_diag_step;
    diag_step(STEP_EINK_WAKE);
    esp_err_t err = ssd1681_create(&s_dev);
    if (err == ESP_OK) err = ssd1681_power_on(s_dev);
    g_diag_step = step;
    if (err != ESP_OK) { fault(err, "open"); return false; }
    s_idle_closed = false;
    return true;
}

/* A session that is about to hit the driver's activation limit is closed;
 * the caller then starts from a clean refresh on a fresh device.          */
static bool near_limit(void)
{
    return s_dev && ssd1681_update_count(s_dev) + SESSION_RESERVE >= SSD1681_MAX_UPDATES;
}

static bool clean_margin_reached(void)
{
    return s_dev && ssd1681_update_count(s_dev) + 4u * SESSION_RESERVE >= SSD1681_MAX_UPDATES;
}

static void analog_off(void)
{
    if (!s_dev || !s_analog) return;
    ssd1681_timing_t t;
    esp_err_t err = ssd1681_analog_power(s_dev, false, &t);
    s_analog = false;
    if (err != ESP_OK) fault(err, "analog off");
}

/* ---- fast drive -------------------------------------------------------------- */

static bool fast_begin(void)
{
    /* A clean refresh on a device that is close to the driver's activation
     * limit (or was used a lot in the OTP profile) starts on a fresh one:
     * the counters only reset with the device, and a clean refresh that
     * leaves "clean due" standing would be asked for again at once.       */
    if (s_dev && (clean_margin_reached() ||
                  (!s_fast_session && ssd1681_update_count(s_dev) > 64u)))
        dev_close();
    if (!dev_open()) return false;
    diag_step(STEP_EINK_FULL);
    esp_err_t err = fast_display_set_dither_pulses(s_ink, s_ink);
    diag_step(STEP_EINK_FULL_WAIT);
    if (err == ESP_OK) err = fast_display_full(s_dev, s_fb, DISPLAY_DITHERED);
    if (err != ESP_OK) { fault(err, "fast full"); return false; }
    s_fast_session = true;
    s_otp_ready = s_analog = s_session_due = false;
    s_stats.sessions++;
    note_timing(true);
    return true;
}

static bool fast_scan(void)
{
    diag_step(STEP_EINK_PARTIAL);
    esp_err_t err = fast_display_update(s_dev, s_fb);
    if (err != ESP_OK) { fault(err, "fast scan"); return false; }
    s_analog = true;
    s_analog_t = HAL_GetTick();
    /* What the burst is driving toward; it is on the glass once the burst
     * has settled (the classic drive diffs against this after a switch).  */
    memcpy(s_shown, s_fb, FB_BYTES);
    note_timing(false);
    return true;
}

/* Deliver what is left of a burst (before the device changes hands).      */
static void fast_finish_burst(void)
{
    unsigned guard = 0;
    while (s_fast_session && s_dev && fast_display_pending(s_dev) && guard++ < 64u)
        if (!fast_scan()) break;
}

/* ---- classic (OTP) drive ------------------------------------------------------ */

static bool otp_full(void)
{
    if (near_limit()) dev_close();
    if (!dev_open()) return false;
    fast_display_release();
    s_fast_session = false;
    diag_step(STEP_EINK_FULL);
    ssd1681_timing_t t;
    diag_step(STEP_EINK_FULL_WAIT);
    esp_err_t err = ssd1681_otp_full(s_dev, s_fb, FB_BYTES, false, &t);
    if (err != ESP_OK) { fault(err, "otp full"); return false; }
    memcpy(s_shown, s_fb, FB_BYTES);
    s_otp_ready = true;
    s_analog = false;
    note_timing(true);
    return true;
}

/* One OTP partial of `frame` against `prev`.                              */
static bool otp_partial_once(const uint8_t *prev)
{
    diag_step(STEP_EINK_PARTIAL);
    ssd1681_timing_t t;
    diag_step(STEP_EINK_PART_WAIT);
    esp_err_t err = ssd1681_otp_partial(s_dev, s_fb, prev, FB_BYTES, &t);
    if (err != ESP_OK) { fault(err, "otp partial"); return false; }
    s_analog = true;
    s_analog_t = HAL_GetTick();
    note_timing(false);
    return true;
}

static bool otp_partial(bool reinforce)
{
    /* Leaving a fast session: let the glass reach the frame first, so the
     * diff below starts from a settled image.                             */
    if (s_fast_session) fast_finish_burst();
    if (s_dev && (s_fast_session || near_limit())) dev_close();
    bool reopened = !s_dev;
    if (!dev_open()) return false;
    if (reopened) {
        /* Deep sleep / session change: s_shown is still what the glass
         * shows. Tell the driver so; no flash needed.                     */
        if (ssd1681_otp_assume_shown(s_dev) != ESP_OK) return otp_full();
        s_otp_ready = true;
    }
    if (!s_otp_ready) return otp_full();
    if (!otp_partial_once(s_shown)) return false;
    if (reinforce) {
        /* 2.6.3 reinforcing pass: "previous" = inverse of the new image, so
         * every pixel counts as changed and is driven once more toward its
         * own colour - no flash.                                           */
        for (unsigned i = 0; i < FB_BYTES; i++) s_shown[i] = (uint8_t)~s_fb[i];
        if (!otp_partial_once(s_shown)) return false;
    }
    memcpy(s_shown, s_fb, FB_BYTES);
    return true;
}

/* ---- public: refreshes ------------------------------------------------------- */

uint8_t *eink_framebuffer(void) { return s_fb; }

void eink_refresh_full(void)
{
    if (!s_rail_ok || s_failed) return;
    s_session_due = false;
    if (want_fast()) {
        /* InkBoy's vendor full is the clean refresh; fast_begin() moves to
         * a fresh device when the activation limit is in view.            */
        if (fast_begin()) memcpy(s_shown, s_fb, FB_BYTES);
    } else {
        (void)otp_full();
    }
}

void eink_refresh_full_fast(void) { eink_refresh_full(); }

void eink_boot_screen(void)
{
    if (!s_rail_ok || s_failed) return;
    (void)otp_full();
}

static void partial(bool reinforce)
{
    if (!s_rail_ok || s_failed) return;
    if (!want_fast()) { (void)otp_partial(reinforce); return; }

    if (s_fast_session && !near_limit()) {
        (void)fast_scan();
        return;
    }
    if (s_fast_session) {                       /* limit in view: renew     */
        eink_refresh_full();
        return;
    }
    /* No fast session yet (boot, wake, back from classic). If the glass
     * image is known, show the new frame at once with an OTP partial and
     * start the session from the main loop; otherwise start it now.       */
    bool known = s_otp_ready || s_idle_closed;
    if (known && otp_partial(false)) { s_session_due = true; return; }
    if (!s_failed && fast_begin()) memcpy(s_shown, s_fb, FB_BYTES);
}

void eink_refresh_partial(void)       { partial(false); }
void eink_refresh_partial_clean(void) { partial(true); }

void eink_refresh_partial_area(int x, int y, int w, int h)
{
    (void)x; (void)y; (void)w; (void)h;
    partial(false);
}

bool eink_settling(void)
{
    return s_session_due || (s_fast_session && fast_display_pending(s_dev) != 0);
}

void eink_settle(void)
{
    unsigned guard = 0;
    while (eink_settling() && !s_failed && guard++ < 64u) (void)eink_service();
}

bool eink_clean_due(void)
{
    return s_fast_session && clean_margin_reached();
}

/* ---- public: service ----------------------------------------------------------- */

bool eink_service(void)
{
    uint32_t now = HAL_GetTick();

    if (s_failed) {
        /* Re-open from a hardware reset and draw with the factory waveform:
         * the known-good path decides whether the panel is back.           */
        uint32_t wait = s_fail_tries < 2u ? FAULT_RETRY_MS : FAULT_SLOW_RETRY_MS;
        if (s_rail_ok && now - s_fail_t >= wait) {
            if (s_fail_tries < 255u) s_fail_tries++;
            s_failed = false;                   /* otp_full() sets it again   */
            if (otp_full()) {
                ESP_LOGW(TAG, "PANEL_RECOVERED,try,%u", s_fail_tries);
                s_fail_tries = 0;
                s_rail_tried = false;
                if (want_fast()) s_session_due = true;
            }
        }
        return false;
    }
    if (!s_dev) return false;

    if (s_session_due) {
        if (want_fast()) {
            if (fast_begin()) memcpy(s_shown, s_fb, FB_BYTES);
        } else {
            s_session_due = false;
        }
        return eink_settling();
    }
    if (s_fast_session) {
        if (fast_display_pending(s_dev)) {
            if (near_limit()) eink_refresh_full();
            else (void)fast_scan();
            return eink_settling();
        }
        if (s_analog && now - s_analog_t >= FAST_ANALOG_IDLE_MS) analog_off();
    } else if (s_analog && now - s_analog_t >= OTP_ANALOG_IDLE_MS) {
        analog_off();
    }
    return false;
}

/* ---- public: power --------------------------------------------------------------- */

void eink_init(void)
{
    port_timer_init();                          /* 1 MHz clock for the driver */
    memset(s_fb, 0xFF, sizeof s_fb);            /* white                      */
    memset(s_shown, 0xFF, sizeof s_shown);
    s_rail_ok = true;
    (void)dev_open();
}

void eink_sleep(void)
{
    /* Fast drive: the session (register LUT, RAM planes) lives in the
     * controller; closing it would cost a flashing refresh to get back.
     * The boosters are already off (eink_service); the controller idles
     * at a few tens of uA, which is nothing next to the awake MCU.         */
    if (!s_dev || s_fast_session || s_session_due || s_failed) return;
    dev_close();
    s_idle_closed = true;
}

void eink_wake(void) { /* lazy: the next refresh re-opens the device */ }

bool eink_is_asleep(void) { return !s_dev; }

void eink_power_off(void)
{
    if (s_dev) eink_settle();
    dev_close();
    (void)ssd1681_port_power(false);            /* OE low, A side low        */
    s_rail_ok = false;
    s_idle_closed = false;
}

void eink_power_on(void)
{
    if (s_rail_ok && s_dev) return;
    s_rail_ok = true;
    /* The player turned the glass white before it slept.                   */
    memset(s_shown, 0xFF, sizeof s_shown);
    s_idle_closed = true;                       /* "image known": see partial() */
    if (s_failed) {                             /* retry at the next service */
        s_fail_tries = 0;
        s_fail_t = HAL_GetTick() - FAULT_RETRY_MS;
    }
}

/* ---- public: configuration ---------------------------------------------------------- */

void eink_set_drive(eink_drive_t drive)
{
    if (drive >= EINK_DRIVE_COUNT) drive = EINK_DRIVE_FAST;
    s_drive = drive;
}

eink_drive_t eink_drive(void) { return s_drive; }
bool eink_fast_active(void)   { return want_fast(); }

void eink_force_classic(bool on) { s_force_classic = on; }
void eink_safe_classic(bool on)  { s_safe_classic = on; }
bool eink_safe_classic_on(void)  { return s_safe_classic; }

void eink_set_ink(uint8_t pulses)
{
    if (pulses < 4u) pulses = 4u;
    if (pulses > DITHER_PULSES_MAX) pulses = DITHER_PULSES_MAX;
    s_ink = pulses;
    /* Applies to pixels that change from now on; no clean refresh needed. */
    (void)fast_display_set_dither_pulses(s_ink, s_ink);
}

void eink_set_halo(uint8_t radius)
{
    drive_counters_set_halo(radius > 2u ? 2u : radius, radius ? HALO_PULSES : 0u);
}

void eink_set_spi_fast(bool on) { ssd1681_port_allow_fast(on); }

/* ---- public: health ------------------------------------------------------------------- */

bool eink_failed(void) { return s_failed; }

bool eink_wants_rail_cycle(void) { return s_failed && s_fail_tries >= 2u && !s_rail_tried; }

void eink_rail_cycled(void)
{
    /* Once per fault: if the panel is still silent after a power-on reset,
     * it is retried every 30 s without taking the SD card down again.     */
    s_rail_tried = true;
    s_fail_tries = 0;
    s_fail_t = HAL_GetTick() - FAULT_RETRY_MS;  /* retry on the next service */
}

const eink_stats_t *eink_stats(void) { return &s_stats; }
