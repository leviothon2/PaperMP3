/**
 * @file    cs43131.h
 * @brief   CS43131 DAC / headphone-amp driver (I2C control, register level).
 *
 * Clock topology (CS43131_dos_and_donts.md):
 *   - 22.5792 MHz crystal on the DAC's XTI/XTO (F0810, 8 pF - the 10 pF
 *     F1010 variant is out of the 5-8 pF spec window; XTAL_IBIAS is set
 *     per DS Table 5-1).
 *   - The DAC is the audio master. Its CLKOUT (= MCLK/2) feeds the STM32
 *     AUDIOCLK pin, so both ends run from the same crystal.
 *   - DAC ASP is always master (drives SCLK1/LRCK1), MCU SAI is slave.
 *   - DSD (V2 board): the DAC's DSD port is not wired, so DSD is sent as
 *     DoP (DSD-over-PCM, 24-bit frames with 0x05/0xFA markers) on the ASP
 *     and routed to the DSD processor (DSD_SRC = ASP).
 *
 * 2.6.0: both rate families play natively. 44.1/88.2/176.4 k (and the
 * 352.8 k DoP carrier) run straight from the 22.5792 MHz crystal; for
 * 32/48/96/192 k the DAC's PLL makes a 24.576 MHz MCLK from the crystal.
 * The PLL is powered only while a 48 k-family stream plays.
 */
#ifndef CS43131_H
#define CS43131_H

#include <stdbool.h>
#include <stdint.h>

#define CS43131_I2C_ADDR    0x30u   /* 7-bit; ADR pin strapped to GND     */

typedef enum {
    CS_DSD_64,          /* 2.8224 MHz  -> DoP @ 176.4 kHz                 */
    CS_DSD_128,         /* 5.6448 MHz  -> DoP @ 352.8 kHz                 */
} cs_dsd_speed_t;

typedef enum {
    CS_HP_EVENT_NONE,
    CS_HP_EVENT_PLUG,
    CS_HP_EVENT_UNPLUG,
} cs_hp_event_t;

bool cs43131_init(void);                       /* reset, XTAL, CLKOUT      */
/* false if any control write failed (codec absent / I2C dead / crystal
 * not running) - the caller must not start the SAI then.                 */
/* PCM at a native frame rate: 32000, 44100, 48000, 88200, 96000, 176400
 * or 192000 Hz. false for any other rate, or if the PLL fails to lock.   */
bool cs43131_start_pcm(uint32_t rate);         /* ASP master, HP up        */
bool cs43131_rate_supported(uint32_t rate);
bool cs43131_start_dop(cs_dsd_speed_t speed);  /* DoP on ASP -> DSD path   */
bool cs43131_stop(void);                       /* pop-free power down      */
bool cs43131_running(void);                    /* HP amp powered           */


/* System sleep: HP off, XTAL + CLKOUT off, only the headphone-PLUG
 * interrupt left unmasked (it is the codec's wake source).               */
/* Returns the headphone event latched at that moment (so a plug during
 * sleep entry still wakes the player).                                   */
cs_hp_event_t cs43131_sleep(void);
bool cs43131_wake(void);                       /* XTAL + CLKOUT back on    */

/* Volume 0..100 -> 0 dB .. -63.5 dB in the DAC's 0.5 dB steps (plus mute
 * at 0). Applied to both channels via the VOL_BEQA linkage.              */
bool cs43131_set_volume(uint8_t vol_0_100);
bool cs43131_mute(bool on);

/* INT pin service (after the EXTI flag): reads and clears the status.    */
cs_hp_event_t cs43131_service_irq_event(void);
/* Main-loop headphone service (2.7.1). irq = the EXTI flag was set. Also
 * serves INT while the pin is held low (missed edge), re-reads the pin's
 * debounced level every 500 ms, and returns changes found elsewhere
 * (e.g. an unplug during system sleep, picked up by cs43131_wake()).     */
cs_hp_event_t cs43131_hp_poll(bool irq);
bool cs43131_headphones_present(void);

/* Raw access (used by usb_app for UAC2 volume passthrough). */
bool cs43131_wr(uint32_t reg, uint8_t val);
bool cs43131_rd(uint32_t reg, uint8_t *val);

#endif /* CS43131_H */
