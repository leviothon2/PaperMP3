/**
 * @file    ssd1681_port_stm32.c
 * @brief   STM32U575 / MP3 mainboard V2 transport for ssd1681_fast.c.
 *          See ssd1681_port.h for the electrical background.
 *
 * Pin map (board.h, "Schematic1 V2"):
 *   PA5 SCK, PA7 MOSI (SPI1 AF5), PA4 CS, PA6 D/C, PA2 RES#  -> TXB0106 A side
 *   PA3 OE of the TXB0106 (330k pull-down: off unless driven)
 *   PA1 BUSY  <- 10k <- panel BUSY (3.3 V, bypasses the TXB0106)
 *
 * Ordering rules carried over from the MP3 firmware's eink.c:
 *   - power-up: every A-side output is driven to its idle level BEFORE OE
 *     goes high, so the TXB0106 never passes an undefined level (its
 *     one-shot edge accelerators would otherwise fire on floating inputs);
 *     RES# is held low until the driver's reset sequence.
 *   - power-down: OE low first, then the A side is driven low, BUSY goes
 *     analog: the B side may be unpowered (rail off) and nothing may
 *     back-feed it.
 */
#include "ssd1681_port.h"
#include "board.h"
#include "esp_timer.h"
#include "stm32u5xx_hal.h"

static SPI_HandleTypeDef s_spi;
static bool     s_inited, s_powered, s_spi_ok;
static bool     s_allow_fast = true;
static unsigned s_hz;
static uint32_t s_prescaler;

static volatile bool    s_armed, s_done;
static volatile int64_t s_rise, s_fall;

/* ---- BUSY edge interrupt (EXTI1, PA1) ------------------------------------- */

void EXTI1_IRQHandler(void)
{
    __HAL_GPIO_EXTI_CLEAR_RISING_IT(EINK_BUSY_PIN);
    __HAL_GPIO_EXTI_CLEAR_FALLING_IT(EINK_BUSY_PIN);
    if (!s_armed) return;
    int64_t now = esp_timer_get_time();
    bool level = HAL_GPIO_ReadPin(EINK_BUSY_PORT, EINK_BUSY_PIN) == GPIO_PIN_SET;
    if (level) {
        if (!s_rise) s_rise = now;
    } else if (!s_fall) {
        /* Both edges of a very short pulse can coalesce into one pending
         * flag; then the rise was never seen. Count it as a zero-length
         * pulse rather than waiting out the timeout.                     */
        if (!s_rise) s_rise = now;
        s_fall = now;
        s_done = true;
    }
}

void ssd1681_port_busy_arm(void)
{
    __disable_irq();
    s_rise = s_fall = 0;
    s_done = false;
    s_armed = true;
    __enable_irq();
}

/* dt-0.2.0: work to do while a refresh runs (SD reads for the panel-load test). Called from the
 * wait loop with BUSY high; it must not touch the panel.                                          */
static void (*s_busy_hook)(void);
void ssd1681_port_set_busy_hook(void (*hook)(void)) { s_busy_hook = hook; }

bool ssd1681_port_busy_wait(uint32_t timeout_ms, int64_t *rise_us, int64_t *fall_us)
{
    const int64_t deadline = esp_timer_get_time() + (int64_t)timeout_ms * 1000;
    bool ok = false;
    for (;;) {
        if (s_done) { ok = true; break; }
        if (s_busy_hook && s_rise) s_busy_hook();
        /* Polled backup: catches a rise the EXTI missed while masked.    */
        if (!s_rise && ssd1681_port_busy()) {
            __disable_irq();
            if (!s_rise) s_rise = esp_timer_get_time();
            __enable_irq();
        }
        if (esp_timer_get_time() >= deadline) break;
    }
    __disable_irq();
    s_armed = false;
    if (rise_us) *rise_us = s_rise;
    if (fall_us) *fall_us = s_fall;
    __enable_irq();
    return ok;
}

int ssd1681_port_busy(void)
{
    return HAL_GPIO_ReadPin(EINK_BUSY_PORT, EINK_BUSY_PIN) == GPIO_PIN_SET;
}

/* ---- pins ------------------------------------------------------------------------ */

static void pins(bool active)
{
    GPIO_InitTypeDef g = { 0 };
    __HAL_RCC_GPIOA_CLK_ENABLE();

    if (!active) {
        HAL_NVIC_DisableIRQ(EXTI1_IRQn);
        HAL_GPIO_WritePin(EINK_OE_PORT, EINK_OE_PIN, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, EINK_CS_PIN | EINK_DC_PIN | EINK_RES_PIN |
                                 EINK_SCK_PIN | EINK_MOSI_PIN, GPIO_PIN_RESET);
        g.Mode  = GPIO_MODE_OUTPUT_PP;
        g.Pull  = GPIO_NOPULL;
        g.Speed = GPIO_SPEED_FREQ_LOW;
        g.Pin   = EINK_CS_PIN | EINK_DC_PIN | EINK_RES_PIN |
                  EINK_SCK_PIN | EINK_MOSI_PIN | EINK_OE_PIN;
        HAL_GPIO_Init(GPIOA, &g);
        g.Mode = GPIO_MODE_ANALOG;
        g.Pin  = EINK_BUSY_PIN;
        HAL_GPIO_Init(EINK_BUSY_PORT, &g);
        return;
    }

    /* CS idle high, RES# low (released by the driver's reset sequence).   */
    HAL_GPIO_WritePin(EINK_OE_PORT, EINK_OE_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(EINK_CS_PORT, EINK_CS_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(EINK_RES_PORT, EINK_RES_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(EINK_DC_PORT, EINK_DC_PIN, GPIO_PIN_RESET);
    g.Mode  = GPIO_MODE_OUTPUT_PP;
    g.Pull  = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_HIGH;
    g.Pin   = EINK_CS_PIN | EINK_DC_PIN | EINK_RES_PIN | EINK_OE_PIN;
    HAL_GPIO_Init(GPIOA, &g);

    /* BUSY: input + EXTI on both edges (10k series, no pull).            */
    g.Mode = GPIO_MODE_IT_RISING_FALLING;
    g.Pull = GPIO_NOPULL;
    g.Pin  = EINK_BUSY_PIN;
    HAL_GPIO_Init(EINK_BUSY_PORT, &g);
    __HAL_GPIO_EXTI_CLEAR_RISING_IT(EINK_BUSY_PIN);
    __HAL_GPIO_EXTI_CLEAR_FALLING_IT(EINK_BUSY_PIN);
    HAL_NVIC_SetPriority(EXTI1_IRQn, 2, 0);
    HAL_NVIC_EnableIRQ(EXTI1_IRQn);

    /* SPI pins. HIGH speed: at VDD = 1.8-1.9 V the "high" slew setting is
     * needed for clean 20 MHz edges into the TXB0106.                    */
    g.Mode      = GPIO_MODE_AF_PP;
    g.Pull      = GPIO_NOPULL;
    g.Speed     = GPIO_SPEED_FREQ_HIGH;
    g.Alternate = EINK_SPI_AF;
    g.Pin       = EINK_SCK_PIN | EINK_MOSI_PIN;
    HAL_GPIO_Init(GPIOA, &g);

    /* Level shifter last: every A-side input is defined now.             */
    HAL_GPIO_WritePin(EINK_OE_PORT, EINK_OE_PIN, GPIO_PIN_SET);
}

/* ---- SPI ------------------------------------------------------------------------- */

static uint32_t prescaler_for(unsigned hz)
{
    static const struct { uint32_t div, reg; } k[] = {
        { 2, SPI_BAUDRATEPRESCALER_2 },   { 4, SPI_BAUDRATEPRESCALER_4 },
        { 8, SPI_BAUDRATEPRESCALER_8 },   { 16, SPI_BAUDRATEPRESCALER_16 },
        { 32, SPI_BAUDRATEPRESCALER_32 }, { 64, SPI_BAUDRATEPRESCALER_64 },
        { 128, SPI_BAUDRATEPRESCALER_128 }, { 256, SPI_BAUDRATEPRESCALER_256 },
    };
    uint32_t pclk = HAL_RCC_GetPCLK2Freq();
    for (unsigned i = 0; i < sizeof k / sizeof k[0]; i++)
        if (pclk / k[i].div <= hz) { s_hz = pclk / k[i].div; return k[i].reg; }
    s_hz = pclk / 256u;
    return SPI_BAUDRATEPRESCALER_256;
}

static esp_err_t spi_config(unsigned hz)
{
    uint32_t p = prescaler_for(hz);
    if (s_spi_ok && p == s_prescaler) return ESP_OK;
    s_spi.Instance               = EINK_SPI;
    s_spi.Init.Mode              = SPI_MODE_MASTER;
    s_spi.Init.Direction         = SPI_DIRECTION_2LINES_TXONLY;
    s_spi.Init.DataSize          = SPI_DATASIZE_8BIT;
    s_spi.Init.CLKPolarity       = SPI_POLARITY_LOW;
    s_spi.Init.CLKPhase          = SPI_PHASE_1EDGE;
    s_spi.Init.NSS               = SPI_NSS_SOFT;
    s_spi.Init.BaudRatePrescaler = p;
    s_spi.Init.FirstBit          = SPI_FIRSTBIT_MSB;
    s_spi.Init.TIMode            = SPI_TIMODE_DISABLE;
    s_spi.Init.CRCCalculation    = SPI_CRCCALCULATION_DISABLE;
    s_spi.Init.NSSPMode          = SPI_NSS_PULSE_DISABLE;
    s_spi.Init.FifoThreshold     = SPI_FIFO_THRESHOLD_01DATA;
    s_spi.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_ENABLE;
    if (HAL_SPI_Init(&s_spi) != HAL_OK) { s_spi_ok = false; return ESP_FAIL; }
    s_prescaler = p;
    s_spi_ok = true;
    return ESP_OK;
}

esp_err_t ssd1681_port_init(void)
{
    if (s_inited) return ESP_OK;
    __HAL_RCC_GPIOA_CLK_ENABLE();
    pins(false);
    s_inited = true;
    return ESP_OK;
}

esp_err_t ssd1681_port_power(bool on)
{
    if (!s_inited) ssd1681_port_init();
    if (on == s_powered) return ESP_OK;
    if (on) {
        __HAL_RCC_SPI1_CLK_ENABLE();
        pins(true);
        s_spi_ok = false;
        if (spi_config(SSD1681_PORT_SLOW_HZ) != ESP_OK) { pins(false); return ESP_FAIL; }
        s_powered = true;
    } else {
        if (s_spi_ok) HAL_SPI_DeInit(&s_spi);
        s_spi_ok = false;
        __HAL_RCC_SPI1_CLK_DISABLE();
        pins(false);
        s_powered = false;
        s_armed = false;
    }
    return ESP_OK;
}

void ssd1681_port_rst(int level)
{
    HAL_GPIO_WritePin(EINK_RES_PORT, EINK_RES_PIN, level ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

esp_err_t ssd1681_port_write(bool data, const uint8_t *bytes, size_t length, unsigned hz)
{
    if (!s_powered) return ESP_ERR_INVALID_STATE;
    if (!s_allow_fast && hz > SSD1681_PORT_SLOW_HZ) hz = SSD1681_PORT_SLOW_HZ;
    if (spi_config(hz) != ESP_OK) return ESP_FAIL;
    HAL_GPIO_WritePin(EINK_DC_PORT, EINK_DC_PIN, data ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(EINK_CS_PORT, EINK_CS_PIN, GPIO_PIN_RESET);
    esp_err_t err = ESP_OK;
    while (length && err == ESP_OK) {
        uint16_t n = length > 0xFFFFu ? 0xFFFFu : (uint16_t)length;
        if (HAL_SPI_Transmit(&s_spi, (uint8_t *)bytes, n, 1000) != HAL_OK) err = ESP_FAIL;
        bytes += n;
        length -= n;
    }
    HAL_GPIO_WritePin(EINK_CS_PORT, EINK_CS_PIN, GPIO_PIN_SET);
    return err;
}

void     ssd1681_port_allow_fast(bool allow) { s_allow_fast = allow; }
bool     ssd1681_port_fast_allowed(void)     { return s_allow_fast; }
unsigned ssd1681_port_active_hz(void)        { return s_hz; }
