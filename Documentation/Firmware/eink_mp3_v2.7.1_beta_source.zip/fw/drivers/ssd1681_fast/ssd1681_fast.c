#include "ssd1681_fast.h"
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include "ssd1681_port.h"
#include "esp_check.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

/* STM32U575 PORT (MP3 mainboard V2) - differences from InkBoy upstream:
 *   - GPIO / SPI / BUSY-ISR / panel-power calls go through ssd1681_port.h
 *     (ssd1681_port_stm32.c). Every command, LUT byte, update-control value,
 *     state check and safety guard below is unchanged from InkBoy.
 *   - "Panel power" is deep sleep + TXB0106 OE low; the +3.3 V rail is
 *     shared with the SD card and owned by main/power.c (see port header).
 *   - The FreeRTOS semaphore/spinlock pair is replaced by the port's
 *     armed EXTI edge capture; the timing semantics (busy_us = rising to
 *     falling BUSY edge) are the same.
 *   - Search for "PORT:" for each local change. */

/* SAFETY: never send command 0x30, which programs waveform OTP. LUTs use volatile command 0x32;
 * the private command whitelist excludes every OTP programmer and booster write. */
enum {
    CMD_DRIVER_OUTPUT = 0x01, CMD_SLEEP = 0x10, CMD_ENTRY = 0x11,
    CMD_RESET = 0x12, CMD_TEMPERATURE = 0x18, CMD_ACTIVATE = 0x20,
    CMD_UPDATE = 0x22, CMD_CURRENT = 0x24, CMD_PREVIOUS = 0x26,
    CMD_LUT = 0x32, CMD_BORDER = 0x3c, CMD_X_WINDOW = 0x44,
    CMD_Y_WINDOW = 0x45, CMD_X_CURSOR = 0x4e, CMD_Y_CURSOR = 0x4f,
    CMD_VENDOR_GATE = 0x03, CMD_VENDOR_SOURCE = 0x04, CMD_VENDOR_VCOM = 0x2c,
    CMD_VENDOR_PARTIAL = 0x37, CMD_VENDOR_END = 0x3f,
    CMD_TEMPERATURE_WRITE = 0x1a, /* PORT: volatile temperature register, OTP reference refreshes only */
};
/* PORT: pins live in board.h / ssd1681_port_stm32.c. */
#define BUSY_TIMEOUT_MS 10000
static const char *TAG = "ssd1681";

struct ssd1681_device {
    bool spi; /* PORT: transport open (was spi_device_handle_t) */
    bool fast_transport;
    unsigned active_spi_hz;
    bool powered, analog_on, fault, full_done;
    bool vendor_profile, vendor_partial, vendor_keep_power, vendor_mixed;
    uint8_t vendor_g0_frames;
    uint8_t gray_frame_rate;
    uint8_t gray_strength, gray_wave_mode;
    uint8_t *gray_wave_planes;
    bool vendor_skip_hold_frame;
    unsigned updates, since_clean;
    bool continuous_play;
};

/* PORT: the BUSY edge ISR lives in ssd1681_port_stm32.c (EXTI1). */

static esp_err_t wait_idle(struct ssd1681_device *d)
{
    const int64_t deadline = esp_timer_get_time() + BUSY_TIMEOUT_MS * 1000LL;
    while (ssd1681_port_busy()) {
        if (esp_timer_get_time() >= deadline) {
            d->fault = true;
            ESP_LOGE(TAG, "BUSY stuck high; aborting");
            return ESP_ERR_TIMEOUT;
        }
        vTaskDelay(1);
    }
    return ESP_OK;
}

static esp_err_t transfer(struct ssd1681_device *d, bool data,
                          const uint8_t *bytes, size_t length)
{
    const unsigned hz = d->fast_transport ? SSD1681_PORT_FAST_HZ : SSD1681_SPI_HZ;
    /* PORT: DC + CS framing and the prescaler change happen in the port. */
    esp_err_t err = ssd1681_port_write(data, bytes, length, hz);
    if (err == ESP_OK) d->active_spi_hz = hz;
    if (err != ESP_OK) d->fault = true;
    return err;
}

static esp_err_t send_command(struct ssd1681_device *d, uint8_t command)
{
    switch (command) {
    case CMD_DRIVER_OUTPUT: case CMD_SLEEP: case CMD_ENTRY: case CMD_RESET:
    case CMD_TEMPERATURE: case CMD_ACTIVATE: case CMD_UPDATE: case CMD_CURRENT:
    case CMD_PREVIOUS: case CMD_LUT: case CMD_BORDER: case CMD_X_WINDOW:
    case CMD_Y_WINDOW: case CMD_X_CURSOR: case CMD_Y_CURSOR:
    case CMD_VENDOR_GATE: case CMD_VENDOR_SOURCE: case CMD_VENDOR_VCOM:
    case CMD_VENDOR_PARTIAL: case CMD_VENDOR_END:
    case CMD_TEMPERATURE_WRITE: /* PORT */
        break;
    default: return ESP_ERR_NOT_SUPPORTED;
    }
    if (!d->powered || !d->spi || d->fault) return ESP_ERR_INVALID_STATE;
    ESP_RETURN_ON_ERROR(wait_idle(d), TAG, "command while busy");
    return transfer(d, false, &command, 1);
}

static esp_err_t reg_write(struct ssd1681_device *d, uint8_t command,
                           const uint8_t *data, size_t length)
{
    ESP_RETURN_ON_ERROR(send_command(d, command), TAG, "command");
    return transfer(d, true, data, length);
}

static esp_err_t reg_byte(struct ssd1681_device *d, uint8_t command, uint8_t data)
{
    return reg_write(d, command, &data, 1);
}

/* PORT: last activation, read by the on-screen timing page. */
ssd1681_timing_t ssd1681_last_timing;
uint8_t ssd1681_last_control;
/* PORT (dt-0.2.0): per-activation statistics. Pixel scans only: analog power (0xC0, 0x03) and the
 * LUT/temperature loads (0xB1, 0x91) are excluded, so "busy per scan" is what the waveform costs. */
ssd1681_scan_stats_t ssd1681_scan_stats;

void ssd1681_scan_stats_reset(void)
{
    ssd1681_scan_stats = (ssd1681_scan_stats_t){ .busy_min_us = INT64_MAX };
}

static void scan_stats_add(uint8_t control, int64_t busy_us)
{
    if (control == 0xc0 || control == 0x03 || control == 0xb1 || control == 0x91) return;
    ssd1681_scan_stats_t *s = &ssd1681_scan_stats;
    if (!s->scans) s->busy_min_us = INT64_MAX;
    s->scans++;
    s->busy_sum_us += busy_us;
    if (busy_us < s->busy_min_us) s->busy_min_us = busy_us;
    if (busy_us > s->busy_max_us) s->busy_max_us = busy_us;
}

static esp_err_t activate(struct ssd1681_device *d, uint8_t control,
                          ssd1681_timing_t *timing)
{
    *timing = (ssd1681_timing_t){0};
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_UPDATE, control), TAG, "update control");
    /* PORT: armed EXTI edge capture replaces the ISR + binary semaphore. */
    ssd1681_port_busy_arm();
    const int64_t started = esp_timer_get_time();
    esp_err_t err = send_command(d, CMD_ACTIVATE);
    int64_t rise_us = 0, fall_us = 0;
    bool complete = ssd1681_port_busy_wait(err == ESP_OK ? BUSY_TIMEOUT_MS : 0, &rise_us, &fall_us);
    if (err == ESP_OK && !complete) {
        ESP_LOGE(TAG, "No complete BUSY pulse for control 0x%02x (GPIO=%d)",
                 control, ssd1681_port_busy());
        err = ESP_ERR_TIMEOUT;
    }
    timing->busy_us = fall_us > rise_us ? fall_us - rise_us : 0;
    timing->activation_us = esp_timer_get_time() - started;
    ssd1681_last_timing = *timing;
    ssd1681_last_control = control;
    if (err == ESP_OK && complete) scan_stats_add(control, timing->busy_us);   /* PORT */
    if (err != ESP_OK || ssd1681_port_busy()) {
        d->fault = true;
        return err == ESP_OK ? ESP_ERR_INVALID_STATE : err;
    }
    return ESP_OK;
}

static bool update_limit_reached(const struct ssd1681_device *d, unsigned reserve)
{
    if (d->continuous_play) return false;
    return d->updates >= SSD1681_MAX_UPDATES - reserve;
}

static bool clean_limit_reached(const struct ssd1681_device *d)
{
    if (d->continuous_play) return false;
    return d->since_clean >= CLEAN_REFRESH_INTERVAL;
}

static void increment_saturated(unsigned *counter)
{
    if (*counter != UINT_MAX) ++*counter;
}

esp_err_t ssd1681_enable_continuous_play(ssd1681_handle_t d)
{
    if (!d) return ESP_ERR_INVALID_ARG;
    if (d->powered || d->fault || d->updates || d->since_clean)
        return ESP_ERR_INVALID_STATE;
    d->continuous_play = true;
    return ESP_OK;
}

static esp_err_t frame_window(struct ssd1681_device *d)
{
    const uint8_t x[] = {0, 24};
    const uint8_t y[] = {d->vendor_profile ? 199 : 0, 0,
                         d->vendor_profile ? 0 : 199, 0};
    const uint8_t cursor_y[] = {d->vendor_profile ? 199 : 0, 0};
    ESP_RETURN_ON_ERROR(reg_write(d, CMD_X_WINDOW, x, sizeof(x)), TAG, "X window");
    ESP_RETURN_ON_ERROR(reg_write(d, CMD_Y_WINDOW, y, sizeof(y)), TAG, "Y window");
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_X_CURSOR, 0), TAG, "X cursor");
    return reg_write(d, CMD_Y_CURSOR, cursor_y, sizeof(cursor_y));
}

static esp_err_t spi_open(struct ssd1681_device *d)
{
    /* PORT: SPI1 + control pins + OE come up together in the port. */
    esp_err_t err = ssd1681_port_power(true);
    if (err != ESP_OK) return err;
    d->spi = true;
    d->active_spi_hz = SSD1681_SPI_HZ;
    return ESP_OK;
}

esp_err_t ssd1681_create(ssd1681_handle_t *out)
{
    if (!out) return ESP_ERR_INVALID_ARG;
    *out = NULL;
    struct ssd1681_device *d = calloc(1, sizeof(*d));
    if (!d) return ESP_ERR_NO_MEM;
    /* PORT: one-time pin/EXTI setup; pins stay parked (OE low) until power-on. */
    esp_err_t err = ssd1681_port_init();
    if (err != ESP_OK) goto fail;
    *out = d;
    return ESP_OK;
fail:
    ESP_LOGE(TAG, "create: %s", esp_err_to_name(err));
    esp_err_t cleanup = ssd1681_destroy(d);
    if (cleanup != ESP_OK) ESP_LOGE(TAG, "cleanup: %s", esp_err_to_name(cleanup));
    return err;
}

esp_err_t ssd1681_power_on(ssd1681_handle_t d)
{
    if (!d) return ESP_ERR_INVALID_ARG;
    if (d->powered || d->fault || update_limit_reached(d, 0))
        return ESP_ERR_INVALID_STATE;
    d->vendor_profile = d->vendor_partial = false;
    d->vendor_keep_power = d->vendor_mixed = false;
    d->vendor_g0_frames = 15;
    d->gray_frame_rate = 2;
    d->gray_strength = d->gray_wave_mode = 0;
    heap_caps_free(d->gray_wave_planes);d->gray_wave_planes=NULL;
    d->fast_transport = false;
    d->vendor_skip_hold_frame = false;
    /* PORT: the +3.3 V rail is already up (main/power.c); "power on" opens
     * the level shifter and the SPI. The datasheet's 10 ms VCI settle is
     * kept so a rail that was just switched on is covered as well. */
    d->powered = true;
    vTaskDelay(pdMS_TO_TICKS(10));
    ESP_RETURN_ON_ERROR(spi_open(d), TAG, "SPI routing");
    ssd1681_port_rst(1);
    vTaskDelay(pdMS_TO_TICKS(50));
    ssd1681_port_rst(0);
    vTaskDelay(pdMS_TO_TICKS(20));
    ssd1681_port_rst(1);
    vTaskDelay(pdMS_TO_TICKS(50));
    ESP_RETURN_ON_ERROR(send_command(d, CMD_RESET), TAG, "software reset");
    vTaskDelay(pdMS_TO_TICKS(10));
    ESP_RETURN_ON_ERROR(wait_idle(d), TAG, "reset busy");
    /* Increasing X/Y addressing, MSB left, as in the GxEPD2 GDEY0154D67 driver; Waveshare's sample
     * uses decreasing Y with a matching reversed gate scan. */
    const uint8_t output[] = {199, 0, 0};
    ESP_RETURN_ON_ERROR(reg_write(d, CMD_DRIVER_OUTPUT, output, sizeof(output)), TAG, "gate scan");
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_ENTRY, 0x03), TAG, "RAM entry");
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_BORDER, 0x05), TAG, "border");
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_TEMPERATURE, 0x80), TAG, "internal temperature");
    d->full_done = d->analog_on = false;
    return frame_window(d);
}

esp_err_t ssd1681_write_frame(ssd1681_handle_t d, const uint8_t *frame,
                            size_t length, bool previous, int64_t *upload_us)
{
    if (!d || !frame || length != SSD1681_FRAME_BYTES || !upload_us)
        return ESP_ERR_INVALID_ARG;
    const int64_t start = esp_timer_get_time();
    ESP_RETURN_ON_ERROR(frame_window(d), TAG, "frame window");
    ESP_RETURN_ON_ERROR(reg_write(d, previous ? CMD_PREVIOUS : CMD_CURRENT,
                                 frame, length), TAG, "frame upload");
    *upload_us = esp_timer_get_time() - start;
    ssd1681_scan_stats.uploads++;                  /* PORT */
    ssd1681_scan_stats.upload_sum_us += *upload_us;
    return ESP_OK;
}

esp_err_t ssd1681_analog_power(ssd1681_handle_t d, bool on, ssd1681_timing_t *timing)
{
    if (!d || !timing) return ESP_ERR_INVALID_ARG;
    *timing = (ssd1681_timing_t){0};
    if (!d->powered || d->fault) return ESP_ERR_INVALID_STATE;
    if (d->vendor_profile && on) return ESP_ERR_INVALID_STATE;
    /* Menu idle may already have powered analog down; repeating power-off gives no BUSY edge and
     * activate() would wait out its timeout. Software state stays authoritative. */
    if (d->analog_on == on) return ESP_OK;
    ESP_RETURN_ON_ERROR(activate(d, on ? 0xc0 : 0x03, timing), TAG, "analog power");
    d->analog_on = on;
    return ESP_OK;
}


#include "ssd1681_vendor_tables.h"

static esp_err_t vendor_reset(struct ssd1681_device *d, bool software)
{
    ESP_RETURN_ON_ERROR(wait_idle(d), TAG, "vendor reset while busy");
    if (d->analog_on) {
        ssd1681_timing_t power;
        ESP_RETURN_ON_ERROR(ssd1681_analog_power(d, false, &power), TAG, "vendor analog off");
    }
    ssd1681_port_rst(1);              /* PORT */
    vTaskDelay(pdMS_TO_TICKS(50));
    ssd1681_port_rst(0);
    vTaskDelay(pdMS_TO_TICKS(20));
    ssd1681_port_rst(1);
    vTaskDelay(pdMS_TO_TICKS(50));
    ESP_RETURN_ON_ERROR(wait_idle(d), TAG, "vendor hardware reset");
    if (software) {
        ESP_RETURN_ON_ERROR(send_command(d, CMD_RESET), TAG, "vendor software reset");
        vTaskDelay(pdMS_TO_TICKS(10));
        ESP_RETURN_ON_ERROR(wait_idle(d), TAG, "vendor software reset busy");
    }
    return ESP_OK;
}

/* Bytes 153..158 are not part of command 0x32: EOPT, gate, 3 source, VCOM.
 * Command 0x37 is the vendor partial setup, sent as-is. */
static esp_err_t vendor_load(struct ssd1681_device *d, bool partial)
{
    const uint8_t *p = partial ? ws_vendor_partial : ws_vendor_full;
    const uint8_t *lut = p;
    uint8_t mixed_lut[SSD1681_LUT_BYTES];
    if (partial && d->vendor_mixed) {
        memcpy(mixed_lut, p, sizeof(mixed_lut));
        mixed_lut[1] = mixed_lut[37] = 0;
        mixed_lut[60] = d->vendor_g0_frames;
        /* Single-frame waveform: keep G1 A's active frame; skip its all-VSS B frame. */
        if (d->vendor_skip_hold_frame) mixed_lut[68] = 0;
        /* SSD1681 fig 6-6: byte 144 low nibble FR[1], high nibble FR[0].
         * Only the active G1 frame-frequency selector changes. */
        mixed_lut[144] = (mixed_lut[144] & 0xf8u) | d->gray_frame_rate;
        ssd1681_gray_wave_lut(mixed_lut,d->gray_wave_mode);
        lut = mixed_lut;
    }
    ESP_RETURN_ON_ERROR(reg_write(d, CMD_LUT, lut, SSD1681_LUT_BYTES), TAG, "vendor LUT");
    ESP_RETURN_ON_ERROR(wait_idle(d), TAG, "vendor LUT busy");
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_VENDOR_END, p[153]), TAG, "vendor end");
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_VENDOR_GATE, p[154]), TAG, "vendor gate");
    const uint8_t *source = p + 155;
    /* SSD1681 rev 0.13 p21: VSL -15/-13/-11/-9 V, selected by LUT1 for white drive. The weak W>L
     * waveform also selects bounded VSH2; VSH1, VCOM, gate and EOPT stay stock. */
    static const uint8_t vsl[] = {0x32, 0x2a, 0x22, 0x1a};
    uint8_t gray_source[3];
    if (partial && d->vendor_mixed &&
        d->vendor_skip_hold_frame && d->gray_frame_rate == 7 &&
        (d->gray_strength || d->gray_wave_mode)) {
        memcpy(gray_source, source, sizeof(gray_source));
        gray_source[2] = vsl[d->gray_strength];
        gray_source[1] = ssd1681_gray_wave_vsh2(d->gray_wave_mode);
        source = gray_source;
    }
    ESP_RETURN_ON_ERROR(reg_write(d, CMD_VENDOR_SOURCE, source, 3), TAG, "vendor source");
    return reg_byte(d, CMD_VENDOR_VCOM, p[158]);
}

static esp_err_t vendor_full_run(struct ssd1681_device *d, const uint8_t *frame,
                                 ssd1681_timing_t *timing)
{
    ESP_RETURN_ON_ERROR(vendor_reset(d, true), TAG, "vendor full reset");
    const uint8_t output[] = {199, 0, 1};
    ESP_RETURN_ON_ERROR(reg_write(d, CMD_DRIVER_OUTPUT, output, sizeof(output)), TAG, "vendor gates");
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_ENTRY, 0x01), TAG, "vendor entry");
    ESP_RETURN_ON_ERROR(frame_window(d), TAG, "vendor window");
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_BORDER, 0x01), TAG, "vendor border");
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_TEMPERATURE, 0x80), TAG, "vendor temperature");
    ssd1681_timing_t prepare;
    ESP_RETURN_ON_ERROR(activate(d, 0xb1, &prepare), TAG, "vendor temperature load");
    ESP_RETURN_ON_ERROR(vendor_load(d, false), TAG, "vendor full package");
    int64_t upload;
    ESP_RETURN_ON_ERROR(ssd1681_write_frame(d, frame, SSD1681_FRAME_BYTES, false, &upload), TAG, "vendor current");
    ESP_RETURN_ON_ERROR(ssd1681_write_frame(d, frame, SSD1681_FRAME_BYTES, true, &upload), TAG, "vendor previous");
    return activate(d, 0xc7, timing);
}

static esp_err_t vendor_partial_prepare(struct ssd1681_device *d)
{
    if (!d->vendor_partial) {
        ESP_RETURN_ON_ERROR(vendor_reset(d, false), TAG, "vendor partial reset");
        ESP_RETURN_ON_ERROR(vendor_load(d, true), TAG, "vendor partial package");
        /* SSD1681 R37 F[6]: 0 disables automatic RAM ping-pong. Mixed scans
         * supply both planes, so no implicit previous image. */
        const uint8_t partial_config[] = {0,0,0,0,0,0,0,0,0,0};
        ESP_RETURN_ON_ERROR(reg_write(d, CMD_VENDOR_PARTIAL, partial_config,
                                      sizeof(partial_config)), TAG, "vendor partial options");
        ESP_RETURN_ON_ERROR(reg_byte(d, CMD_BORDER, 0x80), TAG, "vendor partial border");
        ssd1681_timing_t power;
        ESP_RETURN_ON_ERROR(activate(d, 0xc0, &power), TAG, "vendor partial power");
        d->analog_on = true;
    }
    return ESP_OK;
}

static esp_err_t vendor_result(struct ssd1681_device *d, esp_err_t err, bool partial)
{
    if (err != ESP_OK) {
        d->fault = true;
        esp_err_t cleanup = ssd1681_power_off(d);
        if (cleanup != ESP_OK) ESP_LOGE(TAG, "vendor fault cleanup: %s", esp_err_to_name(cleanup));
        return err;
    }
    d->analog_on = partial && d->vendor_mixed && d->vendor_keep_power;
    d->vendor_partial = partial;
    d->full_done = true;
    if (partial) increment_saturated(&d->since_clean);
    else d->since_clean = 0;
    return ESP_OK;
}

esp_err_t ssd1681_vendor_full(ssd1681_handle_t d, const uint8_t *frame,
                            size_t length, ssd1681_timing_t *timing)
{
    if (!d || !frame || !timing || length != SSD1681_FRAME_BYTES) return ESP_ERR_INVALID_ARG;
    *timing = (ssd1681_timing_t){0};
    if (!d->powered || d->fault || update_limit_reached(d, 0))
        return ESP_ERR_INVALID_STATE;
    increment_saturated(&d->updates); /* Controller resets must never reset the lifetime attempt cap. */
    d->fast_transport = false;
    d->vendor_profile = true;
    d->vendor_partial = d->full_done = false;
    d->vendor_keep_power = d->vendor_mixed = false;
    d->vendor_g0_frames = 15;
    d->gray_frame_rate = 2;
    d->gray_strength = d->gray_wave_mode = 0;
    heap_caps_free(d->gray_wave_planes);d->gray_wave_planes=NULL;
    d->vendor_skip_hold_frame = false;
    return vendor_result(d, vendor_full_run(d, frame, timing), false);
}

esp_err_t ssd1681_vendor_enable_mixed(ssd1681_handle_t d)
{
    if (!d) return ESP_ERR_INVALID_ARG;
    if (!d->powered || d->fault || !d->vendor_profile || !d->full_done ||
        d->vendor_partial || d->analog_on || d->since_clean != 0 ||
        update_limit_reached(d, 1)) return ESP_ERR_INVALID_STATE;
    d->vendor_mixed = d->vendor_keep_power = true;
    return ESP_OK;
}

esp_err_t ssd1681_vendor_set_mixed_frames(ssd1681_handle_t d, unsigned frames)
{
    if (!d || (frames != 4 && frames != 2 && frames != 1)) return ESP_ERR_INVALID_ARG;
    if (!d->powered || d->fault || !d->vendor_profile || !d->full_done ||
        !d->vendor_mixed || d->vendor_partial || d->analog_on ||
        d->since_clean != 0 || update_limit_reached(d, 1))
        return ESP_ERR_INVALID_STATE;
    d->vendor_skip_hold_frame = frames == 1;
    d->vendor_g0_frames = frames == 1 ? 0 : frames - 2;
    return ESP_OK;
}

esp_err_t ssd1681_vendor_set_fast_transport(ssd1681_handle_t d, bool enabled)
{
    if (!d) return ESP_ERR_INVALID_ARG;
    if (!d->powered || d->fault || !d->vendor_profile || !d->full_done ||
        !d->vendor_mixed ||
        d->vendor_partial || d->analog_on ||
        update_limit_reached(d, 1))
        return ESP_ERR_INVALID_STATE;
    d->fast_transport = enabled;
    return ESP_OK;
}
esp_err_t ssd1681_vendor_gray_frame_rate(ssd1681_handle_t d, unsigned code)
{
    if (!d || code > 7) return ESP_ERR_INVALID_ARG;
    if ((d->gray_strength || d->gray_wave_mode) && code != 7) return ESP_ERR_INVALID_STATE;
    if (!d->powered || d->fault || !d->full_done || !d->vendor_profile ||
        !d->vendor_mixed ||
        !d->vendor_skip_hold_frame || d->analog_on ||
        clean_limit_reached(d) || update_limit_reached(d, 1))
        return ESP_ERR_INVALID_STATE;
    d->gray_frame_rate = code;
    /* An existing partial session can change its volatile LUT while analog
     * power is off. Both RAM masks must be supplied by the next mixed scan. */
    if (d->vendor_partial) {
        esp_err_t error = vendor_load(d, true);
        if (error) return vendor_result(d,error,true);
    }
    return ESP_OK;
}
esp_err_t ssd1681_vendor_gray_wave_mode(ssd1681_handle_t d, unsigned mode)
{
    if (!d || mode>=SSD1681_GRAY_WAVE_COUNT) return ESP_ERR_INVALID_ARG;
    if (!d->powered || d->fault || !d->full_done || !d->vendor_profile ||
        !d->vendor_mixed ||
        !d->vendor_skip_hold_frame || d->gray_frame_rate!=7 || d->analog_on ||
        clean_limit_reached(d) || update_limit_reached(d, 1))
        return ESP_ERR_INVALID_STATE;
    if(mode>=SSD1681_GRAY_WAVE_WEAK11 && !d->gray_wave_planes) {
        d->gray_wave_planes=heap_caps_calloc(2,SSD1681_FRAME_BYTES,MALLOC_CAP_DMA|MALLOC_CAP_INTERNAL);
        if(!d->gray_wave_planes) return ESP_ERR_NO_MEM;
    }
    d->gray_wave_mode=mode;
    if(mode<SSD1681_GRAY_WAVE_WEAK11) { heap_caps_free(d->gray_wave_planes);d->gray_wave_planes=NULL; }
    if (d->vendor_partial) {
        esp_err_t error=vendor_load(d,true);
        if (error) return vendor_result(d,error,true);
    }
    return ESP_OK;
}

esp_err_t ssd1681_vendor_gray_strength(ssd1681_handle_t d, unsigned preset)
{
    if (!d || preset > 3) return ESP_ERR_INVALID_ARG;
    if (!d->powered || d->fault || !d->full_done || !d->vendor_profile ||
        !d->vendor_mixed ||
        !d->vendor_skip_hold_frame || d->gray_frame_rate != 7 || d->analog_on ||
        clean_limit_reached(d) || update_limit_reached(d, 1))
        return ESP_ERR_INVALID_STATE;
    d->gray_strength = preset;
    if (d->vendor_partial) {
        esp_err_t error = vendor_load(d, true);
        if (error) return vendor_result(d,error,true);
    }
    return ESP_OK;
}
esp_err_t ssd1681_vendor_mixed_resume(ssd1681_handle_t d, ssd1681_timing_t *timing)
{
    if (!d || !timing) return ESP_ERR_INVALID_ARG;
    *timing = (ssd1681_timing_t){0};
    if (!d->powered || d->fault || !d->vendor_profile || !d->full_done ||
        !d->vendor_mixed || !d->vendor_keep_power || !d->vendor_partial ||
        clean_limit_reached(d) || update_limit_reached(d, 1))
        return ESP_ERR_INVALID_STATE;
    if (d->analog_on) return ESP_OK;
    esp_err_t error = activate(d, 0xc0, timing);
    if (error != ESP_OK) return vendor_result(d, error, true);
    d->analog_on = true;
    return ESP_OK;
}

static esp_err_t vendor_mixed_run(struct ssd1681_device *d, const uint8_t *black,
                                 const uint8_t *white, ssd1681_timing_t *timing)
{
    ESP_RETURN_ON_ERROR(vendor_partial_prepare(d), TAG, "mixed prepare");
    if (!d->analog_on) return ESP_ERR_INVALID_STATE;
    int64_t upload;
    ESP_RETURN_ON_ERROR(ssd1681_write_frame(d, black, SSD1681_FRAME_BYTES, true, &upload), TAG, "mixed R mask");
    ESP_RETURN_ON_ERROR(ssd1681_write_frame(d, white, SSD1681_FRAME_BYTES, false, &upload), TAG, "mixed BW mask");
    return activate(d, 0x0c, timing);
}

esp_err_t ssd1681_vendor_gray_wave_scan(ssd1681_handle_t d,
    const uint8_t *black, const uint8_t *white, const uint8_t *special,
    size_t length, ssd1681_timing_t *timing)
{
    if (!d || !black || !white || !special || !timing || length!=SSD1681_FRAME_BYTES)
        return ESP_ERR_INVALID_ARG;
    *timing=(ssd1681_timing_t){0};
    if (!d->powered || d->fault || !d->vendor_profile || !d->full_done ||
        !d->vendor_mixed || !d->vendor_keep_power ||
        d->gray_frame_rate!=7 || !d->gray_wave_planes || d->gray_wave_mode<SSD1681_GRAY_WAVE_WEAK11 ||
        d->gray_wave_mode>=SSD1681_GRAY_WAVE_COUNT ||
        (d->vendor_partial && !d->analog_on) ||
        clean_limit_reached(d) || update_limit_reached(d, 1))
        return ESP_ERR_INVALID_STATE;
    uint8_t *r=d->gray_wave_planes,*bw=r+SSD1681_FRAME_BYTES;
    unsigned driven=0;
    if (d->fast_transport) {
        /* The fixed frame length is word divisible. memcpy keeps caller masks
         * safe when their addresses are not naturally aligned. */
        for (size_t i=0;i<length;i+=sizeof(uint32_t)) {
            uint32_t b,w,s;
            memcpy(&b,black+i,sizeof(b));
            memcpy(&w,white+i,sizeof(w));
            memcpy(&s,special+i,sizeof(s));
            if ((b&w) || ((b|w)&s)) return ESP_ERR_INVALID_ARG;
            driven+=__builtin_popcount(b|w|s);
            if (driven>SSD1681_MIXED_MAX_DRIVEN_PIXELS) return ESP_ERR_INVALID_ARG;
            uint32_t out_r=b|s,out_bw=w|s;
            memcpy(r+i,&out_r,sizeof(out_r));
            memcpy(bw+i,&out_bw,sizeof(out_bw));
        }
    } else
    {
    for (size_t i=0;i<length;++i) {
        if ((black[i]&white[i]) || ((black[i]|white[i])&special[i])) return ESP_ERR_INVALID_ARG;
        driven+=__builtin_popcount((unsigned)(black[i]|white[i]|special[i]));
        if (driven>SSD1681_MIXED_MAX_DRIVEN_PIXELS) return ESP_ERR_INVALID_ARG;
        r[i]=black[i]|special[i]; bw[i]=white[i]|special[i];
    }
    }
    increment_saturated(&d->updates);
    return vendor_result(d,vendor_mixed_run(d,r,bw,timing),true);
}

esp_err_t ssd1681_vendor_mixed_scan(ssd1681_handle_t d, const uint8_t *black,
                                  const uint8_t *white, size_t length,
                                  ssd1681_timing_t *timing)
{
    if (!d || !black || !white || !timing || length != SSD1681_FRAME_BYTES)
        return ESP_ERR_INVALID_ARG;
    *timing = (ssd1681_timing_t){0};
    if (!d->powered || d->fault || !d->vendor_profile || !d->full_done ||
        !d->vendor_mixed || !d->vendor_keep_power ||
        (d->vendor_partial && !d->analog_on) ||
        clean_limit_reached(d) || update_limit_reached(d, 1))
        return ESP_ERR_INVALID_STATE;
    unsigned driven = 0;
    if (d->fast_transport) {
        /* Same disjointness/count guard, four bytes per popcount. memcpy also
         * accepts unaligned caller buffers without introducing aliasing UB. */
        for (size_t i = 0; i < length; i += sizeof(uint32_t)) {
            uint32_t b, w;
            memcpy(&b, black + i, sizeof(b)); memcpy(&w, white + i, sizeof(w));
            if (b & w) return ESP_ERR_INVALID_ARG;
            driven += __builtin_popcount(b | w);
            if (driven > SSD1681_MIXED_MAX_DRIVEN_PIXELS) return ESP_ERR_INVALID_ARG;
        }
    } else
    {
    for (size_t i = 0; i < length; ++i) {
        if (black[i] & white[i]) return ESP_ERR_INVALID_ARG;
        driven += __builtin_popcount((unsigned)(black[i] | white[i]));
        if (driven > SSD1681_MIXED_MAX_DRIVEN_PIXELS) return ESP_ERR_INVALID_ARG;
    }
    }
    increment_saturated(&d->updates); /* Invalid masks above must not send commands or consume a slot. */
    return vendor_result(d, vendor_mixed_run(d, black, white, timing), true);
}

esp_err_t ssd1681_power_off(ssd1681_handle_t d)
{
    if (!d) return ESP_ERR_INVALID_ARG;
    esp_err_t result = ESP_OK;
    if (d->powered && !d->fault) {
        if (d->analog_on) {
            ssd1681_timing_t timing;
            result = ssd1681_analog_power(d, false, &timing);
        }
        if (result == ESP_OK) result = reg_byte(d, CMD_SLEEP, 0x01);
    }
    /* PORT: always isolate the signals (OE low, A side low), even after a
     * BUSY/SPI failure. The rail stays up: it also powers the SD card. A
     * panel that ignored deep sleep is recovered by main/power.c cycling
     * the whole rail (power_panel_recover). */
    esp_err_t err = ssd1681_port_power(false);
    d->spi = false;
    if (result == ESP_OK) result = err;
    d->powered = d->analog_on = d->full_done = false;
    d->vendor_profile = d->vendor_partial = false;
    d->vendor_keep_power = d->vendor_mixed = false;
    d->vendor_g0_frames = 15;
    d->gray_frame_rate = 2;
    d->gray_strength = d->gray_wave_mode = 0;
    heap_caps_free(d->gray_wave_planes);d->gray_wave_planes=NULL;
    d->vendor_skip_hold_frame = false;
    return result;
}

esp_err_t ssd1681_destroy(ssd1681_handle_t d)
{
    if (!d) return ESP_OK;
    esp_err_t result = ssd1681_power_off(d);
    free(d);  /* PORT: no ISR service / SPI bus objects to release */
    return result;
}

/* ===================================================================================================
 * PORT (STM32U575 fork): OTP reference refreshes.
 *
 * The MP3 player firmware (2.5.0 stable .. 2.6.6) drives this panel only with the waveforms burned
 * into the panel's OTP. These calls reproduce its three refreshes exactly, so the display-test
 * firmware can put them side by side with InkBoy's register-loaded waveforms on the same glass:
 *   - otp_full:      0x22 = 0xF7 (clock+analog on, load temperature + mode-1 LUT, display, off)
 *   - otp_fast_full: temperature register forced to 100 C (0x1A), 0x22 = 0x91 then 0xC7: the OTP's
 *                    hot-weather mode-1 waveform (GDEY0154D67 "fast refresh", ~1.5 s)
 *   - otp_partial:   0x22 = 0xFC (mode-2 LUT, boosters left on), RED RAM = image on the glass
 * They share the command whitelist and fault handling above. No LUT is written (0x32 unused here),
 * so they also serve as the "known good" baseline when a register waveform misbehaves. Each call
 * leaves the InkBoy vendor state cleared: a fast mode needs ssd1681_vendor_full() again afterwards.
 * =================================================================================================== */

static esp_err_t otp_prepare(struct ssd1681_device *d)
{
    ESP_RETURN_ON_ERROR(wait_idle(d), TAG, "otp while busy");
    if (d->vendor_profile || d->vendor_partial) {
        /* A register LUT is loaded: a hardware reset restores the OTP path. */
        ESP_RETURN_ON_ERROR(vendor_reset(d, true), TAG, "otp reset");
        const uint8_t output[] = {199, 0, 0};
        ESP_RETURN_ON_ERROR(reg_write(d, CMD_DRIVER_OUTPUT, output, sizeof(output)), TAG, "otp gates");
        ESP_RETURN_ON_ERROR(reg_byte(d, CMD_ENTRY, 0x03), TAG, "otp entry");
        ESP_RETURN_ON_ERROR(reg_byte(d, CMD_TEMPERATURE, 0x80), TAG, "otp temperature");
        d->analog_on = false;
    }
    d->vendor_profile = d->vendor_partial = false;
    d->vendor_keep_power = d->vendor_mixed = false;
    d->vendor_g0_frames = 15;
    d->gray_frame_rate = 2;
    d->gray_strength = d->gray_wave_mode = 0;
    heap_caps_free(d->gray_wave_planes); d->gray_wave_planes = NULL;
    d->vendor_skip_hold_frame = false;
    d->fast_transport = false;
    return ESP_OK;
}

static esp_err_t otp_result(struct ssd1681_device *d, esp_err_t err, bool partial)
{
    if (err != ESP_OK) {
        d->fault = true;
        (void)ssd1681_power_off(d);
        return err;
    }
    d->full_done = !partial || d->full_done;
    if (partial) increment_saturated(&d->since_clean);
    else d->since_clean = 0;
    return ESP_OK;
}

static esp_err_t otp_full_run(struct ssd1681_device *d, const uint8_t *frame, int temp_c,
                              ssd1681_timing_t *timing)
{
    ESP_RETURN_ON_ERROR(otp_prepare(d), TAG, "otp prepare");
    if (d->analog_on) {
        ssd1681_timing_t power;
        ESP_RETURN_ON_ERROR(ssd1681_analog_power(d, false, &power), TAG, "otp analog off");
    }
    ESP_RETURN_ON_ERROR(reg_byte(d, CMD_BORDER, 0x05), TAG, "otp border");
    int64_t upload;
    ESP_RETURN_ON_ERROR(ssd1681_write_frame(d, frame, SSD1681_FRAME_BYTES, false, &upload), TAG, "otp current");
    ESP_RETURN_ON_ERROR(ssd1681_write_frame(d, frame, SSD1681_FRAME_BYTES, true, &upload), TAG, "otp previous");
    if (temp_c < 0) return activate(d, 0xf7, timing);
    /* SSD1681 0x1A: A[11:4] = whole degrees C. 0x91 loads the LUT for that temperature without
     * re-reading the sensor; the next 0xF7/0xFC reloads the real temperature. */
    const uint8_t hot[] = {(uint8_t)(temp_c > 127 ? 127 : temp_c), 0};
    ESP_RETURN_ON_ERROR(reg_write(d, CMD_TEMPERATURE_WRITE, hot, sizeof(hot)), TAG, "otp hot temperature");
    ssd1681_timing_t load;
    ESP_RETURN_ON_ERROR(activate(d, 0x91, &load), TAG, "otp hot LUT");
    return activate(d, 0xc7, timing);
}

esp_err_t ssd1681_otp_full(ssd1681_handle_t d, const uint8_t *frame, size_t length,
                           bool fast, ssd1681_timing_t *timing)
{
    return ssd1681_otp_full_temp(d, frame, length, fast ? 100 : -1, timing);
}

esp_err_t ssd1681_otp_full_temp(ssd1681_handle_t d, const uint8_t *frame, size_t length,
                                int temp_c, ssd1681_timing_t *timing)
{
    if (!d || !frame || !timing || length != SSD1681_FRAME_BYTES) return ESP_ERR_INVALID_ARG;
    *timing = (ssd1681_timing_t){0};
    if (!d->powered || d->fault || update_limit_reached(d, 0)) return ESP_ERR_INVALID_STATE;
    increment_saturated(&d->updates);
    esp_err_t err = otp_full_run(d, frame, temp_c, timing);
    d->analog_on = false;   /* 0xF7 / 0xC7 end with the analog supply off */
    return otp_result(d, err, false);
}

esp_err_t ssd1681_otp_partial(ssd1681_handle_t d, const uint8_t *frame, const uint8_t *shown,
                              size_t length, ssd1681_timing_t *timing)
{
    if (!d || !frame || !shown || !timing || length != SSD1681_FRAME_BYTES) return ESP_ERR_INVALID_ARG;
    *timing = (ssd1681_timing_t){0};
    if (!d->powered || d->fault || !d->full_done || d->vendor_profile ||
        update_limit_reached(d, 1)) return ESP_ERR_INVALID_STATE;
    increment_saturated(&d->updates);
    int64_t upload;
    esp_err_t err = reg_byte(d, CMD_BORDER, 0x80);
    if (err == ESP_OK) err = ssd1681_write_frame(d, shown, SSD1681_FRAME_BYTES, true, &upload);
    if (err == ESP_OK) err = ssd1681_write_frame(d, frame, SSD1681_FRAME_BYTES, false, &upload);
    if (err == ESP_OK) err = activate(d, 0xfc, timing);
    if (err == ESP_OK) d->analog_on = true;   /* 0xFC leaves the boosters running */
    return otp_result(d, err, true);
}

/* PORT (player 2.7.0): the image on the glass is known without an OTP full refresh in this session.
 * The player turns the panel white with a full refresh before every sleep and before the panel's
 * idle deep sleep it has just drawn the image it keeps in RAM; either way the next OTP partial can
 * diff against that image, exactly as the player's own driver did up to 2.6.7 (eink_power_on /
 * eink_wake seeded the RED RAM the same way). No command is sent here: ssd1681_otp_partial()
 * uploads both RAM planes itself. Only valid on a freshly powered device in the OTP profile. */
esp_err_t ssd1681_otp_assume_shown(ssd1681_handle_t d)
{
    if (!d) return ESP_ERR_INVALID_ARG;
    if (!d->powered || d->fault || d->vendor_profile || d->vendor_partial) return ESP_ERR_INVALID_STATE;
    d->full_done = true;
    return ESP_OK;
}

unsigned ssd1681_update_count(ssd1681_handle_t d) { return d ? d->updates : 0; }
unsigned ssd1681_since_clean(ssd1681_handle_t d) { return d ? d->since_clean : 0; }
bool ssd1681_faulted(ssd1681_handle_t d) { return d && d->fault; }

/* PORT (dt-0.2.0): no temperature read-back. The panel's sensor value lives in register 0x1B, but
 * this port is write-only (SPI1 TX-only on the shared SDA line). The dt firmware uses the nPM1300 die
 * temperature as the proxy and measures the panel's view of it through busy time instead (the OTP
 * picks a longer waveform when cold; see the PANEL THERMOMETER test in display_tests.c). */
