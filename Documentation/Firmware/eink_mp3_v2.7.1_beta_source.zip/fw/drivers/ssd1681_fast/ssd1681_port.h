/**
 * @file    ssd1681_port.h
 * @brief   Board transport for components/ssd1681_fast - the only part of
 *          the InkBoy driver that knows about pins, SPI and interrupts.
 *
 * InkBoy (Waveshare ESP32-S3-ePaper-1.54 V2) drives the panel straight from
 * 3.3 V GPIOs and cuts its supply with an AO3401 high-side switch. The MP3
 * mainboard V2 is different in three ways that this layer hides:
 *
 *   1. The MCU runs at 1.8 V. SCK/MOSI/CS/DC/RES reach the panel through a
 *      TXB0106 auto-direction level shifter (A = 1.8 V, B = +3.3 V) whose
 *      OE (PA3, 330k pull-down) must be high for anything to get through.
 *   2. There is no panel-only power switch. The panel, its boost converter,
 *      the SD card and both level shifters' B sides share one switched
 *      +3.3 V rail (nPM1300 BUCK2). "Power off" therefore means: deep sleep
 *      (cmd 0x10), OE low, MCU-side pins low - the rail itself belongs to
 *      main/power.c, which also needs it for the SD card.
 *   3. BUSY comes straight from the panel (3.3 V) through a 10k series
 *      resistor into PA1 (five-volt-tolerant) - it does NOT pass the TXB0106,
 *      so it can be read even while OE is low. EXTI1 timestamps its edges.
 *
 * Writes are SPI1 TX-only, mode 0, MSB first. 10 MHz (PCLK2/16) is the
 * stock rate; 20 MHz (PCLK2/8) is InkBoy's "fast transport", the SSD1681
 * write-clock limit, and inside the TXB0106's 60 Mbps rating at
 * VCCA 1.8 V / VCCB 3.3 V (17 ns minimum pulse; 20 MHz = 25 ns).
 */
#ifndef SSD1681_PORT_H
#define SSD1681_PORT_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "esp_err.h"

#define SSD1681_PORT_SLOW_HZ  10000000u
#define SSD1681_PORT_FAST_HZ  20000000u

/* One-time setup (clocks, BUSY EXTI). Safe to call repeatedly.          */
esp_err_t ssd1681_port_init(void);
/* "Panel power": true = pins live, SPI on, OE high (rail must be up);
 * false = SPI off, OE low, all A-side outputs low, BUSY analog.         */
esp_err_t ssd1681_port_power(bool on);
void      ssd1681_port_rst(int level);
int       ssd1681_port_busy(void);
/* DC + CS framed write of `length` bytes at `hz` (rounded down to the
 * nearest SPI prescaler).                                                */
esp_err_t ssd1681_port_write(bool data, const uint8_t *bytes, size_t length, unsigned hz);
/* BUSY edge timing: arm before the activation command, then wait for a
 * complete rising->falling pulse. Returns false on timeout.               */
void      ssd1681_port_busy_arm(void);
bool      ssd1681_port_busy_wait(uint32_t timeout_ms, int64_t *rise_us, int64_t *fall_us);
/* dt-0.2.0: called repeatedly while BUSY is high inside busy_wait (NULL = none). Test use only. */
void      ssd1681_port_set_busy_hook(void (*hook)(void));

/* Optional: user override of the transport ceiling (Settings > SPI).
 * If false, "fast transport" requests also run at 10 MHz.               */
void      ssd1681_port_allow_fast(bool allow);
bool      ssd1681_port_fast_allowed(void);
unsigned  ssd1681_port_active_hz(void);

#endif /* SSD1681_PORT_H */
