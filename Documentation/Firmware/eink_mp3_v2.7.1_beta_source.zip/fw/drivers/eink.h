/**
 * @file    eink.h
 * @brief   Panel front-end for the 1.54" 200x200 GDEY0154D67 (SSD1681).
 *
 * 2.7.0: the panel is driven by the InkBoy driver fork (drivers/ssd1681_fast,
 * drivers/inkboy) that the display-test firmware proved on this board. This
 * file keeps the player's old eink_* calls on top of it and adds two drives:
 *
 *   EINK_DRIVE_FAST (default)  InkBoy's register-loaded waveforms. A screen
 *     change is a burst of ~20 ms scans that drive only the pixels that
 *     change, 8 pulses each (about 0.3 s to settle, no flash). The scans are
 *     delivered one per eink_service() call, so the main loop keeps running
 *     between them and a new frame can replace the target at any time.
 *     A session starts with one clean (flashing) refresh and is cleaned
 *     again by the driver's own limit of 2400 scans.
 *   EINK_DRIVE_CLASSIC         the panel's factory (OTP) waveforms, as in
 *     2.6.7: full refresh, partial refresh, partial + reinforcing pass.
 *     Always used while USB storage / USB DAC / the USB prompt is active
 *     (eink_force_classic), because that is where the 2.5.1-2.6.2
 *     register waveform hung the board and the cause was never isolated.
 *
 * Framebuffer: 1 bpp, SSD1681 native: 1 = white, MSB = leftmost pixel,
 * 25 bytes per row (changed in 2.7.0 from 1 = black, so the buffer can be
 * handed to the driver without a copy). gfx.c is the only writer.
 */
#ifndef EINK_H
#define EINK_H

#include <stdbool.h>
#include <stdint.h>

#define EINK_FB_SIZE   (200u * 200u / 8u)

typedef enum { EINK_DRIVE_FAST, EINK_DRIVE_CLASSIC, EINK_DRIVE_COUNT } eink_drive_t;

void eink_init(void);                       /* timer, port, first power-on */
void eink_sleep(void);                      /* classic drive: panel deep sleep
                                               (fast drive keeps its session) */
void eink_wake(void);
bool eink_is_asleep(void);

/* System sleep. eink_power_off(): settle, deep sleep, TXB0106 OE low, pins
 * low. eink_power_on(): driver re-opened; the glass is known to be white. */
void eink_power_off(void);
void eink_power_on(void);

uint8_t *eink_framebuffer(void);            /* 1 = white                   */

/* Clean refresh (flashes): starts / renews the fast session, or an OTP
 * full in the classic drive.                                              */
void eink_refresh_full(void);
/* The OTP hot-weather "fast full" measured SLOWER than the normal full on
 * this panel (display test dt-0.1.0: 1728 ms vs 1390 ms), so it is gone;
 * the name stays for callers and maps to eink_refresh_full().             */
void eink_refresh_full_fast(void);
/* Boot / notice screen: always the factory (OTP) full refresh, so wiring,
 * level shifter, booster and BUSY are proven by the known-good path before
 * the first register waveform is loaded (display-test rule).              */
void eink_boot_screen(void);
/* Show the framebuffer without a flash. Fast drive: starts the scan burst
 * and returns after the first scan (see eink_service / eink_settle).
 * Classic drive: one OTP partial, blocking (~0.36 s).                     */
void eink_refresh_partial(void);
/* Classic drive: partial + reinforcing pass. Fast drive: same as partial. */
void eink_refresh_partial_clean(void);
/* Kept for callers; both drives update the whole frame (the fast drive
 * only drives changed pixels anyway).                                     */
void eink_refresh_partial_area(int x, int y, int w, int h);

/* Call every main-loop lap: delivers the next scan of a running burst,
 * switches the boosters off when the panel has been idle, retries after a
 * panel fault. Returns true while scans are still pending.                */
bool eink_service(void);
bool eink_settling(void);
void eink_settle(void);                     /* block until the burst ends  */

/* Work to run while the panel is busy or the driver is waiting (audio
 * decode pump, USB). Must not draw or refresh.                            */
void eink_set_idle_hook(void (*hook)(void));

/* ---- configuration (Device settings) ------------------------------------ */
void eink_set_drive(eink_drive_t drive);
eink_drive_t eink_drive(void);              /* the configured drive        */
bool eink_fast_active(void);                /* fast drive in use right now */
void eink_force_classic(bool on);           /* USB guard                   */
/* After a fault / brownout / watchdog restart the fast drive is not
 * started unattended (display-test rule: a crash must not turn into a
 * refresh-and-reboot loop). The classic drive is used until the next
 * normal start, or until the user picks a drive in Device settings.       */
void eink_safe_classic(bool on);
bool eink_safe_classic_on(void);
void eink_set_ink(uint8_t pulses);          /* fast drive: 4..8 per pixel  */
void eink_set_halo(uint8_t radius);         /* edge clean-up: 0, 1 or 2 px */
void eink_set_spi_fast(bool on);            /* 20 MHz (default) / 10 MHz   */

/* The fast session is close to the driver's scan limit: the next refresh
 * should be eink_refresh_full().                                          */
bool eink_clean_due(void);

/* ---- health -------------------------------------------------------------- */
bool eink_failed(void);                     /* panel not answering         */
/* Two reset attempts failed: the caller may cycle the +3.3 V rail (when
 * nothing else is using it) and then call eink_recovered().               */
bool eink_wants_rail_cycle(void);
void eink_rail_cycled(void);

typedef struct {
    uint32_t scans;            /* panel activations in this session        */
    uint32_t since_clean;      /* partial scans since the last clean       */
    uint32_t last_busy_ms;     /* BUSY time of the last activation         */
    uint32_t last_full_ms;     /* BUSY time of the last clean refresh      */
    uint32_t faults;           /* panel faults since boot                  */
    uint32_t sessions;         /* fast sessions started since boot         */
} eink_stats_t;
const eink_stats_t *eink_stats(void);

#endif /* EINK_H */
