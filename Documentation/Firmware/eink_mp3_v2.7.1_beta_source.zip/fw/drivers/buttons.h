/**
 * @file    buttons.h
 * @brief   5-key input engine: debounce, short/long/double press, repeat,
 *          and the SW4+SW5 5-second reboot chord.
 *
 * Mapping (software configuration.txt):
 *   SW1  short = play/pause & menu select
 *        long  = resume last-played context (e.g. "playlist 2, shuffle")
 *        double= back
 *   SW2  short = next track / menu down;  held = auto-repeat scroll
 *   SW3  short = previous track / menu up (no double-press: acts at once);
 *        held  = auto-repeat scroll in lists; long = back on Now Playing,
 *        adjust, firmware-update and diagnostics screens
 *   SW4  volume down (auto-repeat)
 *   SW5  volume up   (auto-repeat)
 *   SW4+SW5 held 5 s = reboot (NVIC_SystemReset)
 *   SW1+SW4+SW5 held 5 s = reboot into USB firmware update (ST DFU)
 *
 * Chords: while two or more keys are held no events are produced at all,
 * and the keys involved stay silent until released - so the recovery
 * chords never start playback or change the volume on the way. The reboot
 * chord only arms once vol- and vol+ have each been seen released since
 * boot (a stuck or floating key can't reset-loop the player). At 5 s the
 * main loop is asked to save settings and reboot; if it doesn't within
 * 1.5 s (firmware hung) the SysTick handler resets directly.
 *
 * Implementation: EXTI wakes the MCU on any edge; actual state is sampled
 * on the 1 kHz SysTick and debounced 20 ms, so EXTI bounce is irrelevant.
 */
#ifndef BUTTONS_H
#define BUTTONS_H

#include <stdbool.h>
#include <stdint.h>

typedef enum {
    BTN_SW1, BTN_SW2, BTN_SW3, BTN_SW4, BTN_SW5, BTN_COUNT
} btn_id_t;

typedef enum {
    BTN_EV_NONE = 0,
    BTN_EV_SHORT,       /* released before long threshold, no double pending */
    BTN_EV_LONG,        /* held past 700 ms (fires once)                     */
    BTN_EV_DOUBLE,      /* SW1: two shorts within 300 ms                     */
    BTN_EV_REPEAT,      /* auto-repeat while held (SW2..SW5)                 */
    BTN_EV_CHORD,       /* 2.7.0: SW2 + SW3 held together for chord_ms; id = SW2.
                         * Fires once; both keys then stay silent until released
                         * (no skip, no repeat, no long press on the way).     */
} btn_event_type_t;

typedef struct {
    btn_id_t         id;
    btn_event_type_t type;
    uint32_t         t;     /* dt-0.2.0: HAL tick of the physical press (debounce removed)
                             * or of the repeat - origin for key-to-display latency       */
} btn_event_t;

/* dt-0.2.0: runtime timing (defaults = the player's constants).
 *   sw1_double:   SW1 double-press = back. Off: every SW1 short fires on release at once
 *                 (no 300 ms wait), back stays on SW3 long.
 *   nav_on_press: SW2..SW5 report SHORT on the debounced press instead of the release
 *                 (and stay silent on release); long/repeat unchanged.                     */
typedef struct {
    uint16_t long_ms, double_gap_ms, repeat_delay_ms, repeat_rate_ms;
    uint8_t  debounce_ms;
    bool     sw1_double, nav_on_press;
    uint16_t chord_ms;      /* 2.7.0: SW2 + SW3 hold time for BTN_EV_CHORD      */
} btn_timing_t;
#define BTN_TIMING_DEFAULT { 700, 300, 500, 150, 20, true, false, 350 }
void buttons_set_timing(const btn_timing_t *t);
/* 2.7.0: nav_on_press only acts while this is true. The UI turns it off on
 * screens where a release-time decision matters (Now Playing: the two skip
 * keys pressed together open the quick menu and must not skip first).      */
void buttons_press_mode(bool allow_on_press);
const btn_timing_t *buttons_timing(void);

void buttons_init(void);
void buttons_tick_1ms(void);                 /* call from SysTick           */
bool buttons_get_event(btn_event_t *ev);     /* pop from event FIFO         */
bool buttons_any_pressed(void);              /* raw, for sleep gating       */

/* After a wake from system sleep: drop queued events and ignore every
 * button until it has been seen released, so the press that woke the
 * device is never acted upon (pressing play while asleep only wakes and
 * shows the paused song; a second press plays).                         */
void buttons_ignore_until_release(void);

/* Reboot chord completed: 0 = none, 1 = plain reset, 2 = USB DFU.        */
typedef enum { BTN_REBOOT_NONE, BTN_REBOOT_RESET, BTN_REBOOT_DFU } btn_reboot_t;
btn_reboot_t buttons_reboot_request(void);

#endif /* BUTTONS_H */
