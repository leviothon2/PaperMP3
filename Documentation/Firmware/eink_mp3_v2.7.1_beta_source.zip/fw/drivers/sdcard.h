/**
 * @file    sdcard.h
 * @brief   microSD over SDMMC1 through the TXS02612 level shifter.
 *
 * Player 2.6.6/2.6.7 driver API, extended for the display-test firmware
 * (dt-0.2.0) to find out why the card is unreliable on the V2 board:
 *   - every bus parameter is configurable (clock, width, power-save, flow
 *     control, clock edge, pin speed, polled vs IDMA);
 *   - each init attempt starts from a reset peripheral and a cleared handle;
 *   - a failed init records the stage it stopped at plus the HAL error bits;
 *   - sdcard_probe() walks card identification one command at a time.
 * The player-compatible calls (sdcard_init/read/write/...) behave as before
 * when the configuration is SDCARD_CFG_PLAYER.
 */
#ifndef SDCARD_H
#define SDCARD_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* ---- configuration ------------------------------------------------------- */
typedef struct {
    uint8_t clock_div;     /* SD CLK = 48 MHz / (2 x div): 1 = 24 MHz (player),
                              2 = 12, 3 = 8, 4 = 6, 8 = 3, 60 = 0.4 MHz       */
    uint8_t bus_4bit;      /* 1 = 4-bit (player), 0 = 1-bit                    */
    uint8_t power_save;    /* stop CLK when the bus is idle (player: 1)        */
    uint8_t hw_flow;       /* hardware flow control (player: 1)                */
    uint8_t falling_edge;  /* NEGEDGE: drive CMD/DAT on the falling edge (0)  */
    uint8_t pin_speed;     /* GPIO speed 0..3 = LOW..VERY_HIGH (player: 3)     */
    uint8_t use_dma;       /* IDMA transfers instead of CPU polling (player: 0)*/
} sdcard_cfg_t;

#define SDCARD_CFG_PLAYER   { 1, 1, 1, 1, 0, 3, 0 }
/* dt-0.2.0 default: the player's settings with one change, 12 MHz. At
 * 24 MHz the read round trip through the TXS02612 (4.5 + up to 14 + 6.3 ns)
 * exceeds the 20.8 ns half-period; 12 MHz gives a 41.7 ns window.        */
#define SDCARD_CFG_DEFAULT  { 2, 1, 1, 1, 0, 3, 0 }

void                sdcard_set_config(const sdcard_cfg_t *cfg); /* next init  */
const sdcard_cfg_t *sdcard_config(void);
uint32_t            sdcard_clock_hz(void);          /* configured bus clock   */

/* ---- result of the last init ---------------------------------------------- */
typedef enum {
    SD_STAGE_NONE = 0,
    SD_STAGE_DETECT,      /* card-detect switch says no card                  */
    SD_STAGE_CLOCK,       /* HSI48 (SDMMC kernel clock) not running           */
    SD_STAGE_IDENT,       /* CMD0/CMD8/ACMD41/CMD2/CMD3/CMD9/CMD7 at 400 kHz  */
    SD_STAGE_STATUS,      /* ACMD13 SD status (1-bit, 400 kHz)                */
    SD_STAGE_WIDEBUS,     /* ACMD6 bus width + switch to the working clock    */
    SD_STAGE_TRANSFER,    /* CMD13 polling until the card reports TRANSFER    */
    SD_STAGE_READY,       /* init complete                                    */
} sdcard_stage_t;

typedef struct {
    sdcard_stage_t stage;     /* stage reached (READY = success)              */
    uint32_t hal_err;         /* HAL_SD_ERROR_* bits of the failing step       */
    uint32_t ms;              /* duration of the attempt                       */
    uint32_t clock_hz;        /* bus clock used                                */
    uint8_t  card_type;       /* 0 SDSC, 1 SDHC/SDXC (HAL CardType)            */
    uint8_t  card_speed;      /* 0 normal, 1 high, 2 UHS (from the SD status)  */
    uint32_t blocks;          /* capacity in 512-byte blocks                   */
} sdcard_report_t;

const sdcard_report_t *sdcard_last_report(void);
const char *sdcard_stage_name(sdcard_stage_t s);
/* Short text for HAL_SD_ERROR_* bits, e.g. "DCRC+RXOVR". */
void sdcard_err_text(uint32_t err, char *buf, size_t n);

/* ---- I/O statistics (since the last sdcard_stats_reset) -------------------- */
typedef struct {
    uint32_t reads, read_errs, writes, write_errs;
    uint32_t last_err;        /* HAL_SD_ERROR_* bits of the latest failed I/O  */
} sdcard_stats_t;
const sdcard_stats_t *sdcard_stats(void);
void sdcard_stats_reset(void);

/* ---- player-compatible API ---------------------------------------------------- */
bool     sdcard_present(void);              /* mechanical card detect     */
bool     sdcard_init(void);                 /* enumerate (rail must be on)*/
void     sdcard_deinit(void);               /* SDMMC off                  */
void     sdcard_power_off(void);            /* deinit + pins hi-Z (rail off) */
void     sdcard_idle(void);                 /* 2.6.7 sleep: bus stopped, card powered */
bool     sdcard_ready(void);
uint32_t sdcard_card_id(void);
uint32_t sdcard_block_count(void);
uint32_t sdcard_block_size(void);           /* always 512                 */
bool sdcard_read (uint8_t *buf, uint32_t lba, uint32_t nblk);
bool sdcard_write(const uint8_t *buf, uint32_t lba, uint32_t nblk);

/* ---- step-by-step identification (diagnostics; leaves the card deselected and
 *      the peripheral off; call with FatFs unmounted) ---------------------------- */
typedef struct {
    uint32_t cmd0, cmd8, acmd41, cmd2, cmd3, cmd9, cmd7;  /* SDMMC_ERROR_* (0 = OK) */
    bool     v2;              /* CMD8 answered: physical spec 2.00+            */
    uint32_t acmd41_tries, acmd41_ms;
    uint32_t ocr;             /* bit31 ready, bit30 CCS (SDHC/XC), bit24 S18A  */
    uint32_t cid[4], csd[4];
    uint16_t rca;
    uint32_t blocks;          /* from the CSD                                  */
    uint8_t  last_step;       /* 1..7 = last command attempted                 */
} sdcard_probe_t;
bool sdcard_probe(sdcard_probe_t *p);

/* dt-0.2.1: bus state at the moment of the last failed transfer (taken before any recovery).
 * dcount = bytes the data path was still waiting for (512 for a single block that never
 * started); pins = live input levels, bit0..3 = DAT0..3, bit4 = CMD, bit5 = CLK.               */
typedef struct { bool valid; uint32_t sta, dcount, dctrl, clkcr; uint8_t pins; uint32_t ms; } sdcard_fail_t;
const sdcard_fail_t *sdcard_last_fail(void);

/* dt-0.2.1: one single-block read done by hand: CMD17, then 150 ms of watching the DAT pins
 * (which lines ever went low) and draining the FIFO. Separates "card never answers" from "one
 * DAT line missing" from "data arrives but CRC fails". Card must be initialised (sdcard_init). */
typedef struct {
    uint32_t cmd_err;       /* CMD17 response error (0 = card accepted the read)           */
    uint32_t bytes;         /* words drained from the FIFO x 4                               */
    uint8_t  low_seen;      /* bit n = DATn was seen low at least once                       */
    bool     dataend, dcrc, dtimeout, rxovr, dpsm_active;
    uint32_t dcount;
} sdcard_linecheck_t;
bool sdcard_line_check(uint32_t lba, sdcard_linecheck_t *r);

#endif /* SDCARD_H */
