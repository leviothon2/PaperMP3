/**
 * @file    esp_timer.h
 * @brief   Microsecond time base (TIM2, 32-bit @ 1 MHz, extended to 64 bit).
 *
 * InkBoy paces its scans on esp_timer_get_time() (30 ms dithered slots,
 * 33.334 ms image slots) and measures BUSY pulses in microseconds. The
 * STM32's 1 kHz SysTick is too coarse for that, so TIM2 (a 32-bit timer
 * on APB1) runs at 1 MHz and its overflow (every 71.6 min) is counted in
 * software. Must be started with port_timer_init() before first use.
 */
#ifndef ESP_TIMER_H
#define ESP_TIMER_H

#include <stdint.h>

void    port_timer_init(void);
int64_t esp_timer_get_time(void);

#endif /* ESP_TIMER_H */
