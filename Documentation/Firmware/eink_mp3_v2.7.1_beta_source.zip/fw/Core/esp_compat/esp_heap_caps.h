/**
 * @file    esp_heap_caps.h
 * @brief   heap_caps_* shim. The ESP32-S3 splits internal SRAM / PSRAM /
 *          DMA-capable memory; the U575 has one flat SRAM, so every
 *          capability maps onto the newlib heap ([_sheap, _eheap) in the
 *          linker script).
 */
#ifndef ESP_HEAP_CAPS_H
#define ESP_HEAP_CAPS_H

#include <stddef.h>
#include <stdlib.h>

#define MALLOC_CAP_INTERNAL  (1u << 0)
#define MALLOC_CAP_SPIRAM    (1u << 1)
#define MALLOC_CAP_DMA       (1u << 2)
#define MALLOC_CAP_8BIT      (1u << 3)

static inline void *heap_caps_calloc(size_t n, size_t size, unsigned caps)
{
    (void)caps;
    return calloc(n, size);
}
static inline void *heap_caps_malloc(size_t size, unsigned caps)
{
    (void)caps;
    return malloc(size);
}
static inline void heap_caps_free(void *p) { free(p); }

size_t heap_caps_get_free_size(unsigned caps);
size_t heap_caps_get_largest_free_block(unsigned caps);

#endif /* ESP_HEAP_CAPS_H */
