/**
 * @file    esp_compat.c
 * @brief   Implementation of the ESP-IDF shims (see the headers in include/).
 *
 *   - esp_timer_get_time(): TIM2 @ 1 MHz, 32-bit, overflow counted in the
 *     TIM2 update interrupt -> 64-bit microseconds since port_timer_init().
 *   - port_log(): formats only when ITM/SWO is live (debugger attached and
 *     ITM enabled) or for warnings/errors (kept in a RAM ring the UI can
 *     show). Uses its own formatter because newlib-nano's printf can't do
 *     64-bit integers and InkBoy logs int64_t timings with PRId64.
 *   - port_delay_ms(): busy wait on HAL_GetTick() with an optional idle
 *     hook. No WFI: the MP3 firmware (2.4.1) found that sleeping between
 *     polls during a panel update, the board's largest load step, caused
 *     faults; the panel code here keeps the same rule.
 */
#include "esp_err.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"
#include "freertos/FreeRTOS.h"
#include "stm32u5xx_hal.h"

#include <malloc.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

/* ---- errors ------------------------------------------------------------- */

const char *esp_err_to_name(esp_err_t code)
{
    switch (code) {
    case ESP_OK:                return "ESP_OK";
    case ESP_FAIL:              return "ESP_FAIL";
    case ESP_ERR_NO_MEM:        return "ESP_ERR_NO_MEM";
    case ESP_ERR_INVALID_ARG:   return "ESP_ERR_INVALID_ARG";
    case ESP_ERR_INVALID_STATE: return "ESP_ERR_INVALID_STATE";
    case ESP_ERR_INVALID_SIZE:  return "ESP_ERR_INVALID_SIZE";
    case ESP_ERR_NOT_FOUND:     return "ESP_ERR_NOT_FOUND";
    case ESP_ERR_NOT_SUPPORTED: return "ESP_ERR_NOT_SUPPORTED";
    case ESP_ERR_TIMEOUT:       return "ESP_ERR_TIMEOUT";
    default:                    return "ESP_ERR_?";
    }
}

/* ---- microsecond timer (TIM2) -------------------------------------------- */

static volatile uint32_t s_timer_hi;
static bool s_timer_ok;

void port_timer_init(void)
{
    __HAL_RCC_TIM2_CLK_ENABLE();
    TIM2->CR1 = 0;
    /* APB1 prescaler is 1 (system_clock.c), so the timer kernel clock is
     * PCLK1 = 160 MHz.                                                   */
    uint32_t pclk = HAL_RCC_GetPCLK1Freq();
    TIM2->PSC  = pclk / 1000000u - 1u;
    TIM2->ARR  = 0xFFFFFFFFu;
    TIM2->CNT  = 0;
    TIM2->EGR  = TIM_EGR_UG;                 /* load PSC                  */
    TIM2->SR   = 0;
    TIM2->DIER = TIM_DIER_UIE;
    s_timer_hi = 0;
    HAL_NVIC_SetPriority(TIM2_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(TIM2_IRQn);
    TIM2->CR1 = TIM_CR1_CEN;
    s_timer_ok = true;
}

void TIM2_IRQHandler(void)
{
    if (TIM2->SR & TIM_SR_UIF) {
        TIM2->SR = ~TIM_SR_UIF;
        s_timer_hi++;
    }
}

int64_t esp_timer_get_time(void)
{
    if (!s_timer_ok) return (int64_t)HAL_GetTick() * 1000;
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    uint32_t hi = s_timer_hi;
    uint32_t lo = TIM2->CNT;
    /* Overflow happened but its interrupt hasn't run yet (IRQs masked). */
    if ((TIM2->SR & TIM_SR_UIF) && lo < 0x80000000u) hi++;
    __set_PRIMASK(primask);
    return ((int64_t)hi << 32) | lo;
}

/* ---- delay ----------------------------------------------------------------- */

static void (*s_idle_hook)(void);
void port_set_idle_hook(void (*hook)(void)) { s_idle_hook = hook; }

void port_delay_ms(uint32_t ms)
{
    uint32_t t0 = HAL_GetTick();
    while (HAL_GetTick() - t0 < ms) {
        if (s_idle_hook) s_idle_hook();
    }
}

/* ---- heap ------------------------------------------------------------------- */

extern uint8_t _eheap[];

size_t heap_caps_get_free_size(unsigned caps)
{
    (void)caps;
    struct mallinfo mi = mallinfo();
    uint8_t *brk = (uint8_t *)sbrk(0);
    size_t top = (brk && brk != (uint8_t *)-1 && brk < _eheap) ? (size_t)(_eheap - brk) : 0;
    return top + (size_t)mi.fordblks;
}

size_t heap_caps_get_largest_free_block(unsigned caps)
{
    /* Upper bound: the untouched top of the heap is one block.          */
    (void)caps;
    uint8_t *brk = (uint8_t *)sbrk(0);
    return (brk && brk != (uint8_t *)-1 && brk < _eheap) ? (size_t)(_eheap - brk) : 0;
}

/* ---- logging ------------------------------------------------------------------ */

static char     s_ring[PORT_LOG_LINES][PORT_LOG_LINE_LEN];
static unsigned s_ring_next, s_ring_count;

static bool itm_live(void)
{
    return (DCB->DEMCR & DCB_DEMCR_TRCENA_Msk) &&
           (ITM->TCR & ITM_TCR_ITMENA_Msk) && (ITM->TER & 1u);
}

/* Small printf subset: %[-][0][width][l|ll]{d,i,u,x,X,s,c,%}.            */
typedef struct { char *p; size_t left; } out_t;

static void put(out_t *o, char c)
{
    if (o->left > 1) { *o->p++ = c; o->left--; }
}

static void put_num(out_t *o, uint64_t v, bool neg, unsigned base, bool upper,
                    int width, bool zero, bool left)
{
    char tmp[24];
    int n = 0;
    const char *dig = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    do { tmp[n++] = dig[v % base]; v /= base; } while (v && n < (int)sizeof tmp);
    int len = n + (neg ? 1 : 0);
    if (!left && !zero) while (width-- > len) put(o, ' ');
    if (neg) put(o, '-');
    if (!left && zero) while (width-- > len) put(o, '0');
    while (n) put(o, tmp[--n]);
    if (left) while (width-- > len) put(o, ' ');
}

static void fmt(char *buf, size_t size, const char *f, va_list ap)
{
    out_t o = { buf, size };
    for (; *f; f++) {
        if (*f != '%') { put(&o, *f); continue; }
        f++;
        bool left = false, zero = false;
        int width = 0, lng = 0;
        for (;; f++) {
            if (*f == '-') left = true;
            else if (*f == '0') zero = true;
            else break;
        }
        while (*f >= '0' && *f <= '9') width = width * 10 + (*f++ - '0');
        while (*f == 'l') { lng++; f++; }
        switch (*f) {
        case 'd': case 'i': {
            int64_t v = lng >= 2 ? va_arg(ap, long long) : lng ? va_arg(ap, long) : va_arg(ap, int);
            put_num(&o, v < 0 ? (uint64_t)(-(v + 1)) + 1u : (uint64_t)v, v < 0, 10, false, width, zero, left);
            break;
        }
        case 'u': case 'x': case 'X': {
            uint64_t v = lng >= 2 ? va_arg(ap, unsigned long long) :
                         lng ? va_arg(ap, unsigned long) : va_arg(ap, unsigned);
            put_num(&o, v, false, *f == 'u' ? 10 : 16, *f == 'X', width, zero, left);
            break;
        }
        case 's': {
            const char *s = va_arg(ap, const char *);
            if (!s) s = "(null)";
            int len = (int)strlen(s);
            if (!left) while (width-- > len) put(&o, ' ');
            while (*s) put(&o, *s++);
            if (left) while (width-- > len) put(&o, ' ');
            break;
        }
        case 'c': put(&o, (char)va_arg(ap, int)); break;
        case '%': put(&o, '%'); break;
        case '\0': f--; break;
        default: put(&o, '%'); put(&o, *f); break;
        }
    }
    *o.p = '\0';
}

void port_log(esp_log_level_t level, const char *tag, const char *f, ...)
{
    bool live = itm_live();
    bool keep = level <= ESP_LOG_WARN;
    if (!live && !keep) return;                 /* nothing would see it   */

    char line[160];
    static const char lv[] = "?EWIDV";
    line[0] = lv[level < 6 ? level : 0];
    line[1] = ' ';
    size_t n = 2;
    while (*tag && n < 24) line[n++] = *tag++;
    line[n++] = ':'; line[n++] = ' ';
    va_list ap;
    va_start(ap, f);
    fmt(line + n, sizeof line - n, f, ap);
    va_end(ap);

    if (live) {
        for (const char *p = line; *p; p++) ITM_SendChar((uint32_t)*p);
        ITM_SendChar('\n');
    }
    if (keep) {
        memcpy(s_ring[s_ring_next], line, PORT_LOG_LINE_LEN - 1);
        s_ring[s_ring_next][PORT_LOG_LINE_LEN - 1] = '\0';
        s_ring_next = (s_ring_next + 1) % PORT_LOG_LINES;
        if (s_ring_count < PORT_LOG_LINES) s_ring_count++;
    }
}

unsigned port_log_lines(const char **lines, unsigned max)
{
    unsigned n = s_ring_count < max ? s_ring_count : max;
    for (unsigned i = 0; i < n; i++)
        lines[i] = s_ring[(s_ring_next + PORT_LOG_LINES - n + i) % PORT_LOG_LINES];
    return n;
}
