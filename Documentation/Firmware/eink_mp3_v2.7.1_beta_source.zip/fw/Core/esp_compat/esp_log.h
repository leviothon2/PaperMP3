/**
 * @file    esp_log.h
 * @brief   ESP_LOGx shim: SWO (ITM stimulus port 0) + a small RAM ring.
 *
 * The V2 board brings SWO out on PB3, so InkBoy's structured log lines
 * (PLAYER_DITHER_SCAN, PLAYER_GRAY_SCAN, ...) can be captured with an
 * ST-Link / J-Link SWO viewer at the same verbosity as InkBoy's USB serial.
 *
 * Cost control: when no debugger has enabled ITM, port_log() returns
 * before formatting anything, so the per-scan log calls in fast_display.c
 * cost a function call and two register reads.
 *
 * Note: newlib-nano's printf has no 64-bit (%lld / PRId64) support. The
 * shim therefore formats with its own small vsnprintf wrapper that
 * understands %lld/%llu/%"PRId64" (see esp_compat.c).
 */
#ifndef ESP_LOG_H
#define ESP_LOG_H

#include <stdarg.h>
#include <inttypes.h>

/* Some packaged arm-none-eabi toolchains pair newlib's inttypes.h with GCC's own stdint.h and end
 * up without the 64-bit PRI macros InkBoy's log lines use. port_log() formats them itself.      */
#ifndef PRId64
#define PRId64 "lld"
#endif
#ifndef PRIu64
#define PRIu64 "llu"
#endif

typedef enum {
    ESP_LOG_NONE, ESP_LOG_ERROR, ESP_LOG_WARN, ESP_LOG_INFO, ESP_LOG_DEBUG, ESP_LOG_VERBOSE
} esp_log_level_t;

#ifndef LOG_LOCAL_LEVEL
#define LOG_LOCAL_LEVEL ESP_LOG_INFO
#endif

void port_log(esp_log_level_t level, const char *tag, const char *fmt, ...)
    __attribute__((format(printf, 3, 4)));

#define ESP_LOG_LEVEL_LOCAL(l, tag, fmt, ...) \
    do { if ((l) <= LOG_LOCAL_LEVEL) port_log((l), (tag), fmt, ##__VA_ARGS__); } while (0)

#define ESP_LOGE(tag, fmt, ...) ESP_LOG_LEVEL_LOCAL(ESP_LOG_ERROR, tag, fmt, ##__VA_ARGS__)
#define ESP_LOGW(tag, fmt, ...) ESP_LOG_LEVEL_LOCAL(ESP_LOG_WARN,  tag, fmt, ##__VA_ARGS__)
#define ESP_LOGI(tag, fmt, ...) ESP_LOG_LEVEL_LOCAL(ESP_LOG_INFO,  tag, fmt, ##__VA_ARGS__)
#define ESP_LOGD(tag, fmt, ...) ESP_LOG_LEVEL_LOCAL(ESP_LOG_DEBUG, tag, fmt, ##__VA_ARGS__)

/* Last log lines kept in RAM (newest last) for the on-screen log page.  */
#define PORT_LOG_LINES     8
#define PORT_LOG_LINE_LEN  40
unsigned port_log_lines(const char **lines, unsigned max);

#endif /* ESP_LOG_H */
