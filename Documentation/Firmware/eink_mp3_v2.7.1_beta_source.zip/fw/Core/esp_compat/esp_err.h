/**
 * @file    esp_err.h
 * @brief   ESP-IDF error-code shim for the STM32U575 port.
 *
 * InkBoy's display code (components/ssd1681_fast, main/fast_display.c,
 * main/drive_counters.c, main/gray_plan.c ...) is written against
 * ESP-IDF. Rather than rewriting every return path, this fork provides the
 * small part of the ESP-IDF API those files use. Values match ESP-IDF so
 * log lines compare 1:1 with InkBoy's serial captures.
 *
 * Keeping the InkBoy sources textually close to upstream is the point:
 * a later InkBoy fix can be diffed and applied with little or no editing.
 */
#ifndef ESP_ERR_H
#define ESP_ERR_H

#include <stdint.h>

typedef int esp_err_t;

#define ESP_OK                    0
#define ESP_FAIL                 -1
#define ESP_ERR_NO_MEM            0x101
#define ESP_ERR_INVALID_ARG       0x102
#define ESP_ERR_INVALID_STATE     0x103
#define ESP_ERR_INVALID_SIZE      0x104
#define ESP_ERR_NOT_FOUND         0x105
#define ESP_ERR_NOT_SUPPORTED     0x106
#define ESP_ERR_TIMEOUT           0x107

const char *esp_err_to_name(esp_err_t code);

#endif /* ESP_ERR_H */
