/**
 * @file    esp_attr.h
 * @brief   Memory-placement attributes. On the STM32U575 all 768 KB of SRAM
 *          is one contiguous, DMA-reachable region, so DMA_ATTR only has to
 *          guarantee word alignment (InkBoy reads mask planes as uint32_t).
 */
#ifndef ESP_ATTR_H
#define ESP_ATTR_H

#define DMA_ATTR    __attribute__((aligned(4)))
#define IRAM_ATTR
#define EXT_RAM_BSS_ATTR

#endif /* ESP_ATTR_H */
