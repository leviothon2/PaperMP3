/**
 * @file    FreeRTOS.h
 * @brief   Minimal FreeRTOS shim. This firmware has no RTOS (same as the
 *          MP3 player firmware): one superloop, interrupts only move data.
 *          InkBoy's display path only needs a millisecond delay, which maps
 *          onto port_delay_ms() - a SysTick wait that keeps servicing the
 *          board (button sampling runs in SysTick regardless).
 */
#ifndef FREERTOS_H
#define FREERTOS_H

#include <stdint.h>
#include <stdbool.h>

typedef uint32_t TickType_t;
typedef int      BaseType_t;
typedef unsigned UBaseType_t;

#define pdTRUE   1
#define pdFALSE  0
#define portMAX_DELAY 0xFFFFFFFFu
#define pdMS_TO_TICKS(ms) ((TickType_t)(ms))   /* 1 kHz tick            */

void port_delay_ms(uint32_t ms);
/* Called repeatedly while port_delay_ms() waits (e.g. housekeeping).   */
void port_set_idle_hook(void (*hook)(void));

#endif /* FREERTOS_H */
