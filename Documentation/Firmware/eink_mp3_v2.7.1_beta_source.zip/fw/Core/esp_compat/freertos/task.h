/**
 * @file    task.h
 * @brief   vTaskDelay shim (see FreeRTOS.h).
 */
#ifndef FREERTOS_TASK_H
#define FREERTOS_TASK_H

#include "FreeRTOS.h"

static inline void vTaskDelay(TickType_t ticks) { port_delay_ms(ticks); }

#endif /* FREERTOS_TASK_H */
