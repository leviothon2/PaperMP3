/**
 * @file    main.c
 * @brief   E-ink MP3 player - entry point and superloop.
 *
 * Architecture: no RTOS (flash_budget.md). Interrupts move data (SAI DMA,
 * SysTick button sampling, EXTI wake); the main loop runs the decoder,
 * UI and power management as cooperative steps. Between steps the CPU
 * sleeps in WFI; after the user-set inactivity timeout power.c turns the
 * screen white, drops the 3.3 V rail and puts the MCU into Stop 2.
 *
 * The decoder and USB stack are also serviced from inside e-ink refresh
 * waits (eink_set_idle_hook), so a panel refresh never starves the audio
 * ring.
 *
 * 2.7.0 boot order (from the display-test firmware): settings from
 * internal flash first, so the SD bus settings, key timing and display
 * drive apply before the card or the panel is touched; the USB input
 * limit is set before the panel's boosters run for the first time; the
 * boot screen is drawn with the factory waveform.
 */
#include "stm32u5xx_hal.h"
#include "board.h"
#include "dfu_entry.h"
#include "diag.h"

#include "../../drivers/buttons.h"
#include "../../drivers/eink.h"
#include "../../drivers/gfx.h"
#include "../../drivers/i2c_bus.h"
#include "../../drivers/cs43131.h"
#include "../../drivers/npm1300.h"
#include "../../drivers/sdcard.h"
#include "../../drivers/sai_audio.h"
#include "../../app/settings.h"
#include "../../app/player.h"
#include "../../app/power.h"
#include "../../app/ui.h"
#include "../../app/usb_app.h"
#include "../../app/fuelgauge.h"
#include "../../app/library.h"
#include "../../app/fwupdate.h"
#include "../../app/podcast.h"

void SystemClock_Config(void);

void Error_Handler(void)
{
    __disable_irq();
    /* A hard init failure on a screen-first device: reset and retry. The
     * caller's address is kept for the "Last reset" report.              */
    diag_note_reset(DIAG_RESET_ERROR);
    NVIC_SystemReset();
}

/* Work that must keep running while the e-ink panel is busy.             */
static void background_service(void)
{
    player_poll();
    usb_app_service();
}

/* Reboot chord finished (buttons.c): save, disconnect USB, then reset.   */
static void handle_reboot_request(btn_reboot_t r)
{
    if (usb_app_storage_owned()) usb_app_shutdown();   /* host owns card  */
    else { player_stop(); settings_flush(); usb_app_shutdown(); }
    /* 2.6.0: the USB DFU chord (SW1 + vol- + vol+) only restarted the
     * player (the ROM bootloader never came up on this board); it is now
     * a plain restart. Firmware updates go through the SD card.          */
    (void)r;
    diag_note_reset(DIAG_RESET_CHORD);
    NVIC_SystemReset();
}

int main(void)
{
    /* "Firmware update" was requested before the last reset: hand over to
     * ST's USB DFU bootloader before anything is configured.             */
    dfu_check_and_jump();
    diag_boot();                    /* reset cause, before anything else  */

    HAL_Init();                     /* SysTick @ 1 kHz, NVIC grouping     */
    SystemClock_Config();
    /* Instruction cache (8 KB, 2-way): most code and vector fetches are
     * served from SRAM-like cache instead of the flash array - faster,
     * and far fewer flash reads during load transients. Retained in
     * Stop 2, so it stays on across sleep.                               */
    while (ICACHE->SR & ICACHE_SR_BUSYF) { }
    ICACHE->CR |= ICACHE_CR_EN;

    /* 2.6.0: SD-card update trial bookkeeping; rolls back to the previous
     * bank if a new firmware keeps restarting before it reaches 20 s.    */
    fwu_boot_check();

    /* --- board bring-up, ordered by dependency ------------------------ */
    /* PC3 set up for its role (PMIC IRQ input / rail enable), unused
     * pins parked, low-power options on.                                 */
    power_early_init();
    buttons_init();
    i2c_bus_init();
    settings_boot();                /* defaults + flash copy (no SD yet)  */

    /* PMIC first: charging must work even if everything else fails.     */
    (void)npm1300_init(BATT_CHARGE_MA_DEFAULT, BATT_VTERM_MV);
    /* MCU rail in forced PWM while awake: BOR is only ~100 mV below 1.8 V
     * and load steps (SD, codec, USB) must not dip it.                   */
    (void)npm1300_buck1_pwm(true);
    HAL_Delay(PWR_3V3_SETTLE_MS);   /* BUCK2 may just have been enabled   */
    /* Display test rule: the VBUS input limit is raised from the PMIC's
     * 100 mA start-up value before the panel boosts for the first time
     * (on USB power without a battery the boosters would starve).        */
    {
        npm_vbus_t vbus = NPM_VBUS_NONE;
        if (npm1300_vbus_read(&vbus) && vbus != NPM_VBUS_NONE) npm1300_apply_vbus_limit(vbus);
    }

    eink_init();
    /* This start follows a CPU fault, brownout, watchdog or Error_Handler
     * reset (not a debugger / NRST reset): stay on the factory waveforms. */
    bool after_fault = diag_abnormal() && diag_info()->kind != DIAG_RESET_PIN;
    if (after_fault) eink_safe_classic(true);
    ui_splash();                    /* logo while the rest comes up       */

    /* Codec: starts XTAL and CLKOUT - required before any SAI use.      */
    bool codec_ok = cs43131_init();
    sai_audio_init();

    /* SD + settings + resume state. settings_mount() also applies charge
     * rate, contrast and dark mode; without a card the defaults apply.  */
    bool sd_ok = settings_card_start() && settings_mount();
    if (!sd_ok) settings_apply();

    usb_app_init();                 /* VBUS is checked on the first lap   */
    player_init();
    ui_init(codec_ok, sd_ok);
    if (after_fault) ui_toast("Restarted after a fault");
    eink_set_idle_hook(background_service);

    /* --- superloop ----------------------------------------------------- */
    for (;;) {
        /* 1. Input                                                       */
        diag_step(STEP_LOOP_INPUT);
        btn_reboot_t rr = buttons_reboot_request();
        if (rr) handle_reboot_request(rr);
        btn_event_t ev;
        while (buttons_get_event(&ev)) {
            power_note_activity();
            ui_handle_button(&ev);
        }

        /* 2. USB plug/unplug + mode prompt + class servicing             */
        diag_step(STEP_LOOP_USB);
        usb_app_poll();

        /* 3. Decode: refills the PCM ring; cheap when buffer is full.    */
        diag_step(STEP_LOOP_PLAYER);
        player_poll();

        /* 4. UI: redraws dirty regions; e-ink refresh pacing inside.     */
        diag_step(STEP_LOOP_UI);
        ui_poll();

        /* 5. Codec INT (headphones), card detect, deferred settings save */
        diag_step(STEP_LOOP_POWER);
        player_power_poll();
        settings_poll();
        podcast_poll();
        fuelgauge_poll();
        library_service();
        power_panel_service();      /* panel fault -> rail cycle if free  */

        /* 6. Inactivity -> white screen, rail off, Stop 2 (returns on
         *    wake with the previous screen redrawn).                     */
        if (player_take_sleep_request()) power_request_sleep();   /* sleep timer */
        power_poll();

        /* Sleep until the next interrupt (SysTick at worst: 1 ms) - unless
         * the decoder is hungry or the panel still has scans to deliver.  */
        if (!player_busy() && !eink_settling())
            __WFI();
    }
}

/* HAL timebase already provided by default SysTick implementation.       */
void SysTick_Handler(void)
{
    HAL_IncTick();
    buttons_tick_1ms();
}
