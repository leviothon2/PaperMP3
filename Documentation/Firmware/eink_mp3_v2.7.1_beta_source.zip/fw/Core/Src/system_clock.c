/**
 * @file    system_clock.c
 * @brief   Clock tree for the e-ink MP3 player.
 *
 * The board has NO MCU crystal. V2 also has NO 32.768 kHz LSE (PC14/PC15
 * are unconnected) - the only crystal is the CS43131's 22.5792 MHz:
 *
 *   HSI16  -> PLL1 -> 160 MHz SYSCLK (voltage scale 1)
 *   HSI48 + CRS (synced to USB SOF) -> ICLK -> USB-FS, SDMMC kernel
 *   LSI 32 kHz -> RTC (used only as the sleep wake-up timer)
 *   AUDIOCLK pin (PA0, CS43131 CLKOUT 11.2896 MHz) -> SAI1 kernel
 *   HSI16 -> I2C1 kernel (I2C timing constants assume 16 MHz)
 *
 * Wake-up from Stop 2 lands on HSI16 (STOPWUCK=1) so the I2C1 kernel and
 * SysTick are usable immediately for the cheap "should we really wake?"
 * checks in power.c; SystemClock_Config() is only re-run for a full wake.
 */
#include "stm32u5xx_hal.h"
#include <stdbool.h>

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef  osc = { 0 };
    RCC_ClkInitTypeDef  clk = { 0 };

    __HAL_RCC_PWR_CLK_ENABLE();

    /* Vcore range 1: needed for 160 MHz.                                 */
    if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
        Error_Handler();

    /* Backup domain access for the RTC clock mux (LSI).                  */
    HAL_PWR_EnableBkUpAccess();

    osc.OscillatorType = RCC_OSCILLATORTYPE_HSI | RCC_OSCILLATORTYPE_HSI48 |
                         RCC_OSCILLATORTYPE_LSI;
    osc.HSIState            = RCC_HSI_ON;
    osc.HSI48State          = RCC_HSI48_ON;
    osc.LSIState            = RCC_LSI_ON;
    osc.LSIDiv              = RCC_LSI_DIV1;
    osc.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    osc.PLL.PLLState        = RCC_PLL_ON;
    osc.PLL.PLLSource       = RCC_PLLSOURCE_HSI;      /* 16 MHz           */
    osc.PLL.PLLMBOOST       = RCC_PLLMBOOST_DIV1;
    osc.PLL.PLLM            = 1;                      /* /1  -> 16 MHz    */
    osc.PLL.PLLN            = 20;                     /* x20 -> 320 MHz   */
    osc.PLL.PLLP            = 2;
    osc.PLL.PLLQ            = 2;
    osc.PLL.PLLR            = 2;                      /* /2  -> 160 MHz   */
    osc.PLL.PLLRGE          = RCC_PLLVCIRANGE_1;
    osc.PLL.PLLFRACN        = 0;
    if (HAL_RCC_OscConfig(&osc) != HAL_OK) Error_Handler();

    clk.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK |
                    RCC_CLOCKTYPE_PCLK1  | RCC_CLOCKTYPE_PCLK2 |
                    RCC_CLOCKTYPE_PCLK3;
    clk.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV1;
    clk.APB2CLKDivider = RCC_HCLK_DIV1;
    clk.APB3CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_4) != HAL_OK) Error_Handler();

    /* Wake from Stop on HSI16 (not MSI 4 MHz): I2C1 kernel = HSI anyway. */
    __HAL_RCC_WAKEUPSTOP_CLK_CONFIG(RCC_STOP_WAKEUPCLOCK_HSI);

    /* ---- kernel clocks -------------------------------------------------- */
    static bool kernels_done;           /* survive Stop: configure once    */
    if (kernels_done) return;
    kernels_done = true;

    RCC_PeriphCLKInitTypeDef pclk = { 0 };

    /* SAI1 <- AUDIOCLK pin (CS43131 CLKOUT). The DAC's crystal is the
     * only clock the audio path ever sees.                               */
    pclk.PeriphClockSelection = RCC_PERIPHCLK_SAI1 | RCC_PERIPHCLK_ICLK |
                                RCC_PERIPHCLK_SDMMC | RCC_PERIPHCLK_I2C1 |
                                RCC_PERIPHCLK_RTC;
    pclk.Sai1ClockSelection   = RCC_SAI1CLKSOURCE_PIN;
    pclk.IclkClockSelection   = RCC_ICLK_CLKSOURCE_HSI48;   /* USB 48 MHz  */
    pclk.SdmmcClockSelection  = RCC_SDMMCCLKSOURCE_CLK48;   /* = ICLK      */
    pclk.I2c1ClockSelection   = RCC_I2C1CLKSOURCE_HSI;
    pclk.RTCClockSelection    = RCC_RTCCLKSOURCE_LSI;
    if (HAL_RCCEx_PeriphCLKConfig(&pclk) != HAL_OK) Error_Handler();

    /* CRS: trim HSI48 against USB SOF so USB stays in spec without a
     * crystal.                                                           */
    __HAL_RCC_CRS_CLK_ENABLE();
    RCC_CRSInitTypeDef crs = { 0 };
    crs.Prescaler             = RCC_CRS_SYNC_DIV1;
    crs.Source                = RCC_CRS_SYNC_SOURCE_USB;
    crs.Polarity              = RCC_CRS_SYNC_POLARITY_RISING;
    crs.ReloadValue           = __HAL_RCC_CRS_RELOADVALUE_CALCULATE(48000000, 1000);
    crs.ErrorLimitValue       = 34;
    crs.HSI48CalibrationValue = 32;
    HAL_RCCEx_CRSConfig(&crs);
}
