/**
 * @file    stm32u5xx_it.c
 * @brief   Interrupt handlers. Fault handlers reset (a stalled pocket
 *          player is worse than a rebooted one); EXTI lines fan out to
 *          the owning driver. Fault handlers: see diag.c.
 */
#include "stm32u5xx_hal.h"
#include "board.h"
#include "../../app/power.h"

/* ---- faults ------------------------------------------------------------ *
 * NMI / HardFault / MemManage / BusFault / UsageFault / SecureFault live
 * in diag.c: they record PC, LR and the fault registers in .noinit RAM,
 * then reset. The next boot shows the report (Settings > Last reset).    */
void SVC_Handler(void)        { }
void DebugMon_Handler(void)   { }
void PendSV_Handler(void)     { }
/* SysTick_Handler lives in main.c, RTC_IRQHandler in power.c             */

/* ---- EXTI --------------------------------------------------------------- *
 * Buttons are EXTI 0/2/4/12/13 - they only need the flag cleared (actual
 * sampling happens on SysTick) plus the wake flag for power.c. Codec INT
 * (EXTI10, V2), card detect (EXTI5) and the nPM1300 interrupt (EXTI3,
 * PC3) set flags for the main loop.                                       */
static inline void exti_ack(uint32_t pin)
{
    __HAL_GPIO_EXTI_CLEAR_RISING_IT(pin);
    __HAL_GPIO_EXTI_CLEAR_FALLING_IT(pin);
}

volatile bool g_codec_irq_pending;
volatile bool g_sd_cd_changed;

static inline void button_irq(uint32_t pin)
{
    exti_ack(pin);
    g_pwr_wake_flags |= PWR_WAKE_BUTTON;
}

void EXTI0_IRQHandler(void)  { button_irq(BTN_SW4_PIN); }
void EXTI2_IRQHandler(void)  { button_irq(BTN_SW3_PIN); }
void EXTI4_IRQHandler(void)  { button_irq(BTN_SW5_PIN); }
void EXTI12_IRQHandler(void) { button_irq(BTN_SW1_PIN); }
void EXTI13_IRQHandler(void) { button_irq(BTN_SW2_PIN); }

void EXTI5_IRQHandler(void)
{
    exti_ack(SD_CD_PIN);
    g_sd_cd_changed = true;
}

#if BOARD_PC3_PMIC_IRQ
/* nPM1300 GPIO0 interrupt (VBUS plugged / removed). Level stays high until
 * the events are cleared over I2C - done in thread context.              */
void EXTI3_IRQHandler(void)
{
    exti_ack(PMIC_IRQ_PIN);
    g_pmic_irq_pending = true;
    g_pwr_wake_flags |= PWR_WAKE_PMIC;
}
#endif

void EXTI10_IRQHandler(void)
{
    exti_ack(CODEC_INT_PIN);
    g_codec_irq_pending = true;
    g_pwr_wake_flags |= PWR_WAKE_CODEC;
}

/* ---- DMA / SAI ----------------------------------------------------------- */
void sai_dma_irq(void);
void GPDMA1_Channel0_IRQHandler(void) { sai_dma_irq(); }

/* ---- USB ------------------------------------------------------------------ *
 * STM32U575 uses the OTG-FS (DWC2) controller.                            */
void dcd_int_handler(uint8_t rhport);      /* TinyUSB: tud_int_handler()  */
void OTG_FS_IRQHandler(void) { dcd_int_handler(0); }
