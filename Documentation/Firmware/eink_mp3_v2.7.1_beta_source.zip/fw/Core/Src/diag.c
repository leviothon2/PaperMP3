/**
 * @file    diag.c
 * @brief   Reset diagnostics (see diag.h).
 */
#include "diag.h"
#include "stm32u5xx_hal.h"
#include "ff.h"

#include <stdio.h>
#include <string.h>

#define REC_MAGIC    0xD1A6C0DEu
#define ALIVE_MAGIC  0xA11FE5EDu

/* Written just before a deliberate or fault reset.                       */
typedef struct {
    uint32_t magic;
    uint32_t kind;
    uint32_t fault_type;
    uint32_t pc, lr, cfsr, hfsr, addr;
    uint32_t step;
    uint32_t uptime_ms;
    uint32_t xpsr;               /* stacked xPSR: bits 8:0 = exception no. */
    uint32_t exc_return;         /* LR on entry to the fault handler        */
    uint32_t sp, r0, r1, r2, r3, r12;   /* v2.4.5: faulting frame          */
    uint32_t check;
} rec_t;

static rec_t             s_rec   __attribute__((section(".noinit")));
static volatile uint32_t s_alive __attribute__((section(".noinit")));
static volatile uint32_t s_boots __attribute__((section(".noinit")));
static volatile uint32_t s_logged __attribute__((section(".noinit")));
volatile uint32_t        g_diag_step __attribute__((section(".noinit")));

static diag_info_t s_info;

static uint32_t rec_check(const rec_t *r)
{
    return r->magic ^ r->kind ^ r->fault_type ^ r->pc ^ r->lr ^ r->cfsr ^
           r->hfsr ^ r->addr ^ r->step ^ r->uptime_ms ^ r->xpsr ^
           r->exc_return ^ r->sp ^ r->r0 ^ r->r1 ^ r->r2 ^ r->r3 ^
           r->r12 ^ 0x5A5A5A5Bu;
}

static void rec_commit(void)
{
    s_rec.magic = REC_MAGIC;
    s_rec.check = rec_check(&s_rec);
    __DSB();
}

void diag_boot(void)
{
    uint32_t csr = RCC->CSR;
    RCC->CSR |= RCC_CSR_RMVF;                   /* clear for next time     */

    bool ram_kept = (s_alive == ALIVE_MAGIC);
    bool rec_ok   = ram_kept && s_rec.magic == REC_MAGIC &&
                    s_rec.check == rec_check(&s_rec);

    memset(&s_info, 0, sizeof s_info);
    s_info.csr = csr;
    s_info.boot_count = ram_kept ? s_boots + 1u : 1u;

    if (rec_ok) {
        s_info.kind       = (diag_reset_t)s_rec.kind;
        s_info.fault_type = (uint8_t)s_rec.fault_type;
        s_info.pc   = s_rec.pc;   s_info.lr   = s_rec.lr;
        s_info.cfsr = s_rec.cfsr; s_info.hfsr = s_rec.hfsr;
        s_info.addr = s_rec.addr;
        s_info.step = (diag_step_t)s_rec.step;
        s_info.uptime_ms = s_rec.uptime_ms;
        s_info.xpsr = s_rec.xpsr;
        s_info.exc_return = s_rec.exc_return;
        s_info.sp = s_rec.sp;
        s_info.r0 = s_rec.r0; s_info.r1 = s_rec.r1; s_info.r2 = s_rec.r2;
        s_info.r3 = s_rec.r3; s_info.r12 = s_rec.r12;
    } else if (csr & (RCC_CSR_IWDGRSTF | RCC_CSR_WWDGRSTF)) {
        s_info.kind = DIAG_RESET_WATCHDOG;
    } else if (csr & RCC_CSR_BORRSTF) {
        /* BOR is also set by a real power-up; RAM surviving tells them
         * apart: a full power loss scrambles the alive word.             */
        s_info.kind = ram_kept ? DIAG_RESET_BROWNOUT : DIAG_RESET_POWER_ON;
    } else if (csr & RCC_CSR_SFTRSTF) {
        s_info.kind = DIAG_RESET_SOFTWARE;
    } else if (csr & RCC_CSR_PINRSTF) {
        s_info.kind = ram_kept ? DIAG_RESET_PIN : DIAG_RESET_POWER_ON;
    } else {
        s_info.kind = DIAG_RESET_POWER_ON;
    }
    if (!rec_ok && ram_kept && g_diag_step < STEP_COUNT)
        s_info.step = (diag_step_t)g_diag_step;

    if (!ram_kept) s_logged = 0;
    s_rec.magic = 0;
    s_alive = ALIVE_MAGIC;
    s_boots = s_info.boot_count;
    g_diag_step = STEP_BOOT;

    /* Separate MemManage / Bus / Usage handlers: the report then names
     * the fault class directly instead of everything being a HardFault. */
    SCB->SHCSR |= SCB_SHCSR_MEMFAULTENA_Msk | SCB_SHCSR_BUSFAULTENA_Msk |
                  SCB_SHCSR_USGFAULTENA_Msk;
}

const diag_info_t *diag_info(void) { return &s_info; }

bool diag_abnormal(void)
{
    switch (s_info.kind) {
    case DIAG_RESET_FAULT:
    case DIAG_RESET_ERROR:
    case DIAG_RESET_BROWNOUT:
    case DIAG_RESET_PIN:
    case DIAG_RESET_WATCHDOG:
        return true;
    default:
        return false;
    }
}

static const char *const k_steps[STEP_COUNT] = {
    [STEP_NONE]             = "-",
    [STEP_BOOT]             = "boot",
    [STEP_LOOP_INPUT]       = "buttons",
    [STEP_LOOP_USB]         = "usb poll",
    [STEP_LOOP_PLAYER]      = "decode loop",
    [STEP_LOOP_UI]          = "ui",
    [STEP_LOOP_POWER]       = "power poll",
    [STEP_UI_DRAW]          = "drawing",
    [STEP_EINK_FULL]        = "full refresh",
    [STEP_EINK_PARTIAL]     = "partial refresh",
    [STEP_USB_PROMPT]       = "usb prompt",
    [STEP_USB_ENTER_MSC]    = "usb storage start",
    [STEP_USB_ENTER_DAC]    = "usb dac start",
    [STEP_USB_ENTER_CHARGE] = "charge-only start",
    [STEP_USB_TASK]         = "usb stack",
    [STEP_USB_LEAVE]        = "usb detach",
    [STEP_PLAYLIST_OPEN]    = "playlist open",
    [STEP_PLAYLIST_SCAN]    = "music scan",
    [STEP_TRACK_TAGS]       = "tags/art",
    [STEP_TRACK_OPEN]       = "track open",
    [STEP_AUDIO_START]      = "audio start",
    [STEP_DECODE]           = "decoding",
    [STEP_SD_MOUNT]         = "sd mount",
    [STEP_SETTINGS_WRITE]   = "settings write",
    [STEP_SLEEP]            = "sleep entry",
    [STEP_WAKE]             = "wake",
    [STEP_EINK_WAKE]        = "panel re-init",
    [STEP_EINK_FULL_WAIT]   = "full waveform",
    [STEP_EINK_PART_WAIT]   = "partial waveform",
    [STEP_SD_LOG]           = "crash-log write",
};

const char *diag_step_name(diag_step_t s)
{
    return (s < STEP_COUNT && k_steps[s]) ? k_steps[s] : "?";
}

static const char *fault_name(uint8_t t)
{
    static const char *const n[] = { "Fault", "HardFault", "MemFault",
                                     "BusFault", "UsageFault", "SecureFault",
                                     "NMI" };
    return t < sizeof n / sizeof n[0] ? n[t] : "Fault";
}

void diag_summary(char *buf, int len)
{
    const diag_info_t *d = &s_info;
    switch (d->kind) {
    case DIAG_RESET_FAULT:
        snprintf(buf, len, "%s @%08lX", fault_name(d->fault_type),
                 (unsigned long)d->pc);
        break;
    case DIAG_RESET_ERROR:    snprintf(buf, len, "Init error @%08lX", (unsigned long)d->lr); break;
    case DIAG_RESET_BROWNOUT: snprintf(buf, len, "Brownout (1.8V dip)"); break;
    case DIAG_RESET_PIN:      snprintf(buf, len, "Reset pin (NRST)");    break;
    case DIAG_RESET_WATCHDOG: snprintf(buf, len, "Watchdog");            break;
    case DIAG_RESET_CHORD:    snprintf(buf, len, "Button reset");        break;
    case DIAG_RESET_DFU:      snprintf(buf, len, "After USB update");    break;
    case DIAG_RESET_SOFTWARE: snprintf(buf, len, "Software restart");    break;
    default:                  snprintf(buf, len, "Power on");            break;
    }
}

void diag_note_reset(diag_reset_t kind)
{
    memset(&s_rec, 0, sizeof s_rec);
    s_rec.kind = kind;
    s_rec.step = g_diag_step;
    s_rec.lr   = (uint32_t)__builtin_return_address(0);
    s_rec.uptime_ms = HAL_GetTick();
    rec_commit();
}

/* ---- fault capture --------------------------------------------------------
 * Each handler hands the stacked exception frame (MSP or PSP, chosen by
 * EXC_RETURN bit 2) to diag_fault_entry(). The frame is only read if the
 * stack pointer is inside RAM, so a blown stack can't fault again here.  */
void diag_fault_entry(uint32_t *sp, uint32_t type, uint32_t exc_return);

void diag_fault_entry(uint32_t *sp, uint32_t type, uint32_t exc_return)
{
    memset(&s_rec, 0, sizeof s_rec);
    s_rec.kind       = DIAG_RESET_FAULT;
    s_rec.fault_type = type;
    uint32_t a = (uint32_t)sp;
    s_rec.sp = a;
    if (a >= 0x20000000u && a + 32u <= 0x200C0000u) {
        s_rec.r0   = sp[0]; s_rec.r1 = sp[1]; s_rec.r2 = sp[2];
        s_rec.r3   = sp[3]; s_rec.r12 = sp[4];
        s_rec.lr   = sp[5];
        s_rec.pc   = sp[6];
        s_rec.xpsr = sp[7];
    }
    s_rec.exc_return = exc_return;
    s_rec.cfsr = SCB->CFSR;
    s_rec.hfsr = SCB->HFSR;
    s_rec.addr = (SCB->CFSR & SCB_CFSR_BFARVALID_Msk)  ? SCB->BFAR :
                 (SCB->CFSR & SCB_CFSR_MMARVALID_Msk)  ? SCB->MMFAR : 0u;
    s_rec.step = g_diag_step;
    s_rec.uptime_ms = uwTick;
    rec_commit();
    NVIC_SystemReset();
}

#define FAULT_STUB(name, type)                                          \
    __attribute__((naked)) void name(void)                              \
    {                                                                   \
        __asm volatile(                                                 \
            "tst   lr, #4          \n"                                  \
            "ite   eq              \n"                                  \
            "mrseq r0, msp         \n"                                  \
            "mrsne r0, psp         \n"                                  \
            "movs  r1, #" #type "  \n"                                  \
            "mov   r2, lr          \n"                                  \
            "b     diag_fault_entry\n");                                \
    }

FAULT_STUB(HardFault_Handler,   1)
FAULT_STUB(MemManage_Handler,   2)
FAULT_STUB(BusFault_Handler,    3)
FAULT_STUB(UsageFault_Handler,  4)
FAULT_STUB(SecureFault_Handler, 5)

/* 2.7.0 (display test dt-0.2.0): the settings page (last 8 KB of a bank, app/flash_store.c) is written in place. A
 * reset or brown-out in the middle of a quadword program leaves a double ECC error there, and reading
 * it raises an NMI. Such an NMI is acknowledged and counted (flash_store.c checks the counter around
 * every record read and treats the record as damaged); any other NMI is a fault as before.        */
volatile uint32_t g_flash_ecc_nmi;
int diag_nmi_flash_ecc(void);
int diag_nmi_flash_ecc(void)
{
    uint32_t e = FLASH->ECCR;
    if (!(e & FLASH_ECCR_ECCD) || (e & FLASH_ECCR_ADDR_ECC) < 0x7E000u) return 0;
    FLASH->ECCR = e;                    /* ECCD/ECCC are write-1-to-clear */
    g_flash_ecc_nmi++;
    return 1;
}

__attribute__((naked)) void NMI_Handler(void)
{
    __asm volatile(
        "push  {r0, lr}        \n"
        "bl    diag_nmi_flash_ecc\n"
        "mov   r12, r0         \n"
        "pop   {r0, lr}        \n"
        "cmp   r12, #0         \n"
        "it    ne              \n"
        "bxne  lr              \n"
        "tst   lr, #4          \n"
        "ite   eq              \n"
        "mrseq r0, msp         \n"
        "mrsne r0, psp         \n"
        "movs  r1, #6          \n"
        "mov   r2, lr          \n"
        "b     diag_fault_entry\n");
}

/* ---- SD log ----------------------------------------------------------------- */

/* Only abnormal resets (fault, Error_Handler, brownout, reset pin,
 * watchdog) are logged - 2.5.0 no longer writes a line on every boot.
 * The line is formatted with snprintf into a static buffer and written
 * with ONE f_write (2.4.4's FatFs f_printf() path boot-looped). Also:
 *  - a breadcrumb (STEP_SD_LOG) marks the write; if the previous run died
 *    in it, this boot skips the log instead of looping,
 *  - the file is rotated to crashlog.old above 32 KB.                    */
#define LOG_ROTATE_BYTES  (32u * 1024u)

void diag_log_to_sd(void)
{
    if (!diag_abnormal() || s_logged == s_info.boot_count) return;
    static bool done;
    if (done) return;
    done = true;                                /* never retry in one run  */

    if (s_info.kind == DIAG_RESET_FAULT && s_info.step == STEP_SD_LOG) {
        s_logged = s_info.boot_count;           /* break the loop          */
        return;
    }

    static char line[400];
    char sum[40];
    diag_summary(sum, sizeof sum);
    const diag_info_t *d = &s_info;
    int n = snprintf(line, sizeof line,
        "boot %lu: %s | step=%s pc=%08lX lr=%08lX cfsr=%08lX hfsr=%08lX "
        "addr=%08lX up=%lums csr=%08lX exc=%lu xpsr=%08lX excret=%08lX "
        "sp=%08lX r0=%08lX r1=%08lX r2=%08lX r3=%08lX r12=%08lX fw=%s\n",
        (unsigned long)d->boot_count, sum, diag_step_name(d->step),
        (unsigned long)d->pc, (unsigned long)d->lr, (unsigned long)d->cfsr,
        (unsigned long)d->hfsr, (unsigned long)d->addr,
        (unsigned long)d->uptime_ms, (unsigned long)d->csr,
        (unsigned long)(d->xpsr & 0x1FFu), (unsigned long)d->xpsr,
        (unsigned long)d->exc_return, (unsigned long)d->sp,
        (unsigned long)d->r0, (unsigned long)d->r1, (unsigned long)d->r2,
        (unsigned long)d->r3, (unsigned long)d->r12, FW_VERSION);
    if (n <= 0) return;
    if (n >= (int)sizeof line) n = (int)sizeof line - 1;

    uint32_t prev_step = g_diag_step;
    diag_step(STEP_SD_LOG);

    static FIL f;                               /* off the stack           */
    if (f_open(&f, "0:/crashlog.txt", FA_WRITE | FA_OPEN_APPEND) == FR_OK) {
        if (f_size(&f) > LOG_ROTATE_BYTES) {
            f_close(&f);
            f_unlink("0:/crashlog.old");
            f_rename("0:/crashlog.txt", "0:/crashlog.old");
            if (f_open(&f, "0:/crashlog.txt", FA_WRITE | FA_CREATE_ALWAYS) != FR_OK)
                goto out;
        }
        UINT bw = 0;
        FRESULT wr = f_write(&f, line, (UINT)n, &bw);
        if (f_close(&f) == FR_OK && wr == FR_OK && bw == (UINT)n)
            s_logged = s_info.boot_count;
    }
out:
    g_diag_step = prev_step;
}
