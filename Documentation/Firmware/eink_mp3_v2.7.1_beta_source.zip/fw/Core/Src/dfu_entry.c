/**
 * @file    dfu_entry.c
 * @brief   Software entry into the STM32U5 ROM bootloader (USB DFU).
 *
 * Jumping from a running application is fragile (clocks, IRQs, DMA, USB
 * already configured), so instead the request survives a system reset in
 * a RAM word the startup code never touches, and the jump happens before
 * HAL_Init() while every peripheral is still at its reset value.
 */
#include "dfu_entry.h"
#include "board.h"
#include "stm32u5xx.h"

#define DFU_MAGIC        0xDF0B0071u
#define SYSMEM_BASE      0x0BF90000u     /* STM32U575/585 system memory   */

/* .noinit: placed by the linker script outside .bss/.data, so neither the
 * startup code nor a system reset changes it (SRAM1 keeps its content
 * across a system reset).                                                */
static volatile uint32_t s_dfu_magic __attribute__((section(".noinit")));

void dfu_reboot_to_bootloader(void)
{
    s_dfu_magic = DFU_MAGIC;
    __DSB();
    NVIC_SystemReset();
}

void dfu_check_and_jump(void)
{
    if (s_dfu_magic != DFU_MAGIC) return;
    s_dfu_magic = 0;                     /* one shot: next reset = app    */

    /* VDDUSB is the switched 3.3 V rail. After a reset the PMIC keeps
     * BUCK2 on in the default (PMIC-IRQ) wiring; in the pin-control
     * variant PC3 must be driven high again or the rail drops.           */
#if !BOARD_PC3_PMIC_IRQ
    RCC->AHB2ENR1 |= RCC_AHB2ENR1_GPIOCEN;
    (void)RCC->AHB2ENR1;
    GPIOC->BSRR = GPIO_BSRR_BS3;
    GPIOC->MODER = (GPIOC->MODER & ~GPIO_MODER_MODE3) | GPIO_MODER_MODE3_0;
#endif
    /* Declare VDDUSB valid (removes the USB isolation).                  */
    RCC->AHB3ENR |= RCC_AHB3ENR_PWREN;
    (void)RCC->AHB3ENR;
    PWR->SVMCR |= PWR_SVMCR_USV;

    __disable_irq();
    SysTick->CTRL = 0;
    for (unsigned i = 0; i < sizeof NVIC->ICER / sizeof NVIC->ICER[0]; i++) {
        NVIC->ICER[i] = 0xFFFFFFFFu;
        NVIC->ICPR[i] = 0xFFFFFFFFu;
    }
    __enable_irq();

    const uint32_t *vt = (const uint32_t *)SYSMEM_BASE;
    SCB->VTOR = SYSMEM_BASE;
    __set_MSP(vt[0]);
    ((void (*)(void))vt[1])();
    for (;;) { }
}
