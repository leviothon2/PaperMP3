/**
 * @file    syscalls.c
 * @brief   Minimal newlib-nano system calls for a bare-metal build.
 *
 * Only _sbrk does real work: malloc() (dr_flac, Helix AAC, minimp4) gets
 * the region [_sheap, _eheap) reserved by the linker script, and fails
 * cleanly (NULL) instead of growing into the stack. The rest are stubs so
 * the image links without nosys.specs' "not implemented" warnings.
 */
#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/stat.h>

extern uint8_t _sheap[], _eheap[];

void *_sbrk(ptrdiff_t incr)
{
    static uint8_t *brk = _sheap;
    if (brk + incr > _eheap || brk + incr < _sheap) {
        errno = ENOMEM;
        return (void *)-1;
    }
    uint8_t *prev = brk;
    brk += incr;
    return prev;
}

int  _close(int fd)                       { (void)fd; return -1; }
int  _fstat(int fd, struct stat *st)      { (void)fd; st->st_mode = S_IFCHR; return 0; }
int  _isatty(int fd)                      { (void)fd; return 1; }
int  _lseek(int fd, int p, int d)         { (void)fd; (void)p; (void)d; return 0; }
int  _read(int fd, char *b, int n)        { (void)fd; (void)b; (void)n; return 0; }
int  _write(int fd, const char *b, int n) { (void)fd; (void)b; return n; }
int  _getpid(void)                        { return 1; }
int  _kill(int pid, int sig)              { (void)pid; (void)sig; errno = EINVAL; return -1; }
void _exit(int status)                    { (void)status; for (;;) { } }
