/**
 * @file    diag.h
 * @brief   Reset diagnostics: why did the player last restart?
 *
 * A small record in .noinit RAM survives every reset that does not drop
 * the 1.8 V rail completely. On the next boot diag_boot() combines it with
 * the RCC reset flags and reports one of:
 *   - a CPU fault (HardFault / BusFault / ...) with the faulting PC, LR,
 *     fault-status registers and the last "step" the firmware was in,
 *   - Error_Handler(), a button-chord reset, a firmware-update restart,
 *   - a BROWNOUT: the BOR flag is set but RAM was retained, i.e. the 1.8 V
 *     rail dipped below the BOR threshold (~1.7 V) without collapsing -
 *     the classic signature of a supply that can't deliver a load step,
 *   - the reset pin (NRST: debugger, or something on the board pulling it),
 *   - a plain power-on.
 * 2.5.0: nothing is shown on screen any more; abnormal resets are
 * appended silently to /crashlog.txt on the SD card.
 */
#ifndef DIAG_H
#define DIAG_H

#include <stdbool.h>
#include <stdint.h>

/* What the firmware was doing ("breadcrumb"). Cheap: one RAM store.     */
typedef enum {
    STEP_NONE = 0,
    STEP_BOOT,
    STEP_LOOP_INPUT,
    STEP_LOOP_USB,
    STEP_LOOP_PLAYER,
    STEP_LOOP_UI,
    STEP_LOOP_POWER,
    STEP_UI_DRAW,
    STEP_EINK_FULL,
    STEP_EINK_PARTIAL,
    STEP_USB_PROMPT,
    STEP_USB_ENTER_MSC,
    STEP_USB_ENTER_DAC,
    STEP_USB_ENTER_CHARGE,
    STEP_USB_TASK,
    STEP_USB_LEAVE,
    STEP_PLAYLIST_OPEN,
    STEP_PLAYLIST_SCAN,
    STEP_TRACK_TAGS,
    STEP_TRACK_OPEN,
    STEP_AUDIO_START,
    STEP_DECODE,
    STEP_SD_MOUNT,
    STEP_SETTINGS_WRITE,
    STEP_SLEEP,
    STEP_WAKE,
    STEP_EINK_WAKE,             /* panel HW reset + init after deep sleep */
    STEP_EINK_FULL_WAIT,        /* full waveform running (BUSY high)      */
    STEP_EINK_PART_WAIT,        /* partial waveform running               */
    STEP_SD_LOG,                /* appending to /crashlog.txt (v2.4.5)    */
    STEP_COUNT
} diag_step_t;

typedef enum {
    DIAG_RESET_POWER_ON = 0,    /* normal                                  */
    DIAG_RESET_SOFTWARE,        /* deliberate (settings, update ...)       */
    DIAG_RESET_DFU,             /* firmware-update restart                 */
    DIAG_RESET_CHORD,           /* vol- + vol+ held 5 s                    */
    DIAG_RESET_FAULT,           /* CPU fault, see fault fields             */
    DIAG_RESET_ERROR,           /* Error_Handler()                         */
    DIAG_RESET_BROWNOUT,        /* BOR with RAM retained                   */
    DIAG_RESET_PIN,             /* NRST pulled externally                  */
    DIAG_RESET_WATCHDOG,
} diag_reset_t;

typedef struct {
    diag_reset_t kind;
    uint8_t  fault_type;        /* 1 Hard 2 MemManage 3 Bus 4 Usage 5 Secure 6 NMI */
    uint32_t pc, lr, cfsr, hfsr, addr;
    diag_step_t step;           /* breadcrumb when it happened (if known)  */
    uint32_t uptime_ms;         /* how long the previous run lasted        */
    uint32_t csr;               /* raw RCC->CSR                            */
    uint32_t boot_count;        /* boots since power-on (RAM retained)     */
    uint32_t xpsr;              /* faulting context's xPSR; bits 8:0 = the
                                   exception it was in (15 SysTick, 16+n
                                   IRQ n, 0 = thread)                      */
    uint32_t exc_return;
    uint32_t sp;                /* stack pointer at the fault (v2.4.5)     */
    uint32_t r0, r1, r2, r3, r12;   /* stacked registers at the fault      */
} diag_info_t;

void diag_boot(void);                     /* first thing in main()        */
const diag_info_t *diag_info(void);
bool diag_abnormal(void);                 /* worth showing to the user    */
const char *diag_step_name(diag_step_t s);
/* One short line ("HardFault @0800A1C4") and a longer reason.           */
void diag_summary(char *buf, int len);

extern volatile uint32_t g_diag_step;    /* current breadcrumb (.noinit) */

static inline void diag_step(diag_step_t s) { g_diag_step = (uint32_t)s; }

/* Record why we are about to reset on purpose (caller then resets).     */
void diag_note_reset(diag_reset_t kind);

/* Append this boot's reset cause to /crashlog.txt (FatFs mounted), only
 * if it was abnormal (see diag_abnormal).                                */
void diag_log_to_sd(void);

/* 2.7.0 (display test dt-0.2.0): double-ECC NMIs taken on the settings page
 * and acknowledged (see diag.c, app/flash_store.c).                      */
extern volatile uint32_t g_flash_ecc_nmi;

#endif /* DIAG_H */
