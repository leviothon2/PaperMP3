/**
 * @file    stm32u5xx_hal_conf.h
 * @brief   HAL configuration - modules trimmed to what this firmware uses.
 *          (Derived from the Cube template; unusual values commented.)
 */
#ifndef STM32U5xx_HAL_CONF_H
#define STM32U5xx_HAL_CONF_H

#define HAL_MODULE_ENABLED
#define HAL_CORTEX_MODULE_ENABLED
#define HAL_RCC_MODULE_ENABLED
#define HAL_PWR_MODULE_ENABLED
#define HAL_GPIO_MODULE_ENABLED
#define HAL_DMA_MODULE_ENABLED
#define HAL_EXTI_MODULE_ENABLED
#define HAL_FLASH_MODULE_ENABLED
#define HAL_I2C_MODULE_ENABLED
#define HAL_SPI_MODULE_ENABLED
#define HAL_SAI_MODULE_ENABLED
#define HAL_SD_MODULE_ENABLED
#define HAL_RTC_MODULE_ENABLED

/* Oscillator values: no HSE fitted (see system_clock.c).                 */
#define HSE_VALUE            0UL
#define HSE_STARTUP_TIMEOUT  100UL
#define HSI_VALUE            16000000UL
#define HSI48_VALUE          48000000UL
#define MSI_VALUE            4000000UL
#define LSE_VALUE            32768UL
#define LSE_STARTUP_TIMEOUT  5000UL
#define LSI_VALUE            32000UL
#define EXTERNAL_SAI1_CLOCK_VALUE 11289600UL  /* CS43131 CLKOUT on PA0    */

#define VDD_VALUE            1800UL           /* 1.8 V rail               */
#define TICK_INT_PRIORITY    0UL              /* SysTick samples buttons  */
#define USE_RTOS             0U
#define PREFETCH_ENABLE      1U

#define USE_HAL_SD_REGISTER_CALLBACKS  0U
#define USE_HAL_SAI_REGISTER_CALLBACKS 0U

#define assert_param(expr) ((void)0U)

/* Module headers (order matters).                                        */
#ifdef HAL_RCC_MODULE_ENABLED
#include "stm32u5xx_hal_rcc.h"
#endif
#ifdef HAL_GPIO_MODULE_ENABLED
#include "stm32u5xx_hal_gpio.h"
#endif
#ifdef HAL_DMA_MODULE_ENABLED
#include "stm32u5xx_hal_dma.h"
#endif
#ifdef HAL_CORTEX_MODULE_ENABLED
#include "stm32u5xx_hal_cortex.h"
#endif
#ifdef HAL_PWR_MODULE_ENABLED
#include "stm32u5xx_hal_pwr.h"
#endif
#ifdef HAL_FLASH_MODULE_ENABLED
#include "stm32u5xx_hal_flash.h"
#endif
#ifdef HAL_EXTI_MODULE_ENABLED
#include "stm32u5xx_hal_exti.h"
#endif
#ifdef HAL_I2C_MODULE_ENABLED
#include "stm32u5xx_hal_i2c.h"
#endif
#ifdef HAL_SPI_MODULE_ENABLED
#include "stm32u5xx_hal_spi.h"
#endif
#ifdef HAL_SAI_MODULE_ENABLED
#include "stm32u5xx_hal_sai.h"
#endif
#ifdef HAL_SD_MODULE_ENABLED
#include "stm32u5xx_hal_sd.h"
#endif
#ifdef HAL_RTC_MODULE_ENABLED
#include "stm32u5xx_hal_rtc.h"
#endif

void Error_Handler(void);

#endif /* STM32U5xx_HAL_CONF_H */
