/**
 * @file    board.h
 * @brief   Board definition for the e-ink MP3 player (STM32U575RGT6, LQFP64).
 *
 * Single source of truth for every pin, rail and board-level constant.
 * Matches "Schematic1 V2" (MP3 mainboard V2, 2026-10-06).
 *
 * Power domains:
 *   - MCU VDD/VDDA/VBAT   : 1.8 V (nPM1300 BUCK1, always on)
 *   - +3.3 V rail         : nPM1300 BUCK2 - SWITCHED. Enable = nPM1300 GPIO0,
 *                           driven by MCU PC3 (net GPIO0). Feeds VDDUSB, the
 *                           microSD card (+TXS02612 B side) and the e-ink
 *                           module (+TXB0106 B side). Turned off in sleep.
 *   - microSD card        : 3.3 V behind TXS02612 level shifter (A side 1.8 V)
 *   - e-ink logic         : 3.3 V behind TXB0106 (OE = PA3, 330k pull-down)
 *   - CS43131 digital     : 1.8 V (direct connection, no shifting)
 *   - CS43131 VA/VCP      : V_AMP from TPS7A20 LDO on VCC (always on)
 *
 * Clocking (see system_clock.c):
 *   - No HSE crystal. Core runs from HSI16 x PLL1 = 160 MHz.
 *   - HSI48 + CRS (USB SOF sync) feeds USB-FS and SDMMC kernel.
 *   - NO LSE on V2 (PC14/PC15 unconnected): the RTC runs from LSI and is
 *     only used as the sleep-mode wake-up timer.
 *   - Audio: 22.5792 MHz crystal is on the CS43131 (the DAC is the audio
 *     clock master). Its CLKOUT (= MCLK/2 = 11.2896 MHz) enters PA0 and is
 *     selected as the SAI1 kernel clock (AUDIOCLK) so SAI timing is always
 *     crystal-derived, never MCU-PLL-derived.
 */
#ifndef BOARD_H
#define BOARD_H

#include "stm32u5xx.h"

/* ------------------------------------------------------------------ *
 *  Rails / fixed hardware facts
 * ------------------------------------------------------------------ */
#define BOARD_VDD_MV               1800u       /* VSET1 resistor (47k)   */
/* v2.4: BUCK1 is raised in software at boot to this value. 1.9 V is the
 * nPM1300 step (100 mV) closest to 2.0 V that keeps the CS43131's 1.8 V
 * supplies (VD/VL/VA/VCP, recommended max 1.94 V) in spec; the STM32
 * (1.71-3.6 V), TXB0106/TXS02612 A sides and the nPM1300 VDDIO are fine
 * either way. It moves the rail 200 mV above the MCU's BOR (~1.7 V).   */
#define BOARD_VDD_BOOST_MV         1900u
#define BOARD_AUDIO_XTAL_HZ        22579200u   /* on CS43131 XTI/XTO      */
#define BOARD_AUDIO_CLKOUT_HZ      11289600u   /* CS43131 CLKOUT = MCLK/2 */

/* ------------------------------------------------------------------ *
 *  E-ink panel: WeAct 1.54" 200x200, SSD1681 controller, 4-wire SPI,
 *  through a TXB0106 (A = 1.8 V MCU side, B = switched 3.3 V rail).
 *  (Confirmed over the 2.13" symbol on the schematic.)
 * ------------------------------------------------------------------ */
#define EINK_WIDTH                 200u
#define EINK_HEIGHT                200u
#define EINK_SPI                   SPI1
#define EINK_SPI_AF                GPIO_AF5_SPI1

#define EINK_SCK_PORT              GPIOA        /* net SCL_1  */
#define EINK_SCK_PIN               GPIO_PIN_5
#define EINK_MOSI_PORT             GPIOA        /* net SDA_1  */
#define EINK_MOSI_PIN              GPIO_PIN_7
#define EINK_CS_PORT               GPIOA        /* net CS     */
#define EINK_CS_PIN                GPIO_PIN_4
#define EINK_DC_PORT               GPIOA        /* net D/C    */
#define EINK_DC_PIN                GPIO_PIN_6
#define EINK_RES_PORT              GPIOA        /* net RES - keep LOW until init */
#define EINK_RES_PIN               GPIO_PIN_2
#define EINK_BUSY_PORT             GPIOA        /* net BUSY (10k series) - polled */
#define EINK_BUSY_PIN              GPIO_PIN_1
#define EINK_OE_PORT               GPIOA        /* net OE: TXB0106 output enable */
#define EINK_OE_PIN                GPIO_PIN_3   /* 330k pull-down = off by default */

/* ------------------------------------------------------------------ *
 *  CS43131 DAC / headphone amp - SAI1 block A, 1.8 V direct
 *  The DAC is always the I2S master (SCLK1/LRCK1 out of the DAC); SAI1-A
 *  is a slave transmitter. V2 leaves the DAC's native DSD port (DSDA/
 *  DSDB/DSDCLK) unconnected, so DSD files are sent as DoP (DSD-over-PCM)
 *  on this same I2S link - see audio/dsd.c + drivers/cs43131.c.
 * ------------------------------------------------------------------ */
#define CODEC_SAI                  SAI1
#define CODEC_SAI_BLOCK_A          SAI1_Block_A

#define CODEC_CLKOUT_PORT          GPIOA        /* net CLK_O -> SAI1_EXTCLK */
#define CODEC_CLKOUT_PIN           GPIO_PIN_0   /* AF13                    */
#define CODEC_BCLK_PORT            GPIOA        /* net I2S_CK (SCLK1)      */
#define CODEC_BCLK_PIN             GPIO_PIN_8   /* SAI1_SCK_A, AF13        */
#define CODEC_LRCK_PORT            GPIOA        /* net I2S_WS (LRCK1)      */
#define CODEC_LRCK_PIN             GPIO_PIN_9   /* SAI1_FS_A, AF13         */
#define CODEC_SDOUT_PORT           GPIOA        /* net I2S_SD (SDIN1)      */
#define CODEC_SDOUT_PIN            GPIO_PIN_10  /* SAI1_SD_A, AF13         */

#define CODEC_SAI_AF               GPIO_AF13_SAI1

#define CODEC_RST_PORT             GPIOB        /* net RST - 10k pull-down */
#define CODEC_RST_PIN              GPIO_PIN_0
#define CODEC_INT_PORT             GPIOB        /* net INT - open drain; V2 has NO external
                                                 * pull-up: 2.7.1 enables the internal one */
#define CODEC_INT_PIN              GPIO_PIN_10  /* EXTI10 (V2: was PB1)    */
#define CODEC_INT_EXTI_IRQn        EXTI10_IRQn
/* Jack PJ-3401: HP_DETECT (codec pin 22) -> jack pin 6, pin 5 -> GND.
 * The codec expects LOW = plug in. If this jack's 6-5 switch turns out
 * to be closed with NO plug (detection reads backwards), set this to 1:
 * it sets HPDETECT_INV in the codec.                                     */
#define BOARD_HPDETECT_INVERT      0

/* CS43131 I2C address: ADR strapped to GND -> low bits 00 (see cs43131.h) */

/* ------------------------------------------------------------------ *
 *  I2C1 control bus (CS43131 + nPM1300), 1.8 V, external pull-ups
 * ------------------------------------------------------------------ */
#define CTRL_I2C                   I2C1
#define CTRL_I2C_AF                GPIO_AF4_I2C1
#define CTRL_SCL_PORT              GPIOB
#define CTRL_SCL_PIN               GPIO_PIN_8
#define CTRL_SDA_PORT              GPIOB
#define CTRL_SDA_PIN               GPIO_PIN_9

/* ------------------------------------------------------------------ *
 *  microSD - SDMMC1 4-bit through TXS02612
 *  No external pull-ups needed and the MCU internal SDMMC pull-ups must
 *  stay OFF: the TXS02612 integrates the bus pull-ups on both sides.
 * ------------------------------------------------------------------ */
#define SD_CLK_PORT                GPIOC
#define SD_CLK_PIN                 GPIO_PIN_12  /* SDMMC1_CK,  AF12 */
#define SD_CMD_PORT                GPIOD
#define SD_CMD_PIN                 GPIO_PIN_2   /* SDMMC1_CMD, AF12 */
#define SD_D0_PORT                 GPIOC
#define SD_D0_PIN                  GPIO_PIN_8
#define SD_D1_PORT                 GPIOC
#define SD_D1_PIN                  GPIO_PIN_9
#define SD_D2_PORT                 GPIOC
#define SD_D2_PIN                  GPIO_PIN_10
#define SD_D3_PORT                 GPIOC
#define SD_D3_PIN                  GPIO_PIN_11
#define SD_AF                      GPIO_AF12_SDMMC1

#define SD_CD_PORT                 GPIOC        /* card detect switch, 330k */
#define SD_CD_PIN                  GPIO_PIN_5   /* ext. pull-up to 1.8 V   */
#define SD_CD_EXTI_IRQn            EXTI5_IRQn   /* EXTI5                   */

/* V2: the card has no dedicated LDO any more - it is powered from the
 * switched +3.3 V rail (see PWR_3V3_EN below).                           */

/* ------------------------------------------------------------------ *
 *  Buttons - active LOW, external 47k pull-ups to 1.8 V, FW debounce.
 *  Every button sits on its own EXTI line (no clash with INT=10, CD=5).
 * ------------------------------------------------------------------ */
#define BTN_SW1_PORT               GPIOB        /* play/pause/select */
#define BTN_SW1_PIN                GPIO_PIN_12  /* EXTI12 */
#define BTN_SW2_PORT               GPIOB        /* next / menu down  */
#define BTN_SW2_PIN                GPIO_PIN_13  /* EXTI13 */
#define BTN_SW3_PORT               GPIOC        /* prev / menu up / back */
#define BTN_SW3_PIN                GPIO_PIN_2   /* EXTI2  */
#define BTN_SW4_PORT               GPIOC        /* volume down */
#define BTN_SW4_PIN                GPIO_PIN_0   /* EXTI0  */
#define BTN_SW5_PORT               GPIOC        /* volume up   */
#define BTN_SW5_PIN                GPIO_PIN_4   /* EXTI4  */

/* PH3/BOOT0 has a push button. It is used ONLY to force the ST system
 * bootloader (USB DFU) when held during power-up; the application never
 * reads it. Leave nSWBOOT0 = 1 (BOOT0 pin sampled at reset, the default). */

/* ------------------------------------------------------------------ *
 *  USB-FS (device). CC handled by nPM1300; UCPD unused.
 * ------------------------------------------------------------------ */
#define USB_DM_PORT                GPIOA
#define USB_DM_PIN                 GPIO_PIN_11
#define USB_DP_PORT                GPIOA
#define USB_DP_PIN                 GPIO_PIN_12
#define USB_AF                     GPIO_AF10_USB

/* ------------------------------------------------------------------ *
 *  Power control (V2): the single PC3 <-> nPM1300 GPIO0 wire.
 *
 *  A pin can't be both the PMIC's BUCK2-enable INPUT and the PMIC's
 *  interrupt OUTPUT, and both chips can't drive the net (push-pull
 *  contention). So the wire has one of two roles, chosen here:
 *
 *  BOARD_PC3_PMIC_IRQ = 1  (default)
 *      GPIO0 = nPM1300 interrupt output (active high) -> PC3 = EXTI3.
 *      USB VBUS plug-in raises it and wakes the MCU INSTANTLY (no
 *      polling at all). The +3.3 V rail (BUCK2) is switched over I2C by
 *      the MCU (~0.3 ms) - on button / headphone wake as well as on the
 *      PMIC's VBUS interrupt.
 *
 *  BOARD_PC3_PMIC_IRQ = 0
 *      GPIO0 = BUCK2 enable input driven by PC3 (HIGH = rail on), as in
 *      the first V2 firmware. The PMIC cannot signal the MCU, so VBUS is
 *      polled from the RTC every PWR_VBUS_POLL_MS while asleep.
 *
 *  For a future board spin: route a spare nPM1300 GPIO (GPIO1..4) to a
 *  free MCU pin (PB1/PB2/PC13) as the IRQ line and both schemes can be
 *  used together.
 * ------------------------------------------------------------------ */
#ifndef BOARD_PC3_PMIC_IRQ
#define BOARD_PC3_PMIC_IRQ         1
#endif

#define PWR_3V3_EN_PORT            GPIOC        /* net GPIO0               */
#define PWR_3V3_EN_PIN             GPIO_PIN_3
#define PMIC_IRQ_PORT              GPIOC        /* same net, IRQ role      */
#define PMIC_IRQ_PIN               GPIO_PIN_3   /* EXTI3                   */
#define PMIC_IRQ_EXTI_IRQn         EXTI3_IRQn
#define PWR_3V3_SETTLE_MS          3u           /* BUCK2 soft-start + margin */
/* 2.7.0: off time of the panel-recovery rail cycle (display test: at
 * least 100 ms, so panel and card see a real power-on reset).            */
#define PWR_3V3_RECOVER_OFF_MS     100u
#define PWR_VBUS_POLL_MS           250u         /* polling role only       */

/* nPM1300 GPIO index wired to PC3 (GPIO0 on the schematic).              */
#define NPM_GPIO_PC3               0u

/* Debug: SWD on PA13/PA14, SWO trace on PB3 (header pin). PB3 is left in
 * its reset (TRACESWO) function.                                         */

/* Pins with no connection on V2 - parked in analog mode at boot for the
 * lowest leakage: PA15, PB1, PB2, PB4..PB7, PB14, PB15, PC1, PC6, PC7,
 * PC13, PC14, PC15, PH0, PH1.                                            */
#define BOARD_NC_GPIOA             (GPIO_PIN_15)
#define BOARD_NC_GPIOB             (GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_4 | \
                                    GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7 | \
                                    GPIO_PIN_14 | GPIO_PIN_15)
#define BOARD_NC_GPIOC             (GPIO_PIN_1 | GPIO_PIN_6 | GPIO_PIN_7 | \
                                    GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15)
#define BOARD_NC_GPIOH             (GPIO_PIN_0 | GPIO_PIN_1)

/* ------------------------------------------------------------------ *
 *  Battery (Sony NP-BJ1 "J" type: 3.6 V nominal, 700 mAh / 2.5 Wh)
 * ------------------------------------------------------------------ */
/* Default charge current = 0.5C for the 700 mAh NP-BJ1 (Sony's standard
 * rate for this cell). User-adjustable in Settings > Charge rate for
 * other batteries; the nPM1300 tops out at 800 mA.                       */
#define BATT_CAPACITY_MAH          700u
#define BATT_CHARGE_MA_DEFAULT     350u         /* 0.5C                    */
#define BATT_VTERM_MV              4200u
#define BATT_CHARGE_MA_NO_NTC_MAX  350u         /* cap without thermistor  */
/* VBUS input limit = charge current + this much for the running system,
 * rounded up to 100 mA, never below the 500 mA every USB port supplies. */
#define BATT_SYSTEM_HEADROOM_MA    150u

#endif /* BOARD_H */
