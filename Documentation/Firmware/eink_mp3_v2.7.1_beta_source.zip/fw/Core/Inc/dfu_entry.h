/**
 * @file    dfu_entry.h
 * @brief   Enter ST's ROM USB-DFU bootloader from software - firmware
 *          updates over USB without the BOOT0 button or a debug probe.
 *
 * Flow: dfu_reboot_to_bootloader() leaves a magic word in a .noinit RAM
 * word and resets. The very first call in main(), dfu_check_and_jump(),
 * sees it and jumps into system memory (0x0BF90000) with the chip still in
 * its reset state - the bootloader then enumerates as "STM32 BOOTLOADER"
 * (DFU) and STM32CubeProgrammer (port USB) can program the flash.
 */
#ifndef DFU_ENTRY_H
#define DFU_ENTRY_H

void dfu_check_and_jump(void);           /* first line of main()         */
void dfu_reboot_to_bootloader(void);     /* never returns                */

#endif /* DFU_ENTRY_H */
