/**
 * @file    tusb_config.h
 * @brief   TinyUSB configuration - STM32U5 FS device, MSC + UAC2.
 */
#ifndef TUSB_CONFIG_H
#define TUSB_CONFIG_H

#define CFG_TUSB_MCU                 OPT_MCU_STM32U5
#define CFG_TUSB_OS                  OPT_OS_NONE
#define CFG_TUD_ENABLED              1
#define CFG_TUSB_RHPORT0_MODE        (OPT_MODE_DEVICE | OPT_MODE_FULL_SPEED)

#define CFG_TUD_ENDPOINT0_SIZE       64

/* Both classes compiled in; only one is exposed per enumeration
 * (usb_descriptors.c switches on g_usb_mode).                            */
#define CFG_TUD_MSC                  1
#define CFG_TUD_AUDIO                1
#define CFG_TUD_CDC                  0
#define CFG_TUD_HID                  0

/* MSC: one big bounce buffer = fewer, larger SD transactions.            */
#define CFG_TUD_MSC_EP_BUFSIZE       4096

/* UAC2 speaker: stereo, 32-bit slots (24 used), 44.1/48 k, async + fb.
 * Descriptor length macro comes from app/usb_descriptors.h.              */
#include "../../app/usb_descriptors.h"
#define CFG_TUD_AUDIO_FUNC_1_DESC_LEN            TUD_AUDIO_SPEAKER_STEREO_FB_DESC_LEN
#define CFG_TUD_AUDIO_FUNC_1_N_AS_INT            1
#define CFG_TUD_AUDIO_FUNC_1_CTRL_BUF_SZ         64
#define CFG_TUD_AUDIO_ENABLE_EP_OUT              1
#define CFG_TUD_AUDIO_ENABLE_FEEDBACK_EP         1
#define CFG_TUD_AUDIO_FUNC_1_N_BYTES_PER_SAMPLE_RX  4
#define CFG_TUD_AUDIO_FUNC_1_N_CHANNELS_RX          2
#define CFG_TUD_AUDIO_FUNC_1_MAX_SAMPLE_RATE        96000
#define CFG_TUD_AUDIO_FUNC_1_EP_OUT_SZ_MAX \
    TUD_AUDIO_EP_SIZE(CFG_TUD_AUDIO_FUNC_1_MAX_SAMPLE_RATE, 4, 2)
/* FIFO-count feedback keeps this half full: 16 ms of audio @ 96 k, 32 ms
 * @ 48 k (2.6.0: doubled - more slack for main-loop laps that draw the
 * screen, a suspect for the USB-DAC crackle).                            */
#define CFG_TUD_AUDIO_FUNC_1_EP_OUT_SW_BUF_SZ \
    (CFG_TUD_AUDIO_FUNC_1_EP_OUT_SZ_MAX * 16)
#define CFG_TUD_AUDIO_FUNC_1_RESOLUTION_RX          24
#define CFG_TUD_AUDIO_ENABLE_FEEDBACK_FORMAT_CORRECTION 0

#endif /* TUSB_CONFIG_H */
