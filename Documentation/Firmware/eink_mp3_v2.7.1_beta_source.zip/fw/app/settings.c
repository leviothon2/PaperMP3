/**
 * @file    settings.c
 * @brief   Tiny key=value settings file on the SD card.
 *
 * Writes are deferred: settings_save() only marks the data dirty and the
 * superloop's settings_poll() writes it 5 s after the first unsaved
 * change (so a stream of changes still lands at least every 5 s). v1 skipped the
 * write when the 5 s throttle was active and never retried, so the last
 * change before power-off (e.g. a volume tweak, the resume point) was
 * usually lost. settings_flush() forces the write (sleep, USB MSC hand-off).
 */
#include "settings.h"
#include "power.h"
#include "playlist.h"
#include "board.h"
#include "diag.h"
#include "../drivers/npm1300.h"
#include "../drivers/eink.h"
#include "../drivers/gfx.h"
#include "../drivers/cs43131.h"
#include "../drivers/buttons.h"
#include "../drivers/sdcard.h"
#include "flash_store.h"
#include "../audio/eq.h"
#include "fuelgauge.h"
#include "library.h"
#include "podcast.h"
#include "ff.h"
#include "stm32u5xx_hal.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SETTINGS_PATH   "0:/settings.txt"
#define SAVE_PERIOD_MS  5000u

static FATFS      s_fs;
static bool       s_mounted;
static settings_t s_cfg = {
    .volume        = 40,
    .contrast      = 2,
    .anim_speed    = 1,
    .shuffle       = false,
    .repeat        = 0,
    .usb_default   = 0,
    .album_art     = true,
    .dark_mode     = false,
    .sleep_timeout = POWER_TIMEOUT_DEFAULT, /* 10 min                      */
    .charge_ma     = BATT_CHARGE_MA_DEFAULT,/* 350 mA = 0.5C NP-BJ1        */
    .shuffle_seed  = 0xC0FFEE42u,
    .gapless       = true,
    .eq_on         = false,
    .eq_preset     = 0,
    .text_size     = 0,
    .fuel_gauge    = false,
    .batt_mah      = 700,             /* Sony NP-BJ1                       */
    .drive         = 0,               /* fast (InkBoy)                     */
    .ink           = 8,               /* display test: keep 8/8            */
    .halo          = 0,
    .highlight     = HL_INVERT,
    .spi_fast      = true,            /* display test: 20 MHz holds 30 fps */
    .hp_detect     = true,
    .pod_speed     = 1,               /* 1.0x                              */
    .timer_min     = 20,
    .timer_fade_s  = 30,
    .timer_song_end = false,
    .quick_key     = QK_SKIPS,
    .sw1_double    = true,
    .nav_on_press  = false,
    .long_ms       = 700,
    .sd_clock_div  = 2,               /* 12 MHz (display test dt-0.2.0)    */
    .sd_4bit       = true,
};
static bool     s_dirty;
static uint32_t s_dirty_since;
static uint32_t s_mount_seq;

settings_t *settings_get(void) { return &s_cfg; }

static const uint16_t k_speeds[SETTINGS_SPEED_COUNT] = { 80, 100, 120, 150, 175, 200 };
uint16_t settings_speed_x100(uint8_t idx)
{
    return k_speeds[idx < SETTINGS_SPEED_COUNT ? idx : 1];
}

/* ---- flash copy (2.7.0) ------------------------------------------------------ *
 * A packed image of the device settings. No volume and no resume point:
 * those change all the time and would wear the page (32 saves per erase).
 * The layout id changes whenever this struct does; an older record is then
 * ignored and the defaults apply until the next save.                     */
#define FLASH_LAYOUT 0x2701u
typedef struct __attribute__((packed)) {
    uint8_t  anim_speed, repeat, usb_default, sleep_timeout;
    uint8_t  eq_preset, text_size, menu_refresh;
    uint8_t  drive, ink, halo, highlight, pod_speed, repeat_before_loop;
    uint8_t  timer_min, timer_fade_s, quick_key, sd_clock_div;
    uint16_t charge_ma, batt_mah, long_ms;
    int8_t   eq_custom[10];
    uint16_t flags;
} flash_cfg_t;
_Static_assert(sizeof(flash_cfg_t) <= FLASH_STORE_PAYLOAD, "settings record fits a flash slot");

enum {
    FL_ART = 1u << 0, FL_DARK = 1u << 1, FL_GAPLESS = 1u << 2, FL_FUEL = 1u << 3,
    FL_NO_NTC = 1u << 4, FL_SPI_FAST = 1u << 5, FL_HP = 1u << 6, FL_SONG_END = 1u << 7,
    FL_SW1_DOUBLE = 1u << 8, FL_ON_PRESS = 1u << 9, FL_SD_4BIT = 1u << 10,
};

static bool        s_sd_1bit_session;   /* DAT0-only fallback in use      */
static flash_cfg_t s_flash_last;
static bool        s_flash_valid;

static void flash_pack(flash_cfg_t *f)
{
    memset(f, 0, sizeof *f);
    f->anim_speed = s_cfg.anim_speed;   f->repeat = s_cfg.repeat;
    f->usb_default = s_cfg.usb_default; f->sleep_timeout = s_cfg.sleep_timeout;
    f->eq_preset = s_cfg.eq_preset;     f->text_size = s_cfg.text_size;
    f->menu_refresh = s_cfg.menu_refresh;
    f->drive = s_cfg.drive;             f->ink = s_cfg.ink;
    f->halo = s_cfg.halo;               f->highlight = s_cfg.highlight;
    f->pod_speed = s_cfg.pod_speed;     f->repeat_before_loop = s_cfg.repeat_before_loop;
    f->timer_min = s_cfg.timer_min;     f->timer_fade_s = s_cfg.timer_fade_s;
    f->quick_key = s_cfg.quick_key;     f->sd_clock_div = s_cfg.sd_clock_div;
    f->charge_ma = s_cfg.charge_ma;     f->batt_mah = s_cfg.batt_mah;
    f->long_ms = s_cfg.long_ms;
    memcpy(f->eq_custom, s_cfg.eq_custom, sizeof f->eq_custom);
    f->flags = (uint16_t)(
        (s_cfg.album_art ? FL_ART : 0) | (s_cfg.dark_mode ? FL_DARK : 0) |
        (s_cfg.gapless ? FL_GAPLESS : 0) | (s_cfg.fuel_gauge ? FL_FUEL : 0) |
        (s_cfg.no_thermistor ? FL_NO_NTC : 0) | (s_cfg.spi_fast ? FL_SPI_FAST : 0) |
        (s_cfg.hp_detect ? FL_HP : 0) | (s_cfg.timer_song_end ? FL_SONG_END : 0) |
        (s_cfg.sw1_double ? FL_SW1_DOUBLE : 0) | (s_cfg.nav_on_press ? FL_ON_PRESS : 0) |
        (s_cfg.sd_4bit ? FL_SD_4BIT : 0));
}

static void flash_unpack(const flash_cfg_t *f)
{
    s_cfg.anim_speed = f->anim_speed;   s_cfg.repeat = f->repeat;
    s_cfg.usb_default = f->usb_default; s_cfg.sleep_timeout = f->sleep_timeout;
    s_cfg.eq_preset = f->eq_preset;     s_cfg.text_size = f->text_size;
    s_cfg.menu_refresh = f->menu_refresh;
    s_cfg.drive = f->drive;             s_cfg.ink = f->ink;
    s_cfg.halo = f->halo;               s_cfg.highlight = f->highlight;
    s_cfg.pod_speed = f->pod_speed;     s_cfg.repeat_before_loop = f->repeat_before_loop;
    s_cfg.timer_min = f->timer_min;     s_cfg.timer_fade_s = f->timer_fade_s;
    s_cfg.quick_key = f->quick_key;     s_cfg.sd_clock_div = f->sd_clock_div;
    s_cfg.charge_ma = f->charge_ma;     s_cfg.batt_mah = f->batt_mah;
    s_cfg.long_ms = f->long_ms;
    memcpy(s_cfg.eq_custom, f->eq_custom, sizeof f->eq_custom);
    s_cfg.album_art = f->flags & FL_ART;         s_cfg.dark_mode = f->flags & FL_DARK;
    s_cfg.gapless = f->flags & FL_GAPLESS;       s_cfg.fuel_gauge = f->flags & FL_FUEL;
    s_cfg.no_thermistor = f->flags & FL_NO_NTC;  s_cfg.spi_fast = f->flags & FL_SPI_FAST;
    s_cfg.hp_detect = f->flags & FL_HP;          s_cfg.timer_song_end = f->flags & FL_SONG_END;
    s_cfg.sw1_double = f->flags & FL_SW1_DOUBLE; s_cfg.nav_on_press = f->flags & FL_ON_PRESS;
    s_cfg.sd_4bit = f->flags & FL_SD_4BIT;
}

/* Write the flash copy if a device setting differs from what it holds.   */
static void flash_sync(void)
{
    flash_cfg_t now;
    flash_pack(&now);
    if (s_flash_valid && !memcmp(&now, &s_flash_last, sizeof now)) return;
    if (flash_store_save(&now, sizeof now, FLASH_LAYOUT)) {
        s_flash_last = now;
        s_flash_valid = true;
    }
}

static void clamp(void);

void settings_apply_input(void)
{
    btn_timing_t t = BTN_TIMING_DEFAULT;
    t.long_ms      = s_cfg.long_ms;
    t.sw1_double   = s_cfg.sw1_double;
    t.nav_on_press = s_cfg.nav_on_press;
    buttons_set_timing(&t);
}

void settings_apply_display(void)
{
    eink_set_spi_fast(s_cfg.spi_fast);
    eink_set_drive(s_cfg.drive ? EINK_DRIVE_CLASSIC : EINK_DRIVE_FAST);
    eink_set_ink(s_cfg.ink);
    eink_set_halo(s_cfg.halo);
}

static void apply_sd_bus(void)
{
    sdcard_cfg_t c = SDCARD_CFG_DEFAULT;
    c.clock_div = s_cfg.sd_clock_div;
    c.bus_4bit  = (s_cfg.sd_4bit && !s_sd_1bit_session) ? 1 : 0;
    sdcard_set_config(&c);                     /* used by the next init    */
}

void settings_boot(void)
{
    flash_cfg_t f;
    if (flash_store_load(&f, sizeof f, FLASH_LAYOUT)) {
        flash_unpack(&f);
        s_flash_last = f;
        s_flash_valid = true;
        clamp();
    }
    apply_sd_bus();
    settings_apply_input();
    settings_apply_display();
    gfx_set_invert(s_cfg.dark_mode);
}

const int8_t *settings_eq_gains(void)
{
    const int8_t *g = eq_preset_gains(s_cfg.eq_preset);
    return g ? g : s_cfg.eq_custom;
}

void settings_apply_eq(void)
{
    s_cfg.eq_on = s_cfg.eq_preset != 0;          /* preset 0 = "Off"      */
    eq_configure(s_cfg.eq_on, settings_eq_gains());
}

/* ---- card start + mount (display test dt-0.2.0 / dt-0.2.1) ------------------- *
 * The hardened driver reports the stage an init stopped at; three tries,
 * each from a reset peripheral. If the card initialises but its 4-bit
 * reads fail (seen on the test board: DAT1-3 through the TXS02612), the
 * card is used on DAT0 only for this session and the status says so.     */
static uint8_t s_sd_tries;
static int     s_sd_fresult = -1;

bool settings_card_start(void)
{
    s_sd_tries = 0;
    for (unsigned i = 1; i <= 3u; i++) {
        s_sd_tries++;
        if (!sdcard_present()) return false;
        if (sdcard_init()) return true;
        sdcard_stage_t st = sdcard_last_report()->stage;
        if (st == SD_STAGE_CLOCK || st == SD_STAGE_DETECT) return false;
        sdcard_deinit();
        HAL_Delay(20u * i);
    }
    return false;
}

bool settings_remount_quiet(void)
{
    FRESULT fr = f_mount(&s_fs, "0:", 1);
    if (fr == FR_DISK_ERR || fr == FR_NOT_READY) {   /* transfer error: once more */
        sdcard_deinit();
        if (sdcard_init()) fr = f_mount(&s_fs, "0:", 1);
    }
    if ((fr == FR_DISK_ERR || fr == FR_NOT_READY) && sdcard_config()->bus_4bit) {
        sdcard_cfg_t c = *sdcard_config();
        c.bus_4bit = 0;
        sdcard_set_config(&c);
        sdcard_deinit();
        if (sdcard_init()) fr = f_mount(&s_fs, "0:", 1);
        s_sd_1bit_session = (fr == FR_OK);
        if (!s_sd_1bit_session) { c.bus_4bit = 1; sdcard_set_config(&c); }
    }
    s_sd_fresult = (int)fr;
    s_mounted = (fr == FR_OK);
    if (!s_mounted) f_unmount("0:");
    return s_mounted;
}

void settings_sd_status(char *buf, unsigned n)
{
    if (s_mounted) {
        snprintf(buf, n, "SD ok, %lu MHz %s%s", (unsigned long)(sdcard_clock_hz() / 1000000u),
                 sdcard_config()->bus_4bit ? "4-bit" : "1-bit",
                 s_sd_1bit_session ? " (fallback)" : s_sd_tries > 1 ? " (retry)" : "");
        return;
    }
    if (!sdcard_present()) { snprintf(buf, n, "No SD card"); return; }
    if (!sdcard_ready()) {
        const sdcard_report_t *r = sdcard_last_report();
        char e[24];
        sdcard_err_text(r->hal_err, e, sizeof e);
        snprintf(buf, n, "SD fail: %s %s", sdcard_stage_name(r->stage), e);
        return;
    }
    snprintf(buf, n, "SD: no FAT/exFAT (FR%d)", s_sd_fresult);
}

bool settings_mount(void)
{
    diag_step(STEP_SD_MOUNT);
    if (!settings_remount_quiet()) return false;
    settings_load();
    settings_apply();
    playlist_invalidate_scan();
    podcast_card_changed();             /* list + positions re-read       */
    diag_log_to_sd();
    s_mount_seq++;
    return true;
}

uint32_t settings_mount_seq(void) { return s_mount_seq; }

void settings_apply(void)
{
    /* NTC mode first: it caps the charge current. Written only when it
     * is on or changes, so the default leaves the charger as before.    */
    if (s_cfg.no_thermistor || npm1300_no_ntc())
        npm1300_set_no_ntc(s_cfg.no_thermistor);
    if (s_cfg.no_thermistor && s_cfg.charge_ma > BATT_CHARGE_MA_NO_NTC_MAX)
        s_cfg.charge_ma = BATT_CHARGE_MA_NO_NTC_MAX;
    npm1300_set_charge_current(s_cfg.charge_ma);
    settings_apply_display();
    settings_apply_input();
    apply_sd_bus();
    settings_apply_eq();
    fuelgauge_enable(s_cfg.fuel_gauge, s_cfg.batt_mah);
    gfx_set_invert(s_cfg.dark_mode);
}

void settings_unmount(void)
{
    library_close();                    /* its open index files die too   */
    podcast_card_changed();
    if (s_mounted) f_unmount("0:");
    s_mounted = false;
}

bool settings_mounted(void) { return s_mounted; }

static uint32_t to_u32(const char *v) { return (uint32_t)strtoul(v, NULL, 10); }

static void apply_kv(const char *k, const char *v)
{
    if      (!strcmp(k, "volume"))        s_cfg.volume = (uint8_t)atoi(v);
    else if (!strcmp(k, "contrast"))      s_cfg.contrast = (uint8_t)atoi(v);
    else if (!strcmp(k, "anim_speed"))    s_cfg.anim_speed = (uint8_t)atoi(v);
    else if (!strcmp(k, "shuffle"))       s_cfg.shuffle = atoi(v) != 0;
    else if (!strcmp(k, "repeat"))        s_cfg.repeat = (uint8_t)atoi(v);
    else if (!strcmp(k, "usb_default"))   s_cfg.usb_default = (uint8_t)atoi(v);
    else if (!strcmp(k, "album_art"))     s_cfg.album_art = atoi(v) != 0;
    else if (!strcmp(k, "dark_mode"))     s_cfg.dark_mode = atoi(v) != 0;
    else if (!strcmp(k, "sleep_timeout")) s_cfg.sleep_timeout = (uint8_t)atoi(v);
    else if (!strcmp(k, "charge_ma"))     s_cfg.charge_ma = (uint16_t)atoi(v);
    else if (!strcmp(k, "last_playlist")) {
        strncpy(s_cfg.last_playlist, v, sizeof s_cfg.last_playlist - 1);
        s_cfg.last_playlist[sizeof s_cfg.last_playlist - 1] = '\0';
    }
    else if (!strcmp(k, "last_track"))    s_cfg.last_track_idx = to_u32(v);
    else if (!strcmp(k, "last_pos_ms"))   s_cfg.last_pos_ms = to_u32(v);
    else if (!strcmp(k, "shuffle_seed"))  s_cfg.shuffle_seed = to_u32(v);
    else if (!strcmp(k, "last_shuffle"))  s_cfg.last_shuffle = atoi(v) != 0;
    else if (!strcmp(k, "gapless"))       s_cfg.gapless = atoi(v) != 0;
    else if (!strcmp(k, "eq_preset"))     s_cfg.eq_preset = (uint8_t)atoi(v);
    else if (!strcmp(k, "eq_custom")) {
        const char *p = v;
        for (int b = 0; b < 10 && *p; b++) {
            s_cfg.eq_custom[b] = (int8_t)strtol(p, (char **)&p, 10);
            while (*p == ',' || *p == ' ') p++;
        }
    }
    else if (!strcmp(k, "text_size"))     s_cfg.text_size = (uint8_t)atoi(v);
    else if (!strcmp(k, "fuel_gauge"))    s_cfg.fuel_gauge = atoi(v) != 0;
    else if (!strcmp(k, "batt_mah"))      s_cfg.batt_mah = (uint16_t)atoi(v);
    else if (!strcmp(k, "menu_refresh"))  s_cfg.menu_refresh = (uint8_t)atoi(v);
    else if (!strcmp(k, "no_thermistor")) s_cfg.no_thermistor = atoi(v) != 0;
    else if (!strcmp(k, "display_drive")) s_cfg.drive = (uint8_t)atoi(v);
    else if (!strcmp(k, "ink"))           s_cfg.ink = (uint8_t)atoi(v);
    else if (!strcmp(k, "edge_cleanup"))  s_cfg.halo = (uint8_t)atoi(v);
    else if (!strcmp(k, "highlight"))     s_cfg.highlight = (uint8_t)atoi(v);
    else if (!strcmp(k, "spi_fast"))      s_cfg.spi_fast = atoi(v) != 0;
    else if (!strcmp(k, "hp_detect"))     s_cfg.hp_detect = atoi(v) != 0;
    else if (!strcmp(k, "podcast_speed")) s_cfg.pod_speed = (uint8_t)atoi(v);
    else if (!strcmp(k, "repeat_before_loop")) s_cfg.repeat_before_loop = (uint8_t)atoi(v);
    else if (!strcmp(k, "timer_min"))     s_cfg.timer_min = (uint8_t)atoi(v);
    else if (!strcmp(k, "timer_fade_s"))  s_cfg.timer_fade_s = (uint8_t)atoi(v);
    else if (!strcmp(k, "timer_song_end")) s_cfg.timer_song_end = atoi(v) != 0;
    else if (!strcmp(k, "quick_key"))     s_cfg.quick_key = (uint8_t)atoi(v);
    else if (!strcmp(k, "btn_sw1_double")) s_cfg.sw1_double = atoi(v) != 0;
    else if (!strcmp(k, "btn_nav_on_press")) s_cfg.nav_on_press = atoi(v) != 0;
    else if (!strcmp(k, "btn_long_ms"))   s_cfg.long_ms = (uint16_t)atoi(v);
    else if (!strcmp(k, "sd_clock_div"))  s_cfg.sd_clock_div = (uint8_t)atoi(v);
    else if (!strcmp(k, "sd_4bit"))       s_cfg.sd_4bit = atoi(v) != 0;
    /* 2.5.0: the diagnostic keys of 2.4.x (codec_hp, grayscale,
     * full_refresh, panel_sleep) are ignored and dropped on the next save. */
}

static void clamp(void)
{
    if (s_cfg.volume > 100)   s_cfg.volume = 100;
    if (s_cfg.contrast > 4)   s_cfg.contrast = 4;
    if (s_cfg.anim_speed > 2) s_cfg.anim_speed = 2;
    if (s_cfg.repeat > 2)     s_cfg.repeat = 0;
    if (s_cfg.usb_default > 3) s_cfg.usb_default = 0;
    if (s_cfg.sleep_timeout >= POWER_TIMEOUT_COUNT)
        s_cfg.sleep_timeout = POWER_TIMEOUT_DEFAULT;
    if (s_cfg.charge_ma < 32 || s_cfg.charge_ma > 800)
        s_cfg.charge_ma = BATT_CHARGE_MA_DEFAULT;
    if (s_cfg.eq_preset >= EQ_PRESET_COUNT) s_cfg.eq_preset = 0;
    for (int b = 0; b < 10; b++) {
        if (s_cfg.eq_custom[b] >  EQ_GAIN_MAX) s_cfg.eq_custom[b] =  EQ_GAIN_MAX;
        if (s_cfg.eq_custom[b] < -EQ_GAIN_MAX) s_cfg.eq_custom[b] = -EQ_GAIN_MAX;
    }
    if (s_cfg.text_size > 2) s_cfg.text_size = 0;
    if (s_cfg.menu_refresh > 1) s_cfg.menu_refresh = 0;
    if (s_cfg.batt_mah < 100 || s_cfg.batt_mah > 10000) s_cfg.batt_mah = 700;
    if (s_cfg.drive > 1)     s_cfg.drive = 0;
    if (s_cfg.ink < 4 || s_cfg.ink > 8) s_cfg.ink = 8;
    if (s_cfg.halo > 2)      s_cfg.halo = 0;
    if (s_cfg.highlight >= HL_COUNT) s_cfg.highlight = HL_INVERT;
    if (s_cfg.pod_speed >= SETTINGS_SPEED_COUNT) s_cfg.pod_speed = 1;
    if (s_cfg.repeat_before_loop > 1) s_cfg.repeat_before_loop = 0;
    if (s_cfg.timer_min < 1 || s_cfg.timer_min > 180) s_cfg.timer_min = 20;
    if (s_cfg.timer_fade_s != 0 && s_cfg.timer_fade_s != 10 &&
        s_cfg.timer_fade_s != 30 && s_cfg.timer_fade_s != 60) s_cfg.timer_fade_s = 30;
    if (s_cfg.quick_key >= QK_COUNT) s_cfg.quick_key = QK_SKIPS;
    if (s_cfg.long_ms < 300 || s_cfg.long_ms > 1500) s_cfg.long_ms = 700;
    /* 48 MHz / (2 x div): 1 = 24 MHz ... 60 = 400 kHz                      */
    if (s_cfg.sd_clock_div < 1 || s_cfg.sd_clock_div > 60) s_cfg.sd_clock_div = 2;
}

void settings_load(void)
{
    FIL f;
    if (!s_mounted || f_open(&f, SETTINGS_PATH, FA_READ) != FR_OK) return;

    char line[128];
    while (f_gets(line, sizeof line, &f)) {
        char *nl = strpbrk(line, "\r\n");
        if (nl) *nl = '\0';
        if (line[0] == '#' || !line[0]) continue;
        char *eq = strchr(line, '=');
        if (!eq) continue;
        *eq = '\0';
        apply_kv(line, eq + 1);
    }
    f_close(&f);
    clamp();
}

/* v2.4.5: the whole file is formatted into one static buffer and written
 * with a single f_write - FatFs f_printf() is no longer used anywhere.  */
static char s_wbuf[2560];
static int  s_wlen;

static void put(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void put(const char *fmt, ...)
{
    if (s_wlen >= (int)sizeof s_wbuf - 1) return;
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(s_wbuf + s_wlen, sizeof s_wbuf - (size_t)s_wlen, fmt, ap);
    va_end(ap);
    if (n > 0) s_wlen += n;
    if (s_wlen > (int)sizeof s_wbuf - 1) s_wlen = (int)sizeof s_wbuf - 1;
}

static void write_now(void)
{
    static FIL f;
    diag_step(STEP_SETTINGS_WRITE);
    flash_sync();                       /* device settings; no card needed */
    if (!s_mounted) { s_dirty = false; return; }

    s_wlen = 0;
    put("# e-ink mp3 player settings (edit freely, one key=value per line)\n");
    put("volume=%u\n",        s_cfg.volume);
    put("contrast=%u\n",      s_cfg.contrast);
    put("anim_speed=%u\n",    s_cfg.anim_speed);
    put("shuffle=%u\n",       s_cfg.shuffle ? 1 : 0);
    put("repeat=%u\n",        s_cfg.repeat);
    put("usb_default=%u\n",   s_cfg.usb_default);
    put("album_art=%u\n",     s_cfg.album_art ? 1 : 0);
    put("dark_mode=%u\n",     s_cfg.dark_mode ? 1 : 0);
    put("# sleep_timeout: 0=2min 1=5min 2=10min 3=30min 4=1h 5=never\n");
    put("sleep_timeout=%u\n", s_cfg.sleep_timeout);
    put("# charge_ma: battery charge current 32..800 (NP-BJ1: 350 = 0.5C)\n");
    put("charge_ma=%u\n",     s_cfg.charge_ma);
    put("last_playlist=%s\n", s_cfg.last_playlist);
    put("last_track=%lu\n",   (unsigned long)s_cfg.last_track_idx);
    put("last_pos_ms=%lu\n",  (unsigned long)s_cfg.last_pos_ms);
    put("shuffle_seed=%lu\n", (unsigned long)s_cfg.shuffle_seed);
    put("last_shuffle=%u\n",  s_cfg.last_shuffle ? 1 : 0);
    put("gapless=%u\n",       s_cfg.gapless ? 1 : 0);
    put("# eq_preset: 0 Off 1 Bass 2 Warm 3 Bright 4 Vocal 5 Loudness 6 Custom\n");
    put("eq_preset=%u\n",     s_cfg.eq_preset);
    put("# eq_custom: dB for 31,62,125,250,500,1k,2k,4k,8k,16k Hz (-12..12)\n");
    put("eq_custom=%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
        s_cfg.eq_custom[0], s_cfg.eq_custom[1], s_cfg.eq_custom[2], s_cfg.eq_custom[3],
        s_cfg.eq_custom[4], s_cfg.eq_custom[5], s_cfg.eq_custom[6], s_cfg.eq_custom[7],
        s_cfg.eq_custom[8], s_cfg.eq_custom[9]);
    put("# text_size: 0 small, 1 medium, 2 large\n");
    put("text_size=%u\n",     s_cfg.text_size);
    put("# fuel_gauge: 1 = measure battery current for an accurate %% (uses a little power)\n");
    put("fuel_gauge=%u\n",    s_cfg.fuel_gauge ? 1 : 0);
    put("batt_mah=%u\n",      s_cfg.batt_mah);
    put("# menu_refresh: 0 gentle (menus change without a full flash), 1 classic\n");
    put("menu_refresh=%u\n",  s_cfg.menu_refresh);
    put("# no_thermistor: 1 = charge although the battery has no thermistor (max 350 mA)\n");
    put("no_thermistor=%u\n", s_cfg.no_thermistor ? 1 : 0);
    put("# display_drive: 0 fast (InkBoy waveforms), 1 classic (factory waveforms)\n");
    put("display_drive=%u\n", s_cfg.drive);
    put("# ink: fast drive, pulses per changed pixel 4..8; edge_cleanup: 0 off, 1 or 2 px\n");
    put("ink=%u\n",           s_cfg.ink);
    put("edge_cleanup=%u\n",  s_cfg.halo);
    put("# highlight: 0 invert, 1 bold, 2 arrow, 3 bar, 4 frame\n");
    put("highlight=%u\n",     s_cfg.highlight);
    put("# spi_fast: 1 = 20 MHz panel SPI, 0 = 10 MHz\n");
    put("spi_fast=%u\n",      s_cfg.spi_fast ? 1 : 0);
    put("# hp_detect: 1 = no playback while the headphone jack is empty\n");
    put("hp_detect=%u\n",     s_cfg.hp_detect ? 1 : 0);
    put("# podcast_speed: 0 0.8x, 1 1.0x, 2 1.2x, 3 1.5x, 4 1.75x, 5 2.0x\n");
    put("podcast_speed=%u\n", s_cfg.pod_speed);
    put("repeat_before_loop=%u\n", s_cfg.repeat_before_loop);
    put("# sleep timer: last duration (min), fade-out 0/10/30/60 s, finish the song first\n");
    put("timer_min=%u\n",     s_cfg.timer_min);
    put("timer_fade_s=%u\n",  s_cfg.timer_fade_s);
    put("timer_song_end=%u\n", s_cfg.timer_song_end ? 1 : 0);
    put("# quick_key: quick menu opens with 0 both skip keys, 1 hold play, 2 either\n");
    put("quick_key=%u\n",     s_cfg.quick_key);
    put("btn_sw1_double=%u\n", s_cfg.sw1_double ? 1 : 0);
    put("btn_nav_on_press=%u\n", s_cfg.nav_on_press ? 1 : 0);
    put("btn_long_ms=%u\n",   s_cfg.long_ms);
    put("# SD bus: clock = 48 MHz / (2 x sd_clock_div) (2 = 12 MHz, 1 = 24 MHz); sd_4bit=0 uses DAT0 only\n");
    put("sd_clock_div=%u\n",  s_cfg.sd_clock_div);
    put("sd_4bit=%u\n",       s_cfg.sd_4bit ? 1 : 0);

    if (f_open(&f, SETTINGS_PATH, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK)
        return;
    UINT bw = 0;
    FRESULT wr = f_write(&f, s_wbuf, (UINT)s_wlen, &bw);
    if (f_close(&f) == FR_OK && wr == FR_OK && bw == (UINT)s_wlen) s_dirty = false;
}

void settings_save(void)
{
    /* Mark dirty; settings_poll() writes it out. SD writes stall the
     * decoder for a few ms, so they are batched.                         */
    if (!s_dirty) s_dirty_since = HAL_GetTick();
    s_dirty = true;
}

void settings_poll(void)
{
    if (s_dirty && HAL_GetTick() - s_dirty_since >= SAVE_PERIOD_MS)
        write_now();
}

void settings_flush(void)
{
    if (s_dirty) write_now();
    podcast_flush();                    /* episode positions              */
}
