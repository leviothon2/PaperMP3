/**
 * @file    podcast.c
 * @brief   /Podcasts list + listening positions (see podcast.h).
 */
#include "podcast.h"
#include "settings.h"
#include "diag.h"
#include "../audio/decoder.h"
#include "ff.h"
#include "stm32u5xx_hal.h"

#include <stdio.h>
#include <string.h>
#include <strings.h>

#define POD_DIR     "0:/Podcasts"
#define POD_IDX     "0:/.eplayer/podcasts.idx"
#define POD_TMP     "0:/.eplayer/podcasts.tmp"
#define POD_DAT     "0:/.eplayer/podcasts.dat"
#define POD_PATH    256u
#define KEY_LEN     28u
#define SAVE_MS     20000u
/* An episode within this of its end counts as finished; one stopped in
 * its first seconds counts as not started.                                */
#define DONE_TAIL_MS  15000u
#define START_MS       5000u

typedef struct { uint32_t hash, pos_ms, len_ms, flags; } rec_t;   /* 16 B   */
#define REC_DONE  1u

static rec_t    s_rec[POD_MAX];
static uint32_t s_nrec;
static bool     s_loaded, s_dirty;
static uint32_t s_dirty_t;
static uint32_t s_count;
static uint32_t s_seen_mount = 0xFFFFFFFFu;
static uint32_t s_use;                 /* round-robin victim when full       */

/* ---- helpers ---------------------------------------------------------------- */

static uint32_t path_hash(const char *p)
{
    uint32_t h = 2166136261u;                   /* FNV-1a, case-folded       */
    for (; *p; p++) {
        char c = *p;
        if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
        if (c == '\\') c = '/';
        h = (h ^ (uint8_t)c) * 16777619u;
    }
    return h ? h : 1u;
}

bool podcast_path_is(const char *path)
{
    return path && !strncasecmp(path, POD_DIR "/", sizeof POD_DIR);
}

void podcast_name(const char *path, char *buf, uint32_t len)
{
    const char *b = strrchr(path, '/');
    b = b ? b + 1 : path;
    snprintf(buf, len, "%s", b);
    char *dot = strrchr(buf, '.');
    if (dot && dot != buf) *dot = '\0';
}

const char *podcast_index_path(void) { return POD_IDX; }
uint32_t    podcast_count(void)      { return s_count; }

/* ---- positions ---------------------------------------------------------------- */

static void load_positions(void)
{
    if (s_loaded) return;
    s_loaded = true;
    s_nrec = 0;
    FIL f;
    if (f_open(&f, POD_DAT, FA_READ) != FR_OK) return;
    UINT br = 0;
    if (f_read(&f, s_rec, sizeof s_rec, &br) == FR_OK) s_nrec = br / sizeof(rec_t);
    f_close(&f);
}

static rec_t *find(uint32_t h)
{
    for (uint32_t i = 0; i < s_nrec; i++) if (s_rec[i].hash == h) return &s_rec[i];
    return NULL;
}

void podcast_progress(const char *path, pod_progress_t *out)
{
    *out = (pod_progress_t){ POD_NEW, 0, 0 };
    if (!settings_mounted()) return;
    load_positions();
    const rec_t *r = find(path_hash(path));
    if (!r) return;
    out->len_ms = r->len_ms;
    if (r->flags & REC_DONE) { out->state = POD_DONE; return; }
    if (r->pos_ms >= START_MS) { out->state = POD_STARTED; out->pos_ms = r->pos_ms; }
}

void podcast_note(const char *path, uint32_t pos_ms, uint32_t len_ms, bool finished)
{
    if (!settings_mounted()) return;
    load_positions();
    uint32_t h = path_hash(path);
    rec_t *r = find(h);
    if (!r) {
        if (s_nrec < POD_MAX) r = &s_rec[s_nrec++];
        else r = &s_rec[s_use++ % POD_MAX];     /* table full: reuse a slot  */
        *r = (rec_t){ h, 0, 0, 0 };
    }
    if (len_ms && pos_ms + DONE_TAIL_MS >= len_ms) finished = true;
    uint32_t flags = finished ? REC_DONE : 0;
    if (finished) pos_ms = 0;
    if (r->pos_ms == pos_ms && r->flags == flags && (!len_ms || r->len_ms == len_ms)) return;
    r->pos_ms = pos_ms;
    r->flags  = flags;
    if (len_ms) r->len_ms = len_ms;
    if (!s_dirty) s_dirty_t = HAL_GetTick();
    s_dirty = true;
}

void podcast_flush(void)
{
    if (!s_dirty || !settings_mounted()) return;
    FIL f;
    f_mkdir("0:/.eplayer");
    if (f_open(&f, POD_DAT, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) return;
    UINT bw = 0;
    FRESULT wr = f_write(&f, s_rec, s_nrec * sizeof(rec_t), &bw);
    if (f_close(&f) == FR_OK && wr == FR_OK) s_dirty = false;
}

void podcast_poll(void)
{
    if (s_dirty && HAL_GetTick() - s_dirty_t >= SAVE_MS) podcast_flush();
}

void podcast_card_changed(void)
{
    s_loaded = false;
    s_dirty = false;
    s_nrec = 0;
    s_count = 0;
    s_seen_mount = 0xFFFFFFFFu;
}

/* ---- the list --------------------------------------------------------------------- */

typedef struct { char key[KEY_LEN]; uint32_t off; } ent_t;        /* 32 B     */

static void make_key(char *key, const char *path)
{
    const char *p = path + sizeof POD_DIR;      /* past "0:/Podcasts/"       */
    unsigned i = 0;
    for (; *p && i < KEY_LEN - 1u; p++) {
        char c = *p;
        if (c >= 'a' && c <= 'z') c = (char)(c - 32);
        key[i++] = c;
    }
    key[i] = '\0';
}

static void walk(FIL *out, const char *dir_path, int depth, ent_t *ents, uint32_t *n)
{
    DIR dir;
    FILINFO fi;
    char path[POD_PATH];
    if (depth > 3 || f_opendir(&dir, dir_path) != FR_OK) return;
    while (*n < POD_MAX && f_readdir(&dir, &fi) == FR_OK && fi.fname[0]) {
        if (fi.fname[0] == '.' || (fi.fattrib & (AM_HID | AM_SYS))) continue;
        if (strlen(dir_path) + strlen(fi.fname) + 2u > sizeof path) continue;
        strcpy(path, dir_path);
        strcat(path, "/");
        strcat(path, fi.fname);
        if (fi.fattrib & AM_DIR) {
            walk(out, path, depth + 1, ents, n);
        } else if (dec_format_from_path(fi.fname) != DEC_FMT_UNKNOWN) {
            ents[*n].off = (uint32_t)f_tell(out);
            make_key(ents[*n].key, path);
            (*n)++;
            f_puts(path, out);
            f_putc('\n', out);
        }
    }
    f_closedir(&dir);
}

/* Unsorted walk into a temp file, then the lines are copied out in name
 * order (keys in RAM: the first 27 characters after "/Podcasts/").        */
static uint32_t rebuild(void)
{
    /* On the stack (about 8 KB with the two files): this runs from the UI,
     * a few calls deep, and static RAM is short.                           */
    ent_t ents[POD_MAX];
    FIL tmp, idx;
    uint32_t n = 0;
    diag_step(STEP_PLAYLIST_SCAN);
    f_mkdir("0:/.eplayer");
    if (f_open(&tmp, POD_TMP, FA_READ | FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) return 0;
    walk(&tmp, POD_DIR, 0, ents, &n);

    for (uint32_t i = 1; i < n; i++) {          /* insertion sort, stable     */
        ent_t e = ents[i];
        uint32_t j = i;
        while (j && strcmp(ents[j - 1].key, e.key) > 0) { ents[j] = ents[j - 1]; j--; }
        ents[j] = e;
    }
    uint32_t written = 0;
    if (f_open(&idx, POD_IDX, FA_WRITE | FA_CREATE_ALWAYS) == FR_OK) {
        char line[POD_PATH];
        for (uint32_t i = 0; i < n; i++) {
            if (f_lseek(&tmp, ents[i].off) != FR_OK || !f_gets(line, sizeof line, &tmp)) continue;
            f_puts(line, &idx);
            written++;
        }
        f_close(&idx);
    }
    f_close(&tmp);
    f_unlink(POD_TMP);
    return written;
}

uint32_t podcast_refresh(void)
{
    if (!settings_mounted()) { s_count = 0; return 0; }
    if (s_seen_mount != settings_mount_seq()) {
        s_seen_mount = settings_mount_seq();
        s_count = rebuild();
    }
    return s_count;
}

bool podcast_entry(uint32_t n, char *path, uint32_t len)
{
    if (n >= s_count) return false;
    FIL f;
    if (f_open(&f, POD_IDX, FA_READ) != FR_OK) return false;
    bool ok = false;
    for (uint32_t at = 0; at <= n; at++) {      /* <= 200 short lines        */
        if (!f_gets(path, (int)len, &f)) break;
        ok = (at == n);
    }
    f_close(&f);
    if (!ok) return false;
    char *nl = strpbrk(path, "\r\n");
    if (nl) *nl = '\0';
    return true;
}
