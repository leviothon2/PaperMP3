/**
 * @file    usb_descriptors.c
 * @brief   TinyUSB descriptor sets. Two mutually-exclusive personalities
 *          selected by g_usb_mode before tud_init():
 *            1 = MSC (mass storage, raw microSD)
 *            2 = UAC2 (stereo 16/24-bit, 44.1/48 kHz "USB DAC")
 *          Different PIDs so hosts don't cache the wrong configuration.
 */
#include "tusb.h"
#include "usb_descriptors.h"
#include "stm32u5xx.h"
#include <string.h>

extern volatile uint8_t g_usb_mode;

#define USB_VID   0xCAFE            /* replace with a real VID for production */
#define USB_PID_MSC 0x4001
#define USB_PID_DAC 0x4002

/* ---- device ------------------------------------------------------------ */

static tusb_desc_device_t const desc_device = {
    .bLength            = sizeof(tusb_desc_device_t),
    .bDescriptorType    = TUSB_DESC_DEVICE,
    .bcdUSB             = 0x0200,
    .bDeviceClass       = 0x00,
    .bDeviceSubClass    = 0x00,
    .bDeviceProtocol    = 0x00,
    .bMaxPacketSize0    = CFG_TUD_ENDPOINT0_SIZE,
    .idVendor           = USB_VID,
    .idProduct          = USB_PID_MSC,
    .bcdDevice          = 0x0100,
    .iManufacturer      = 1,
    .iProduct           = 2,
    .iSerialNumber      = 3,
    .bNumConfigurations = 1,
};

uint8_t const *tud_descriptor_device_cb(void)
{
    static tusb_desc_device_t d;
    d = desc_device;
    d.idProduct = (g_usb_mode == 2) ? USB_PID_DAC : USB_PID_MSC;
    return (uint8_t const *)&d;
}

/* ---- configuration ------------------------------------------------------- */

enum { ITF_NUM_MSC = 0, ITF_NUM_MSC_TOTAL };

#define EPNUM_MSC_OUT  0x01
#define EPNUM_MSC_IN   0x81

#define CONFIG_MSC_LEN (TUD_CONFIG_DESC_LEN + TUD_MSC_DESC_LEN)

static uint8_t const desc_cfg_msc[] = {
    TUD_CONFIG_DESCRIPTOR(1, ITF_NUM_MSC_TOTAL, 0, CONFIG_MSC_LEN,
                          0x80, 100),
    TUD_MSC_DESCRIPTOR(ITF_NUM_MSC, 0, EPNUM_MSC_OUT, EPNUM_MSC_IN, 64),
};

/* UAC2: speaker topology, async, 1 clock source, 44.1/48 k, 24-in-32.
 * The descriptor macro lives in usb_descriptors.h (TinyUSB 0.17 ships it
 * only as example code, v1 assumed it was part of the library).          */
#define EPNUM_AUDIO_OUT   0x02
#define EPNUM_AUDIO_FB    0x82

static uint8_t const desc_cfg_dac[] = {
    TUD_CONFIG_DESCRIPTOR(1, 2, 0, TUD_CONFIG_DESC_LEN +
                          CFG_TUD_AUDIO_FUNC_1_DESC_LEN, 0x80, 100),
    TUD_AUDIO_SPEAKER_STEREO_FB_DESCRIPTOR(
        /*itfnum*/ 0, /*stridx*/ 2,
        /*bytes/sample*/ 4, /*bits used*/ 24,
        /*ep out*/ EPNUM_AUDIO_OUT, /*ep size*/ CFG_TUD_AUDIO_FUNC_1_EP_OUT_SZ_MAX,
        /*ep feedback*/ EPNUM_AUDIO_FB, /*fb size*/ 4),
};

uint8_t const *tud_descriptor_configuration_cb(uint8_t index)
{
    (void)index;
    return (g_usb_mode == 2) ? desc_cfg_dac : desc_cfg_msc;
}

/* ---- strings ---------------------------------------------------------------- */

static char const *string_desc_arr[] = {
    (const char[]){ 0x09, 0x04 },        /* 0: English (US)               */
    "eink-mp3",                          /* 1: manufacturer               */
    "E-ink MP3 Player",                  /* 2: product                    */
    NULL,                                /* 3: serial = chip UID (below)  */
};

uint16_t const *tud_descriptor_string_cb(uint8_t index, uint16_t langid)
{
    (void)langid;
    static uint16_t desc_str[32];
    uint8_t len;

    if (index == 0) {
        memcpy(&desc_str[1], string_desc_arr[0], 2);
        len = 1;
    } else {
        if (index >= sizeof string_desc_arr / sizeof string_desc_arr[0])
            return NULL;
        if (index == 3) {
            /* Serial = 96-bit unique device ID, hex - lets a host keep
             * per-device settings for several players.                   */
            static const char hex[] = "0123456789ABCDEF";
            const uint32_t uid[3] = { *(const uint32_t *)UID_BASE,
                                      *(const uint32_t *)(UID_BASE + 4),
                                      *(const uint32_t *)(UID_BASE + 8) };
            len = 24;
            for (uint8_t i = 0; i < 24; i++)
                desc_str[1 + i] = (uint16_t)hex[(uid[i / 8] >> (28 - 4 * (i % 8))) & 0xF];
        } else {
            const char *s = string_desc_arr[index];
            len = (uint8_t)strlen(s);
            if (len > 31) len = 31;
            for (uint8_t i = 0; i < len; i++) desc_str[1 + i] = (uint16_t)s[i];
        }
    }
    desc_str[0] = (uint16_t)((TUSB_DESC_STRING << 8) | (2 * len + 2));
    return desc_str;
}
