/**
 * @file    fuelgauge.h
 * @brief   Optional coulomb-counting fuel gauge (2.6.0, default off).
 *
 * Off: the battery icon follows the cell voltage (open-circuit-voltage
 * table) exactly as before, and nothing extra runs.
 * On: once a second while awake the nPM1300 samples battery voltage AND
 * current; the charge that flowed is integrated into a remaining-capacity
 * figure, which is what the icon fill and the percentage next to it show.
 * Corrections:
 *   - start: OCV estimate (voltage corrected by I x 0.15 ohm),
 *   - charger reports "complete": 100 %,
 *   - after >= 1 h asleep (cell rested): re-sync to the rested OCV,
 *   - below 3.35 V under load: capped at 3 %.
 * Sleep time is measured with the RTC; sleep current is assumed constant.
 * The remaining capacity is kept in an RTC backup register, so it
 * survives resets and firmware updates (not a full power loss).
 * Cost: one I2C + ADC conversion per second while awake - a small but
 * real drain, hence optional.
 */
#ifndef FUELGAUGE_H
#define FUELGAUGE_H

#include <stdbool.h>
#include <stdint.h>

void fuelgauge_enable(bool on, uint16_t capacity_mah);
bool fuelgauge_enabled(void);
void fuelgauge_poll(void);                 /* main loop; self-paced 1 s   */
int  fuelgauge_percent(void);              /* 0..100, -1 = not available  */
void fuelgauge_before_sleep(void);
void fuelgauge_after_wake(void);

#endif /* FUELGAUGE_H */
