/**
 * @file    player.h
 * @brief   Playback state machine: track lifecycle, next/prev, resume,
 *          decode pump and power management.
 *
 * States: STOPPED, PLAYING, PAUSED. PAUSED has two hidden sub-states -
 * output live (DAC muted, ring kept) and no output (after a wake, or after
 * 30 s paused); the next play press starts the DAC in the latter case.
 *
 * Every state or track change bumps player_seq() (and player_track_seq()
 * for a new track), which the UI polls - the player never has to call
 * into the UI, and the UI can't miss a change it didn't cause.
 */
#ifndef PLAYER_H
#define PLAYER_H

#include <stdbool.h>
#include <stdint.h>
#include "../audio/tags.h"

typedef enum {
    PLAYER_STOPPED, PLAYER_PLAYING, PLAYER_PAUSED,
} player_state_t;

typedef enum {
    PLAYER_ERR_NONE,
    PLAYER_ERR_NO_MUSIC,       /* playlist empty / missing / unplayable   */
    PLAYER_ERR_OUTPUT,         /* DAC or I2S clock not working            */
    PLAYER_ERR_BUSY,           /* USB storage or DAC owns the card/audio  */
    PLAYER_ERR_NO_HEADPHONES,  /* 2.7.0: jack empty - loaded, not playing */
} player_err_t;

void player_init(void);

/* Context = playlist file name ("" = all songs) + position + order.      */
bool player_play(const char *playlist_file, uint32_t track_pos, bool shuffle);
bool player_resume_last(void);        /* SW1 long press                   */
void player_toggle_pause(void);
void player_next(void);               /* user skip (ignores repeat-one)   */
void player_prev(void);               /* restarts track if > 3 s in       */
void player_stop(void);
void player_volume_delta(int8_t d);   /* +-1 per key repeat               */

player_state_t player_state(void);
const track_tags_t *player_tags(void);
const uint8_t *player_art(void);      /* ART_SIZE^2 gray or NULL          */
uint32_t player_pos_ms(void);         /* what you HEAR (buffer subtracted)*/
uint32_t player_len_ms(void);
uint32_t player_track_pos(void);
const char *player_playlist_file(void);
bool     player_shuffled(void);       /* current context is shuffled      */

uint32_t     player_seq(void);        /* any state/track change           */
uint32_t     player_track_seq(void);  /* a different track was loaded     */
player_err_t player_take_error(void); /* last error, cleared on read      */

/* ---- 2.7.0 ------------------------------------------------------------- */

/* Headphone gate (Device settings > Headphone detect): with the jack
 * empty a track still loads - title, art, position - but stays paused,
 * and play does nothing until headphones are in. Unplugging pauses.      */
bool player_output_allowed(void);

/* Queue = the entries of the current list after the playing one.         */
uint32_t player_queue_count(void);
bool     player_queue_title(uint32_t n, char *buf, uint32_t len);
bool     player_jump(uint32_t queue_n);   /* play the n-th upcoming entry */

/* Loop the current song (repeat one); off returns to the Repeat setting
 * that was active before.                                                */
void player_set_loop(bool on);
bool player_loop(void);

/* Remove the playing song from its /Playlists file on the card and move
 * on to the next one. Only for playlist files.                           */
bool player_can_remove(void);
bool player_remove_current(void);

/* Podcasts: the current list is the /Podcasts list. Speed is the global
 * settings.pod_speed; call player_speed_changed() after changing it.     */
bool player_is_podcast(void);
void player_speed_changed(void);

/* Sleep timer. minutes = 0 switches it off. When it runs out the player
 * fades (settings.timer_fade_s) and pauses - or lets the song finish
 * first (settings.timer_song_end) - and asks for system sleep.           */
void    player_timer_set(uint8_t minutes);
uint8_t player_timer_minutes(void);       /* as set, not remaining; 0 off */
bool    player_take_sleep_request(void);

/* System sleep (power.c): save + close files / re-open paused.
 * same_card = false when a different SD card is in after the wake.      */
void player_prepare_sleep(void);
void player_after_wake(bool same_card);

/* Storage events (card removed / USB storage takes the card).           */
void player_storage_lost(void);

/* Superloop hooks                                                         */
void player_poll(void);               /* decode pump (also from e-ink idle)*/
void player_power_poll(void);         /* codec IRQ, SD card detect        */
bool player_busy(void);               /* true = skip WFI this lap         */

#endif /* PLAYER_H */
