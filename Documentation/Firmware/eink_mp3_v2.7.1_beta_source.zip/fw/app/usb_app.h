/**
 * @file    usb_app.h
 * @brief   USB device logic (TinyUSB): mass storage (raw microSD) or
 *          UAC2 "USB DAC" - selected via an on-screen prompt when USB power
 *          appears (any source: computer, charger, power bank), or forced by
 *          the Settings > USB preference.
 *
 * Storage and DAC fall back to charge-only when no computer enumerates the
 * device within a few seconds (wall chargers), and storage returns to the
 * player when the computer ejects the drive.
 */
#ifndef USB_APP_H
#define USB_APP_H

#include <stdbool.h>

typedef enum { USB_OFF, USB_PROMPT, USB_MSC, USB_DAC, USB_CHARGE } usb_state_t;

void usb_app_init(void);
void usb_app_poll(void);          /* call every superloop lap             */
void usb_app_service(void);       /* stack + DAC pump only (e-ink idle)   */
usb_state_t usb_app_state(void);
bool usb_app_active(void);        /* storage/DAC running: blocks sleep    */
bool usb_app_busy(void);          /* storage or DAC owns card/audio       */
bool usb_app_storage_owned(void); /* host has the raw SD card             */
void usb_app_prepare_sleep(void); /* close an open prompt before sleep    */
void usb_app_vbus_replugged(void);/* wake was a fresh plug-in: re-prompt  */
void usb_app_shutdown(void);      /* clean disconnect before a reset      */

#endif /* USB_APP_H */
