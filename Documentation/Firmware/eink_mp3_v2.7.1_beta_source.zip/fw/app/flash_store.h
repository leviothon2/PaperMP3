#pragma once
/* Settings in internal flash (dt-0.2.0).
 *
 * dt-0.1.0 kept settings only on the SD card - which never mounted on the test board, so nothing
 * could be kept, least of all the SD bus settings needed to make the card work. The firmware is now
 * limited to 504 KB (linker script) and the last 8 KB page of the running bank (0x0807E000) is a
 * small log of 256-byte records:
 *
 *   quadword 0      magic 'DTS1', sequence, layout|length, CRC-32 of the payload
 *   quadwords 1-15  payload (<= 240 bytes)
 *
 * A save programs quadwords 1-15 of the next blank slot first and quadword 0 last, so a record
 * without its header is never taken as valid; the newest valid sequence wins. 32 saves per page
 * erase (10k cycle endurance: ~320k saves). A reset in the middle of a program can leave a double
 * ECC error; reading it raises an NMI that diag.c acknowledges for this page only, and the record is
 * then skipped. The other bank's copy is never touched: after an SD firmware install or rollback the
 * new image starts with whatever its own bank holds (usually nothing -> defaults, then settings.txt
 * from the card if it mounts). */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define FLASH_STORE_ADDR     0x0807E000u
#define FLASH_STORE_PAYLOAD  240u

typedef struct {
    uint32_t seq;           /* sequence of the record loaded / last written (0: none) */
    uint8_t  slot;          /* its slot 0..31                                           */
    uint8_t  used;          /* slots in use (incl. damaged)                             */
    uint8_t  damaged;       /* slots skipped: header without valid CRC or ECC NMI       */
    bool     erase_failed, write_failed;
} flash_store_info_t;

/* Newest valid record with this layout id: copied into `out` (len bytes). false = none.        */
bool flash_store_load(void *out, size_t len, uint16_t layout);
bool flash_store_save(const void *data, size_t len, uint16_t layout);
bool flash_store_erase(void);
const flash_store_info_t *flash_store_info(void);
