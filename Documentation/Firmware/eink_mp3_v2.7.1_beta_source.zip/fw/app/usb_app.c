/**
 * @file    usb_app.c
 * @brief   TinyUSB device glue: VBUS-triggered mode prompt, MSC backed by
 *          raw SD blocks, UAC2 streaming into the audio pipeline.
 *
 * Mode flow:
 *   VBUS present (nPM1300)  -> input-current limit from CC, prompt
 *   user picks storage/DAC/charge -> tud_init with the right descriptor
 *   set (usb_descriptors.c switches on g_usb_mode)
 *   no enumeration within USB_ENUM_TIMEOUT_MS (a charger, not a computer)
 *   -> charge-only; storage ejected by the host -> charge-only (player
 *   usable again, card remounted).
 *
 * VBUS is checked on the very first superloop lap, so with a cable already
 * in at power-up the prompt is the first screen (v2.2 showed the menu and
 * popped the prompt up ~2 s later from the slow safety poll).
 *
 * MSC: the host gets the raw card. FatFs is unmounted first and the
 * player stops - concurrent access would corrupt the filesystem.
 * On detach the card is re-mounted and the "Play all" cache invalidated
 * (the host may have added or removed music).
 *
 * UAC2: 44.1/48/88.2/96 kHz, 24-in-32-bit stereo, asynchronous with a feedback
 * endpoint. TinyUSB computes the feedback from its own FIFO fill level
 * ("FIFO count" method), so audio is pulled from that FIFO only as fast
 * as the DAC consumes it - the FIFO level then tracks the clock offset
 * between host and DAC crystal. (v1 drained the FIFO in the RX callback,
 * which pinned it at empty and made the feedback meaningless.)
 * 2.6.0: every rate is played natively (no resampling).
 *
 * V2: VDDUSB is the switched 3.3 V rail - it is (re)validated here every
 * time a USB personality starts, and invalidated by power.c before sleep.
 */
#include "usb_app.h"
#include "ui.h"
#include "player.h"
#include "playlist.h"
#include "settings.h"
#include "power.h"
#include "diag.h"
#include "board.h"
#include "../drivers/npm1300.h"
#include "../drivers/sdcard.h"
#include "../drivers/cs43131.h"
#include "../audio/audio_pipeline.h"
#include "stm32u5xx_hal.h"

#include "tusb.h"
#include <string.h>

volatile uint8_t g_usb_mode;             /* read by usb_descriptors.c     */

#define USB_ENUM_TIMEOUT_MS  6000u       /* no host by then = charger     */

static usb_state_t s_state = USB_OFF;
static uint32_t    s_vbus_poll_t;
static bool        s_tud_up;
static bool        s_first_poll = true;
static uint32_t    s_enter_t;
static bool        s_was_mounted;
static volatile bool s_eject_req;
static bool        s_in_service;
static uint8_t     s_absent_reads;       /* VBUS-gone debounce            */
static bool        s_vbus_seen;          /* last VBUS reading: present    */
/* 2.5.1: last VBUS status the input-current limit was applied for.
 * NPM_ILIM_UNKNOWN forces the next check to apply it (boot, after sleep). */
#define NPM_ILIM_UNKNOWN 0xFFu
static uint8_t     s_ilim_st = NPM_ILIM_UNKNOWN;
#define VBUS_RECHECK_MS  300u            /* confirm a removal this soon   */

#if BOARD_PC3_PMIC_IRQ
/* VBUS changes arrive as nPM1300 interrupts on PC3. 2.6.4: the timed
 * poll runs only while USB is plugged in (removal safety net + USB-C
 * current advertisement changes); unplugged, a plug-in is seen by its
 * interrupt alone.                                                       */
#define VBUS_POLL_MS     2000u
#else
#define VBUS_POLL_MS     500u
#endif

/* ---- PHY / stack ------------------------------------------------------------ */

static void usb_phy_enable(void)
{
    /* U575 = OTG-FS (DWC2), device mode only on this board.              */
    __HAL_RCC_PWR_CLK_ENABLE();
    HAL_PWREx_EnableVddUSB();

    GPIO_InitTypeDef g = { 0 };
    g.Mode      = GPIO_MODE_AF_PP;
    g.Pull      = GPIO_NOPULL;
    g.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    g.Alternate = USB_AF;
    g.Pin       = USB_DM_PIN | USB_DP_PIN;
    HAL_GPIO_Init(GPIOA, &g);

    __HAL_RCC_USB_OTG_FS_CLK_ENABLE();
    HAL_NVIC_SetPriority(OTG_FS_IRQn, 6, 0);
    HAL_NVIC_EnableIRQ(OTG_FS_IRQn);
}

static void usb_stack_stop(void)
{
    if (!s_tud_up) return;
    tud_disconnect();
    tud_deinit(0);
    HAL_NVIC_DisableIRQ(OTG_FS_IRQn);
    __HAL_RCC_USB_OTG_FS_CLK_DISABLE();
    GPIO_InitTypeDef g = { 0 };
    g.Mode = GPIO_MODE_ANALOG;
    g.Pin  = USB_DM_PIN | USB_DP_PIN;
    HAL_GPIO_Init(GPIOA, &g);
    s_tud_up = false;
}

static void enter_mode(usb_state_t mode)
{
    s_enter_t = HAL_GetTick();
    s_was_mounted = false;
    s_eject_req = false;
    if (mode == USB_MSC) {
        diag_step(STEP_USB_ENTER_MSC);
        player_stop();
        settings_flush();
        /* Hand the raw card to the host - unmount our filesystem view.   */
        settings_unmount();
        s_state = mode;
        g_usb_mode = 1;
        usb_phy_enable();
        s_tud_up = tud_init(0);
    } else if (mode == USB_DAC) {
        diag_step(STEP_USB_ENTER_DAC);
        player_stop();
        s_state = mode;
        g_usb_mode = 2;
        usb_phy_enable();
        s_tud_up = tud_init(0);
        /* v2.4: no pipe_start here - the DAC/HP amp powers up when the
         * host starts streaming (uac_pump), not at plug-in.              */
    } else {
        /* USB_CHARGE: nothing to do - nPM1300 charges autonomously.      */
        diag_step(STEP_USB_ENTER_CHARGE);
        s_state = mode;
    }
    ui_usb_mode_changed();
}

/* Storage/DAC personality off; card back to the player.                  */
static void stop_personality(void)
{
    diag_step(STEP_USB_LEAVE);
    bool was_msc = (s_state == USB_MSC);
    usb_stack_stop();
    if (s_state == USB_DAC) pipe_stop();
    if (was_msc) {
        s_state = USB_CHARGE;            /* storage no longer owned       */
        /* settings_mount() re-reads settings.txt (the host may have
         * edited it), re-lists playlists and marks Play all stale.       */
        if (sdcard_ready() || settings_card_start()) settings_mount();
    }
}

static void fall_back_to_charge(const char *why)
{
    stop_personality();
    s_state = USB_CHARGE;
    ui_usb_mode_changed();
    ui_toast(why);
}

static void leave_mode(void)
{
    if (s_state == USB_MSC || s_state == USB_DAC) stop_personality();
    ui_close_usb_prompt();
    s_state = USB_OFF;
    ui_usb_mode_changed();
}

void usb_app_init(void)
{
    s_state = USB_OFF;
    s_first_poll = true;
}

usb_state_t usb_app_state(void) { return s_state; }

void usb_app_shutdown(void)
{
    if (s_tud_up) {
        tud_disconnect();                /* host sees a clean unplug      */
        HAL_Delay(100);
    }
}

void usb_app_prepare_sleep(void)
{
    /* Only the prompt / charge-only states can reach sleep (storage and
     * DAC block it). An unanswered prompt is closed - it re-opens on wake
     * because VBUS is still there; "charge only" is kept so a button wake
     * while charging doesn't ask again.                                  */
    if (s_state == USB_PROMPT) {
        ui_close_usb_prompt();
        s_state = USB_OFF;
    }
    s_ilim_st = NPM_ILIM_UNKNOWN;    /* re-apply the input limit on wake  */
}

void usb_app_vbus_replugged(void)
{
    /* Cable was pulled and re-inserted while asleep: treat as new.       */
    if (s_state == USB_CHARGE) s_state = USB_OFF;
    s_first_poll = true;            /* check now and re-apply the limit   */
}

/* ---- UAC2 streaming (main-loop context) ------------------------------------- */

#if CFG_TUD_AUDIO
static volatile uint32_t s_uac_rate = 44100;
static volatile bool     s_uac_rate_changed;
static volatile bool     s_uac_streaming;

static void uac_pump(void)
{
    if (s_uac_rate_changed) {
        s_uac_rate_changed = false;
        if (pipe_mode() != PIPE_IDLE) {   /* restart only if running      */
            pipe_start_pcm(s_uac_rate);   /* resampler handles 48 k       */
            cs43131_set_volume(settings_get()->volume);
        }
    }
    if (s_uac_streaming && pipe_mode() == PIPE_IDLE) {
        pipe_start_pcm(s_uac_rate);       /* first stream: amp up now     */
        cs43131_set_volume(settings_get()->volume);
    }
    if (!s_uac_streaming || pipe_mode() != PIPE_PCM) return;

    /* Keep ~25 ms in the DAC ring; the rest waits in TinyUSB's FIFO so
     * its fill level drives the feedback endpoint.                       */
    static uint8_t buf[192 * 8];          /* 192 frames x 8 bytes         */
    static int32_t frames[192 * 2];
    const uint32_t target = s_uac_rate / 40u;
    for (;;) {
        uint32_t fill = pipe_fill_frames();
        if (fill >= target) break;
        uint16_t avail = tud_audio_available();
        if (avail < 8) break;
        uint16_t n = tud_audio_read(buf, avail < sizeof buf ? (avail & ~7u)
                                                            : sizeof buf);
        uint32_t nf = n / 8u;
        for (uint32_t i = 0; i < nf * 2; i++) {
            const uint8_t *p = &buf[i * 4];
            frames[i] = (int32_t)((uint32_t)p[0] | ((uint32_t)p[1] << 8) |
                                  ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24));
        }
        /* 2.7.0 headphone gate: the stream is still consumed (the host's
         * feedback loop needs that) but silence goes to the DAC.          */
        if (!player_output_allowed()) memset(frames, 0, nf * 2u * sizeof frames[0]);
        pipe_push_pcm(frames, nf);
        if (!nf) break;
    }
}
#endif

/* ---- poll ---------------------------------------------------------------------- */

void usb_app_service(void)
{
    if (!s_tud_up || s_in_service) return;
    s_in_service = true;
    uint32_t step = g_diag_step;
    diag_step(STEP_USB_TASK);
    tud_task();
#if CFG_TUD_AUDIO
    if (s_state == USB_DAC) uac_pump();
#endif
    g_diag_step = step;
    s_in_service = false;
}

void usb_app_poll(void)
{
    uint32_t now = HAL_GetTick();

    /* VBUS state: first lap, on a PMIC interrupt (PC3), or every
     * VBUS_POLL_MS.                                                      */
    bool irq = s_first_poll;
    s_first_poll = false;
#if BOARD_PC3_PMIC_IRQ
    if (g_pmic_irq_pending) {
        g_pmic_irq_pending = false;
        (void)npm1300_take_vbus_events();   /* clears + drops the line    */
        irq = true;
    }
#endif
    bool recheck = s_absent_reads && now - s_vbus_poll_t >= VBUS_RECHECK_MS;
#if BOARD_PC3_PMIC_IRQ
    bool timed = s_vbus_seen && now - s_vbus_poll_t >= VBUS_POLL_MS;
#else
    bool timed = now - s_vbus_poll_t >= VBUS_POLL_MS;   /* no IRQ line    */
#endif
    if (irq || recheck || timed) {
        s_vbus_poll_t = now;
#if !BOARD_PC3_PMIC_IRQ
        /* No interrupt line: a plug-in between two polls still latches
         * the PMIC's VBUS-detected event - treat it like the interrupt.  */
        if (npm1300_take_vbus_events() & NPM_EV_VBUS_DETECTED) irq = true;
#endif
        npm_vbus_t st;
        if (npm1300_vbus_read(&st)) {          /* failed read = no change  */
            bool vbus = st != NPM_VBUS_NONE;
            /* 2.6.4: the input limit is written when it can have
             * changed - plug-in / PMIC interrupt, a different USB-C
             * current advertisement, or the first check after boot or
             * sleep - not on every 2 s poll (2.6.1-2.6.3). 2.6.2 showed
             * the USB-menu hang came from the register e-ink waveform,
             * not from this. A replug always raises the VBUS interrupt,
             * which re-applies it over the nPM1300's ~100 mA default.   */
            s_vbus_seen = vbus;
            if (vbus && (irq || (uint8_t)st != s_ilim_st)) {
                npm1300_apply_vbus_limit(st);
                s_ilim_st = (uint8_t)st;
            } else if (!vbus) {
                s_ilim_st = NPM_ILIM_UNKNOWN;  /* next plug-in re-applies  */
            }

            if (vbus) {
                s_absent_reads = 0;
                if (s_state == USB_OFF) {
                    power_note_activity();
                    diag_step(STEP_USB_PROMPT);
                    s_state = USB_PROMPT;
                    ui_show_usb_prompt();      /* may return a fixed preference */
                }
            } else if (s_state != USB_OFF) {
                /* Leave only after two "gone" readings 300 ms apart, so a
                 * glitch never tears down a mode and re-asks the question. */
                if (++s_absent_reads >= 2) {
                    s_absent_reads = 0;
                    power_note_activity();
                    leave_mode();              /* detach: restore the player */
                }
            }
        }
    }

    if (s_state == USB_PROMPT) {
        switch (ui_usb_choice()) {
        case UI_USB_MSC:    enter_mode(USB_MSC);    break;
        case UI_USB_DAC:    enter_mode(USB_DAC);    break;
        case UI_USB_CHARGE: enter_mode(USB_CHARGE); break;
        default: break;                  /* still waiting on the user     */
        }
    }

    usb_app_service();

    /* No computer on the other end (charger / power bank): don't hold the
     * player hostage - fall back to charge-only.                         */
    if (s_state == USB_MSC || s_state == USB_DAC) {
        if (tud_mounted()) s_was_mounted = true;
        if (!s_was_mounted && now - s_enter_t >= USB_ENUM_TIMEOUT_MS)
            fall_back_to_charge("No computer - charging");
        else if (s_state == USB_MSC && s_eject_req)
            fall_back_to_charge("Storage ejected");
    }
}

bool usb_app_active(void) { return s_state == USB_MSC || s_state == USB_DAC; }
bool usb_app_busy(void) { return usb_app_active(); }
bool usb_app_storage_owned(void) { return s_state == USB_MSC; }

/* ====================================================================== *
 *  TinyUSB MSC callbacks - raw microSD passthrough
 * ====================================================================== */
#if CFG_TUD_MSC

uint8_t tud_msc_get_maxlun_cb(void) { return 1; }

void tud_msc_inquiry_cb(uint8_t lun, uint8_t vendor_id[8],
                        uint8_t product_id[16], uint8_t product_rev[4])
{
    (void)lun;
    memcpy(vendor_id,  "EINKMP3 ", 8);
    memcpy(product_id, "microSD         ", 16);
    memcpy(product_rev, "2.0 ", 4);
}

bool tud_msc_test_unit_ready_cb(uint8_t lun)
{
    (void)lun;
    return sdcard_ready() || sdcard_init();
}

void tud_msc_capacity_cb(uint8_t lun, uint32_t *block_count,
                         uint16_t *block_size)
{
    (void)lun;
    *block_count = sdcard_block_count();
    *block_size  = (uint16_t)sdcard_block_size();
}

int32_t tud_msc_read10_cb(uint8_t lun, uint32_t lba, uint32_t offset,
                          void *buffer, uint32_t bufsize)
{
    (void)lun; (void)offset;             /* whole-block transfers only    */
    uint32_t nblk = bufsize / 512;
    if (!nblk || !sdcard_read(buffer, lba, nblk)) return -1;
    power_note_activity();
    return (int32_t)(nblk * 512);
}

int32_t tud_msc_write10_cb(uint8_t lun, uint32_t lba, uint32_t offset,
                           uint8_t *buffer, uint32_t bufsize)
{
    (void)lun; (void)offset;
    uint32_t nblk = bufsize / 512;
    if (!nblk || !sdcard_write(buffer, lba, nblk)) return -1;
    power_note_activity();
    return (int32_t)(nblk * 512);
}

bool tud_msc_start_stop_cb(uint8_t lun, uint8_t power_condition,
                           bool start, bool load_eject)
{
    (void)lun; (void)power_condition;
    /* "Eject" in the host's file manager = START STOP UNIT with LoEj=1,
     * Start=0: hand the card back to the player.                         */
    if (load_eject && !start) s_eject_req = true;
    return true;
}

int32_t tud_msc_scsi_cb(uint8_t lun, uint8_t const scsi_cmd[16],
                        void *buffer, uint16_t bufsize)
{
    (void)buffer; (void)bufsize;
    /* Unsupported command: report ILLEGAL REQUEST / INVALID COMMAND so
     * the host stops retrying it.                                        */
    (void)scsi_cmd;
    tud_msc_set_sense(lun, SCSI_SENSE_ILLEGAL_REQUEST, 0x20, 0x00);
    return -1;
}
#endif /* CFG_TUD_MSC */

/* ====================================================================== *
 *  TinyUSB UAC2 callbacks - USB DAC
 * ====================================================================== */
#if CFG_TUD_AUDIO

/* 2.6.0: up to 96 kHz (full-speed USB: 96 k x 2 ch x 4 B = 768 B/ms, the
 * most a 1023-byte isochronous packet carries); every rate plays
 * natively on the DAC (48 k family via its PLL).                         */
static const uint32_t k_rates[] = { 44100, 48000, 88200, 96000 };
#define N_RATES (sizeof k_rates / sizeof k_rates[0])

static int8_t  s_mute[3];
static int16_t s_vol[3];               /* 1/256 dB                        */

static bool clock_get(uint8_t rhport, audio_control_request_t const *req)
{
    if (req->bControlSelector == AUDIO_CS_CTRL_SAM_FREQ) {
        if (req->bRequest == AUDIO_CS_REQ_CUR) {
            audio_control_cur_4_t cur = { (int32_t)tu_htole32(s_uac_rate) };
            return tud_audio_buffer_and_schedule_control_xfer(rhport,
                    (tusb_control_request_t const *)req, &cur, sizeof cur);
        }
        if (req->bRequest == AUDIO_CS_REQ_RANGE) {
            audio_control_range_4_n_t(N_RATES) r = { .wNumSubRanges = tu_htole16(N_RATES) };
            for (unsigned i = 0; i < N_RATES; i++) {
                r.subrange[i].bMin = (int32_t)k_rates[i];
                r.subrange[i].bMax = (int32_t)k_rates[i];
                r.subrange[i].bRes = 0;
            }
            return tud_audio_buffer_and_schedule_control_xfer(rhport,
                    (tusb_control_request_t const *)req, &r, sizeof r);
        }
    } else if (req->bControlSelector == AUDIO_CS_CTRL_CLK_VALID &&
               req->bRequest == AUDIO_CS_REQ_CUR) {
        audio_control_cur_1_t v = { .bCur = 1 };
        return tud_audio_buffer_and_schedule_control_xfer(rhport,
                (tusb_control_request_t const *)req, &v, sizeof v);
    }
    return false;
}

static bool fu_get(uint8_t rhport, audio_control_request_t const *req)
{
    uint8_t ch = req->bChannelNumber < 3 ? req->bChannelNumber : 0;
    if (req->bControlSelector == AUDIO_FU_CTRL_MUTE && req->bRequest == AUDIO_CS_REQ_CUR) {
        audio_control_cur_1_t m = { .bCur = s_mute[ch] };
        return tud_audio_buffer_and_schedule_control_xfer(rhport,
                (tusb_control_request_t const *)req, &m, sizeof m);
    }
    if (req->bControlSelector == AUDIO_FU_CTRL_VOLUME) {
        if (req->bRequest == AUDIO_CS_REQ_RANGE) {
            audio_control_range_2_n_t(1) r = {
                .wNumSubRanges = tu_htole16(1),
                .subrange[0] = { .bMin = tu_htole16(-63 * 256), .bMax = 0,
                                 .bRes = tu_htole16(128) }
            };
            return tud_audio_buffer_and_schedule_control_xfer(rhport,
                    (tusb_control_request_t const *)req, &r, sizeof r);
        }
        if (req->bRequest == AUDIO_CS_REQ_CUR) {
            audio_control_cur_2_t v = { .bCur = tu_htole16(s_vol[ch]) };
            return tud_audio_buffer_and_schedule_control_xfer(rhport,
                    (tusb_control_request_t const *)req, &v, sizeof v);
        }
    }
    return false;
}

static void apply_host_volume(void)
{
    /* Host master volume (0 .. -63 dB) -> the DAC's 0..100 scale.        */
    if (s_mute[0]) { cs43131_set_volume(0); return; }
    int32_t db256 = s_vol[0];
    if (db256 < -63 * 256) db256 = -63 * 256;
    if (db256 > 0) db256 = 0;
    cs43131_set_volume((uint8_t)(100 + (db256 * 100) / (63 * 256 + 1) ));
}

bool tud_audio_get_req_entity_cb(uint8_t rhport, tusb_control_request_t const *p_request)
{
    audio_control_request_t const *req = (audio_control_request_t const *)p_request;
    if (req->bEntityID == UAC2_ENTITY_CLOCK)        return clock_get(rhport, req);
    if (req->bEntityID == UAC2_ENTITY_FEATURE_UNIT) return fu_get(rhport, req);
    return false;
}

bool tud_audio_set_req_entity_cb(uint8_t rhport, tusb_control_request_t const *p_request,
                                 uint8_t *buf)
{
    (void)rhport;
    audio_control_request_t const *req = (audio_control_request_t const *)p_request;
    if (req->bRequest != AUDIO_CS_REQ_CUR) return false;

    if (req->bEntityID == UAC2_ENTITY_CLOCK &&
        req->bControlSelector == AUDIO_CS_CTRL_SAM_FREQ &&
        req->wLength == sizeof(audio_control_cur_4_t)) {
        uint32_t r = (uint32_t)((audio_control_cur_4_t const *)buf)->bCur;
        if (r != s_uac_rate) { s_uac_rate = r; s_uac_rate_changed = true; }
        return true;
    }
    if (req->bEntityID == UAC2_ENTITY_FEATURE_UNIT) {
        uint8_t ch = req->bChannelNumber < 3 ? req->bChannelNumber : 0;
        if (req->bControlSelector == AUDIO_FU_CTRL_MUTE &&
            req->wLength == sizeof(audio_control_cur_1_t)) {
            s_mute[ch] = ((audio_control_cur_1_t const *)buf)->bCur;
            apply_host_volume();
            return true;
        }
        if (req->bControlSelector == AUDIO_FU_CTRL_VOLUME &&
            req->wLength == sizeof(audio_control_cur_2_t)) {
            s_vol[ch] = ((audio_control_cur_2_t const *)buf)->bCur;
            apply_host_volume();
            return true;
        }
    }
    return false;
}

bool tud_audio_set_itf_cb(uint8_t rhport, tusb_control_request_t const *p_request)
{
    (void)rhport;
    uint8_t const alt = tu_u16_low(tu_le16toh(p_request->wValue));
    s_uac_streaming = (alt != 0);
    return true;
}

bool tud_audio_set_itf_close_EP_cb(uint8_t rhport, tusb_control_request_t const *p_request)
{
    (void)rhport; (void)p_request;
    s_uac_streaming = false;
    return true;
}

void tud_audio_feedback_params_cb(uint8_t func_id, uint8_t alt_itf,
                                  audio_feedback_params_t *fb)
{
    (void)func_id; (void)alt_itf;
    fb->method      = AUDIO_FEEDBACK_METHOD_FIFO_COUNT;
    fb->sample_freq = s_uac_rate;
}
#endif /* CFG_TUD_AUDIO */
