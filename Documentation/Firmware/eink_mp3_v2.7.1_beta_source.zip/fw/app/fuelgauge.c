/**
 * @file    fuelgauge.c
 * @brief   Coulomb counter + OCV correction (see fuelgauge.h).
 */
#include "fuelgauge.h"
#include "../drivers/npm1300.h"
#include "stm32u5xx_hal.h"

#define FG_MAGIC          0xF6A70000u      /* BKP2R high half              */
#define FG_PERIOD_MS      1000u
#define FG_SAVE_MS        60000u
#define R_INTERNAL_MOHM   150              /* NP-BJ1-class cell + contacts */
#define SLEEP_UA          120              /* assumed Stop 2 battery drain */
#define REST_RESYNC_S     3600u

static bool     s_on;
static bool     s_valid;                   /* remaining is meaningful      */
static uint32_t s_cap_uah;
static int64_t  s_rem_uas;                 /* remaining charge, uA*s       */
static uint32_t s_last_t, s_last_save;
static uint32_t s_sleep_rtc;               /* RTC seconds at sleep entry   */

/* ---- persistence (RTC backup registers, keep through resets) ----------- */

static void bkp_save(void)
{
    __HAL_RCC_RTCAPB_CLK_ENABLE();
    TAMP->BKP2R = FG_MAGIC | (s_cap_uah / 1000u & 0xFFFFu);
    TAMP->BKP3R = (uint32_t)(s_rem_uas / 3600);           /* uAh           */
}

static bool bkp_load(void)
{
    __HAL_RCC_RTCAPB_CLK_ENABLE();
    uint32_t m = TAMP->BKP2R;
    if ((m & 0xFFFF0000u) != FG_MAGIC || (m & 0xFFFFu) != s_cap_uah / 1000u)
        return false;
    uint32_t uah = TAMP->BKP3R;
    if (uah > s_cap_uah) return false;
    s_rem_uas = (int64_t)uah * 3600;
    return true;
}

/* ---- helpers -------------------------------------------------------------- */

static uint32_t bcd(uint32_t v) { return (v >> 4) * 10u + (v & 0x0Fu); }

/* The RTC clock (LSI) is selected at boot in every build, but only the
 * PC3-pin-role build starts the calendar (power.c). Start it here if
 * nobody has - it is only used to time sleep periods.                   */
static void rtc_start(void)
{
    if (RCC->BDCR & RCC_BDCR_RTCEN) return;
    static RTC_HandleTypeDef h;
    __HAL_RCC_RTC_ENABLE();
    __HAL_RCC_RTCAPB_CLK_ENABLE();
    h.Instance            = RTC;
    h.Init.HourFormat     = RTC_HOURFORMAT_24;
    h.Init.AsynchPrediv   = 127;              /* LSI 32 kHz -> 1 Hz        */
    h.Init.SynchPrediv    = 249;
    h.Init.OutPut         = RTC_OUTPUT_DISABLE;
    h.Init.OutPutRemap    = RTC_OUTPUT_REMAP_NONE;
    h.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
    h.Init.OutPutType     = RTC_OUTPUT_TYPE_OPENDRAIN;
    h.Init.OutPutPullUp   = RTC_OUTPUT_PULLUP_NONE;
    h.Init.BinMode        = RTC_BINARY_NONE;
    h.Init.BinMixBcdU     = RTC_BINARY_MIX_BCDU_0;
    (void)HAL_RTC_Init(&h);
}

/* RTC calendar (LSI clocked, never set) as seconds; day-of-month wraps
 * are handled for one month, ample for sleep spans.                     */
static uint32_t rtc_seconds(void)
{
    uint32_t tr = RTC->TR;
    uint32_t dr = RTC->DR;                     /* unlocks the shadow regs  */
    uint32_t s  = bcd(tr & 0x7Fu);
    uint32_t m  = bcd((tr >> 8) & 0x7Fu);
    uint32_t h  = bcd((tr >> 16) & 0x3Fu);
    uint32_t d  = bcd(dr & 0x3Fu);
    return ((d * 24u + h) * 60u + m) * 60u + s;
}

static void set_from_ocv(uint16_t mv, int32_t ma_x10)
{
    /* Open-circuit estimate: discharge current pulls the terminal voltage
     * down by I x R, charge current pushes it up.                        */
    int32_t ocv = (int32_t)mv - (ma_x10 * R_INTERNAL_MOHM) / 10000;
    if (ocv < 0) ocv = 0;
    uint8_t pct = npm1300_soc_from_ocv((uint16_t)ocv);
    s_rem_uas = (int64_t)s_cap_uah * 36 * pct;            /* uAh*3600/100  */
    s_valid = true;
}

static void clamp(void)
{
    int64_t full = (int64_t)s_cap_uah * 3600;
    if (s_rem_uas > full) s_rem_uas = full;
    if (s_rem_uas < 0)    s_rem_uas = 0;
}

/* ---- API -------------------------------------------------------------------- */

void fuelgauge_enable(bool on, uint16_t capacity_mah)
{
    uint32_t cap = (uint32_t)capacity_mah * 1000u;
    if (on == s_on && cap == s_cap_uah) return;
    s_on = on;
    s_cap_uah = cap;
    s_valid = false;
    if (!on) return;
    rtc_start();
    (void)npm1300_fg_setup();
    if (bkp_load()) s_valid = true;            /* carry on after a reset   */
    s_last_t = HAL_GetTick() - FG_PERIOD_MS;   /* sample now              */
    s_last_save = HAL_GetTick();
}

bool fuelgauge_enabled(void) { return s_on; }

void fuelgauge_poll(void)
{
    if (!s_on) return;
    uint32_t now = HAL_GetTick();
    uint32_t dt = now - s_last_t;
    if (dt < FG_PERIOD_MS) return;
    s_last_t = now;

    uint16_t mv;
    int32_t  ma_x10;
    if (!npm1300_fg_sample(&mv, &ma_x10)) return;
    if (mv < 2500 || mv > 4500) { s_valid = false; return; }   /* no cell */

    if (!s_valid) {
        set_from_ocv(mv, ma_x10);
    } else {
        /* integrate: mA x10 * ms -> uA*s = ma_x10 * 100 * dt / 1000      */
        s_rem_uas += (int64_t)ma_x10 * (int64_t)dt / 10;
        uint8_t st = 0;
        if (npm1300_charge_status(&st) && (st & 0x02u))        /* complete */
            s_rem_uas = (int64_t)s_cap_uah * 3600;
        if (mv < 3350 && ma_x10 < 0) {
            int64_t cap3 = (int64_t)s_cap_uah * 36 * 3;       /* 3 %       */
            if (s_rem_uas > cap3) s_rem_uas = cap3;
        }
        clamp();
    }
    if (now - s_last_save >= FG_SAVE_MS) { s_last_save = now; bkp_save(); }
}

int fuelgauge_percent(void)
{
    if (!s_on || !s_valid || !s_cap_uah) return -1;
    int64_t pct = (s_rem_uas * 100 + (int64_t)s_cap_uah * 1800) /
                  ((int64_t)s_cap_uah * 3600);
    if (pct > 100) pct = 100;
    if (pct < 0)   pct = 0;
    return (int)pct;
}

void fuelgauge_before_sleep(void)
{
    if (!s_on) return;
    s_sleep_rtc = rtc_seconds();
    bkp_save();
}

void fuelgauge_after_wake(void)
{
    if (!s_on) return;
    uint32_t now = rtc_seconds();
    uint32_t slept = now >= s_sleep_rtc ? now - s_sleep_rtc
                                        : now + 31u * 86400u - s_sleep_rtc;
    if (s_valid) {
        s_rem_uas -= (int64_t)SLEEP_UA * slept;
        clamp();
    }
    /* A long rest makes the terminal voltage a good OCV: re-sync on the
     * first sample after waking.                                         */
    if (slept >= REST_RESYNC_S) s_valid = false;
    s_last_t = HAL_GetTick() - FG_PERIOD_MS;
}
