/**
 * @file    fwupdate.c
 * @brief   Dual-bank SD-card firmware update with trial boot + rollback.
 *
 * Erase note: FLASH_NSCR.BKER (HAL's FLASH_BANK_1/2) selects the PHYSICAL
 * bank, which is not the one at 0x08080000 when SWAP_BANK is set - the
 * same rule Zephyr's STM32L5/U5 flash driver applies. Getting this wrong
 * would erase the running firmware, so it is derived from the live
 * OPTR value and double-checked before every erase.
 */
#include "fwupdate.h"
#include "ff.h"
#include "stm32u5xx_hal.h"

#include <string.h>
#include <strings.h>

#define FW_DIR          "0:/Firmware"
#define BANK_SIZE       (512u * 1024u)
#define RUN_BASE        0x08000000u
#define OTHER_BASE      0x08080000u
#define PAGE_SIZE       0x2000u
#define TRIAL_OK_MS     20000u
#define TRIAL_MAX_BOOTS 3u

#define BKP_FWU         (TAMP->BKP0R)
#define FWU_TRIAL       0xF1A71000u      /* | boot count                  */
#define FWU_DONE        0xF1A7D0E0u      /* trial passed, toast pending   */
#define FWU_ROLLED      0xF1A7BAC0u      /* rolled back, toast pending    */

/* Identification block, found by scanning an image for the two magic
 * words (they are assembled at run time below, so the scanner's own
 * literal pool can't produce a false match).                             */
typedef struct {
    uint32_t m0, m1;
    char     version[16];
    char     channel[8];
    uint32_t m2;
} fw_ident_t;

#define IDENT_M0  0x594C5045u            /* "EPLY"                        */
#define IDENT_M1  0x4E454449u            /* "IDEN"                        */
#define IDENT_M2  0x21444E45u            /* "END!"                        */

__attribute__((used, aligned(4)))
const fw_ident_t g_fw_ident = { IDENT_M0, IDENT_M1, FW_VERSION, FW_CHANNEL, IDENT_M2 };

static bool     s_trial;                 /* this boot is a trial          */
static bool     s_trial_done;

/* ---- helpers --------------------------------------------------------------- */

static void bkp_access(void)
{
    __HAL_RCC_PWR_CLK_ENABLE();
    HAL_PWR_EnableBkUpAccess();
    __HAL_RCC_RTCAPB_CLK_ENABLE();
}

bool fwu_bank_swapped(void) { return (FLASH->OPTR & FLASH_OPTR_SWAP_BANK) != 0; }

static bool dual_bank(void)
{
    return (FLASH->OPTR & FLASH_OPTR_DUALBANK) != 0;
}

static bool vectors_ok(uint32_t sp, uint32_t rv)
{
    return sp > 0x20000000u && sp <= 0x200C0000u && (sp & 3u) == 0 &&
           (rv & 1u) && rv >= RUN_BASE + 0x100u && rv < RUN_BASE + BANK_SIZE;
}

static void icache_invalidate(void)
{
    ICACHE->CR |= ICACHE_CR_CACHEINV;
    while (ICACHE->SR & ICACHE_SR_BUSYF) { }
}

static uint32_t crc32_update(uint32_t crc, const uint8_t *p, uint32_t n)
{
    crc = ~crc;
    while (n--) {
        crc ^= *p++;
        for (int k = 0; k < 8; k++) crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
    }
    return ~crc;
}

/* Scan [p, p+n) for the ident block; copies the version if found.        */
static bool find_ident(const uint8_t *p, uint32_t n, char *ver, uint32_t len)
{
    volatile uint32_t m0 = IDENT_M0 - 1u, m1 = IDENT_M1 - 1u, m2 = IDENT_M2 - 1u;
    uint32_t a = m0 + 1u, b = m1 + 1u, c = m2 + 1u;
    for (uint32_t i = 0; i + sizeof(fw_ident_t) <= n; i += 4) {
        const fw_ident_t *id = (const fw_ident_t *)(const void *)(p + i);
        if (id->m0 == a && id->m1 == b && id->m2 == c) {
            if (ver && len) {
                uint32_t k = 0;
                for (; k < sizeof id->version && k + 1 < len && id->version[k]; k++)
                    ver[k] = (id->version[k] >= 0x20 && id->version[k] < 0x7F)
                           ? id->version[k] : '?';
                ver[k] = '\0';
            }
            return true;
        }
    }
    return false;
}

/* Flip SWAP_BANK and reload the option bytes (= system reset).           */
static bool swap_banks(void)
{
    if (!dual_bank()) return false;
    HAL_FLASH_Unlock();
    HAL_FLASH_OB_Unlock();
    FLASH_OBProgramInitTypeDef ob = { 0 };
    ob.OptionType = OPTIONBYTE_USER;
    ob.USERType   = OB_USER_SWAP_BANK;
    ob.USERConfig = fwu_bank_swapped() ? OB_SWAP_BANK_DISABLE : OB_SWAP_BANK_ENABLE;
    if (HAL_FLASHEx_OBProgram(&ob) == HAL_OK) {
        __DSB();
        HAL_FLASH_OB_Launch();               /* does not return            */
    }
    HAL_FLASH_OB_Lock();
    HAL_FLASH_Lock();
    return false;
}

/* ---- boot / trial ------------------------------------------------------------- */

void fwu_boot_check(void)
{
    bkp_access();
    uint32_t v = BKP_FWU;
    if ((v & 0xFFFFFF00u) != (FWU_TRIAL & 0xFFFFFF00u)) return;
    uint32_t boots = v & 0xFFu;
    if (boots >= TRIAL_MAX_BOOTS) {
        /* The new firmware never made it to 20 s: back to the old one.    */
        const uint32_t *o = (const uint32_t *)OTHER_BASE;
        if (vectors_ok(o[0], o[1])) {
            BKP_FWU = FWU_ROLLED;
            swap_banks();
        }
        BKP_FWU = 0;                         /* nothing to go back to      */
        return;
    }
    BKP_FWU = (FWU_TRIAL & 0xFFFFFF00u) | (boots + 1u);
    s_trial = true;
}

fwu_event_t fwu_poll(void)
{
    if (s_trial && !s_trial_done && HAL_GetTick() >= TRIAL_OK_MS) {
        s_trial_done = true;
        bkp_access();
        BKP_FWU = 0;
        return FWU_EVT_INSTALLED;
    }
    static bool checked;
    if (!checked) {
        checked = true;
        bkp_access();
        if (BKP_FWU == FWU_ROLLED) { BKP_FWU = 0; return FWU_EVT_ROLLED_BACK; }
    }
    return FWU_EVT_NONE;
}

const char *fwu_running_version(void) { return g_fw_ident.version; }

bool fwu_previous(char *version, uint32_t len)
{
    const uint32_t *o = (const uint32_t *)OTHER_BASE;
    if (!dual_bank() || !vectors_ok(o[0], o[1])) return false;
    icache_invalidate();
    if (!find_ident((const uint8_t *)OTHER_BASE, BANK_SIZE, version, len)) {
        strncpy(version, "older", len - 1);
        version[len - 1] = '\0';
    }
    return true;
}

bool fwu_switch_previous(const char **err)
{
    const uint32_t *o = (const uint32_t *)OTHER_BASE;
    if (!dual_bank())                 { *err = "Single-bank flash"; return false; }
    if (!vectors_ok(o[0], o[1]))      { *err = "No previous firmware"; return false; }
    bkp_access();
    BKP_FWU = FWU_TRIAL & 0xFFFFFF00u;   /* the old one is on trial too   */
    swap_banks();
    BKP_FWU = 0;
    *err = "Option bytes refused";
    return false;
}

/* ---- file listing ----------------------------------------------------------------- */

static uint8_t s_buf[4096] __attribute__((aligned(16)));

uint32_t fwu_list(fwu_file_t *out, uint32_t max)
{
    DIR d;
    FILINFO fi;
    uint32_t n = 0;
    if (f_opendir(&d, FW_DIR) != FR_OK) return 0;
    while (n < max && f_readdir(&d, &fi) == FR_OK && fi.fname[0]) {
        if (fi.fattrib & (AM_DIR | AM_HID | AM_SYS) || fi.fname[0] == '.') continue;
        const char *dot = strrchr(fi.fname, '.');
        if (!dot || strcasecmp(dot, ".bin")) continue;
        if (strlen(fi.fname) >= sizeof out[n].name) continue;
        strcpy(out[n].name, fi.fname);
        out[n].size = (uint32_t)fi.fsize;
        strcpy(out[n].version, "?");
        /* version from the image's ident block                           */
        char path[64];
        strcpy(path, FW_DIR "/");
        strcat(path, fi.fname);
        FIL f;
        if (f_open(&f, path, FA_READ) == FR_OK) {
            UINT br;
            uint32_t off = 0;
            while (off < fi.fsize && off < BANK_SIZE) {
                if (f_read(&f, s_buf, sizeof s_buf, &br) != FR_OK || !br) break;
                if (find_ident(s_buf, br, out[n].version, sizeof out[n].version)) break;
                off += br > 64 ? br - 64 : br;              /* overlap     */
                if (br > 64 && f_lseek(&f, off) != FR_OK) break;
            }
            f_close(&f);
        }
        n++;
    }
    f_closedir(&d);
    return n;
}

/* ---- install -------------------------------------------------------------------------- */

static bool program_block(uint32_t addr, const uint8_t *src, uint32_t len)
{
    /* len multiple of 16 (caller pads with 0xFF).                        */
    for (uint32_t i = 0; i < len; i += 16) {
        uint32_t q[4];
        memcpy(q, src + i, 16);
        if (q[0] == 0xFFFFFFFFu && q[1] == 0xFFFFFFFFu &&
            q[2] == 0xFFFFFFFFu && q[3] == 0xFFFFFFFFu) continue;   /* erased */
        if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_QUADWORD, addr + i,
                              (uint32_t)q) != HAL_OK)
            return false;
    }
    return true;
}

bool fwu_install(const char *name, fwu_progress_cb cb, const char **err)
{
    char path[64];
    FIL f;
    UINT br;
    *err = "?";
    if (!dual_bank()) { *err = "Single-bank flash"; return false; }
    if (strlen(name) + sizeof FW_DIR + 2 > sizeof path) { *err = "Name too long"; return false; }
    strcpy(path, FW_DIR "/");
    strcat(path, name);
    if (f_open(&f, path, FA_READ) != FR_OK) { *err = "Can't open file"; return false; }
    uint32_t size = (uint32_t)f_size(&f);
    if (size < 16384u || size > BANK_SIZE) { f_close(&f); *err = "Bad size"; return false; }

    uint8_t head[16];
    if (f_read(&f, head, 16, &br) != FR_OK || br != 16) { f_close(&f); *err = "Read error"; return false; }
    uint32_t sp, rv;
    memcpy(&sp, head, 4);
    memcpy(&rv, head + 4, 4);
    if (!vectors_ok(sp, rv)) { f_close(&f); *err = "Not a firmware image"; return false; }

    /* Erase the other bank's pages. BKER = physical bank: with SWAP_BANK
     * set, 0x08080000 is physical bank 1.                                */
    if (cb) cb(0, "Erasing");
    uint32_t pages = (size + PAGE_SIZE - 1u) / PAGE_SIZE;
    FLASH_EraseInitTypeDef er = {
        .TypeErase = FLASH_TYPEERASE_PAGES,
        .Banks     = fwu_bank_swapped() ? FLASH_BANK_1 : FLASH_BANK_2,
        .Page      = 0,
        .NbPages   = pages,
    };
    /* Paranoia: never touch the bank we are executing from.              */
    uint32_t pc = (uint32_t)__builtin_return_address(0);
    if (pc >= OTHER_BASE && pc < OTHER_BASE + BANK_SIZE) { f_close(&f); *err = "Bank check"; return false; }

    HAL_FLASH_Unlock();
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS);   /* stale flags block HAL */
    uint32_t page_err = 0;
    if (HAL_FLASHEx_Erase(&er, &page_err) != HAL_OK) {
        HAL_FLASH_Lock(); f_close(&f); *err = "Erase failed"; return false;
    }
    icache_invalidate();
    /* Erased must read back as 0xFF (and proves we hit the right bank).  */
    const uint32_t *chk = (const uint32_t *)OTHER_BASE;
    for (uint32_t i = 0; i < 256; i++)
        if (chk[i] != 0xFFFFFFFFu) { HAL_FLASH_Lock(); f_close(&f); *err = "Erase verify"; return false; }

    /* Program everything except the first 16 bytes; CRC as we go.        */
    uint32_t crc_file = crc32_update(0, head, 16);
    uint32_t off = 16;
    int last_pct = -1;
    bool ok = true;
    memcpy(s_buf, head, 16);                  /* first chunk starts at 0   */
    uint32_t chunk_base = 0, fill = 16;
    while (ok && off < size) {
        uint32_t want = sizeof s_buf - fill;
        if (want > size - off) want = size - off;
        if (f_read(&f, s_buf + fill, want, &br) != FR_OK || br != want) { ok = false; *err = "Read error"; break; }
        crc_file = crc32_update(crc_file, s_buf + fill, want);
        fill += want;
        off  += want;
        uint32_t plen = (fill + 15u) & ~15u;
        memset(s_buf + fill, 0xFF, plen - fill);
        uint32_t skip = (chunk_base == 0) ? 16u : 0u;   /* vectors later  */
        if (!program_block(OTHER_BASE + chunk_base + skip, s_buf + skip, plen - skip)) {
            ok = false; *err = "Program failed"; break;
        }
        chunk_base += fill;
        fill = 0;
        int pct = (int)((uint64_t)off * 90u / size);
        if (cb && pct / 10 != last_pct / 10) { last_pct = pct; cb(pct, "Writing"); }
    }
    f_close(&f);
    if (!ok) { HAL_FLASH_Lock(); return false; }

    /* Verify (CRC over the written image, with the real first 16 bytes). */
    if (cb) cb(92, "Verifying");
    icache_invalidate();
    uint32_t crc_flash = crc32_update(0, head, 16);
    crc_flash = crc32_update(crc_flash, (const uint8_t *)OTHER_BASE + 16, size - 16);
    if (crc_flash != crc_file) { HAL_FLASH_Lock(); *err = "Verify failed"; return false; }

    /* Make it bootable: the vector words go in last.                     */
    if (!program_block(OTHER_BASE, head, 16)) { HAL_FLASH_Lock(); *err = "Program failed"; return false; }
    HAL_FLASH_Lock();
    icache_invalidate();
    if (memcmp((const void *)OTHER_BASE, head, 16)) { *err = "Verify failed"; return false; }

    if (cb) cb(100, "Restarting");
    bkp_access();
    BKP_FWU = FWU_TRIAL & 0xFFFFFF00u;       /* boot count 0              */
    swap_banks();                            /* restarts on success       */
    BKP_FWU = 0;
    *err = "Option bytes refused";
    return false;
}
