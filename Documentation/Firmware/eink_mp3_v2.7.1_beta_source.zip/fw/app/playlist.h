/**
 * @file    playlist.h
 * @brief   Playlists per software configuration.txt: audio lives anywhere
 *          on the SD card; playlists are plain text files in /Playlists/
 *          whose FILE NAME is the playlist name. Each line is a path to
 *          an audio file (m3u-compatible: '#' lines ignored).
 *
 * Two built-ins: "Play all" (recursive scan of /Music, or the whole card
 * if /Music is absent) and per-playlist shuffle via a Fisher-Yates
 * permutation of indices (the file order itself is never modified).
 *
 * To keep RAM bounded, track paths are not held in RAM: the playlist is
 * indexed by line offsets (built once on open, kept in a static array of
 * up to PL_MAX_TRACKS u32 offsets = 16 KB).
 */
#ifndef PLAYLIST_H
#define PLAYLIST_H

#include <stdbool.h>
#include <stdint.h>

#define PL_MAX_TRACKS   4096u
#define PL_MAX_LISTS    32u
#define PL_NAME_MAX     64u
#define PL_PATH_MAX     256u

typedef struct {
    char     name[PL_NAME_MAX];       /* file name without extension      */
    char     file[PL_NAME_MAX];       /* file name with extension         */
} playlist_desc_t;

/* Enumerate playlist files in /Playlists.                                */
uint32_t playlist_enumerate(playlist_desc_t *out, uint32_t max);

/* Open a playlist by file name; "" = "Play all" scan.                    */
bool     playlist_open(const char *file);
uint32_t playlist_count(void);
/* Fetch track path by position (through the shuffle map if enabled).     */
bool     playlist_track(uint32_t pos, char *path, uint32_t path_len);

void     playlist_set_shuffle(bool on, uint32_t seed);
bool     playlist_shuffled(void);

/* 2.7.0 */
bool     playlist_is_file(void);       /* a /Playlists file is open (not
                                          a library view, scan or podcasts) */
bool     playlist_is_podcasts(void);
/* Delete entry `pos` (play order) from the open /Playlists file on the
 * card. The play order of the remaining entries is kept; afterwards
 * position `pos` is what used to be the next entry. Closes the UI's
 * browse handle (playlist_browse_open() again afterwards).               */
bool     playlist_remove(uint32_t pos);

/* System sleep: close the open list file (FatFs handles do not survive an
 * SD power cycle) / re-open it. The line index and shuffle map stay in
 * RAM (Stop 2 retains SRAM).                                              */
void     playlist_suspend(void);
bool     playlist_resume(void);

/* Mark the cached "Play all" scan stale (rebuilt on the next Play all). */
void     playlist_invalidate_scan(void);
bool     playlist_scan_needed(void);   /* next Play all will rescan       */

/* 2.6.0 - library builder access to the "Play all" scan (rebuilt if
 * stale; blocking directory walk).                                       */
bool        playlist_build_scan(void);
bool        playlist_ensure_scan(void);
const char *playlist_scan_path(void);

/* 2.6.0 - browse a /Playlists file for the UI without disturbing the
 * list that is playing. Returns the entry count.                         */
uint32_t playlist_browse_open(const char *file);
void     playlist_browse_close(void);
uint32_t playlist_browse_count(void);
bool     playlist_browse_entry(uint32_t n, char *path, uint32_t len);

#endif /* PLAYLIST_H */
