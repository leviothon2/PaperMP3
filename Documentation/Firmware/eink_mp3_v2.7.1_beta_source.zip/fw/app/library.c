/**
 * @file    library.c
 * @brief   Background-built music library index (see library.h).
 */
#include "library.h"
#include "playlist.h"
#include "settings.h"
#include "diag.h"
#include "../audio/tags.h"
#include "ff.h"
#include "stm32u5xx_hal.h"

#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define LIB_DIR    "0:/.eplayer"
#define F_TRACKS   LIB_DIR "/tracks.db"
#define F_ARTISTS  LIB_DIR "/artists.db"
#define F_ALBUMS   LIB_DIR "/albums.db"
#define F_ALBAZ    LIB_DIR "/albaz.db"
#define F_SONGAZ   LIB_DIR "/songaz.db"
#define F_PATHS    LIB_DIR "/paths.db"
#define F_TMP      LIB_DIR "/build.tmp"

#define LIB_MAX_TRACKS   4096u
#define LIB_MAX_ARTISTS  1024u
#define LIB_MAX_ALBUMS   1536u
#define KEY_LEN          16           /* sort key prefix kept in RAM       */
#define TKEY_LEN         22           /* title sort key                    */
#define LIB_MAGIC        0x42494C45u  /* "ELIB"                            */
#define LIB_VERSION      1u
#define SLICE_MS         12u          /* per main-loop lap                 */

typedef struct {
    uint32_t magic, version, count, n_artists, n_albums, sig, truncated, rsv;
} lib_hdr_t;                                           /* 32 bytes        */

typedef struct {                                       /* build.tmp       */
    char     path[256];
    char     title[LIB_NAME_MAX];
    char     artist[LIB_NAME_MAX];
    char     album[LIB_NAME_MAX];
    uint16_t trackno;
    uint8_t  disc;
    uint8_t  pad;
} tmp_rec_t;

typedef struct { uint32_t hash; uint16_t idx; uint16_t pad; } path_ent_t;

/* ---- build arena (only used while building) ------------------------------ */

typedef struct { char key[KEY_LEN]; uint32_t hash; } art_e_t;            /* 20 */
typedef struct { char key[KEY_LEN]; uint32_t hash; uint16_t artist, pad; } alb_e_t; /* 24 */
typedef struct { uint16_t artist, album, dt, rec; } trk_e_t;             /* 8  */
typedef struct { char key[TKEY_LEN]; uint16_t idx; } song_e_t;           /* 24 */

#define HT_ART  2048u
#define HT_ALB  4096u
typedef struct {
    art_e_t  art[LIB_MAX_ARTISTS];
    alb_e_t  alb[LIB_MAX_ALBUMS];
    trk_e_t  trk[LIB_MAX_TRACKS];
    uint16_t art_order[LIB_MAX_ARTISTS];
    uint16_t alb_order[LIB_MAX_ALBUMS];
    union {                                   /* hash tables, then ranks  */
        struct { uint16_t art_ht[HT_ART]; uint16_t alb_ht[HT_ALB]; } h;
        struct { uint16_t art_rank[LIB_MAX_ARTISTS]; uint16_t alb_rank[LIB_MAX_ALBUMS]; } r;
    } u;
} arena_a_t;

typedef union {
    arena_a_t  a;
    song_e_t   songs[LIB_MAX_TRACKS];
    path_ent_t paths[LIB_MAX_TRACKS];
} arena_t;

static arena_t s_ar;

/* ---- state ------------------------------------------------------------------- */

typedef enum {
    S_NONE, S_CHECK, S_TAGS, S_SORT, S_WRITE, S_ALBAZ, S_SONGS_READ,
    S_SONGS_WRITE, S_PATHS_READ, S_PATHS_WRITE, S_FINISH,
} step_t;

static lib_state_t s_state = LIB_IDLE;
static step_t      s_step;
static lib_hdr_t   s_hdr;                 /* of the READY index            */
static uint32_t    s_mount_seq;           /* mount the index was checked on*/
static uint32_t    s_build_seq;
static bool        s_force;

/* build bookkeeping */
static uint32_t s_total_lines, s_scan_sig;
static uint32_t s_ntrk, s_nart, s_nalb, s_pos;
static bool     s_trunc;
static FIL      s_scan, s_tmp, s_ftr, s_far, s_fal;
static bool     s_scan_open, s_tmp_open, s_ftr_open, s_far_open, s_fal_open;
/* streaming writer state (S_WRITE) */
static lib_artist_t s_cur_art;
static lib_album_t  s_cur_alb;
static int32_t      s_cur_art_rank, s_cur_alb_rank;
static uint32_t     s_alb_written, s_art_written;

/* readers (READY) */
typedef enum { RF_TRACKS, RF_ARTISTS, RF_ALBUMS, RF_ALBAZ, RF_SONGAZ, RF_PATHS, RF_N } rf_t;
static const char *const k_rf_path[RF_N] = { F_TRACKS, F_ARTISTS, F_ALBUMS, F_ALBAZ, F_SONGAZ, F_PATHS };
static FIL  s_rf[RF_N];
static bool s_rf_open[RF_N];

/* ---- helpers ------------------------------------------------------------------- */

/* Case-insensitive FNV-1a. Paths are normalised on the way: a leading
 * "0:" is dropped and '\\' counts as '/', so "0:/Music/a.mp3",
 * "/Music/a.mp3" and "\\Music\\a.mp3" (Windows playlists) all match.       */
static uint32_t fnv_up(const char *s)
{
    uint32_t h = 2166136261u;
    if (s[0] == '0' && s[1] == ':') s += 2;
    for (; *s; s++) {
        uint8_t c = (uint8_t)*s;
        if (c >= 'a' && c <= 'z') c -= 32;
        if (c == '\\') c = '/';
        h ^= c;
        h *= 16777619u;
    }
    return h;
}

static bool path_eq(const char *a, const char *b)
{
    if (a[0] == '0' && a[1] == ':') a += 2;
    if (b[0] == '0' && b[1] == ':') b += 2;
    for (;; a++, b++) {
        char x = *a, y = *b;
        if (x >= 'a' && x <= 'z') x -= 32;
        if (y >= 'a' && y <= 'z') y -= 32;
        if (x == '\\') x = '/';
        if (y == '\\') y = '/';
        if (x != y) return false;
        if (!x) return true;
    }
}

/* Upper-cased sort key; a leading "The " is ignored ("The Beatles" sorts
 * under B).                                                              */
static void make_key(char *key, int len, const char *s)
{
    if (!strncasecmp(s, "the ", 4) && s[4]) s += 4;
    int i = 0;
    for (; i < len && s[i]; i++) {
        char c = s[i];
        key[i] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : c;
    }
    for (; i < len; i++) key[i] = 0;
}

static void copy_name(char *dst, const char *src, const char *fallback)
{
    const char *s = (src && src[0]) ? src : fallback;
    strncpy(dst, s, LIB_NAME_MAX - 1);
    dst[LIB_NAME_MAX - 1] = '\0';
}

static bool rd_at(FIL *f, uint32_t off, void *buf, uint32_t n)
{
    UINT br;
    if (f_lseek(f, off) != FR_OK) return false;
    return f_read(f, buf, n, &br) == FR_OK && br == n;
}

static bool wr(FIL *f, const void *buf, uint32_t n)
{
    UINT bw;
    return f_write(f, buf, n, &bw) == FR_OK && bw == n;
}

static void close_build_files(void)
{
    if (s_scan_open) f_close(&s_scan);
    if (s_tmp_open)  f_close(&s_tmp);
    if (s_ftr_open)  f_close(&s_ftr);
    if (s_far_open)  f_close(&s_far);
    if (s_fal_open)  f_close(&s_fal);
    s_scan_open = s_tmp_open = s_ftr_open = s_far_open = s_fal_open = false;
}

static void close_readers(void)
{
    for (int i = 0; i < RF_N; i++)
        if (s_rf_open[i]) { f_close(&s_rf[i]); s_rf_open[i] = false; }
}

static FIL *reader(rf_t r)
{
    if (s_state != LIB_READY) return NULL;
    if (!s_rf_open[r]) {
        if (f_open(&s_rf[r], k_rf_path[r], FA_READ) != FR_OK) return NULL;
        s_rf_open[r] = true;
    }
    return &s_rf[r];
}

static void fail(void)
{
    close_build_files();
    s_step = S_NONE;
    s_state = LIB_FAILED;
}

/* ---- public control ------------------------------------------------------------ */

lib_state_t library_state(void) { return s_state; }
bool        library_ready(void) { return s_state == LIB_READY; }
uint32_t    library_sig(void)   { return s_hdr.sig; }
bool        library_truncated(void) { return s_hdr.truncated != 0; }
uint32_t    library_track_count(void)  { return library_ready() ? s_hdr.count : 0; }
uint32_t    library_artist_count(void) { return library_ready() ? s_hdr.n_artists : 0; }
uint32_t    library_album_count(void)  { return library_ready() ? s_hdr.n_albums : 0; }

uint8_t library_progress(void)
{
    switch (s_step) {
    case S_TAGS:
        return (uint8_t)(s_total_lines ? (s_ntrk * 80u) / s_total_lines : 0);
    case S_SORT:        return 80;
    case S_WRITE:       return (uint8_t)(80 + (s_ntrk ? s_pos * 8u / s_ntrk : 0));
    case S_ALBAZ:       return 88;
    case S_SONGS_READ:
    case S_SONGS_WRITE: return 92;
    case S_PATHS_READ:
    case S_PATHS_WRITE: return 96;
    case S_FINISH:      return 99;
    default:            return 0;
    }
}

void library_close(void)
{
    close_readers();
    if (s_step != S_NONE) {              /* build interrupted (sleep, MSC) */
        close_build_files();
        s_step = S_NONE;
        s_state = LIB_IDLE;
    }
}

void library_request(void)
{
    if (s_step != S_NONE) return;                         /* busy          */
    if (s_state == LIB_READY && s_mount_seq == settings_mount_seq() && !s_force)
        return;
    close_readers();
    s_state = LIB_SCANNING;
    s_step = S_CHECK;
}

/* Resume of a library list right after boot: trust the index on the card
 * if its header is valid (its signature is still checked against the
 * resume string by the caller). The next library_request() re-validates
 * against a fresh scan, because s_mount_seq stays stale.                 */
bool library_try_cached(void)
{
    if (s_state == LIB_READY) return true;
    if (s_step != S_NONE || !settings_mounted()) return false;
    FIL f;
    lib_hdr_t h;
    if (f_open(&f, F_TRACKS, FA_READ) != FR_OK) return false;
    bool ok = rd_at(&f, 0, &h, sizeof h);
    f_close(&f);
    if (!ok || h.magic != LIB_MAGIC || h.version != LIB_VERSION || !h.count) return false;
    s_hdr = h;
    s_mount_seq = settings_mount_seq() - 1u;  /* revalidate on next request */
    s_state = LIB_READY;
    return true;
}

void library_rebuild(void)
{
    s_force = true;
    library_close();
    s_state = LIB_IDLE;
    library_request();
}

/* ---- build steps ------------------------------------------------------------------ */

static bool scan_sig(void)
{
    FIL f;
    if (f_open(&f, playlist_scan_path(), FA_READ) != FR_OK) return false;
    char line[256];
    uint32_t h = 2166136261u, n = 0;
    while (f_gets(line, sizeof line, &f)) {
        if (!line[0] || line[0] == '\n' || line[0] == '\r') continue;
        for (const char *p = line; *p; p++) { h ^= (uint8_t)*p; h *= 16777619u; }
        n++;
    }
    f_close(&f);
    s_total_lines = n;
    s_scan_sig = h ^ (n * 0x9E3779B9u) ^ LIB_VERSION;
    return true;
}

static bool step_check(void)
{
    diag_step(STEP_PLAYLIST_SCAN);
    s_build_seq = settings_mount_seq();
    if (!settings_mounted() || !playlist_ensure_scan() || !scan_sig()) return false;
    if (!s_total_lines) return false;                    /* no music       */

    if (!s_force) {
        FIL f;
        lib_hdr_t h;
        if (f_open(&f, F_TRACKS, FA_READ) == FR_OK) {
            bool ok = rd_at(&f, 0, &h, sizeof h);
            f_close(&f);
            if (ok && h.magic == LIB_MAGIC && h.version == LIB_VERSION &&
                h.sig == s_scan_sig && h.count) {
                s_hdr = h;
                s_mount_seq = s_build_seq;
                s_state = LIB_READY;
                s_step = S_NONE;
                return true;
            }
        }
    }
    s_force = false;

    /* Full build.                                                         */
    f_mkdir(LIB_DIR);
    memset(&s_ar.a, 0, sizeof s_ar.a);
    for (uint32_t i = 0; i < HT_ART; i++) s_ar.a.u.h.art_ht[i] = 0xFFFF;
    for (uint32_t i = 0; i < HT_ALB; i++) s_ar.a.u.h.alb_ht[i] = 0xFFFF;
    s_ntrk = s_nart = s_nalb = 0;
    s_trunc = false;
    if (f_open(&s_scan, playlist_scan_path(), FA_READ) != FR_OK) return false;
    s_scan_open = true;
    if (f_open(&s_tmp, F_TMP, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) return false;
    s_tmp_open = true;
    s_state = LIB_BUILDING;
    s_step = S_TAGS;
    return true;
}

static int find_or_add_artist(const char *name)
{
    uint32_t h = fnv_up(name);
    uint32_t i = h & (HT_ART - 1);
    for (;;) {
        uint16_t e = s_ar.a.u.h.art_ht[i];
        if (e == 0xFFFF) break;
        if (s_ar.a.art[e].hash == h) return e;
        i = (i + 1) & (HT_ART - 1);
    }
    if (s_nart >= LIB_MAX_ARTISTS) return -1;
    uint16_t id = (uint16_t)s_nart++;
    make_key(s_ar.a.art[id].key, KEY_LEN, name);
    s_ar.a.art[id].hash = h;
    s_ar.a.u.h.art_ht[i] = id;
    return id;
}

static int find_or_add_album(uint16_t artist, const char *name)
{
    uint32_t h = fnv_up(name) ^ ((uint32_t)artist * 0x9E3779B1u);
    uint32_t i = h & (HT_ALB - 1);
    for (;;) {
        uint16_t e = s_ar.a.u.h.alb_ht[i];
        if (e == 0xFFFF) break;
        if (s_ar.a.alb[e].hash == h && s_ar.a.alb[e].artist == artist) return e;
        i = (i + 1) & (HT_ALB - 1);
    }
    if (s_nalb >= LIB_MAX_ALBUMS) return -1;
    uint16_t id = (uint16_t)s_nalb++;
    make_key(s_ar.a.alb[id].key, KEY_LEN, name);
    s_ar.a.alb[id].hash = h;
    s_ar.a.alb[id].artist = artist;
    s_ar.a.u.h.alb_ht[i] = id;
    return id;
}

static bool step_tags(uint32_t t0)
{
    char path[256];
    static track_tags_t tg;
    static tmp_rec_t rec;
    while (HAL_GetTick() - t0 < SLICE_MS) {
        if (s_ntrk >= LIB_MAX_TRACKS) { s_trunc = true; break; }
        if (!f_gets(path, sizeof path, &s_scan)) {
            f_close(&s_scan); s_scan_open = false;
            f_close(&s_tmp);  s_tmp_open = false;
            s_step = S_SORT;
            return true;
        }
        char *nl = strpbrk(path, "\r\n");
        if (nl) *nl = '\0';
        if (!path[0]) continue;

        diag_step(STEP_TRACK_TAGS);
        tags_read(path, &tg, NULL);
        memset(&rec, 0, sizeof rec);
        strncpy(rec.path, path, sizeof rec.path - 1);
        copy_name(rec.title,  tg.title,  "?");
        copy_name(rec.artist, tg.albumartist[0] ? tg.albumartist : tg.artist,
                  "Unknown artist");
        copy_name(rec.album,  tg.album,  "Unknown album");
        rec.trackno = tg.track;
        rec.disc    = tg.disc;

        int a = find_or_add_artist(rec.artist);
        int b = (a >= 0) ? find_or_add_album((uint16_t)a, rec.album) : -1;
        if (a < 0 || b < 0) { s_trunc = true; continue; }
        if (!wr(&s_tmp, &rec, sizeof rec)) return false;
        trk_e_t *t = &s_ar.a.trk[s_ntrk];
        t->artist = (uint16_t)a;
        t->album  = (uint16_t)b;
        t->dt     = (uint16_t)(((rec.disc & 0x0Fu) << 12) |
                               (rec.trackno > 4095 ? 4095 : rec.trackno));
        t->rec    = (uint16_t)s_ntrk;
        s_ntrk++;
    }
    if (s_ntrk >= LIB_MAX_TRACKS) {
        f_close(&s_scan); s_scan_open = false;
        f_close(&s_tmp);  s_tmp_open = false;
        s_step = S_SORT;
    }
    return true;
}

/* qsort comparators (arena via file statics)                              */
static int cmp_art(const void *x, const void *y)
{
    const art_e_t *a = &s_ar.a.art[*(const uint16_t *)x];
    const art_e_t *b = &s_ar.a.art[*(const uint16_t *)y];
    int c = memcmp(a->key, b->key, KEY_LEN);
    if (c) return c;
    return (a->hash > b->hash) - (a->hash < b->hash);
}
static int cmp_alb(const void *x, const void *y)
{
    const alb_e_t *a = &s_ar.a.alb[*(const uint16_t *)x];
    const alb_e_t *b = &s_ar.a.alb[*(const uint16_t *)y];
    int ra = s_ar.a.u.r.art_rank[a->artist], rb = s_ar.a.u.r.art_rank[b->artist];
    if (ra != rb) return ra - rb;
    int c = memcmp(a->key, b->key, KEY_LEN);
    if (c) return c;
    return (a->hash > b->hash) - (a->hash < b->hash);
}
static int cmp_alb_az(const void *x, const void *y)
{
    const alb_e_t *a = &s_ar.a.alb[*(const uint16_t *)x];
    const alb_e_t *b = &s_ar.a.alb[*(const uint16_t *)y];
    int c = memcmp(a->key, b->key, KEY_LEN);
    if (c) return c;
    int ra = s_ar.a.u.r.art_rank[a->artist], rb = s_ar.a.u.r.art_rank[b->artist];
    return ra - rb;
}
static int cmp_trk(const void *x, const void *y)
{
    const trk_e_t *a = x, *b = y;
    int c = (int)s_ar.a.u.r.art_rank[a->artist] - (int)s_ar.a.u.r.art_rank[b->artist];
    if (c) return c;
    c = (int)s_ar.a.u.r.alb_rank[a->album] - (int)s_ar.a.u.r.alb_rank[b->album];
    if (c) return c;
    c = (int)a->dt - (int)b->dt;
    if (c) return c;
    return (int)a->rec - (int)b->rec;
}
static int cmp_song(const void *x, const void *y)
{
    const song_e_t *a = x, *b = y;
    int c = memcmp(a->key, b->key, TKEY_LEN);
    return c ? c : (int)a->idx - (int)b->idx;
}
static int cmp_path(const void *x, const void *y)
{
    const path_ent_t *a = x, *b = y;
    if (a->hash != b->hash) return (a->hash > b->hash) ? 1 : -1;
    return (int)a->idx - (int)b->idx;
}

static bool step_sort(void)
{
    if (!s_ntrk) return false;
    for (uint32_t i = 0; i < s_nart; i++) s_ar.a.art_order[i] = (uint16_t)i;
    qsort(s_ar.a.art_order, s_nart, sizeof(uint16_t), cmp_art);
    /* hash tables are done with: the union now holds ranks               */
    for (uint32_t i = 0; i < s_nart; i++) s_ar.a.u.r.art_rank[s_ar.a.art_order[i]] = (uint16_t)i;
    for (uint32_t i = 0; i < s_nalb; i++) s_ar.a.alb_order[i] = (uint16_t)i;
    qsort(s_ar.a.alb_order, s_nalb, sizeof(uint16_t), cmp_alb);
    for (uint32_t i = 0; i < s_nalb; i++) s_ar.a.u.r.alb_rank[s_ar.a.alb_order[i]] = (uint16_t)i;
    qsort(s_ar.a.trk, s_ntrk, sizeof(trk_e_t), cmp_trk);

    if (f_open(&s_tmp, F_TMP, FA_READ) != FR_OK) return false;
    s_tmp_open = true;
    if (f_open(&s_ftr, F_TRACKS, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) return false;
    s_ftr_open = true;
    if (f_open(&s_far, F_ARTISTS, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) return false;
    s_far_open = true;
    if (f_open(&s_fal, F_ALBUMS, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) return false;
    s_fal_open = true;
    lib_hdr_t h = { 0 };                       /* magic written at the end */
    if (!wr(&s_ftr, &h, sizeof h)) return false;
    s_pos = 0;
    s_cur_art_rank = s_cur_alb_rank = -1;
    s_alb_written = s_art_written = 0;
    s_step = S_WRITE;
    return true;
}

static bool flush_album(void)
{
    if (s_cur_alb_rank < 0) return true;
    s_alb_written++;
    return wr(&s_fal, &s_cur_alb, sizeof s_cur_alb);
}

static bool flush_artist(void)
{
    if (s_cur_art_rank < 0) return true;
    s_art_written++;
    return wr(&s_far, &s_cur_art, sizeof s_cur_art);
}

static bool step_write(uint32_t t0)
{
    static tmp_rec_t r;
    static lib_track_t t;
    while (s_pos < s_ntrk && HAL_GetTick() - t0 < SLICE_MS) {
        const trk_e_t *e = &s_ar.a.trk[s_pos];
        if (!rd_at(&s_tmp, (uint32_t)e->rec * sizeof r, &r, sizeof r)) return false;
        int ar = s_ar.a.u.r.art_rank[e->artist];
        int al = s_ar.a.u.r.alb_rank[e->album];

        if (al != s_cur_alb_rank) {
            if (!flush_album()) return false;
            if (ar != s_cur_art_rank) {
                if (!flush_artist()) return false;
                memset(&s_cur_art, 0, sizeof s_cur_art);
                copy_name(s_cur_art.name, r.artist, "Unknown artist");
                s_cur_art.first_album = (uint16_t)s_alb_written;
                s_cur_art.first_track = s_pos;
                s_cur_art_rank = ar;
            }
            memset(&s_cur_alb, 0, sizeof s_cur_alb);
            copy_name(s_cur_alb.name, r.album, "Unknown album");
            s_cur_alb.artist = (uint16_t)ar;
            s_cur_alb.first_track = s_pos;
            s_cur_alb_rank = al;
            s_cur_art.n_albums++;
        }
        s_cur_alb.n_tracks++;
        s_cur_art.n_tracks++;

        memset(&t, 0, sizeof t);
        memcpy(t.path, r.path, sizeof t.path);
        memcpy(t.title, r.title, sizeof t.title);
        t.artist  = (uint16_t)ar;
        t.album   = (uint16_t)al;
        t.trackno = r.trackno;
        t.disc    = r.disc;
        if (!wr(&s_ftr, &t, sizeof t)) return false;
        s_pos++;
    }
    if (s_pos >= s_ntrk) {
        if (!flush_album() || !flush_artist()) return false;
        f_close(&s_tmp); s_tmp_open = false;
        f_close(&s_far); s_far_open = false;
        f_close(&s_fal); s_fal_open = false;
        f_close(&s_ftr); s_ftr_open = false;
        s_step = S_ALBAZ;
    }
    return true;
}

static bool step_albaz(void)
{
    /* Albums A-Z: reuse alb_order (album ids), sorted by name.            */
    for (uint32_t i = 0; i < s_nalb; i++) s_ar.a.alb_order[i] = (uint16_t)i;
    qsort(s_ar.a.alb_order, s_nalb, sizeof(uint16_t), cmp_alb_az);
    FIL f;
    if (f_open(&f, F_ALBAZ, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) return false;
    bool ok = true;
    for (uint32_t i = 0; i < s_nalb && ok; i++) {
        uint16_t rank = s_ar.a.u.r.alb_rank[s_ar.a.alb_order[i]];
        ok = wr(&f, &rank, sizeof rank);
    }
    f_close(&f);
    if (!ok) return false;
    if (f_open(&s_ftr, F_TRACKS, FA_READ) != FR_OK) return false;
    s_ftr_open = true;
    s_pos = 0;
    s_step = S_SONGS_READ;                    /* arena is free from here  */
    return true;
}

static bool step_songs_read(uint32_t t0)
{
    static lib_track_t t;
    while (s_pos < s_ntrk && HAL_GetTick() - t0 < SLICE_MS) {
        if (!rd_at(&s_ftr, sizeof(lib_hdr_t) + s_pos * sizeof t, &t, sizeof t)) return false;
        make_key(s_ar.songs[s_pos].key, TKEY_LEN, t.title);
        s_ar.songs[s_pos].idx = (uint16_t)s_pos;
        s_pos++;
    }
    if (s_pos >= s_ntrk) s_step = S_SONGS_WRITE;
    return true;
}

static bool step_songs_write(void)
{
    qsort(s_ar.songs, s_ntrk, sizeof(song_e_t), cmp_song);
    FIL f;
    if (f_open(&f, F_SONGAZ, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) return false;
    bool ok = true;
    for (uint32_t i = 0; i < s_ntrk && ok; i++) ok = wr(&f, &s_ar.songs[i].idx, sizeof(uint16_t));
    f_close(&f);
    if (!ok) return false;
    s_pos = 0;
    s_step = S_PATHS_READ;
    return true;
}

static bool step_paths_read(uint32_t t0)
{
    static lib_track_t t;
    while (s_pos < s_ntrk && HAL_GetTick() - t0 < SLICE_MS) {
        if (!rd_at(&s_ftr, sizeof(lib_hdr_t) + s_pos * sizeof t, &t, sizeof t)) return false;
        s_ar.paths[s_pos].hash = fnv_up(t.path);
        s_ar.paths[s_pos].idx  = (uint16_t)s_pos;
        s_ar.paths[s_pos].pad  = 0;
        s_pos++;
    }
    if (s_pos >= s_ntrk) s_step = S_PATHS_WRITE;
    return true;
}

static bool step_paths_write(void)
{
    f_close(&s_ftr); s_ftr_open = false;
    qsort(s_ar.paths, s_ntrk, sizeof(path_ent_t), cmp_path);
    FIL f;
    if (f_open(&f, F_PATHS, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) return false;
    bool ok = wr(&f, s_ar.paths, s_ntrk * sizeof(path_ent_t));
    f_close(&f);
    if (!ok) return false;
    s_step = S_FINISH;
    return true;
}

static bool step_finish(void)
{
    lib_hdr_t h = {
        .magic = LIB_MAGIC, .version = LIB_VERSION, .count = s_ntrk,
        .n_artists = s_art_written, .n_albums = s_alb_written,
        .sig = s_scan_sig, .truncated = s_trunc ? 1u : 0u,
    };
    FIL f;
    if (f_open(&f, F_TRACKS, FA_WRITE | FA_OPEN_EXISTING) != FR_OK) return false;
    bool ok = f_lseek(&f, 0) == FR_OK && wr(&f, &h, sizeof h);
    ok = (f_close(&f) == FR_OK) && ok;
    if (!ok) return false;
    f_unlink(F_TMP);
    s_hdr = h;
    s_mount_seq = s_build_seq;
    s_state = LIB_READY;
    s_step = S_NONE;
    return true;
}

void library_service(void)
{
    if (s_step == S_NONE) return;
    /* Card changed or went away mid-build: drop it, re-request later.    */
    if (s_step != S_CHECK && (settings_mount_seq() != s_build_seq || !settings_mounted())) {
        close_build_files();
        s_step = S_NONE;
        s_state = LIB_IDLE;
        return;
    }
    uint32_t t0 = HAL_GetTick();
    bool ok = true;
    switch (s_step) {
    case S_CHECK:       ok = step_check();          break;
    case S_TAGS:        ok = step_tags(t0);         break;
    case S_SORT:        ok = step_sort();           break;
    case S_WRITE:       ok = step_write(t0);        break;
    case S_ALBAZ:       ok = step_albaz();          break;
    case S_SONGS_READ:  ok = step_songs_read(t0);   break;
    case S_SONGS_WRITE: ok = step_songs_write();    break;
    case S_PATHS_READ:  ok = step_paths_read(t0);   break;
    case S_PATHS_WRITE: ok = step_paths_write();    break;
    case S_FINISH:      ok = step_finish();         break;
    default: break;
    }
    if (!ok) fail();
}

/* ---- readers --------------------------------------------------------------------- */

bool library_track(uint32_t idx, lib_track_t *out)
{
    FIL *f = reader(RF_TRACKS);
    if (!f || idx >= s_hdr.count) return false;
    return rd_at(f, sizeof(lib_hdr_t) + idx * sizeof *out, out, sizeof *out);
}

bool library_track_path(uint32_t idx, char *path, uint32_t len)
{
    FIL *f = reader(RF_TRACKS);
    if (!f || idx >= s_hdr.count || !len) return false;
    uint32_t n = len < 256 ? len : 256;
    if (!rd_at(f, sizeof(lib_hdr_t) + idx * sizeof(lib_track_t), path, n)) return false;
    path[n - 1] = '\0';
    return path[0] != '\0';
}

bool library_artist(uint32_t idx, lib_artist_t *out)
{
    FIL *f = reader(RF_ARTISTS);
    if (!f || idx >= s_hdr.n_artists) return false;
    return rd_at(f, idx * sizeof *out, out, sizeof *out);
}

bool library_album(uint32_t idx, lib_album_t *out)
{
    FIL *f = reader(RF_ALBUMS);
    if (!f || idx >= s_hdr.n_albums) return false;
    return rd_at(f, idx * sizeof *out, out, sizeof *out);
}

bool library_album_az(uint32_t pos, uint32_t *album_idx)
{
    FIL *f = reader(RF_ALBAZ);
    uint16_t v;
    if (!f || pos >= s_hdr.n_albums || !rd_at(f, pos * 2u, &v, 2)) return false;
    *album_idx = v;
    return true;
}

bool library_song_az(uint32_t pos, uint32_t *track_idx)
{
    FIL *f = reader(RF_SONGAZ);
    uint16_t v;
    if (!f || pos >= s_hdr.count || !rd_at(f, pos * 2u, &v, 2)) return false;
    *track_idx = v;
    return true;
}

bool library_title_for_path(const char *path, char *title, uint32_t len)
{
    FIL *f = reader(RF_PATHS);
    if (!f || !s_hdr.count) return false;
    uint32_t h = fnv_up(path);
    /* lower bound of h                                                   */
    uint32_t lo = 0, hi = s_hdr.count;
    path_ent_t e;
    while (lo < hi) {
        uint32_t mid = (lo + hi) / 2;
        if (!rd_at(f, mid * sizeof e, &e, sizeof e)) return false;
        if (e.hash < h) lo = mid + 1; else hi = mid;
    }
    static lib_track_t t;
    for (uint32_t i = lo; i < s_hdr.count; i++) {
        if (!rd_at(f, i * sizeof e, &e, sizeof e) || e.hash != h) break;
        if (library_track(e.idx, &t) && path_eq(t.path, path)) {
            strncpy(title, t.title, len - 1);
            title[len - 1] = '\0';
            return true;
        }
    }
    return false;
}
