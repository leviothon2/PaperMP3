/**
 * @file    power.h
 * @brief   System power manager: inactivity sleep, switched 3.3 V rail,
 *          Stop 2 entry/exit and wake-source filtering.
 *
 * Behaviour (V2 hardware):
 *   - The player is always on while music plays (and while USB storage /
 *     USB DAC is active). It never sleeps on its own in those states.
 *   - After `settings.sleep_timeout` of inactivity (user setting) it:
 *       1. saves the resume state (playlist, track, position) to SD,
 *       2. turns the e-ink completely white (one full refresh),
 *       3. powers the panel and SD card down and switches the +3.3 V rail
 *          (nPM1300 BUCK2) off,
 *       4. puts the STM32 into Stop 2 (SRAM + registers retained).
 *   - Wake sources:
 *       * any button press (EXTI),
 *       * power input: USB VBUS appearing. Default (BOARD_PC3_PMIC_IRQ=1):
 *         the nPM1300 raises its GPIO0 interrupt on PC3 and the MCU wakes
 *         at once and switches the 3.3 V rail on over I2C. Alternative
 *         (=0): PC3 enables the rail and VBUS is polled every 250 ms.
 *       * headphones PLUGGED IN (CS43131 INT). An unplug while asleep is
 *         masked and never wakes the system.
 *   - A button press, headphone plug or USB plug that happens WHILE the
 *     player is going to sleep (the white refresh takes ~2 s) is kept and
 *     wakes it straight back up (v2.2 discarded it).
 *   - On wake the rail comes back, the panel is re-initialised and - since
 *     it is known to be blank white - the previous screen is drawn with a
 *     fast PARTIAL refresh. The button press that woke the device is
 *     swallowed: pressing play while asleep only shows the paused song;
 *     a second press starts playback.
 */
#ifndef POWER_H
#define POWER_H

#include <stdbool.h>
#include <stdint.h>

/* Wake/IRQ flags set from interrupt handlers (stm32u5xx_it.c).           */
#define PWR_WAKE_BUTTON   (1u << 0)
#define PWR_WAKE_CODEC    (1u << 1)
#define PWR_WAKE_RTC      (1u << 2)
#define PWR_WAKE_PMIC     (1u << 3)
#define PWR_WAKE_FORCE    (1u << 4)     /* event seen during sleep entry   */
extern volatile uint32_t g_pwr_wake_flags;
extern volatile bool     g_pmic_irq_pending;   /* nPM1300 IRQ on PC3       */

/* Called first thing in main(): sets up PC3 for its role (PMIC interrupt
 * input, or rail-enable output driven HIGH before npm1300_init hands BUCK2
 * to it), parks unconnected pins and enables the low-power options.      */
void power_early_init(void);

/* Switch the +3.3 V rail (e-ink, SD card, VDDUSB).                       */
void power_rail_3v3(bool on);
bool power_rail_3v3_is_on(void);

/* Any user-visible activity: restarts the inactivity timer.              */
void power_note_activity(void);

/* Superloop hook: enters sleep when the inactivity timeout expires.      */
void power_poll(void);

/* Run the whole sleep cycle now; returns after wake-up.                  */
void power_sleep_now(void);
/* 2.7.0: sleep at the next power_poll() if nothing blocks it (sleep
 * timer ran out).                                                        */
void power_request_sleep(void);
/* 2.7.0: a panel that did not come back after two resets gets a power-on
 * reset by cycling the +3.3 V rail - only while nothing else needs the
 * rail (music playing, USB storage / DAC). Paused playback is kept.      */
void power_panel_service(void);

/* Inactivity timeout options (index stored in settings.sleep_timeout).   */
#define POWER_TIMEOUT_COUNT   6u        /* 2, 5, 10, 30 min, 1 h, never */
#define POWER_TIMEOUT_DEFAULT 2u        /* 10 min                        */
uint32_t    power_timeout_ms(uint8_t idx);        /* 0 = never          */
const char *power_timeout_label(uint8_t idx);

#endif /* POWER_H */
