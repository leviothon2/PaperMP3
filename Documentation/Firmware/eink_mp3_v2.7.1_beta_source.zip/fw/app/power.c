/**
 * @file    power.c
 * @brief   Inactivity sleep / wake orchestration (see power.h).
 *
 * Ordering matters on both edges:
 *
 *   sleep:  clear stale wake flags (they are set by every key press)
 *           player state -> SD (settings.txt)    needs SD + rail
 *           screen -> white (full refresh)        needs panel + rail
 *           panel deep-sleep, OE low, pins low    before the rail drops
 *           SD unmount + SDMMC off, pins analog   before the rail drops
 *           VDDUSB invalid                        before the rail drops
 *           codec: HP off, XTAL/CLKOUT off, only "plug" IRQ unmasked
 *           BUCK2 off (I2C task; PC3 low in the pin-control build)
 *           BUCK1 back to auto (PFM) mode
 *           Stop 2 loop (filters spurious / non-qualifying wakes); any
 *           wake source that fired during the steps above wakes at once
 *
 *   wake:   PLL back (160 MHz), swallow the button press that woke us
 *           BUCK1 forced PWM, BUCK2 on, wait for soft-start
 *           panel re-init, previous screen via PARTIAL refresh from white
 *           codec XTAL + CLKOUT back (SAI kernel clock)
 *           SD + FatFs remount; if the card's CID changed, the player
 *           drops the track instead of indexing a different card
 *           player re-opens the track (paused)
 */
#include "power.h"
#include "fuelgauge.h"
#include "library.h"
#include "settings.h"
#include "player.h"
#include "ui.h"
#include "usb_app.h"
#include "board.h"
#include "diag.h"
#include "../drivers/buttons.h"
#include "../drivers/eink.h"
#include "../drivers/sdcard.h"
#include "../drivers/cs43131.h"
#include "../drivers/npm1300.h"
#include "../drivers/sai_audio.h"
#include "stm32u5xx_hal.h"

void SystemClock_Config(void);

volatile uint32_t g_pwr_wake_flags;
volatile bool     g_pmic_irq_pending;           /* EXTI3, IRQ role only    */

#if !BOARD_PC3_PMIC_IRQ
static RTC_HandleTypeDef s_rtc;
static bool     s_rtc_ok;
#endif
static bool     s_rail_on;
static uint32_t s_last_activity;

/* ---- timeout table --------------------------------------------------------- */

/* Long steps on purpose: every sleep costs one full white refresh going
 * down (the most expensive thing the panel does), so short timeouts that
 * cycle often can cost more than they save.                              */
static const struct { uint32_t ms; const char *label; } k_timeouts[POWER_TIMEOUT_COUNT] = {
    {   2u * 60000u, "2 min"  },
    {   5u * 60000u, "5 min"  },
    {  10u * 60000u, "10 min" },
    {  30u * 60000u, "30 min" },
    {  60u * 60000u, "1 hour" },
    {   0u,          "never"  },
};

uint32_t power_timeout_ms(uint8_t idx)
{
    return k_timeouts[idx < POWER_TIMEOUT_COUNT ? idx : POWER_TIMEOUT_DEFAULT].ms;
}

const char *power_timeout_label(uint8_t idx)
{
    return k_timeouts[idx < POWER_TIMEOUT_COUNT ? idx : POWER_TIMEOUT_DEFAULT].label;
}

/* ---- rail ------------------------------------------------------------------ */

void power_rail_3v3(bool on)
{
#if BOARD_PC3_PMIC_IRQ
    (void)npm1300_buck2(on);                    /* BUCK2 task over I2C     */
#else
    HAL_GPIO_WritePin(PWR_3V3_EN_PORT, PWR_3V3_EN_PIN,
                      on ? GPIO_PIN_SET : GPIO_PIN_RESET);
#endif
    if (on && !s_rail_on) HAL_Delay(PWR_3V3_SETTLE_MS);
    s_rail_on = on;
}

bool power_rail_3v3_is_on(void) { return s_rail_on; }

/* ---- init ------------------------------------------------------------------ */

static void park_unused_pins(void)
{
    GPIO_InitTypeDef g = { 0 };
    g.Mode = GPIO_MODE_ANALOG;
    g.Pull = GPIO_NOPULL;
    g.Pin = BOARD_NC_GPIOA; HAL_GPIO_Init(GPIOA, &g);
    g.Pin = BOARD_NC_GPIOB; HAL_GPIO_Init(GPIOB, &g);
    g.Pin = BOARD_NC_GPIOC; HAL_GPIO_Init(GPIOC, &g);
    g.Pin = BOARD_NC_GPIOH; HAL_GPIO_Init(GPIOH, &g);
}

#if !BOARD_PC3_PMIC_IRQ
static void rtc_init(void)
{
    __HAL_RCC_RTC_ENABLE();
    __HAL_RCC_RTCAPB_CLK_ENABLE();

    s_rtc.Instance            = RTC;
    s_rtc.Init.HourFormat     = RTC_HOURFORMAT_24;
    s_rtc.Init.AsynchPrediv   = 127;          /* LSI 32 kHz -> 250 Hz      */
    s_rtc.Init.SynchPrediv    = 249;          /* -> 1 Hz calendar          */
    s_rtc.Init.OutPut         = RTC_OUTPUT_DISABLE;
    s_rtc.Init.OutPutRemap    = RTC_OUTPUT_REMAP_NONE;
    s_rtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
    s_rtc.Init.OutPutType     = RTC_OUTPUT_TYPE_OPENDRAIN;
    s_rtc.Init.OutPutPullUp   = RTC_OUTPUT_PULLUP_NONE;
    s_rtc.Init.BinMode        = RTC_BINARY_NONE;
    s_rtc.Init.BinMixBcdU     = RTC_BINARY_MIX_BCDU_0;
    s_rtc_ok = (HAL_RTC_Init(&s_rtc) == HAL_OK);

    HAL_NVIC_SetPriority(RTC_IRQn, 12, 0);
    HAL_NVIC_EnableIRQ(RTC_IRQn);
}
#endif

void power_early_init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();

    GPIO_InitTypeDef g = { 0 };
#if BOARD_PC3_PMIC_IRQ
    /* PC3 = PMIC interrupt input (rising edge = VBUS event). Never driven
     * by the MCU in this role - the PMIC drives the net push-pull.       */
    g.Mode = GPIO_MODE_IT_RISING;
    g.Pull = GPIO_NOPULL;
    g.Pin  = PMIC_IRQ_PIN;
    HAL_GPIO_Init(PMIC_IRQ_PORT, &g);
    HAL_NVIC_SetPriority(PMIC_IRQ_EXTI_IRQn, 11, 0);
    HAL_NVIC_EnableIRQ(PMIC_IRQ_EXTI_IRQn);
#else
    /* 3.3 V enable: HIGH before anything touches the PMIC.               */
    HAL_GPIO_WritePin(PWR_3V3_EN_PORT, PWR_3V3_EN_PIN, GPIO_PIN_SET);
    g.Mode  = GPIO_MODE_OUTPUT_PP;
    g.Pull  = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Pin   = PWR_3V3_EN_PIN;
    HAL_GPIO_Init(PWR_3V3_EN_PORT, &g);
    rtc_init();
#endif
    s_rail_on = true;                           /* BUCK2 default-on (VSET2) */

    park_unused_pins();

    /* Stop 2 current: ultra-low-power BOR/PVD sampling, flash off in Stop. */
    HAL_PWREx_EnableUltraLowPowerMode();
    /* v2.4.1: flash is NOT powered down in Sleep (WFI) any more. With it
     * on, every interrupt woke the flash and immediately fetched its
     * vector from it; during the e-ink refresh's current peak that fetch
     * returned garbage (HardFault, PC 0x00930010, LR = EXC_RETURN, every
     * time ~817 ms into the splash refresh). Stop 2 still turns the flash
     * off on its own.                                                    */
    __HAL_FLASH_SLEEP_POWERDOWN_DISABLE();

    s_last_activity = HAL_GetTick();
}

/* ---- activity / policy --------------------------------------------------------- */

void power_note_activity(void) { s_last_activity = HAL_GetTick(); }

static bool sleep_blocked(void)
{
    /* Always on while music plays or the host owns the device.           */
    return player_state() == PLAYER_PLAYING || usb_app_active() ||
           buttons_any_pressed() ||
           library_state() == LIB_BUILDING || library_state() == LIB_SCANNING;
}

static bool s_sleep_req;
void power_request_sleep(void) { s_sleep_req = true; }

void power_panel_service(void)
{
    if (!eink_wants_rail_cycle()) return;
    if (player_state() == PLAYER_PLAYING || usb_app_active()) return;
    diag_step(STEP_SLEEP);
    uint32_t card_id = sdcard_card_id();
    player_prepare_sleep();                     /* files closed, paused    */
    settings_flush();
    settings_unmount();
    sdcard_power_off();                         /* pins hi-Z before the rail drops */
    eink_power_off();                           /* OE low, A side low      */
    power_rail_3v3(false);
    HAL_Delay(PWR_3V3_RECOVER_OFF_MS);
    power_rail_3v3(true);
    eink_power_on();
    eink_rail_cycled();
    bool same_card = false;
    if (settings_card_start()) {
        uint32_t id = sdcard_card_id();
        same_card = (id != 0 && id == card_id);
        if (same_card) settings_remount_quiet();
        else           settings_mount();
    }
    player_after_wake(same_card);
    ui_after_wake();
}

void power_poll(void)
{
    if (sleep_blocked()) { s_last_activity = HAL_GetTick(); s_sleep_req = false; return; }
    if (s_sleep_req) {
        s_sleep_req = false;
        power_sleep_now();
        return;
    }

    uint32_t timeout = power_timeout_ms(settings_get()->sleep_timeout);
    if (!timeout) return;                       /* "never"                 */
    if (HAL_GetTick() - s_last_activity >= timeout)
        power_sleep_now();
}

/* ---- Stop 2 helpers ---------------------------------------------------------------- */

#if BOARD_PC3_PMIC_IRQ
/* VBUS plug-in is the only PMIC event allowed to wake the system; removal
 * is masked while asleep and re-enabled on wake. Returns true if a plug-in
 * was latched (happened during sleep entry) - the caller wakes at once.  */
static bool vbus_wake_arm(bool sleeping)
{
    npm1300_vbus_irq_enable(true, !sleeping);
    uint8_t ev = npm1300_take_vbus_events();    /* drop the line, re-arm   */
    __HAL_GPIO_EXTI_CLEAR_IT(PMIC_IRQ_PIN);
    g_pmic_irq_pending = false;
    return sleeping && (ev & NPM_EV_VBUS_DETECTED);
}
#else
static bool vbus_wake_arm(bool sleeping)
{
    if (!s_rtc_ok) return false;
    if (sleeping) {
        /* LSI/16 = 2 kHz ticks -> PWR_VBUS_POLL_MS poll period. Each poll
         * is a Stop-2 exit on HSI16 plus a 2-byte I2C read (~0.1 ms).    */
        HAL_RTCEx_SetWakeUpTimer_IT(&s_rtc, (2000u * PWR_VBUS_POLL_MS) / 1000u - 1u,
                                    RTC_WAKEUPCLOCK_RTCCLK_DIV16, 0);
    } else {
        HAL_RTCEx_DeactivateWakeUpTimer(&s_rtc);
    }
    return false;
}

void RTC_IRQHandler(void)
{
    HAL_RTCEx_WakeUpTimerIRQHandler(&s_rtc);
}

void HAL_RTCEx_WakeUpTimerEventCallback(RTC_HandleTypeDef *hrtc)
{
    (void)hrtc;
    g_pwr_wake_flags |= PWR_WAKE_RTC;
}
#endif

/* Enter Stop 2 once; returns with SYSCLK = HSI16 and SysTick running.
 * Called with interrupts masked (PRIMASK): WFI still wakes on a pending
 * IRQ, so a flag raised just before entry cannot be lost.               */
static void stop2_once(void)
{
    HAL_SuspendTick();
    __HAL_PWR_CLEAR_FLAG(PWR_FLAG_STOPF);
    HAL_PWREx_EnterSTOP2Mode(PWR_STOPENTRY_WFI);
    /* -- asleep -- */
    SystemCoreClockUpdate();                    /* HSI16 after wake-up     */
    HAL_InitTick(TICK_INT_PRIORITY);
    HAL_ResumeTick();
}

/* Sleep until a qualifying wake source fires. Returns true if the wake
 * was a power-input (VBUS) plug-in.                                      */
static bool stop2_until_wake(void)
{
    bool vbus_was = npm1300_vbus_status() != NPM_VBUS_NONE;

    for (;;) {
        __disable_irq();
        if (!g_pwr_wake_flags) stop2_once();
        __enable_irq();                         /* ISRs run here           */

        uint32_t f;
        __disable_irq();
        f = g_pwr_wake_flags;
        g_pwr_wake_flags = 0;
        __enable_irq();

        if (f & PWR_WAKE_FORCE)  return (f & PWR_WAKE_PMIC) != 0;
        if (f & PWR_WAKE_BUTTON) return false;

        if (f & PWR_WAKE_CODEC) {
            /* Only a headphone PLUG wakes (unplug is masked while asleep,
             * but re-check the status in case both latched).              */
            if (cs43131_service_irq_event() == CS_HP_EVENT_PLUG) return false;
        }

#if BOARD_PC3_PMIC_IRQ
        if (f & PWR_WAKE_PMIC) {
            /* PMIC asserted GPIO0: read + clear (drops the line).         */
            g_pmic_irq_pending = false;
            uint8_t ev = npm1300_take_vbus_events();
            if (ev & NPM_EV_VBUS_DETECTED) return true;   /* power input */
        }
        (void)vbus_was;
#else
        if (f & PWR_WAKE_RTC) {
            bool vbus = npm1300_vbus_status() != NPM_VBUS_NONE;
            bool plugged = vbus && !vbus_was;
            vbus_was = vbus;
            if (plugged) return true;           /* power input appeared    */
        }
#endif
    }
}

/* ---- the sleep cycle -------------------------------------------------------------- */

static void wake_flag_set(uint32_t f)          /* ISRs also write the word */
{
    __disable_irq();
    g_pwr_wake_flags |= f;
    __enable_irq();
}

void power_sleep_now(void)
{
    /* 0. Flags left over from normal operation (every key press and codec
     *    IRQ sets one) must not cut the sleep short - but anything that
     *    happens from here on must wake us (v2.2 cleared them only just
     *    before Stop 2 and lost events from the ~2 s sleep entry).       */
    diag_step(STEP_SLEEP);
    __disable_irq();
    g_pwr_wake_flags = 0;
    __enable_irq();
    bool vbus_before = npm1300_vbus_status() != NPM_VBUS_NONE;
    uint32_t card_id = sdcard_card_id();

    /* 1. state -> SD while SD is still powered.                           */
    player_prepare_sleep();
    usb_app_prepare_sleep();
    settings_flush();
    fuelgauge_before_sleep();

    /* 2. completely white screen, then the panel is powered down.         */
    ui_prepare_sleep();
    eink_power_off();

    /* 3. storage idle. 2.6.7: the card stays powered (rail on), bus
     * stopped - see sdcard_idle().                                       */
    settings_unmount();
    sdcard_idle();

    /* 4. codec to standby, only "headphones plugged" may interrupt.        */
    if (cs43131_sleep() == CS_HP_EVENT_PLUG)
        wake_flag_set(PWR_WAKE_FORCE);          /* plugged during entry    */
    sai_clock_pin(false);                       /* CLKOUT stopped          */

    /* 5. 2.6.7: the +3.3 V rail (BUCK2) stays ON through sleep. It feeds
     * the SD card, the TXS02612 card side, the panel (deep sleep, ~1 uA)
     * and VDDUSB; switching it off left the card without a clean power-on
     * reset after long sleeps (see CHANGELOG 2.6.6/2.6.7). Costs the
     * card's standby current. VDDUSB is still isolated inside the MCU.  */
    HAL_PWREx_DisableVddUSB();
    HAL_NVIC_DisableIRQ(SD_CD_EXTI_IRQn);       /* card swap is no wake    */

    (void)npm1300_buck1_pwm(false);             /* auto mode: low Iq        */

    /* 6. Stop 2 until a real wake source.                                  */
    if (vbus_wake_arm(true) ||
        (!vbus_before && npm1300_vbus_status() != NPM_VBUS_NONE))
        wake_flag_set(PWR_WAKE_FORCE | PWR_WAKE_PMIC);
    bool woke_by_vbus = stop2_until_wake();
    vbus_wake_arm(false);

    /* ---- wake ---------------------------------------------------------------- */
    SystemClock_Config();                       /* back to 160 MHz         */
    diag_step(STEP_WAKE);
    buttons_ignore_until_release();             /* swallow the wake press  */
    (void)npm1300_buck1_pwm(true);
    fuelgauge_after_wake();

    /* Rail never went off (2.6.7). Screen first: everything it shows (menu, tags, art, position) is
     * still in RAM, so the user sees the previous state ~0.3 s after the
     * press, while storage and audio come back behind it.                */
    eink_power_on();                            /* panel known white       */
    ui_after_wake();                            /* partial redraw          */

    cs43131_wake();
    sai_clock_pin(true);
    if (woke_by_vbus) usb_app_vbus_replugged();

    __HAL_GPIO_EXTI_CLEAR_IT(SD_CD_PIN);
    HAL_NVIC_EnableIRQ(SD_CD_EXTI_IRQn);
    bool same_card = false;
    if (settings_card_start()) {
        uint32_t id = sdcard_card_id();
        same_card = (id != 0 && id == card_id);
        if (same_card) settings_remount_quiet();
        else           settings_mount();        /* new card: full reload   */
    }
    player_after_wake(same_card);               /* re-open track, paused   */

    s_last_activity = HAL_GetTick();
}
