/**
 * @file    podcast.h
 * @brief   Podcasts (2.7.0): every audio file under /Podcasts, as one
 *          plain list, with a per-episode listening position.
 *
 * Podcasts are kept apart from music: the folder is skipped by the music
 * scan (Shuffle all, Music, Artists, Albums never contain an episode), the
 * list has no Shuffle / Play rows, an episode resumes where it stopped,
 * and playback stops at the end of the episode.
 *
 *   /Podcasts/...            episodes (sub-folders allowed, 3 levels)
 *   /.eplayer/podcasts.idx   the list, one path per line, sorted by name
 *   /.eplayer/podcasts.dat   positions: 16 bytes per episode
 *
 * The list is rebuilt whenever the card was mounted since the last look
 * (a computer may have added episodes). Positions are keyed by a hash of
 * the path, so they survive a rebuild; entries of deleted files drop out
 * the next time the table fills up. Up to 200 episodes.
 */
#ifndef PODCAST_H
#define PODCAST_H

#include <stdbool.h>
#include <stdint.h>

#define POD_MAX        200u
#define POD_LIST_SPEC  "@pod"          /* playlist_open() name of the list */

typedef enum { POD_NEW, POD_STARTED, POD_DONE } pod_state_t;

typedef struct {
    pod_state_t state;
    uint32_t    pos_ms;        /* where to resume (POD_STARTED)             */
    uint32_t    len_ms;        /* 0 = not known yet                         */
} pod_progress_t;

bool        podcast_path_is(const char *path);     /* under /Podcasts       */
/* Make sure the list matches the card; returns the number of episodes.    */
uint32_t    podcast_refresh(void);
uint32_t    podcast_count(void);
const char *podcast_index_path(void);
bool        podcast_entry(uint32_t n, char *path, uint32_t len);
/* Display name: the file name without folder and extension.                */
void        podcast_name(const char *path, char *buf, uint32_t len);

void podcast_progress(const char *path, pod_progress_t *out);
/* Record a position. finished = the episode played to its end.            */
void podcast_note(const char *path, uint32_t pos_ms, uint32_t len_ms, bool finished);
void podcast_flush(void);              /* write positions if they changed   */
void podcast_poll(void);               /* main loop: deferred write         */
void podcast_card_changed(void);       /* mount / unmount                   */

#endif /* PODCAST_H */
