/**
 * @file    player.c
 * @brief   Playback engine.
 *
 * Track lifecycle is split in two so sleep/wake can re-open a track
 * without touching the audio hardware:
 *   open_track()   playlist lookup, tags/art, decoder open (+ seek)
 *   start_output() DAC + SAI + ring ("pipe") for the decoded format
 * A track can therefore be PAUSED with no output running (after a wake,
 * after a resume, or after 30 s paused): the next play press calls
 * start_output().
 *
 * Decode pump: whenever the ring is below half (186 ms at 44.1 kHz),
 * decode in 512-frame chunks until it is half full again. The pump also
 * runs from the e-ink driver's idle hook, so panel refreshes (0.3-4 s)
 * no longer starve the ring.
 *
 * v2.3 robustness: a PLAYING state is only kept while audio actually
 * flows - end of stream with nowhere to go stops; an output that stops
 * consuming (no I2S clock, dead codec) stops with PLAYER_ERR_OUTPUT; a
 * new playlist stops the old track before the list file is swapped.
 */
#include "player.h"
#include "playlist.h"
#include "settings.h"
#include "power.h"
#include "usb_app.h"
#include "diag.h"
#include "podcast.h"
#include "library.h"
#include "../audio/timestretch.h"
#include "../audio/decoder.h"
#include "../audio/dsd.h"
#include "../audio/audio_pipeline.h"
#include "../drivers/cs43131.h"
#include "../drivers/sdcard.h"
#include "stm32u5xx_hal.h"

#include <string.h>

extern volatile bool g_codec_irq_pending;   /* stm32u5xx_it.c             */
extern volatile bool g_sd_cd_changed;

#define PAUSE_OUTPUT_OFF_MS  30000u  /* paused this long: DAC + SAI off    */
#define STALL_MS              1500u  /* PLAYING but the DAC takes nothing  */

static player_state_t s_state = PLAYER_STOPPED;
static track_tags_t   s_tags;
static uint8_t        s_art[ART_SIZE * ART_SIZE];
static bool           s_has_art;
static dec_info_t     s_dinfo;
static dsd_info_t     s_dsdinfo;
static bool           s_is_dsd;
static bool           s_track_open;         /* decoder/DSD file is open   */
static uint32_t       s_track_pos;
static uint32_t       s_resume_ms;          /* position while suspended   */
static bool           s_suspended;          /* closed for system sleep    */
static bool           s_shuffle;            /* current context shuffled   */
static char           s_playlist_file[PL_NAME_MAX];
static char           s_path[PL_PATH_MAX];

static uint32_t       s_seq, s_track_seq;
static player_err_t   s_err;
static uint32_t       s_paused_at;
static uint32_t       s_last_consumed, s_last_progress;
static bool           s_in_poll;
/* What the running output was started for (to reuse it on the next track) */
static bool           s_out_dsd;
static uint32_t       s_out_rate;           /* PCM source Hz / dsd_rate_t */
/* Gapless (2.6.0)                                                         */
static bool           s_gap_wait;           /* next track queued; output
                                               restarts once the ring drains
                                               (format differs)           */
static bool           s_gap_skip;           /* ...or the next entry failed:
                                               advance normally then      */
static bool           s_tags_pending;       /* opened gaplessly: tags/art
                                               still to read              */
/* 2.7.0                                                                   */
static bool           s_is_pod;             /* context = /Podcasts list   */
static uint32_t       s_pod_note_t;         /* last periodic position note */
static uint8_t        s_timer_min;          /* sleep timer as set, 0 = off */
static uint32_t       s_timer_end;          /* HAL tick it runs out        */
static bool           s_timer_wait_eos;     /* ran out: stop after the song */
static bool           s_sleep_req;
static int            s_fade_vol = -1;      /* volume the fade has applied */
static uint32_t       s_fade_t;

static void fade_restore(void);
static void timer_fire(void);
static void timer_poll(uint32_t now);

static void changed(bool track)
{
    s_seq++;
    if (track) s_track_seq++;
}

static void set_error(player_err_t e) { s_err = e; s_seq++; }

bool player_output_allowed(void)
{
    return !settings_get()->hp_detect || cs43131_headphones_present();
}

bool player_is_podcast(void) { return s_is_pod && s_state != PLAYER_STOPPED; }

static void context_set(const char *playlist_file)
{
    strncpy(s_playlist_file, playlist_file ? playlist_file : "", sizeof s_playlist_file - 1);
    s_playlist_file[sizeof s_playlist_file - 1] = '\0';
    s_is_pod = !strcmp(s_playlist_file, POD_LIST_SPEC);
}

/* Podcast speed: the stretcher exists only while an episode plays at a
 * speed other than 1.0x (PCM up to 48 kHz); everything else is untouched. */
static void stretch_setup(void)
{
    uint16_t sp = settings_speed_x100(settings_get()->pod_speed);
    bool want = s_is_pod && s_track_open && !s_is_dsd && sp != 100u &&
                s_dinfo.sample_rate <= TS_MAX_RATE;
    if (!want) { ts_end(); return; }
    if (ts_active()) ts_set_speed(sp);
    else (void)ts_begin(s_dinfo.sample_rate, sp);
}

void player_speed_changed(void)
{
    if (s_state != PLAYER_STOPPED) stretch_setup();
    changed(false);
}

/* ---- track lifecycle ------------------------------------------------------ */

static void close_decoder(void)
{
    dec_close();
    dsd_close();
    ts_end();
    s_track_open = false;
}

static void close_track(void)
{
    pipe_stop();
    close_decoder();
    s_gap_wait = s_gap_skip = s_tags_pending = false;
}

static bool seek_ms(uint32_t ms)
{
    if (!s_track_open) return false;
    ts_reset();
    return s_is_dsd ? dsd_seek_ms(ms) : dec_seek_ms(ms);
}

/* Open playlist entry `pos`; read tags/art only when `with_tags`.        */
static bool open_track(uint32_t pos, bool with_tags)
{
    close_decoder();               /* output is the caller's decision      */
    s_is_dsd = false;

    if (!playlist_track(pos, s_path, sizeof s_path)) return false;
    s_track_pos = pos;

    if (with_tags) {
        s_tags_pending = false;
        diag_step(STEP_TRACK_TAGS);
        settings_t *cfg = settings_get();
        tags_read(s_path, &s_tags, cfg->album_art ? s_art : NULL);
        s_has_art = s_tags.has_art;
    }

    diag_step(STEP_TRACK_OPEN);
    if (dec_format_from_path(s_path) == DEC_FMT_DSD) {
        if (!dsd_open(s_path, &s_dsdinfo)) return false;
        if (s_dsdinfo.rate == DSD_256) { dsd_close(); return false; }
        s_is_dsd = true;
    } else {
        if (!dec_open(s_path, &s_dinfo)) return false;
    }
    s_track_open = true;
    return true;
}

static bool start_output(void)
{
    diag_step(STEP_AUDIO_START);
    bool ok = s_is_dsd ? pipe_start_dop(s_dsdinfo.rate)
                       : pipe_start_pcm(s_dinfo.sample_rate);
    if (ok) {
        cs43131_set_volume(settings_get()->volume);
        s_out_dsd  = s_is_dsd;
        s_out_rate = s_is_dsd ? (uint32_t)s_dsdinfo.rate : s_dinfo.sample_rate;
    }
    s_last_consumed = pipe_consumed();
    s_last_progress = HAL_GetTick();
    return ok;
}

/* Close the DAC/SAI but keep the track open, re-synced to what was heard
 * (the ring's unplayed audio is dropped, so step the decoder back).      */
static void close_output(void)
{
    if (pipe_mode() == PIPE_IDLE) return;
    uint32_t heard = player_pos_ms();
    pipe_stop();
    if (!seek_ms(heard)) s_resume_ms = heard;
}

static void remember(uint32_t track, uint32_t pos_ms)
{
    settings_t *cfg = settings_get();
    strncpy(cfg->last_playlist, s_playlist_file, sizeof cfg->last_playlist - 1);
    cfg->last_playlist[sizeof cfg->last_playlist - 1] = '\0';
    cfg->last_track_idx = track;
    cfg->last_pos_ms    = pos_ms;
    cfg->last_shuffle   = s_shuffle;
    settings_save();
    /* Podcasts keep a position per episode as well.                       */
    if (s_is_pod && s_track_open && track == s_track_pos)
        podcast_note(s_path, pos_ms, player_len_ms(), false);
}

static void remember_position(uint32_t pos_ms) { remember(s_track_pos, pos_ms); }

/* v2.4: a running output is reused when the next track has the same
 * format (PCM source rate / DSD speed): the ring is flushed instead of the
 * DAC doing a full pop-free power-down and charge-pump restart on every
 * track change - each restart is an inrush on the 1.8 V rail.            */
static bool output_matches(void)
{
    pipe_mode_t m = pipe_mode();
    if (m == PIPE_IDLE || s_out_dsd != s_is_dsd) return false;
    if (s_is_dsd) return m == PIPE_DOP && s_out_rate == (uint32_t)s_dsdinfo.rate;
    return m == PIPE_PCM && s_out_rate == s_dinfo.sample_rate;
}

static bool reuse_or_start_output(void)
{
    if (output_matches()) {
        pipe_flush();
        if (pipe_paused()) pipe_pause(false);
        cs43131_set_volume(settings_get()->volume);
        s_last_consumed = pipe_consumed();
        s_last_progress = HAL_GetTick();
        return true;
    }
    pipe_stop();
    return start_output();
}

/* Open + play; unplayable entries (corrupt, DSD256, missing) are skipped
 * forward, bounded so a playlist of nothing but bad files can't spin.    */
static bool load_track(uint32_t pos)
{
    uint32_t n = playlist_count();
    bool output_failed = false;
    /* Leaving an episode by skipping: keep where it was.                  */
    if (s_is_pod && s_track_open && s_state != PLAYER_STOPPED)
        podcast_note(s_path, player_pos_ms(), player_len_ms(), false);
    for (uint32_t tries = 0; tries < n && tries < 16; tries++) {
        if (open_track(pos, true)) {
            uint32_t start_ms = 0;
            if (s_is_pod) {
                /* Resume the episode where it was left.                    */
                pod_progress_t pg;
                podcast_progress(s_path, &pg);
                if (pg.state == POD_STARTED && seek_ms(pg.pos_ms)) start_ms = pg.pos_ms;
                stretch_setup();
                s_pod_note_t = HAL_GetTick();
            }
            if (!player_output_allowed()) {
                /* 2.7.0 headphone gate: loaded and shown, but paused with
                 * no output; play starts it once headphones are in.       */
                pipe_stop();
                s_resume_ms = start_ms;
                s_state = PLAYER_PAUSED;
                s_paused_at = HAL_GetTick();
                remember_position(start_ms);
                changed(true);
                set_error(PLAYER_ERR_NO_HEADPHONES);
                return true;
            }
            if (reuse_or_start_output()) {
                s_state = PLAYER_PLAYING;
                remember_position(start_ms);
                changed(true);
                return true;
            }
            output_failed = true;
            break;                       /* the DAC, not the file, failed */
        }
        if (s_is_pod) break;             /* never slide to another episode */
        if (++pos >= n) {
            if (settings_get()->repeat == 1) pos = 0;
            else break;
        }
    }
    close_track();
    s_state = PLAYER_STOPPED;
    changed(true);
    set_error(output_failed ? PLAYER_ERR_OUTPUT : PLAYER_ERR_NO_MUSIC);
    return false;
}

/* Stop at the end of the list: the resume point goes back to the start
 * (v2.2 saved the end of the last track, so "resume" played nothing).    */
static void stop_at_end(void)
{
    close_track();
    if (s_state != PLAYER_STOPPED) remember(0, 0);
    s_state = PLAYER_STOPPED;
    changed(false);
}

/* user = SW2; !user = end of stream. Returns false if nothing was loaded. */
static bool advance(bool user)
{
    uint32_t n = playlist_count();
    if (!n) return false;
    settings_t *cfg = settings_get();
    if (s_is_pod && !user) return false;       /* an episode ends: stop   */
    uint32_t next = s_track_pos + 1;
    if (!user && cfg->repeat == 2) next = s_track_pos;   /* repeat one: EOF only */
    if (next >= n) {
        if (cfg->repeat == 1) next = 0;
        else return false;
    }
    return load_track(next);
}

void player_init(void) { }

bool player_play(const char *playlist_file, uint32_t track_pos, bool shuffle)
{
    if (usb_app_busy()) { set_error(PLAYER_ERR_BUSY); return false; }
    player_stop();                       /* old track off before the list */
    settings_t *cfg = settings_get();
    if (!playlist_open(playlist_file)) { set_error(PLAYER_ERR_NO_MUSIC); return false; }
    context_set(playlist_file);
    /* Fresh order per play; the seed and the shuffle flag are saved with
     * the resume point so the same order comes back after a reboot.     */
    s_shuffle = shuffle;
    cfg->shuffle_seed = HAL_GetTick() ^ (SysTick->VAL << 12) ^ 0xC0FFEE42u;
    playlist_set_shuffle(shuffle, cfg->shuffle_seed);
    if (track_pos >= playlist_count()) track_pos = 0;
    return load_track(track_pos);
}

bool player_resume_last(void)
{
    if (usb_app_busy()) { set_error(PLAYER_ERR_BUSY); return false; }
    player_stop();
    settings_t *cfg = settings_get();
    if (!playlist_open(cfg->last_playlist)) {
        if (!playlist_open("")) { set_error(PLAYER_ERR_NO_MUSIC); return false; }
        cfg->last_playlist[0] = '\0';
        cfg->last_track_idx = 0;
        cfg->last_pos_ms = 0;
    }
    context_set(cfg->last_playlist);
    s_shuffle = cfg->last_shuffle;                   /* same order        */
    playlist_set_shuffle(s_shuffle, cfg->shuffle_seed);
    uint32_t pos = cfg->last_track_idx;
    uint32_t ms  = cfg->last_pos_ms;
    if (pos >= playlist_count()) { pos = 0; ms = 0; }
    if (!load_track(pos)) return false;
    /* An episode has already been put at its own saved position.          */
    if (!s_is_pod && ms && s_track_pos == pos && seek_ms(ms)) {
        pipe_flush();
        s_resume_ms = ms;
        remember_position(ms);
    }
    return true;
}

void player_toggle_pause(void)
{
    if (s_state == PLAYER_PLAYING) {
        pipe_pause(true);
        s_state = PLAYER_PAUSED;
        s_paused_at = HAL_GetTick();
        remember_position(player_pos_ms());
        changed(false);
    } else if (s_state == PLAYER_PAUSED) {
        if (!player_output_allowed()) {         /* 2.7.0 headphone gate    */
            set_error(PLAYER_ERR_NO_HEADPHONES);
            return;
        }
        if (pipe_mode() == PIPE_IDLE) {
            /* Paused with no output (after wake / long pause).           */
            if (!s_track_open) { player_stop(); return; }
            if (!start_output()) {
                close_track();
                s_state = PLAYER_STOPPED;
                changed(false);
                set_error(PLAYER_ERR_OUTPUT);
                return;
            }
        } else {
            pipe_pause(false);
        }
        s_last_consumed = pipe_consumed();
        s_last_progress = HAL_GetTick();
        s_state = PLAYER_PLAYING;
        changed(false);
    }
}

void player_next(void)
{
    if (s_state == PLAYER_STOPPED || !playlist_count()) return;
    if (!advance(true)) stop_at_end();
}

void player_prev(void)
{
    uint32_t n = playlist_count();
    if (s_state == PLAYER_STOPPED || !n) return;
    if (player_pos_ms() > 3000) {                     /* restart current */
        if (seek_ms(0)) { pipe_flush(); changed(false); return; }
        load_track(s_track_pos);         /* no seek (rare): re-open       */
        return;
    }
    uint32_t prev = s_track_pos ? s_track_pos - 1
                  : (settings_get()->repeat == 1 ? n - 1 : 0);
    load_track(prev);
}

void player_stop(void)
{
    if (s_state != PLAYER_STOPPED) remember_position(player_pos_ms());
    fade_restore();
    close_track();
    if (s_state != PLAYER_STOPPED) { s_state = PLAYER_STOPPED; changed(false); }
}

void player_storage_lost(void)
{
    close_track();
    if (s_state != PLAYER_STOPPED) { s_state = PLAYER_STOPPED; changed(false); }
}

void player_volume_delta(int8_t d)
{
    settings_t *cfg = settings_get();
    int v = (int)cfg->volume + d;
    if (v < 0) v = 0;
    if (v > 100) v = 100;
    cfg->volume = (uint8_t)v;
    cs43131_set_volume(cfg->volume);
    settings_save();
}

/* ---- accessors ------------------------------------------------------------- */

player_state_t player_state(void) { return s_state; }
const track_tags_t *player_tags(void) { return &s_tags; }
const uint8_t *player_art(void) { return s_has_art ? s_art : NULL; }
uint32_t player_track_pos(void) { return s_track_pos; }
const char *player_playlist_file(void) { return s_playlist_file; }
bool player_shuffled(void) { return s_shuffle; }
uint32_t player_seq(void) { return s_seq; }
uint32_t player_track_seq(void) { return s_track_seq; }

player_err_t player_take_error(void)
{
    player_err_t e = s_err;
    s_err = PLAYER_ERR_NONE;
    return e;
}

uint32_t player_pos_ms(void)
{
    if (s_suspended || !s_track_open) return s_resume_ms;
    uint32_t t = s_is_dsd ? dsd_tell_ms() : dec_tell_ms();
    uint32_t b = pipe_buffered_ms();           /* decoded, not yet heard  */
    if (ts_active()) {
        /* Buffered audio is in output time; the episode moves faster.    */
        b = b * settings_speed_x100(settings_get()->pod_speed) / 100u +
            ts_pending_in() * 1000u / s_dinfo.sample_rate;
    }
    return t > b ? t - b : 0;
}

uint32_t player_len_ms(void)
{
    return s_is_dsd ? s_dsdinfo.duration_ms : s_dinfo.duration_ms;
}

/* ---- system sleep ----------------------------------------------------------- */

void player_prepare_sleep(void)
{
    if (s_state == PLAYER_PLAYING) {          /* not normally reached     */
        pipe_pause(true);
        s_state = PLAYER_PAUSED;
    }
    s_resume_ms = player_pos_ms();
    if (s_state != PLAYER_STOPPED) remember_position(s_resume_ms);
    close_track();                            /* FatFs handles die w/ SD  */
    playlist_suspend();
    s_suspended = true;
}

void player_after_wake(bool same_card)
{
    if (!s_suspended) return;
    s_suspended = false;
    if (!same_card) {                         /* card swapped while asleep */
        if (s_state != PLAYER_STOPPED) { s_state = PLAYER_STOPPED; changed(true); }
        return;
    }
    playlist_resume();
    if (s_state == PLAYER_STOPPED) return;

    /* Re-open the same track at the same spot, PAUSED, no output yet.
     * Tags + art are still in RAM (Stop 2 retains SRAM).                 */
    if (sdcard_ready() && open_track(s_track_pos, false)) {
        if (s_resume_ms) seek_ms(s_resume_ms);
        s_state = PLAYER_PAUSED;
    } else {
        s_state = PLAYER_STOPPED;             /* card removed             */
        changed(true);
    }
}

/* ---- pumps ------------------------------------------------------------------ */

/* Decode into the ring until it is half full. Returns true at end of the
 * current stream.                                                        */
static bool pump(void)
{
    static int32_t pcm[512 * 2];
    if (!s_track_open) return false;
    if (s_is_dsd) {
        while (pipe_hungry() && pipe_writable_frames() >= 512) {
            uint32_t n = dsd_read_dop(pcm, 512);
            if (!n) return true;
            pipe_push_dop(pcm, n);
        }
    } else if (ts_active()) {
        /* Podcast at a speed other than 1.0x: decoder -> stretcher -> ring. */
        for (;;) {
            if (!pipe_hungry()) break;
            uint32_t room = pipe_max_input_frames();
            if (room < 64) break;
            uint32_t m = ts_pull(pcm, room > 512 ? 512 : room);
            if (m) { pipe_push_pcm(pcm, m); continue; }
            uint32_t want = ts_room();
            if (want > 512) want = 512;
            if (!want) break;
            uint32_t n = dec_read(pcm, want);
            if (!n) return true;                 /* tail < 40 ms dropped  */
            ts_push(pcm, n);
        }
    } else {
        for (;;) {
            if (!pipe_hungry()) break;
            uint32_t want = pipe_max_input_frames();
            if (want < 64) break;                /* ring nearly full      */
            if (want > 512) want = 512;
            uint32_t n = dec_read(pcm, want);
            if (!n) return true;
            pipe_push_pcm(pcm, n);
        }
    }
    return false;
}

/* Called from tags.c between its file reads (cover-art decode can take
 * longer than the ring lasts at high sample rates).                      */
static void pump_hook(void)
{
    if (s_state == PLAYER_PLAYING && pipe_mode() != PIPE_IDLE) (void)pump();
}

/* End of stream with gapless on: open the next entry right away and keep
 * the output running if its format matches - no drain, no flush, so the
 * last sample of one track is followed by the first of the next. Returns
 * false when there is no next entry (end of list): the caller drains and
 * stops as before.                                                       */
static bool gapless_next(void)
{
    uint32_t n = playlist_count();
    if (!n || s_is_pod || s_timer_wait_eos) return false;
    settings_t *cfg = settings_get();
    uint32_t next = s_track_pos + 1;
    if (cfg->repeat == 2) next = s_track_pos;            /* repeat one     */
    if (next >= n) {
        if (cfg->repeat == 1) next = 0;
        else return false;
    }
    if (!open_track(next, false)) {
        /* Unplayable: let the tail play out, then skip on normally.       */
        s_gap_wait = s_gap_skip = true;
        return true;
    }
    if (output_matches()) {
        s_tags_pending = true;                 /* seamless: ring untouched */
        return true;
    }
    s_gap_wait = true;                         /* new rate: drain, restart */
    return true;
}

/* ---- sleep timer (2.7.0) ---------------------------------------------------- */

static void fade_restore(void)
{
    if (s_fade_vol >= 0) cs43131_set_volume(settings_get()->volume);
    s_fade_vol = -1;
}

static void timer_fire(void)
{
    if (s_state == PLAYER_PLAYING) {
        pipe_pause(true);                     /* silence before the level  */
        s_state = PLAYER_PAUSED;              /* comes back up             */
        s_paused_at = HAL_GetTick();
        remember_position(player_pos_ms());
    }
    fade_restore();
    s_timer_min = 0;
    s_timer_wait_eos = false;
    s_sleep_req = true;
    changed(false);
}

static void timer_poll(uint32_t now)
{
    if (!s_timer_min) return;
    if (s_timer_wait_eos) {                   /* waiting for the song's end */
        if (s_state != PLAYER_PLAYING) timer_fire();   /* paused by hand   */
        return;
    }
    int32_t left = (int32_t)(s_timer_end - now);
    settings_t *cfg = settings_get();
    if (s_state != PLAYER_PLAYING) {
        if (left <= 0) timer_fire();
        return;
    }
    if (cfg->timer_song_end) {
        if (left <= 0) s_timer_wait_eos = true;   /* handled at end of song */
        return;
    }
    int32_t fade_ms = (int32_t)cfg->timer_fade_s * 1000;
    if (left > 0 && fade_ms && left < fade_ms && now - s_fade_t >= 200u) {
        int v = (int)((int32_t)cfg->volume * left / fade_ms);
        if (v < 1) v = 1;
        if (v != s_fade_vol) {
            cs43131_set_volume((uint8_t)v);
            s_fade_vol = v;
        }
        s_fade_t = now;
    }
    if (left <= 0) timer_fire();
}

void player_timer_set(uint8_t minutes)
{
    fade_restore();
    s_timer_min = minutes;
    s_timer_wait_eos = false;
    s_timer_end = HAL_GetTick() + (uint32_t)minutes * 60000u;
    if (minutes) {
        settings_get()->timer_min = minutes;
        settings_save();
    }
    changed(false);
}

uint8_t player_timer_minutes(void) { return s_timer_min; }

bool player_take_sleep_request(void)
{
    bool r = s_sleep_req;
    s_sleep_req = false;
    return r;
}

/* ---- loop / queue / remove (2.7.0) ------------------------------------------- */

bool player_loop(void) { return settings_get()->repeat == 2; }

void player_set_loop(bool on)
{
    settings_t *cfg = settings_get();
    if (on && cfg->repeat != 2) {
        cfg->repeat_before_loop = cfg->repeat;
        cfg->repeat = 2;
    } else if (!on && cfg->repeat == 2) {
        cfg->repeat = cfg->repeat_before_loop <= 1 ? cfg->repeat_before_loop : 0;
    }
    settings_save();
    changed(false);
}

uint32_t player_queue_count(void)
{
    uint32_t n = playlist_count();
    if (s_state == PLAYER_STOPPED || s_track_pos + 1u >= n) return 0;
    return n - s_track_pos - 1u;
}

bool player_queue_title(uint32_t q, char *buf, uint32_t len)
{
    char path[PL_PATH_MAX];
    if (q >= player_queue_count() ||
        !playlist_track(s_track_pos + 1u + q, path, sizeof path)) return false;
    if (!s_is_pod && library_title_for_path(path, buf, len)) return true;
    podcast_name(path, buf, len);             /* file name, no extension   */
    return true;
}

bool player_jump(uint32_t q)
{
    if (q >= player_queue_count()) return false;
    return load_track(s_track_pos + 1u + q);
}

bool player_can_remove(void)
{
    return s_state != PLAYER_STOPPED && playlist_is_file();
}

bool player_remove_current(void)
{
    if (!player_can_remove()) return false;
    uint32_t pos = s_track_pos;
    bool was_playing = (s_state == PLAYER_PLAYING);
    if (!playlist_remove(pos)) return false;  /* list unchanged, keeps playing */
    uint32_t n = playlist_count();
    if (pos >= n) {
        if (n && settings_get()->repeat == 1) pos = 0;
        else { stop_at_end(); return true; }  /* it was the last song      */
    }
    /* Position `pos` is now the song that came next.                      */
    if (load_track(pos) && !was_playing && s_state == PLAYER_PLAYING)
        player_toggle_pause();                /* it was paused: stay paused */
    return true;
}

void player_poll(void)
{
    if (s_in_poll) return;                    /* e-ink idle hook re-entry */
    s_in_poll = true;
    uint32_t now = HAL_GetTick();

    /* Long pause: power the DAC + SAI down, keep the track open.         */
    if (s_state == PLAYER_PAUSED && pipe_mode() != PIPE_IDLE &&
        now - s_paused_at >= PAUSE_OUTPUT_OFF_MS)
        close_output();

    timer_poll(now);

    if (s_state != PLAYER_PLAYING) { s_in_poll = false; return; }
    diag_step(STEP_DECODE);

    if (s_is_pod && now - s_pod_note_t >= 30000u) {
        s_pod_note_t = now;
        podcast_note(s_path, player_pos_ms(), player_len_ms(), false);
    }

    /* PLAYING must mean audio is flowing.                                 */
    if (pipe_mode() == PIPE_IDLE || (!s_track_open && !s_gap_wait)) {
        player_stop();
        set_error(PLAYER_ERR_OUTPUT);
        s_in_poll = false;
        return;
    }
    uint32_t c = pipe_consumed();
    if (c != s_last_consumed) {
        s_last_consumed = c;
        s_last_progress = now;
    } else if (now - s_last_progress >= STALL_MS) {
        player_stop();                         /* no I2S clock from DAC   */
        set_error(PLAYER_ERR_OUTPUT);
        s_in_poll = false;
        return;
    }

    /* While the old tail drains before an output-format change, the next
     * track (already open) must not be decoded at the old rate.          */
    bool eos = s_gap_wait ? false : pump();

    /* ---- gapless (2.6.0) ---------------------------------------------- */
    if (s_gap_wait) {
        /* Previous track's tail is still in the ring; the next one needs a
         * different output format (or failed to open).                    */
        if (pipe_fill_frames() == 0) {
            s_gap_wait = false;
            if (s_gap_skip) {
                s_gap_skip = false;
                if (!advance(false)) stop_at_end();
            } else {
                diag_step(STEP_TRACK_TAGS);
                settings_t *cfg = settings_get();
                tags_read(s_path, &s_tags, cfg->album_art ? s_art : NULL);
                s_has_art = s_tags.has_art;
                if (reuse_or_start_output()) {
                    remember_position(0);
                    changed(true);
                } else {
                    close_track();
                    s_state = PLAYER_STOPPED;
                    changed(true);
                    set_error(PLAYER_ERR_OUTPUT);
                }
            }
        }
    } else if (eos) {
        if (settings_get()->gapless && gapless_next()) {
            /* next track queued straight behind this one                  */
        } else if (pipe_fill_frames() == 0) {
            /* Track finished and the ring drained (tail not cut).         */
            if (s_is_pod) podcast_note(s_path, 0, player_len_ms(), true);
            if (s_timer_wait_eos) {
                /* Sleep timer, "finish the song": the next song is loaded
                 * so resume continues there, and paused at once.          */
                if (!advance(false)) stop_at_end();
                timer_fire();
            } else if (!advance(false)) {
                stop_at_end();
            }
        }
    }

    /* Gaplessly opened track: read its tags/art once the ring is well
     * filled; the decode pump keeps running from tags.c's idle hook
     * while the cover art decodes.                                        */
    if (s_tags_pending && s_state == PLAYER_PLAYING && !pipe_hungry()) {
        s_tags_pending = false;
        diag_step(STEP_TRACK_TAGS);
        settings_t *cfg = settings_get();
        tags_set_idle_hook(pump_hook);
        tags_read(s_path, &s_tags, cfg->album_art ? s_art : NULL);
        tags_set_idle_hook(NULL);
        s_has_art = s_tags.has_art;
        remember_position(0);
        changed(true);
    }
    s_in_poll = false;
}

bool player_busy(void)
{
    return s_state == PLAYER_PLAYING && pipe_hungry();
}

void player_power_poll(void)
{
    /* Codec interrupt: headphone plug/unplug.                            */
    {
        bool irq = g_codec_irq_pending;
        g_codec_irq_pending = false;
        cs_hp_event_t ev = cs43131_hp_poll(irq);  /* 2.7.1: edge, level, poll */
        if (ev == CS_HP_EVENT_UNPLUG && s_state == PLAYER_PLAYING) {
            player_toggle_pause();                /* auto-pause on unplug */
            if (settings_get()->hp_detect) set_error(PLAYER_ERR_NO_HEADPHONES);
        }
        if (ev != CS_HP_EVENT_NONE) power_note_activity();
    }

    /* SD card removal: stop cleanly before FatFs starts failing.         */
    if (g_sd_cd_changed) {
        g_sd_cd_changed = false;
        power_note_activity();
        if (!sdcard_present()) {
            player_storage_lost();
            podcast_card_changed();
            settings_unmount();
            if (!usb_app_storage_owned()) sdcard_deinit();
        } else if (!sdcard_ready() && !usb_app_storage_owned()) {
            /* Never mount while the host owns the card (USB storage):
             * two writers on one FAT volume corrupt it.                  */
            if (settings_card_start()) settings_mount();
        }
    }
}
