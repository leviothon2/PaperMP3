/**
 * @file    playlist.c
 * @brief   Playlist files + "Play all" scan + shuffle permutation.
 */
#include "playlist.h"
#include "diag.h"
#include "../audio/decoder.h"
#include "library.h"
#include "podcast.h"
#include "ff.h"

#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define PLAYLIST_DIR "0:/Playlists"
#define MUSIC_DIR    "0:/Music"
#define ALLSONGS_IDX "0:/.playall.idx"    /* cached scan results          */

static bool     s_open, s_is_scan, s_suspended;
/* 2.6.0 library views: "@songs:SIG" (all songs A-Z) and
 * "@range:FIRST:COUNT:SIG" (an artist's or album's tracks). No file of
 * our own - entries come from the library index files.                  */
typedef enum { PL_SRC_FILE, PL_SRC_SONGS, PL_SRC_RANGE } pl_src_t;
static pl_src_t s_src;
static bool     s_is_pod;              /* 2.7.0: the /Podcasts list          */
static uint32_t s_range_first;
static FIL      s_fil;
static char     s_open_path[PL_PATH_MAX];  /* for suspend/resume          */
static uint32_t s_count;
static uint32_t s_offsets[PL_MAX_TRACKS];
static uint16_t s_shuffle_map_valid;
static bool     s_shuffled;
static uint16_t s_map[PL_MAX_TRACKS];  /* shuffle permutation             */
/* "Play all" cache: trusted only for files written since the card was
 * mounted by us. Any mount (boot, card insert, end of a USB-storage
 * session) marks it stale, so music copied with a PC card reader shows up
 * on the next Play all without having to delete .playall.idx by hand.   */
static bool     s_scan_stale = true;

/* Playlist files: visible, with a playlist extension. Skips macOS "._x"
 * AppleDouble files, desktop.ini, Thumbs.db and the like.               */
static bool is_playlist_name(const char *n)
{
    if (n[0] == '.') return false;
    const char *dot = strrchr(n, '.');
    if (!dot) return false;
    return !strcasecmp(dot, ".m3u") || !strcasecmp(dot, ".m3u8") ||
           !strcasecmp(dot, ".txt");
}

/* ---- enumeration --------------------------------------------------------- */

uint32_t playlist_enumerate(playlist_desc_t *out, uint32_t max)
{
    DIR dir;
    FILINFO fi;
    uint32_t n = 0;

    if (f_opendir(&dir, PLAYLIST_DIR) != FR_OK) return 0;
    while (n < max && f_readdir(&dir, &fi) == FR_OK && fi.fname[0]) {
        if (fi.fattrib & (AM_DIR | AM_HID | AM_SYS)) continue;
        if (!is_playlist_name(fi.fname)) continue;
        strncpy(out[n].file, fi.fname, PL_NAME_MAX - 1);
        out[n].file[PL_NAME_MAX - 1] = '\0';
        strncpy(out[n].name, fi.fname, PL_NAME_MAX - 1);
        out[n].name[PL_NAME_MAX - 1] = '\0';
        char *dot = strrchr(out[n].name, '.');
        if (dot) *dot = '\0';              /* playlist name = file name    */
        n++;
    }
    f_closedir(&dir);
    return n;
}

/* ---- "Play all": recursive scan cached into an index file ----------------- */

static bool scan_dir(FIL *idx, const char *dir_path, int depth)
{
    DIR dir;
    FILINFO fi;
    char path[PL_PATH_MAX];

    if (depth > 6) return true;            /* bounded recursion            */
    if (f_opendir(&dir, dir_path) != FR_OK) return false;

    while (f_readdir(&dir, &fi) == FR_OK && fi.fname[0]) {
        if (fi.fname[0] == '.') continue;
        if ((unsigned)(strlen(dir_path) + strlen(fi.fname) + 2) > sizeof path)
            continue;
        strcpy(path, dir_path);
        strcat(path, "/");
        strcat(path, fi.fname);
        if (fi.fattrib & AM_DIR) {
            /* 2.7.0: podcasts are not music (whole-card scan, no /Music). */
            if (depth == 0 && !strcasecmp(fi.fname, "Podcasts")) continue;
            scan_dir(idx, path, depth + 1);
        } else if (dec_format_from_path(fi.fname) != DEC_FMT_UNKNOWN) {
            f_puts(path, idx);
            f_putc('\n', idx);
        }
    }
    f_closedir(&dir);
    return true;
}

bool playlist_build_scan(void)
{
    FIL idx;
    diag_step(STEP_PLAYLIST_SCAN);
    if (f_open(&idx, ALLSONGS_IDX, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK)
        return false;
    DIR d;
    bool have_music = (f_opendir(&d, MUSIC_DIR) == FR_OK);
    if (have_music) f_closedir(&d);
    scan_dir(&idx, have_music ? MUSIC_DIR : "0:", 0);
    f_close(&idx);
    return true;
}

/* ---- open + index --------------------------------------------------------- */

static bool index_lines(void)
{
    s_count = 0;
    f_lseek(&s_fil, 0);

    char line[PL_PATH_MAX];
    FSIZE_t pos = 0;
    while (f_gets(line, sizeof line, &s_fil)) {
        FSIZE_t next = f_tell(&s_fil);
        if (line[0] && line[0] != '#' && line[0] != '\n' &&
            line[0] != '\r' && s_count < PL_MAX_TRACKS)
            s_offsets[s_count++] = (uint32_t)pos;
        pos = next;
    }
    return s_count > 0;
}

static bool open_library_view(const char *spec)
{
    uint32_t a = 0, b = 0, sig = 0;
    const char *p;
    if (!strncmp(spec, "@songs:", 7)) {
        sig = (uint32_t)strtoul(spec + 7, NULL, 16);
        if (!library_try_cached() || sig != library_sig()) return false;
        s_src = PL_SRC_SONGS;
        s_count = library_track_count();
    } else if (!strncmp(spec, "@range:", 7)) {
        a = (uint32_t)strtoul(spec + 7, (char **)&p, 10);
        if (*p == ':') b = (uint32_t)strtoul(p + 1, (char **)&p, 10);
        if (*p == ':') sig = (uint32_t)strtoul(p + 1, NULL, 16);
        if (!library_try_cached() || sig != library_sig()) return false;
        if (!b || a + b > library_track_count()) return false;
        s_src = PL_SRC_RANGE;
        s_range_first = a;
        s_count = b;
    } else {
        return false;
    }
    if (s_count > PL_MAX_TRACKS) s_count = PL_MAX_TRACKS;
    s_open = true;
    s_is_scan = false;
    strncpy(s_open_path, spec, sizeof s_open_path - 1);
    s_open_path[sizeof s_open_path - 1] = '\0';
    return s_count > 0;
}

bool playlist_open(const char *file)
{
    diag_step(STEP_PLAYLIST_OPEN);
    if (s_open && s_src == PL_SRC_FILE) f_close(&s_fil);
    s_open = false;
    s_suspended = false;
    s_shuffled = false;
    s_shuffle_map_valid = 0;
    s_src = PL_SRC_FILE;
    s_is_pod = false;
    if (file && !strcmp(file, POD_LIST_SPEC)) {
        /* The podcast list is an index file like the "Play all" scan.     */
        if (!podcast_refresh()) return false;
        if (f_open(&s_fil, podcast_index_path(), FA_READ) != FR_OK) return false;
        s_open = true;
        s_is_scan = false;
        s_is_pod = true;
        strcpy(s_open_path, podcast_index_path());
        if (!index_lines()) { f_close(&s_fil); s_open = false; return false; }
        return true;
    }
    if (file && file[0] == '@') return open_library_view(file);

    char path[PL_PATH_MAX];
    if (!file || !file[0]) {
        s_is_scan = true;
        /* Rebuild the scan cache once per mount, or if it is missing.   */
        FILINFO fi;
        if (s_scan_stale || f_stat(ALLSONGS_IDX, &fi) != FR_OK) {
            if (!playlist_build_scan()) return false;
            s_scan_stale = false;
        }
        strcpy(path, ALLSONGS_IDX);
    } else {
        s_is_scan = false;
        if (strlen(file) + sizeof PLAYLIST_DIR + 2 > sizeof path) return false;
        strcpy(path, PLAYLIST_DIR);
        strcat(path, "/");
        strcat(path, file);
    }

    if (f_open(&s_fil, path, FA_READ) != FR_OK) return false;
    s_open = true;
    s_suspended = false;
    strcpy(s_open_path, path);
    if (!index_lines()) { f_close(&s_fil); s_open = false; return false; }
    return true;
}

void playlist_suspend(void)
{
    if (!s_open) return;
    if (s_src == PL_SRC_FILE) f_close(&s_fil);
    s_open = false;
    s_suspended = true;
}

bool playlist_resume(void)
{
    if (!s_suspended) return s_open;
    s_suspended = false;
    if (s_src != PL_SRC_FILE) { s_open = true; return true; }
    if (f_open(&s_fil, s_open_path, FA_READ) != FR_OK) {
        s_count = 0;
        return false;
    }
    s_open = true;
    return true;
}

void playlist_invalidate_scan(void)
{
    s_scan_stale = true;
}

bool playlist_scan_needed(void) { return s_scan_stale; }

uint32_t playlist_count(void) { return s_open ? s_count : 0; }

bool playlist_track(uint32_t pos, char *path, uint32_t path_len)
{
    if (!s_open || pos >= s_count) return false;
    uint32_t idx = (s_shuffled && s_shuffle_map_valid) ? s_map[pos] : pos;

    if (s_src == PL_SRC_SONGS) {
        uint32_t t;
        return library_song_az(idx, &t) && library_track_path(t, path, path_len);
    }
    if (s_src == PL_SRC_RANGE)
        return library_track_path(s_range_first + idx, path, path_len);

    if (f_lseek(&s_fil, s_offsets[idx]) != FR_OK) return false;
    if (!f_gets(path, (int)path_len, &s_fil)) return false;
    char *nl = strpbrk(path, "\r\n");
    if (nl) *nl = '\0';
    /* Playlist lines may be relative ("Music/x.mp3") or absolute.        */
    if (path[0] != '0' && path[0] != '/') {
        char tmp[PL_PATH_MAX];
        if (strlen(path) + 4 > sizeof tmp) return false;
        strcpy(tmp, "0:/");
        strcat(tmp, path);
        strncpy(path, tmp, path_len - 1);
        path[path_len - 1] = '\0';
    }
    return true;
}

/* xorshift32 - deterministic per seed so resume keeps the same order.    */
static uint32_t xs32(uint32_t *st)
{
    uint32_t x = *st;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    return *st = x;
}

void playlist_set_shuffle(bool on, uint32_t seed)
{
    s_shuffled = on;
    if (!on || !s_open || s_count < 2) return;
    if (seed == 0) seed = 0xA5A5A5A5u;
    for (uint32_t i = 0; i < s_count; i++) s_map[i] = (uint16_t)i;
    for (uint32_t i = s_count - 1; i > 0; i--) {
        uint32_t j = xs32(&seed) % (i + 1);
        uint16_t t = s_map[i]; s_map[i] = s_map[j]; s_map[j] = t;
    }
    s_shuffle_map_valid = 1;
}

bool playlist_shuffled(void) { return s_shuffled; }

/* ---- 2.7.0: remove one entry from a /Playlists file ------------------------ */

bool playlist_is_file(void)
{
    return s_open && s_src == PL_SRC_FILE && !s_is_scan && !s_is_pod;
}

bool playlist_is_podcasts(void) { return s_open && s_is_pod; }

bool playlist_remove(uint32_t pos)
{
    if (!playlist_is_file() || pos >= s_count) return false;
    uint32_t line_idx = (s_shuffled && s_shuffle_map_valid) ? s_map[pos] : pos;
    diag_step(STEP_PLAYLIST_OPEN);

    /* The UI may be browsing this very file through its own handle.      */
    playlist_browse_close();

    /* Copy every line except entry number line_idx into a temp file next
     * to the list, then swap the files. Comment and blank lines are kept. */
    char tmp_path[PL_PATH_MAX];
    if (strlen(PLAYLIST_DIR) + 12u > sizeof tmp_path) return false;
    strcpy(tmp_path, PLAYLIST_DIR);
    strcat(tmp_path, "/~list.tmp");

    FIL out;
    if (f_open(&out, tmp_path, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) return false;
    char line[PL_PATH_MAX];
    uint32_t entry = 0;
    bool ok = true, removed = false;
    f_lseek(&s_fil, 0);
    while (ok && f_gets(line, sizeof line, &s_fil)) {
        bool is_entry = line[0] && line[0] != '#' && line[0] != '\n' && line[0] != '\r';
        if (is_entry && entry < PL_MAX_TRACKS) {
            if (entry++ == line_idx) { removed = true; continue; }
        }
        UINT bw = 0, n = (UINT)strlen(line);
        ok = f_write(&out, line, n, &bw) == FR_OK && bw == n;
    }
    ok = (f_close(&out) == FR_OK) && ok && removed;
    if (!ok) { f_unlink(tmp_path); return false; }

    f_close(&s_fil);
    s_open = false;
    if (f_unlink(s_open_path) != FR_OK || f_rename(tmp_path, s_open_path) != FR_OK) {
        /* The original is either untouched or gone with the copy still
         * there under its temp name: try to put it in place once more.    */
        f_rename(tmp_path, s_open_path);
    }
    if (f_open(&s_fil, s_open_path, FA_READ) != FR_OK) { s_count = 0; return false; }
    s_open = true;

    uint32_t old_count = s_count;
    bool have = index_lines();                  /* s_count = old_count - 1 */
    /* Keep the play order: drop position `pos` from the shuffle map and
     * close the gap in the line numbers.                                  */
    if (s_shuffled && s_shuffle_map_valid) {
        for (uint32_t i = pos; i + 1u < old_count; i++) s_map[i] = s_map[i + 1u];
        for (uint32_t i = 0; i < s_count; i++)
            if (s_map[i] > line_idx) s_map[i]--;
    }
    (void)have;
    return true;
}

/* ---- "Play all" scan access for the library builder ----------------------- */

bool playlist_ensure_scan(void)
{
    FILINFO fi;
    if (s_scan_stale || f_stat(ALLSONGS_IDX, &fi) != FR_OK) {
        if (!playlist_build_scan()) return false;
        s_scan_stale = false;
    }
    return true;
}

const char *playlist_scan_path(void) { return ALLSONGS_IDX; }

/* ---- browsing a playlist file (UI), independent of the playing list ------- */

#define BR_STRIDE 16u                          /* sparse line index        */
static FIL      s_br_fil;
static bool     s_br_open;
static uint32_t s_br_count;
static uint32_t s_br_marks[PL_MAX_TRACKS / BR_STRIDE];   /* every 16th line */
static uint32_t s_br_cur_line;                 /* line the file pos is at */

static bool br_is_entry(const char *line)
{
    return line[0] && line[0] != '#' && line[0] != '\n' && line[0] != '\r';
}

uint32_t playlist_browse_open(const char *file)
{
    playlist_browse_close();
    char path[PL_PATH_MAX];
    if (!file || strlen(file) + sizeof PLAYLIST_DIR + 2 > sizeof path) return 0;
    strcpy(path, PLAYLIST_DIR);
    strcat(path, "/");
    strcat(path, file);
    if (f_open(&s_br_fil, path, FA_READ) != FR_OK) return 0;
    s_br_open = true;
    char line[PL_PATH_MAX];
    s_br_count = 0;
    FSIZE_t pos = 0;
    while (f_gets(line, sizeof line, &s_br_fil) && s_br_count < PL_MAX_TRACKS) {
        FSIZE_t next = f_tell(&s_br_fil);
        if (br_is_entry(line)) {
            if ((s_br_count % BR_STRIDE) == 0) s_br_marks[s_br_count / BR_STRIDE] = (uint32_t)pos;
            s_br_count++;
        }
        pos = next;
    }
    s_br_cur_line = UINT32_MAX;
    return s_br_count;
}

void playlist_browse_close(void)
{
    if (s_br_open) f_close(&s_br_fil);
    s_br_open = false;
    s_br_count = 0;
}

uint32_t playlist_browse_count(void) { return s_br_open ? s_br_count : 0; }

bool playlist_browse_entry(uint32_t n, char *path, uint32_t len)
{
    if (!s_br_open || n >= s_br_count) return false;
    uint32_t line = (n / BR_STRIDE) * BR_STRIDE;
    if (s_br_cur_line == UINT32_MAX || n < s_br_cur_line ||
        n - s_br_cur_line > BR_STRIDE) {
        if (f_lseek(&s_br_fil, s_br_marks[n / BR_STRIDE]) != FR_OK) return false;
        s_br_cur_line = line;
    } else {
        line = s_br_cur_line;
    }
    char buf[PL_PATH_MAX];
    while (f_gets(buf, sizeof buf, &s_br_fil)) {
        if (!br_is_entry(buf)) continue;
        if (line == n) {
            s_br_cur_line = n + 1;
            char *nl = strpbrk(buf, "\r\n");
            if (nl) *nl = '\0';
            if (buf[0] != '0' && buf[0] != '/') {
                if (strlen(buf) + 4 > len) return false;
                strcpy(path, "0:/");
                strcat(path, buf);
            } else {
                strncpy(path, buf, len - 1);
                path[len - 1] = '\0';
            }
            return true;
        }
        line++;
    }
    s_br_cur_line = UINT32_MAX;
    return false;
}
