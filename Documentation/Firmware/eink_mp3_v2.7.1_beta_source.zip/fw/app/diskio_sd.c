/**
 * @file    diskio_sd.c
 * @brief   FatFs media-access layer -> sdcard.c driver.
 */
#include "ff.h"
#include "diskio.h"
#include "../drivers/sdcard.h"
#include "stm32u5xx_hal.h"

DSTATUS disk_status(BYTE pdrv)
{
    if (pdrv != 0) return STA_NOINIT;
    return sdcard_ready() ? 0 : STA_NOINIT;
}

DSTATUS disk_initialize(BYTE pdrv)
{
    if (pdrv != 0) return STA_NOINIT;
    if (!sdcard_ready() && !sdcard_init()) return STA_NOINIT;
    return 0;
}

DRESULT disk_read(BYTE pdrv, BYTE *buff, LBA_t sector, UINT count)
{
    if (pdrv != 0) return RES_PARERR;
    return sdcard_read(buff, (uint32_t)sector, count) ? RES_OK : RES_ERROR;
}

#if FF_FS_READONLY == 0
DRESULT disk_write(BYTE pdrv, const BYTE *buff, LBA_t sector, UINT count)
{
    if (pdrv != 0) return RES_PARERR;
    return sdcard_write(buff, (uint32_t)sector, count) ? RES_OK : RES_ERROR;
}
#endif

DRESULT disk_ioctl(BYTE pdrv, BYTE cmd, void *buff)
{
    if (pdrv != 0) return RES_PARERR;
    switch (cmd) {
    case CTRL_SYNC:        return RES_OK;   /* sdcard.c writes through   */
    case GET_SECTOR_COUNT: *(LBA_t *)buff = sdcard_block_count(); return RES_OK;
    case GET_SECTOR_SIZE:  *(WORD *)buff  = 512;  return RES_OK;
    case GET_BLOCK_SIZE:   *(DWORD *)buff = 8;    return RES_OK;
    default:               return RES_PARERR;
    }
}

DWORD get_fattime(void)
{
    /* RTC-backed timestamps: wire to HAL_RTC when clock-set UI exists.
     * Fixed date keeps FatFs happy meanwhile.                            */
    return ((DWORD)(2026 - 1980) << 25) | ((DWORD)7 << 21) | ((DWORD)1 << 16);
}
