/**
 * @file    ui.c
 * @brief   Menus, library browser, now-playing, quick menu, EQ and firmware
 *          screens for the 200x200 e-ink.
 *
 * Layout rules:
 *   - lists: one item per row; the row font and height follow Device
 *     settings > Text size (small 30 px rows = 6 rows, medium 36 = 5,
 *     large 45 = 4). Lists turn a page at a time and wrap around: up from
 *     the first row lands on the last and the other way round (a HELD key
 *     stops at the end instead, so auto-repeat can't run in circles).
 *   - a row can carry a right-aligned value ("Text size ... Small"), be a
 *     section header (compact, not selectable: the sub-headings of Device
 *     settings and "Up next" in the quick menu) and be followed by a bold
 *     rule.
 *   - the cursor has five looks (Device settings > Highlight): inverted
 *     row, bold + one size larger, arrow in the left margin, bar on the
 *     left edge, frame. Only the selected row changes; the other rows
 *     keep their font and position in every style.
 *   - status bar: text left; right-aligned cluster
 *     [sleep timer] [pause] [loop] [shuffle] [battery %] [bolt] [battery].
 *     On Now Playing the text is the ARTIST. A "toast" (short message,
 *     4 s) temporarily replaces the text.
 *   - main menu: Last played, Playlists, Shuffle all, Music, Albums,
 *     Artists, Podcasts (if /Podcasts has episodes), Device settings.
 *   - song lists of a playlist, artist or album start with "Shuffle" and
 *     "Play", then a bold line, then the songs (or albums). "Music" is the
 *     plain A-Z list of every song; "Podcasts" is a plain list of episodes
 *     with how much is left of each.
 *   - Now Playing: album art (120x120, dithered) centred, one title row
 *     beneath, transport strip at the bottom. Both skip keys held together
 *     (or a long press of play - Device settings > Quick menu) open the
 *     quick menu: podcast speed, sleep timer, remove from playlist, loop
 *     song, and the queue. Music keeps playing underneath.
 *
 * Refresh policy: screens mark themselves dirty; ui_poll() coalesces and
 * issues at most one panel refresh per lap. With the fast drive (2.7.0,
 * InkBoy) a refresh starts a burst of short scans that the main loop
 * delivers one per lap, so keys are read between scans and a new frame
 * simply replaces the target; see do_refresh().
 *
 * Change detection: the player, settings (card mounts), USB, library and
 * firmware-update modules expose counters/state; ui_poll() compares them
 * every lap.
 */
#include "ui.h"
#include "player.h"
#include "playlist.h"
#include "library.h"
#include "podcast.h"
#include "settings.h"
#include "usb_app.h"
#include "power.h"
#include "fuelgauge.h"
#include "fwupdate.h"
#include "diag.h"
#include "board.h"
#include "../audio/eq.h"
#include "../audio/audio_pipeline.h"
#include "../drivers/gfx.h"
#include "../drivers/eink.h"
#include "../drivers/npm1300.h"
#include "../drivers/cs43131.h"
#include "../assets/font.h"
#include "stm32u5xx_hal.h"

#include <stdio.h>
#include <string.h>

/* ---- screens ------------------------------------------------------------- */

typedef enum {
    SCR_MENU_MAIN, SCR_MENU_SETTINGS,
    SCR_SETTING_ADJUST,             /* ink strength "folder"              */
    SCR_NOW_PLAYING, SCR_USB_PROMPT,
    SCR_USB_ACTIVE,                 /* storage / DAC running: player off  */
    SCR_BROWSE,                     /* library + playlist lists           */
    SCR_EQ,
    SCR_FIRMWARE, SCR_FW_CONFIRM,
    SCR_ERROR,                      /* boot problem (no card, codec)       */
    SCR_QUICK,                      /* 2.7.0: quick menu over Now Playing  */
    SCR_TIMER,                      /* sleep-timer duration                */
    SCR_REMOVE,                     /* "remove from playlist?"             */
    SCR_ABOUT,                      /* versions, SD, panel, battery        */
} screen_t;

typedef enum {
    B_MUSIC, B_ARTISTS, B_ALBUMS,   /* top-level library lists            */
    B_ARTIST, B_ALBUM,              /* one artist / one album             */
    B_PLAYLIST,                     /* one /Playlists file                */
    B_PLAYLISTS,                    /* 2.7.0: the list of playlists       */
    B_PODCASTS,                     /* 2.7.0: /Podcasts episodes          */
} browse_t;

#define STATUS_H    20
#define LIST_H      (200 - STATUS_H)
#define HDR_ROWS    2               /* "Shuffle", "Play" before the line  */
#define SECTION_H   18              /* compact section-header row         */

/* status-bar right-aligned icon cluster                                   */
#define BATT_X      172
#define BATT_Y      4

#define ART_X       40
#define ART_Y       24

/* Now Playing (2.6.5): one gap everywhere - the blank rows between the
 * status-bar rule and the art frame (3 px). The transport strip sits at
 * the bottom with the same gap below it; the title sits the same gap
 * above the bar. There's no elapsed-time counter (it changed every
 * redraw and ghosted); the bar runs from the left edge to the track
 * length, which only changes with the track.                             */
#define NP_GAP      (ART_Y - 1 - STATUS_H)
#define TR_BAR_X    4
#define TR_BAR_H    12
#define TR_BAR_Y    (200 - NP_GAP - TR_BAR_H)
#define TR_Y        (TR_BAR_Y - 1)          /* strip top                  */
#define NP_TEXT_BOT (TR_BAR_Y - NP_GAP)     /* first row below the title  */
#define NP_TEXT_TOP (ART_Y + ART_SIZE + 1 + NP_GAP)   /* below the frame  */

/* Volume indicator (2.6.5): replaces the status-bar title while the
 * volume keys are in use; hidden once no key has been pressed for this. */
#define VOL_SHOW_MS 3000u

#define TOAST_MS            4000u
#define PANEL_IDLE_SLEEP_MS 15000u

static screen_t s_scr = SCR_MENU_MAIN;
static screen_t s_return_scr = SCR_MENU_MAIN;   /* after the USB prompt   */
static screen_t s_np_return  = SCR_MENU_MAIN;   /* back from Now Playing  */
static bool     s_dirty, s_want_full, s_force_partial, s_status_tick;
static bool     s_want_real_full;           /* a clean refresh, whatever  */
static uint32_t s_partials_since_full;
static uint32_t s_last_refresh;
static bool     s_codec_ok = true;
static const char *s_err_msg;

static uint32_t s_seen_player_seq, s_seen_track_seq, s_seen_mount_seq;

/* list state of the current screen                                        */
static int  s_sel, s_top;
static int  s_main_sel, s_main_top;             /* kept while browsing    */
static playlist_desc_t s_lists[PL_MAX_LISTS];
static uint32_t s_nlists;
static uint32_t s_npods;                        /* episodes in /Podcasts  */

/* browse navigation stack                                                 */
typedef struct { browse_t kind; uint16_t param; int16_t sel, top; } nav_t;
#define NAV_MAX 4
static nav_t    s_nav[NAV_MAX];
static int      s_nav_n;
static lib_artist_t s_cur_artist;
static lib_album_t  s_cur_album;
static lib_state_t  s_seen_lib_state;
static uint8_t      s_seen_lib_pct;
static uint32_t     s_lib_draw_t;

static int s_eq_band;
static int s_set_sel, s_set_top;                /* kept while in a sub-screen */
static int s_quick_sel;

/* firmware screens                                                        */
static fwu_file_t s_fw_files[FWU_MAX_FILES];
static uint32_t   s_fw_nfiles;
static char       s_fw_prev[20];
static bool       s_fw_prev_ok;
static int        s_fw_action;              /* -1 previous, else file idx  */

/* battery status cache                                                    */
static uint8_t  s_batt_pct = 50;
static int      s_batt_shown_pct = -1;      /* number in the status bar    */
static bool     s_batt_chg;
static bool     s_batt_absent;
static uint8_t  s_absent_votes;
static uint32_t s_batt_last_poll;
static uint32_t s_batt_last_draw;
static bool     s_batt_tick;

static int      s_np_last_fill = -1;
static bool     s_vol_shown;
static uint32_t s_btn_last;
static uint32_t s_np_last_draw;
static bool     s_np_tick;

static char     s_toast[32];
static uint32_t s_toast_until;

static ui_usb_choice_t s_usb_choice = UI_USB_ASK;
static int s_usb_sel;

/* Screen refreshes before a clean (flashing) one, by Device settings >
 * Full refresh (often / normal / rarely). Classic drive: OTP partials,
 * as before. Fast drive: bursts; the driver's own 2400-scan limit comes
 * on top (eink_clean_due).                                               */
static const uint16_t k_budget_classic[3] = { 8, 30, 120 };
static const uint16_t k_budget_fast[3]    = { 40, 120, 250 };

static void go(screen_t scr)
{
    s_scr = scr;
    s_dirty = s_want_full = true;
}

/* ---- text size --------------------------------------------------------------- */

static const font_t *list_font(void)
{
    switch (settings_get()->text_size) {
    case 1:  return &font_ui17;
    case 2:  return &font_ui21;
    default: return &font_ui14;
    }
}
/* Highlight "bold": the selected row, bold and one size up.               */
static const font_t *list_font_bold(void)
{
    switch (settings_get()->text_size) {
    case 1:  return &font_ui19b;
    case 2:  return &font_ui23b;
    default: return &font_ui16b;
    }
}
static int row_h(void)
{
    static const uint8_t h[3] = { 30, 36, 45 };
    uint8_t t = settings_get()->text_size;
    return h[t < 3 ? t : 0];
}

/* ---- toast ----------------------------------------------------------------------- */

static bool toast_active(void)
{
    return s_toast[0] && (int32_t)(s_toast_until - HAL_GetTick()) > 0;
}

void ui_toast(const char *msg)
{
    strncpy(s_toast, msg, sizeof s_toast - 1);
    s_toast[sizeof s_toast - 1] = '\0';
    s_toast_until = HAL_GetTick() + TOAST_MS;
    s_status_tick = true;
}

/* ---- status bar --------------------------------------------------------------------- */

static const char *browse_title(void);

static const char *screen_title(void)
{
    switch (s_scr) {
    case SCR_MENU_MAIN:      return "e.player";
    case SCR_MENU_SETTINGS:
    case SCR_SETTING_ADJUST: return "Device settings";
    case SCR_NOW_PLAYING:    return player_tags()->artist[0] ? player_tags()->artist
                                    : player_is_podcast() ? "Podcast" : "Now playing";
    case SCR_USB_PROMPT:     return "USB connected";
    case SCR_USB_ACTIVE:     return usb_app_storage_owned() ? "USB storage" : "USB DAC";
    case SCR_BROWSE:         return browse_title();
    case SCR_EQ:             return "Equaliser";
    case SCR_FIRMWARE:
    case SCR_FW_CONFIRM:     return "Firmware";
    case SCR_ERROR:          return "e.player";
    case SCR_QUICK:          return player_tags()->title[0] ? player_tags()->title : "Quick menu";
    case SCR_TIMER:          return "Sleep timer";
    case SCR_REMOVE:         return "Remove song";
    case SCR_ABOUT:          return "About";
    }
    return "";
}

/* Left edge of the battery cluster (percentage text included).           */
static int batt_cluster_x(void)
{
    int x = BATT_X - GFX_BATT_BOLT_W - 2;
    if (s_batt_shown_pct >= 0 && !s_batt_absent) {
        char t[12];
        snprintf(t, sizeof t, "%d%%", s_batt_shown_pct);
        x -= gfx_text_width(&font_ui11, t) + 2;
    }
    return x;
}

static void draw_battery(void)
{
    gfx_battery_icon(BATT_X, BATT_Y, s_batt_pct, s_batt_chg && !s_batt_absent,
                     s_batt_absent);
    if (s_batt_shown_pct >= 0 && !s_batt_absent) {
        char t[12];
        snprintf(t, sizeof t, "%d%%", s_batt_shown_pct);
        int w = gfx_text_width(&font_ui11, t);
        gfx_text(&font_ui11, BATT_X - GFX_BATT_BOLT_W - 2 - w, 3, t, GFX_BLACK);
    }
}

/* Speaker glyph (11 x 10, rows y..y+9) + level bar.                      */
static void draw_volume(int x, int y, int max_w)
{
    gfx_fill_rect(x, y + 3, 3, 4, GFX_BLACK);                /* body      */
    for (int k = 0; k < 4; k++) {                            /* cone      */
        int top = y + 2 - (k < 3 ? k : 2);
        gfx_vline(x + 3 + k, top, 10 - 2 * (top - y), GFX_BLACK);
    }
    int bw = max_w - 12;
    if (bw > 80) bw = 80;
    if (bw > 20) gfx_progress_bar(x + 12, y, bw, GFX_BATT_H, settings_get()->volume, 100);
}

/* Loop glyph: a closed track with an arrow head (12 x 10).               */
#define LOOP_W 12
static void draw_loop_icon(int x, int y)
{
    gfx_hline(x + 2, y + 1, 8, GFX_BLACK);
    gfx_hline(x + 2, y + 8, 8, GFX_BLACK);
    gfx_vline(x,     y + 3, 4, GFX_BLACK);
    gfx_vline(x + 11, y + 3, 4, GFX_BLACK);
    gfx_pixel(x + 1, y + 2, GFX_BLACK);  gfx_pixel(x + 10, y + 2, GFX_BLACK);
    gfx_pixel(x + 1, y + 7, GFX_BLACK);  gfx_pixel(x + 10, y + 7, GFX_BLACK);
    /* arrow head on the top run, pointing right                          */
    gfx_vline(x + 6, y - 1, 5, GFX_BLACK);
    gfx_vline(x + 7, y,     3, GFX_BLACK);
    gfx_pixel(x + 8, y + 1, GFX_BLACK);
}

/* Sleep-timer mark: a small crescent moon (8 x 10) before the minutes.   */
#define MOON_W 8
static void draw_moon_icon(int x, int y)
{
    static const uint8_t rows[10] = {
        0x38, 0x70, 0xE0, 0xE0, 0xE0, 0xE0, 0xF1, 0x7F, 0x3E, 0x1C };
    for (int j = 0; j < 10; j++)
        for (int i = 0; i < 8; i++)
            if (rows[j] & (0x80u >> i)) gfx_pixel(x + i, y + j, GFX_BLACK);
}

/* Right cluster, laid out from the battery leftwards; returns the x where
 * the title has to stop.                                                  */
static int draw_status_icons(void)
{
    int x = batt_cluster_x();
    draw_battery();
    bool active = player_state() != PLAYER_STOPPED;
    if (active && player_shuffled()) {
        x -= GFX_SHUF_W + 3;
        gfx_shuffle_icon(x, BATT_Y, GFX_BLACK);
    }
    if (active && player_loop()) {
        x -= LOOP_W + 3;
        draw_loop_icon(x, BATT_Y);
    }
    if (player_state() == PLAYER_PAUSED) {
        x -= 8 + 3;
        gfx_fill_rect(x, BATT_Y, 3, 10, GFX_BLACK);
        gfx_fill_rect(x + 5, BATT_Y, 3, 10, GFX_BLACK);
    }
    if (player_timer_minutes()) {
        /* The minutes as set - a fixed number, not a countdown (a number
         * that changes every minute would redraw and ghost all night).   */
        char t[8];
        snprintf(t, sizeof t, "%u", player_timer_minutes());
        int w = gfx_text_width(&font_ui11, t);
        x -= w + 3;
        gfx_text(&font_ui11, x, 3, t, GFX_BLACK);
        x -= MOON_W + 2;
        draw_moon_icon(x, BATT_Y);
    }
    return x - 6;
}

static void draw_status_bar(void)
{
    gfx_fill_rect(0, 0, 200, STATUS_H, GFX_WHITE);
    int right = draw_status_icons();
    if (s_vol_shown)
        draw_volume(4, BATT_Y, right - 4);
    else
        gfx_text_ellipsis(&font_ui11, 4, 3, right - 4,
                          toast_active() ? s_toast : screen_title(), GFX_BLACK);
    gfx_hline(0, STATUS_H - 1, 200, GFX_BLACK);
}

/* ---- generic list ---------------------------------------------------------------------- */

typedef enum { ROW_ITEM, ROW_SECTION } row_kind_t;

typedef struct {
    char text[96];
    char value[24];             /* right-aligned, "" = none                */
    bool small_value;           /* value always in the small font (a note
                                   about the row rather than a setting)    */
} row_t;

typedef struct {
    void       (*row)(int idx, row_t *out);
    row_kind_t (*kind)(int idx);    /* NULL = every row is an item        */
    int          count;
    int          rule_after;        /* bold line under this row, -1 none  */
} list_t;

static row_kind_t list_kind(const list_t *l, int idx)
{
    return l->kind ? l->kind(idx) : ROW_ITEM;
}

static int list_row_h(const list_t *l, int idx)
{
    return list_kind(l, idx) == ROW_SECTION ? SECTION_H : row_h();
}

/* The page that shows row `sel`: rows [*top, *end). Pages are filled top
 * down; a section header never ends a page (it stays with its first
 * item).                                                                  */
static void list_page(const list_t *l, int sel, int *top, int *end)
{
    if (!l->kind) {                              /* uniform rows: O(1)     */
        int vr = LIST_H / row_h();
        *top = (sel / vr) * vr;
        *end = *top + vr < l->count ? *top + vr : l->count;
        return;
    }
    int t = 0, h = 0, i;
    for (i = 0; i < l->count; i++) {
        int rh = list_row_h(l, i);
        int need = rh;
        if (list_kind(l, i) == ROW_SECTION && i + 1 < l->count) need += row_h();
        if (h && h + need > LIST_H) {
            if (i > sel) break;                  /* sel's page ends here   */
            t = i;
            h = 0;
        }
        h += rh;
    }
    *top = t;
    *end = i;
}

/* Arrow in the left margin (highlight "arrow"): 6 x 11 solid triangle.   */
static void draw_cursor_arrow(int x, int cy)
{
    for (int i = 0; i < 6; i++) gfx_vline(x + i, cy - 5 + i, 11 - 2 * i, GFX_BLACK);
}

/* 2 px frame with clipped corners (highlight "frame").                   */
static void draw_cursor_frame(int x, int y, int w, int h)
{
    gfx_fill_rect(x + 2, y, w - 4, 2, GFX_BLACK);
    gfx_fill_rect(x + 2, y + h - 2, w - 4, 2, GFX_BLACK);
    gfx_fill_rect(x, y + 2, 2, h - 4, GFX_BLACK);
    gfx_fill_rect(x + w - 2, y + 2, 2, h - 4, GFX_BLACK);
    gfx_pixel(x + 1, y + 1, GFX_BLACK);          gfx_pixel(x + w - 2, y + 1, GFX_BLACK);
    gfx_pixel(x + 1, y + h - 2, GFX_BLACK);      gfx_pixel(x + w - 2, y + h - 2, GFX_BLACK);
}

static void draw_list(const list_t *l)
{
    gfx_clear(GFX_WHITE);
    draw_status_bar();

    const font_t *f = list_font();
    const uint8_t hl = settings_get()->highlight;
    /* Arrow style: every row is indented by the same amount, so nothing
     * but the arrow moves when the cursor does.                           */
    const int tx = (hl == HL_ARROW) ? 16 : 10;
    const int right_edge = 190;

    if (s_sel >= l->count) s_sel = l->count ? l->count - 1 : 0;
    if (s_sel < 0) s_sel = 0;
    /* page-wise scrolling (less ghosting than shifting every row)        */
    int page_end;
    list_page(l, s_sel, &s_top, &page_end);

    int y = STATUS_H;
    int last = s_top;
    for (int idx = s_top; idx < page_end; idx++) {
        int rh = list_row_h(l, idx);
        if (y + rh > 200) break;
        last = idx;
        static row_t r;
        r.value[0] = '\0';
        r.small_value = false;
        l->row(idx, &r);

        if (list_kind(l, idx) == ROW_SECTION) {
            /* small caps-style label sitting on a rule                    */
            gfx_text_ellipsis(&font_ui11, 4, y + SECTION_H - font_ui11.height - 1, 186,
                              r.text, GFX_BLACK);
            gfx_hline(0, y + SECTION_H - 1, 196, GFX_BLACK);
            y += rh;
            continue;
        }

        bool sel = (idx == s_sel);
        const font_t *rf = (sel && hl == HL_BOLD) ? list_font_bold() : f;
        int vw = 0;
        if (r.value[0]) {
            /* value in the list font if both fit, else in the small one  */
            const font_t *vf = f;
            vw = gfx_text_width(vf, r.value);
            if (r.small_value || tx + gfx_text_width(rf, r.text) + 8 + vw > right_edge) {
                vf = &font_ui11;
                vw = gfx_text_width(vf, r.value);
            }
            gfx_text(vf, right_edge - vw, y + (rh - vf->height) / 2, r.value, GFX_BLACK);
            vw += 8;
        }
        gfx_text_ellipsis(rf, tx, y + (rh - rf->height) / 2, right_edge - tx - vw,
                          r.text, GFX_BLACK);

        bool ruled = (idx == l->rule_after);
        if (sel) {
            switch (hl) {
            case HL_ARROW: draw_cursor_arrow(5, y + rh / 2);               break;
            case HL_BAR:   gfx_fill_rect(0, y + 2, 4, rh - (ruled ? 6 : 4), GFX_BLACK); break;
            case HL_FRAME: draw_cursor_frame(1, y + 1, 194, rh - (ruled ? 4 : 2)); break;
            case HL_BOLD:  break;                /* the font is the cursor */
            default:       gfx_invert_rect(0, y, 196, rh);                 break;
            }
        }
        if (ruled)                                       /* the bold line  */
            gfx_fill_rect(0, y + rh - 3, 196, 3, GFX_BLACK);
        else if (!(sel && hl == HL_INVERT))
            gfx_hline(10, y + rh - 1, 180, GFX_LIGHT);   /* separator      */
        y += rh;
    }
    if (s_top > 0 || last + 1 < l->count) {              /* scroll bar     */
        gfx_fill_rect(197, STATUS_H, 3, LIST_H, GFX_LIGHT);
        int shown = last - s_top + 1;
        int bar_h = (shown * LIST_H) / l->count;
        if (bar_h < 6) bar_h = 6;
        int bar_y = STATUS_H + (s_top * (LIST_H - bar_h)) / (l->count - shown ? l->count - shown : 1);
        if (bar_y + bar_h > 200) bar_y = 200 - bar_h;
        gfx_fill_rect(197, bar_y, 3, bar_h, GFX_BLACK);
    }
}

static void row_set(row_t *r, const char *text) { snprintf(r->text, sizeof r->text, "%s", text); }
static void row_val(row_t *r, const char *v)    { snprintf(r->value, sizeof r->value, "%s", v); }

static void status_bar_now(void)
{
    draw_status_bar();
    eink_refresh_partial_area(0, 0, 200, STATUS_H);
    s_partials_since_full++;
    s_last_refresh = HAL_GetTick();
    s_status_tick = false;
}

static void center_text(const font_t *f, int y, const char *s, gfx_color_t c)
{
    int w = gfx_text_width(f, s);
    gfx_text_ellipsis(f, w < 192 ? (200 - w) / 2 : 4, y, 192, s, c);
}

/* ---- playing ------------------------------------------------------------------------------ */

static void play_error_toast(player_err_t e)
{
    switch (e) {
    case PLAYER_ERR_NONE:          break;
    case PLAYER_ERR_BUSY:          ui_toast("USB in use");          break;
    case PLAYER_ERR_OUTPUT:        ui_toast("Audio output error");  break;
    case PLAYER_ERR_NO_HEADPHONES: ui_toast("Plug in headphones");  break;
    default: ui_toast(settings_mounted() ? "No playable music" : "No SD card"); break;
    }
}

static void enter_now_playing(screen_t from)
{
    s_seen_player_seq = player_seq();
    s_seen_track_seq  = player_track_seq();
    s_np_last_fill = -1;
    if (from != SCR_NOW_PLAYING && from != SCR_QUICK && from != SCR_TIMER && from != SCR_REMOVE)
        s_np_return = from;
    go(SCR_NOW_PLAYING);
    play_error_toast(player_take_error());      /* e.g. headphones missing */
}

static void start_play(const char *list, uint32_t pos, bool shuffle)
{
    if (!list[0] && playlist_scan_needed() && settings_mounted()) {
        ui_toast("Scanning music...");
        status_bar_now();
        eink_settle();
    }
    screen_t from = s_scr;
    if (player_play(list, pos, shuffle)) {
        enter_now_playing(from);
    } else {
        player_err_t e = player_take_error();
        play_error_toast(e ? e : PLAYER_ERR_NO_MUSIC);
        s_dirty = true;
    }
}

static void resume_last(void)
{
    screen_t from = s_scr;
    if (player_state() != PLAYER_STOPPED) { enter_now_playing(from); return; }
    if (player_resume_last()) {
        enter_now_playing(from);
    } else {
        player_err_t e = player_take_error();
        play_error_toast(e ? e : PLAYER_ERR_NO_MUSIC);
    }
}

static void play_songs_az(uint32_t pos)
{
    char spec[24];
    snprintf(spec, sizeof spec, "@songs:%08lX", (unsigned long)library_sig());
    start_play(spec, pos, false);
}

static void play_range(uint32_t first, uint32_t n, uint32_t pos, bool shuffle)
{
    char spec[48];
    snprintf(spec, sizeof spec, "@range:%lu:%lu:%08lX", (unsigned long)first,
             (unsigned long)n, (unsigned long)library_sig());
    start_play(spec, pos, shuffle);
}

/* ---- main menu ------------------------------------------------------------------------------- */

enum { MAIN_LAST, MAIN_PLAYLISTS, MAIN_SHUFFLE, MAIN_MUSIC, MAIN_ALBUMS, MAIN_ARTISTS,
       MAIN_PODCASTS, MAIN_SETTINGS, MAIN_COUNT };

/* "Podcasts" is listed only when the card has episodes.                  */
static int main_item(int idx)
{
    if (!s_npods && idx >= MAIN_PODCASTS) idx++;
    return idx;
}
static int main_count(void) { return s_npods ? MAIN_COUNT : MAIN_COUNT - 1; }

static void main_row(int idx, row_t *r)
{
    switch (main_item(idx)) {
    case MAIN_LAST:      row_set(r, player_state() != PLAYER_STOPPED ? "Now playing" : "Last played"); break;
    case MAIN_PLAYLISTS: row_set(r, "Playlists");       break;
    case MAIN_SHUFFLE:   row_set(r, "Shuffle all");     break;
    case MAIN_MUSIC:     row_set(r, "Music");           break;
    case MAIN_ALBUMS:    row_set(r, "Albums");          break;
    case MAIN_ARTISTS:   row_set(r, "Artists");         break;
    case MAIN_PODCASTS:  row_set(r, "Podcasts");        break;
    case MAIN_SETTINGS:  row_set(r, "Device settings"); break;
    }
}

static void browse_push(browse_t kind, uint16_t param);
static void settings_open(void);

static void main_activate(void)
{
    switch (main_item(s_sel)) {
    case MAIN_LAST:      resume_last();                  break;
    case MAIN_PLAYLISTS: browse_push(B_PLAYLISTS, 0);    break;
    case MAIN_SHUFFLE:   start_play("", 0, true);        break;
    case MAIN_MUSIC:     browse_push(B_MUSIC, 0);        break;
    case MAIN_ALBUMS:    browse_push(B_ALBUMS, 0);       break;
    case MAIN_ARTISTS:   browse_push(B_ARTISTS, 0);      break;
    case MAIN_PODCASTS:  browse_push(B_PODCASTS, 0);     break;
    case MAIN_SETTINGS:
        s_main_sel = s_sel; s_main_top = s_top;
        s_set_sel = s_set_top = -1;
        settings_open();
        break;
    }
}

/* ---- browse ----------------------------------------------------------------------------------- */

static nav_t *nav(void) { return &s_nav[s_nav_n - 1]; }

static bool browse_needs_lib(browse_t k)
{
    return k != B_PLAYLIST && k != B_PLAYLISTS && k != B_PODCASTS;
}

static void browse_load(void)
{
    nav_t *n = nav();
    if (n->kind == B_ARTIST) library_artist(n->param, &s_cur_artist);
    if (n->kind == B_ALBUM)  library_album(n->param, &s_cur_album);
    if (n->kind == B_PLAYLIST && n->param < s_nlists)
        playlist_browse_open(s_lists[n->param].file);
    if (n->kind == B_PODCASTS) s_npods = podcast_refresh();
}

static void browse_push(browse_t kind, uint16_t param)
{
    if (s_scr == SCR_MENU_MAIN) { s_main_sel = s_sel; s_main_top = s_top; s_nav_n = 0; }
    else if (s_nav_n) { nav()->sel = (int16_t)s_sel; nav()->top = (int16_t)s_top; }
    if (s_nav_n >= NAV_MAX) s_nav_n = NAV_MAX - 1;
    s_nav[s_nav_n++] = (nav_t){ kind, param, 0, 0 };
    s_sel = s_top = 0;
    if (browse_needs_lib(kind)) {
        library_request();
        s_seen_lib_state = library_state();
    }
    if (library_ready() || !browse_needs_lib(kind)) browse_load();
    go(SCR_BROWSE);
}

static void back_to_main(void)
{
    s_nav_n = 0;
    s_sel = s_main_sel;
    s_top = s_main_top;
    go(SCR_MENU_MAIN);
}

static void browse_pop(void)
{
    if (s_nav_n && nav()->kind == B_PLAYLIST) playlist_browse_close();
    if (s_nav_n > 1) {
        s_nav_n--;
        s_sel = nav()->sel;
        s_top = nav()->top;
        browse_load();
        go(SCR_BROWSE);
    } else {
        back_to_main();
    }
}

static const char *browse_title(void)
{
    if (!s_nav_n) return "";
    switch (nav()->kind) {
    case B_MUSIC:     return "Music";
    case B_ARTISTS:   return "Artists";
    case B_ALBUMS:    return "Albums";
    case B_ARTIST:    return s_cur_artist.name;
    case B_ALBUM:     return s_cur_album.name;
    case B_PLAYLIST:  return nav()->param < s_nlists ? s_lists[nav()->param].name : "";
    case B_PLAYLISTS: return "Playlists";
    case B_PODCASTS:  return "Podcasts";
    }
    return "";
}

static int browse_header(void)
{
    browse_t k = nav()->kind;
    return (k == B_ARTIST || k == B_ALBUM || k == B_PLAYLIST) ? HDR_ROWS : 0;
}

static int browse_count(void)
{
    switch (nav()->kind) {
    case B_MUSIC:     return (int)library_track_count();
    case B_ARTISTS:   return (int)library_artist_count();
    case B_ALBUMS:    return (int)library_album_count();
    case B_ARTIST:    return HDR_ROWS + s_cur_artist.n_albums;
    case B_ALBUM:     return HDR_ROWS + (int)s_cur_album.n_tracks;
    case B_PLAYLIST:  return HDR_ROWS + (int)playlist_browse_count();
    case B_PLAYLISTS: return (int)s_nlists;
    case B_PODCASTS:  return (int)s_npods;
    }
    return 0;
}

static void title_of_track(uint32_t t, char *buf, int len, bool with_no)
{
    static lib_track_t tr;
    if (!library_track(t, &tr)) { snprintf(buf, len, "?"); return; }
    if (with_no && tr.trackno) snprintf(buf, len, "%u. %s", tr.trackno, tr.title);
    else snprintf(buf, len, "%s", tr.title);
}

/* "12m left", "1h05 left", "played", "new" for an episode row.            */
static void podcast_badge(const char *path, char *buf, int len)
{
    pod_progress_t pg;
    podcast_progress(path, &pg);
    if (pg.state == POD_DONE)      { snprintf(buf, len, "played"); return; }
    if (pg.state == POD_NEW)       { snprintf(buf, len, "new");    return; }
    if (!pg.len_ms || pg.len_ms <= pg.pos_ms) { snprintf(buf, len, "started"); return; }
    uint32_t min = (pg.len_ms - pg.pos_ms + 59999u) / 60000u;
    if (min >= 60) snprintf(buf, len, "%luh%02lu left", (unsigned long)(min / 60), (unsigned long)(min % 60));
    else           snprintf(buf, len, "%lum left", (unsigned long)min);
}

static void browse_row(int idx, row_t *r)
{
    nav_t *n = nav();
    char *buf = r->text;
    int len = (int)sizeof r->text;
    int hdr = browse_header();
    if (idx < hdr) { snprintf(buf, len, "%s", idx == 0 ? "Shuffle" : "Play"); return; }
    int k = idx - hdr;
    uint32_t v;
    switch (n->kind) {
    case B_MUSIC:
        if (library_song_az((uint32_t)k, &v)) title_of_track(v, buf, len, false);
        else snprintf(buf, len, "?");
        break;
    case B_ARTISTS: {
        lib_artist_t a;
        snprintf(buf, len, "%s", library_artist((uint32_t)k, &a) ? a.name : "?");
        break;
    }
    case B_ALBUMS: {
        lib_album_t a;
        if (library_album_az((uint32_t)k, &v) && library_album(v, &a))
            snprintf(buf, len, "%s", a.name);
        else snprintf(buf, len, "?");
        break;
    }
    case B_ARTIST: {
        lib_album_t a;
        snprintf(buf, len, "%s",
                 library_album(s_cur_artist.first_album + (uint32_t)k, &a) ? a.name : "?");
        break;
    }
    case B_ALBUM:
        title_of_track(s_cur_album.first_track + (uint32_t)k, buf, len, true);
        break;
    case B_PLAYLIST: {
        char path[PL_PATH_MAX];
        if (!playlist_browse_entry((uint32_t)k, path, sizeof path)) { snprintf(buf, len, "?"); break; }
        if (library_title_for_path(path, buf, (uint32_t)len)) break;
        podcast_name(path, buf, (uint32_t)len);     /* file name, no extension */
        break;
    }
    case B_PLAYLISTS:
        snprintf(buf, len, "%s", (uint32_t)k < s_nlists ? s_lists[k].name : "?");
        break;
    case B_PODCASTS: {
        char path[PL_PATH_MAX];
        if (!podcast_entry((uint32_t)k, path, sizeof path)) { snprintf(buf, len, "?"); break; }
        podcast_name(path, buf, (uint32_t)len);
        podcast_badge(path, r->value, (int)sizeof r->value);
        r->small_value = true;
        break;
    }
    }
}

static void draw_message(const char *l1, const char *l2, const char *l3)
{
    gfx_clear(GFX_WHITE);
    draw_status_bar();
    center_text(&font_ui14, 70, l1, GFX_BLACK);
    if (l2) center_text(&font_ui11, 100, l2, GFX_DARK);
    if (l3) center_text(&font_ui11, 116, l3, GFX_DARK);
}

static void draw_library_wait(void)
{
    char l[40];
    lib_state_t st = library_state();
    if (st == LIB_FAILED) {
        draw_message(settings_mounted() ? "No music found" : "No SD card",
                     "Add music, then try again", NULL);
    } else if (st == LIB_BUILDING) {
        gfx_clear(GFX_WHITE);
        draw_status_bar();
        center_text(&font_ui14, 56, "Building library", GFX_BLACK);
        snprintf(l, sizeof l, "%u %%", library_progress());
        center_text(&font_ui18b, 84, l, GFX_BLACK);
        gfx_progress_bar(30, 116, 140, 10, library_progress(), 100);
        center_text(&font_ui11, 140, "Only needed after music", GFX_DARK);
        center_text(&font_ui11, 156, "changes. Playback continues.", GFX_DARK);
    } else {
        draw_message("Scanning music...", NULL, NULL);
    }
}

static void browse_list(list_t *l)
{
    int hdr = browse_header();
    *l = (list_t){ browse_row, NULL, browse_count(), hdr ? hdr - 1 : -1 };
}

static void draw_browse(void)
{
    browse_t k = nav()->kind;
    if (browse_needs_lib(k) && !library_ready()) { draw_library_wait(); return; }
    if (k == B_PLAYLISTS && !s_nlists) {
        draw_message(settings_mounted() ? "No playlists" : "No SD card",
                     "Put .m3u or .txt files", "in /Playlists");
        return;
    }
    if (k == B_PODCASTS && !s_npods) {
        draw_message(settings_mounted() ? "No podcasts" : "No SD card",
                     "Put episodes in /Podcasts", NULL);
        return;
    }
    list_t l;
    browse_list(&l);
    draw_list(&l);
}

static void browse_activate(void)
{
    nav_t *n = nav();
    if (browse_needs_lib(n->kind) && !library_ready()) {
        if (library_state() == LIB_FAILED) { library_request(); s_dirty = true; }
        return;
    }
    int hdr = browse_header();
    int k = s_sel - hdr;
    uint32_t v;
    switch (n->kind) {
    case B_MUSIC:    play_songs_az((uint32_t)s_sel); break;
    case B_ARTISTS:  browse_push(B_ARTIST, (uint16_t)s_sel); break;
    case B_ALBUMS:
        if (library_album_az((uint32_t)s_sel, &v)) browse_push(B_ALBUM, (uint16_t)v);
        break;
    case B_ARTIST:
        if (s_sel < hdr) play_range(s_cur_artist.first_track, s_cur_artist.n_tracks, 0, s_sel == 0);
        else browse_push(B_ALBUM, (uint16_t)(s_cur_artist.first_album + k));
        break;
    case B_ALBUM:
        if (s_sel < hdr) play_range(s_cur_album.first_track, s_cur_album.n_tracks, 0, s_sel == 0);
        else play_range(s_cur_album.first_track, s_cur_album.n_tracks, (uint32_t)k, false);
        break;
    case B_PLAYLIST: {
        const char *file = n->param < s_nlists ? s_lists[n->param].file : "";
        if (s_sel < hdr) start_play(file, 0, s_sel == 0);
        else start_play(file, (uint32_t)k, false);
        break;
    }
    case B_PLAYLISTS:
        if ((uint32_t)s_sel < s_nlists) browse_push(B_PLAYLIST, (uint16_t)s_sel);
        break;
    case B_PODCASTS:
        /* An episode is simply chosen and played (it resumes where it was
         * left); there is no Shuffle or Play row here.                    */
        if ((uint32_t)s_sel < s_npods) start_play(POD_LIST_SPEC, (uint32_t)s_sel, false);
        break;
    }
}

/* ---- device settings ---------------------------------------------------------------------------- *
 * One list with compact section headers. The rows are built per drive:
 * the fast drive offers ink strength and edge clean-up, the classic drive
 * its menu-refresh style.                                                */

typedef enum {
    SEC_DISPLAY, SET_HIGHLIGHT, SET_TEXT, SET_DARK, SET_ART, SET_DRIVE, SET_ANIM,
    SET_INK, SET_HALO, SET_REFRESH,
    SEC_PLAYBACK, SET_EQ, SET_GAPLESS, SET_REPEAT, SET_HP, SET_SPEED,
    SEC_TIMER, SET_TIMER_FADE, SET_TIMER_SONG,
    SEC_CONTROLS, SET_QUICK, SET_DOUBLE, SET_ON_PRESS, SET_LONG,
    SEC_POWER, SET_SLEEP, SET_USB, SET_CHARGE, SET_NO_NTC, SET_CHARGER, SET_FUEL,
    SEC_SYSTEM, SET_LIBRARY, SET_FIRMWARE, SET_ABOUT,
    SET_ID_COUNT
} set_id_t;

static uint8_t s_set_rows[SET_ID_COUNT];
static int     s_set_n;

static bool set_is_section(set_id_t id)
{
    return id == SEC_DISPLAY || id == SEC_PLAYBACK || id == SEC_TIMER ||
           id == SEC_CONTROLS || id == SEC_POWER || id == SEC_SYSTEM;
}

static void settings_build(void)
{
    bool fast = settings_get()->drive == 0;
    s_set_n = 0;
    for (int id = 0; id < SET_ID_COUNT; id++) {
        if ((id == SET_INK || id == SET_HALO) && !fast) continue;
        if (id == SET_REFRESH && fast) continue;
        s_set_rows[s_set_n++] = (uint8_t)id;
    }
}

static int settings_index_of(set_id_t id)
{
    for (int i = 0; i < s_set_n; i++) if (s_set_rows[i] == id) return i;
    return 0;
}

static const uint16_t k_charge_opts[SETTINGS_CHARGE_COUNT] = SETTINGS_CHARGE_OPTS;
static const char *const k_text_sizes[3] = { "Small", "Medium", "Large" };
static const char *const k_highlights[HL_COUNT] = { "Invert", "Bold", "Arrow", "Bar", "Frame" };
static const char *const k_quick_keys[QK_COUNT] = { "skip keys", "hold play", "either" };
static const char *const k_on_off[2] = { "off", "on" };

static void speed_text(char *buf, int len)
{
    unsigned s = settings_speed_x100(settings_get()->pod_speed);
    if (s % 10) snprintf(buf, len, "%u.%02ux", s / 100, s % 100);
    else        snprintf(buf, len, "%u.%ux", s / 100, (s % 100) / 10);
}

static row_kind_t settings_kind(int idx)
{
    return set_is_section((set_id_t)s_set_rows[idx]) ? ROW_SECTION : ROW_ITEM;
}

static void settings_row(int idx, row_t *r)
{
    settings_t *c = settings_get();
    char v[24] = "";
    switch ((set_id_t)s_set_rows[idx]) {
    case SEC_DISPLAY:    row_set(r, "DISPLAY");        return;
    case SEC_PLAYBACK:   row_set(r, "PLAYBACK");       return;
    case SEC_TIMER:      row_set(r, "SLEEP TIMER");    return;
    case SEC_CONTROLS:   row_set(r, "CONTROLS");       return;
    case SEC_POWER:      row_set(r, "POWER & USB");    return;
    case SEC_SYSTEM:     row_set(r, "SYSTEM");         return;

    case SET_HIGHLIGHT:  row_set(r, "Highlight");      row_val(r, k_highlights[c->highlight]); return;
    case SET_TEXT:       row_set(r, "Text size");      row_val(r, k_text_sizes[c->text_size]); return;
    case SET_DARK:       row_set(r, "Dark mode");      row_val(r, k_on_off[c->dark_mode]);     return;
    case SET_ART:        row_set(r, "Album art");      row_val(r, k_on_off[c->album_art]);     return;
    case SET_DRIVE:      row_set(r, "Display drive");
                         row_val(r, c->drive ? "classic" : eink_safe_classic_on() ? "fast (off)" : "fast"); return;
    case SET_ANIM:       row_set(r, "Full refresh");
                         row_val(r, (const char *[]){ "often", "normal", "rarely" }[c->anim_speed]); return;
    case SET_INK:        row_set(r, "Ink strength");   snprintf(v, sizeof v, "%u", c->ink - 3u); break;
    case SET_HALO:       row_set(r, "Edge clean-up");
                         row_val(r, (const char *[]){ "off", "1 px", "2 px" }[c->halo]);        return;
    case SET_REFRESH:    row_set(r, "Menu refresh");   row_val(r, c->menu_refresh ? "classic" : "gentle"); return;

    case SET_EQ:         row_set(r, "Equaliser");      row_val(r, eq_preset_name(c->eq_preset)); return;
    case SET_GAPLESS:    row_set(r, "Gapless");        row_val(r, k_on_off[c->gapless]);       return;
    case SET_REPEAT:     row_set(r, "Repeat");
                         row_val(r, (const char *[]){ "off", "all", "one" }[c->repeat]);        return;
    case SET_HP:         row_set(r, "Headphone detect"); row_val(r, k_on_off[c->hp_detect]);   return;
    case SET_SPEED:      row_set(r, "Podcast speed");  speed_text(v, sizeof v);                break;

    case SET_TIMER_FADE: row_set(r, "Fade out");
                         if (c->timer_fade_s) snprintf(v, sizeof v, "%u s", c->timer_fade_s);
                         else snprintf(v, sizeof v, "off");
                         break;
    case SET_TIMER_SONG: row_set(r, "Finish the song"); row_val(r, k_on_off[c->timer_song_end]); return;

    case SET_QUICK:      row_set(r, "Quick menu");     row_val(r, k_quick_keys[c->quick_key]); return;
    case SET_DOUBLE:     row_set(r, "Double-press back"); row_val(r, k_on_off[c->sw1_double]); return;
    case SET_ON_PRESS:   row_set(r, "Keys act on");    row_val(r, c->nav_on_press ? "press" : "release"); return;
    case SET_LONG:       row_set(r, "Long press");
                         snprintf(v, sizeof v, "%u.%u s", c->long_ms / 1000u, (c->long_ms % 1000u) / 100u);
                         break;

    case SET_SLEEP:      row_set(r, "Sleep after");    row_val(r, power_timeout_label(c->sleep_timeout)); return;
    case SET_USB:        row_set(r, "USB");
                         row_val(r, (const char *[]){ "ask", "storage", "DAC", "charge" }[c->usb_default]); return;
    case SET_CHARGE:     row_set(r, "Charge rate");    snprintf(v, sizeof v, "%u mA", c->charge_ma); break;
    case SET_NO_NTC:     row_set(r, "Force charge");   row_val(r, k_on_off[c->no_thermistor]); return;
    case SET_CHARGER:    row_set(r, "Charger");        row_val(r, npm1300_charger_state());    return;
    case SET_FUEL:       row_set(r, "Battery %");      row_val(r, k_on_off[c->fuel_gauge]);    return;

    case SET_LIBRARY:    row_set(r, "Rebuild library"); return;
    case SET_FIRMWARE:   row_set(r, "Firmware");       row_val(r, fwu_running_version());      return;
    case SET_ABOUT:      row_set(r, "About");          return;
    case SET_ID_COUNT:   break;
    }
    row_val(r, v);
}

static void settings_open(void)
{
    settings_build();
    if (s_set_sel < 0) { s_set_sel = 1; s_set_top = 0; }   /* first item, not the header */
    s_sel = s_set_sel;
    s_top = s_set_top;
    go(SCR_MENU_SETTINGS);
}

static void fw_screen_open(void)
{
    s_fw_nfiles  = settings_mounted() ? fwu_list(s_fw_files, FWU_MAX_FILES) : 0;
    s_fw_prev_ok = fwu_previous(s_fw_prev, sizeof s_fw_prev);
    s_sel = s_top = 0;
    go(SCR_FIRMWARE);
}

static void settings_activate(void)
{
    settings_t *c = settings_get();
    set_id_t id = (set_id_t)s_set_rows[s_sel];
    s_set_sel = s_sel;
    s_set_top = s_top;
    switch (id) {
    case SET_HIGHLIGHT: c->highlight = (uint8_t)((c->highlight + 1) % HL_COUNT); break;
    case SET_TEXT:
        c->text_size = (uint8_t)((c->text_size + 1) % 3);
        s_want_full = true;                     /* whole layout changes   */
        break;
    case SET_DARK:
        c->dark_mode = !c->dark_mode;
        gfx_set_invert(c->dark_mode);
        s_want_full = s_want_real_full = true;  /* every pixel flips      */
        break;
    case SET_ART:     c->album_art = !c->album_art;               break;
    case SET_DRIVE:
        c->drive = !c->drive;
        eink_safe_classic(false);               /* the user has decided   */
        settings_apply_display();
        settings_build();                       /* rows differ per drive  */
        s_sel = settings_index_of(SET_DRIVE);
        s_want_full = s_want_real_full = true;  /* new drive starts clean */
        break;
    case SET_ANIM:    c->anim_speed = (uint8_t)((c->anim_speed + 1) % 3); break;
    case SET_INK:
        s_scr = SCR_SETTING_ADJUST;
        break;
    case SET_HALO:
        c->halo = (uint8_t)((c->halo + 1) % 3);
        eink_set_halo(c->halo);
        break;
    case SET_REFRESH: c->menu_refresh = !c->menu_refresh;         break;

    case SET_EQ:
        s_eq_band = 0;
        go(SCR_EQ);
        return;
    case SET_GAPLESS: c->gapless = !c->gapless;                   break;
    case SET_REPEAT:  c->repeat = (uint8_t)((c->repeat + 1) % 3); break;
    case SET_HP:      c->hp_detect = !c->hp_detect;               break;
    case SET_SPEED:
        c->pod_speed = (uint8_t)((c->pod_speed + 1) % SETTINGS_SPEED_COUNT);
        player_speed_changed();
        break;

    case SET_TIMER_FADE:
        c->timer_fade_s = c->timer_fade_s == 0 ? 10 : c->timer_fade_s == 10 ? 30 :
                          c->timer_fade_s == 30 ? 60 : 0;
        break;
    case SET_TIMER_SONG: c->timer_song_end = !c->timer_song_end;  break;

    case SET_QUICK:    c->quick_key = (uint8_t)((c->quick_key + 1) % QK_COUNT); break;
    case SET_DOUBLE:
        c->sw1_double = !c->sw1_double;
        settings_apply_input();
        if (!c->sw1_double) ui_toast("Back = hold the up key");
        break;
    case SET_ON_PRESS: c->nav_on_press = !c->nav_on_press; settings_apply_input(); break;
    case SET_LONG:
        c->long_ms = c->long_ms <= 500 ? 700 : c->long_ms <= 700 ? 1000 : 500;
        settings_apply_input();
        break;

    case SET_SLEEP:
        c->sleep_timeout = (uint8_t)((c->sleep_timeout + 1) % POWER_TIMEOUT_COUNT);
        break;
    case SET_USB:     c->usb_default = (uint8_t)((c->usb_default + 1) % 4); break;
    case SET_CHARGE: {
        unsigned i = 0;
        while (i < SETTINGS_CHARGE_COUNT && k_charge_opts[i] <= c->charge_ma) i++;
        if (i >= SETTINGS_CHARGE_COUNT ||
            (c->no_thermistor && k_charge_opts[i] > BATT_CHARGE_MA_NO_NTC_MAX))
            i = 0;                  /* no-NTC: options stop at 350 mA    */
        c->charge_ma = k_charge_opts[i];
        npm1300_set_charge_current(c->charge_ma);
        break;
    }
    case SET_NO_NTC:
        c->no_thermistor = !c->no_thermistor;
        if (c->no_thermistor && c->charge_ma > BATT_CHARGE_MA_NO_NTC_MAX)
            c->charge_ma = BATT_CHARGE_MA_NO_NTC_MAX;
        npm1300_set_no_ntc(c->no_thermistor);
        npm1300_set_charge_current(c->charge_ma);
        s_batt_last_poll = HAL_GetTick() - 10000u;   /* re-read charging */
        break;
    case SET_CHARGER:               /* read-only: just refresh the row   */
        break;
    case SET_FUEL:
        c->fuel_gauge = !c->fuel_gauge;
        fuelgauge_enable(c->fuel_gauge, c->batt_mah);
        s_batt_last_poll = HAL_GetTick() - 10000u;   /* redraw the icon   */
        s_batt_last_draw = 0;
        break;
    case SET_LIBRARY:
        if (!settings_mounted()) { ui_toast("No SD card"); return; }
        library_rebuild();
        ui_toast("Rebuilding library");
        return;
    case SET_FIRMWARE:
        fw_screen_open();
        return;
    case SET_ABOUT:
        go(SCR_ABOUT);
        return;
    default:
        return;                     /* section header                    */
    }
    settings_save();
    s_dirty = true;
}

/* ---- adjust (ink strength) -------------------------------------------------------------------- */

static void draw_adjust(void)
{
    settings_t *c = settings_get();
    gfx_clear(GFX_WHITE);
    draw_status_bar();
    gfx_text(&font_ui18b, 20, 44, "Ink strength", GFX_BLACK);
    gfx_progress_bar(20, 84, 160, 16, (uint32_t)(c->ink - 3), 5);
    char l[8];
    snprintf(l, sizeof l, "%u", c->ink - 3u);
    center_text(&font_ui18b, 106, l, GFX_BLACK);
    gfx_text(&font_ui11, 20, 140, "Pulses per changed pixel.", GFX_DARK);
    gfx_text(&font_ui11, 20, 156, "Lower = faster and lighter.", GFX_DARK);
    gfx_text(&font_ui11, 20, 178, "vol +/- to adjust, back to exit", GFX_BLACK);
}

static void adjust_delta(int d)
{
    settings_t *c = settings_get();
    int v = c->ink + d;
    if (v < 4) v = 4;
    if (v > 8) v = 8;
    c->ink = (uint8_t)v;
    eink_set_ink(c->ink);
    settings_save();
    s_dirty = true;
}

static void back_to_settings(void) { settings_open(); }

/* ---- EQ ------------------------------------------------------------------------------------------ */

#define EQ_Y0     104                /* 0 dB line                          */
#define EQ_PX_DB  4

static void draw_eq(void)
{
    settings_t *c = settings_get();
    const int8_t *g = settings_eq_gains();
    char l[40];
    gfx_clear(GFX_WHITE);
    draw_status_bar();

    snprintf(l, sizeof l, "Preset: %s", eq_preset_name(c->eq_preset));
    gfx_text(&font_ui11, 4, 23, l, GFX_BLACK);
    if (c->eq_preset != 0 && eq_active()) {
        int p = eq_preamp_tenths();
        snprintf(l, sizeof l, "pre %d.%d dB", p / 10, (p < 0 ? -p : p) % 10);
        gfx_text(&font_ui11, 196 - gfx_text_width(&font_ui11, l), 23, l, GFX_DARK);
    }
    uint16_t hz = eq_band_hz[s_eq_band];
    if (hz >= 1000) snprintf(l, sizeof l, "%u kHz  %+d dB", hz / 1000, g[s_eq_band]);
    else            snprintf(l, sizeof l, "%u Hz  %+d dB", hz, g[s_eq_band]);
    center_text(&font_ui11, 38, l, GFX_BLACK);

    gfx_hline(0, EQ_Y0, 200, GFX_LIGHT);
    static const char *const lab[EQ_BANDS] = {
        "31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k" };
    for (int b = 0; b < EQ_BANDS; b++) {
        int x = b * 20;
        int h = g[b] * EQ_PX_DB;
        if (h > 0) gfx_fill_rect(x + 6, EQ_Y0 - h, 8, h, GFX_BLACK);
        if (h < 0) gfx_fill_rect(x + 6, EQ_Y0 + 1, 8, -h, GFX_BLACK);
        if (!h)    gfx_fill_rect(x + 6, EQ_Y0 - 1, 8, 3, GFX_BLACK);
        int lw = gfx_text_width(&font_ui11, lab[b]);
        gfx_text(&font_ui11, x + (20 - lw) / 2, 156, lab[b], GFX_BLACK);
        if (b == s_eq_band) {
            gfx_rect(x + 1, 52, 18, 104, GFX_BLACK);
            gfx_invert_rect(x + 1, 155, 18, 13);
        }
    }
    gfx_text(&font_ui11, 4, 182, eq_rate_limited() ? "Off for >96 kHz (bit-perfect)"
                                                   : "vol: gain  play: preset", GFX_DARK);
}

static void eq_edit(int d)
{
    settings_t *c = settings_get();
    if (c->eq_preset != EQ_PRESET_CUSTOM) {
        const int8_t *g = eq_preset_gains(c->eq_preset);
        for (int b = 0; b < EQ_BANDS; b++) c->eq_custom[b] = g ? g[b] : 0;
        c->eq_preset = EQ_PRESET_CUSTOM;
    }
    int v = c->eq_custom[s_eq_band] + d;
    if (v >  EQ_GAIN_MAX) v =  EQ_GAIN_MAX;
    if (v < -EQ_GAIN_MAX) v = -EQ_GAIN_MAX;
    c->eq_custom[s_eq_band] = (int8_t)v;
    c->eq_on = true;
    settings_apply_eq();
    settings_save();
    s_dirty = true;
}

static void eq_next_preset(void)
{
    settings_t *c = settings_get();
    c->eq_preset = (uint8_t)((c->eq_preset + 1) % EQ_PRESET_COUNT);
    c->eq_on = c->eq_preset != 0;
    settings_apply_eq();
    settings_save();
    s_dirty = true;
}

/* ---- firmware -------------------------------------------------------------------------------------- */

#define FW_ROWS_FIXED 2              /* running, previous                  */

static int fw_count(void)
{
    return FW_ROWS_FIXED + (s_fw_nfiles ? (int)s_fw_nfiles : 1);
}

static void fw_row(int idx, row_t *r)
{
    char *buf = r->text;
    int len = (int)sizeof r->text;
    if (idx == 0) { snprintf(buf, len, "Running %s %s", fwu_running_version(), FW_CHANNEL); return; }
    if (idx == 1) {
        snprintf(buf, len, s_fw_prev_ok ? "Previous: %s" : "Previous: none", s_fw_prev);
        return;
    }
    if (!s_fw_nfiles) { snprintf(buf, len, "No .bin in /Firmware"); return; }
    const fwu_file_t *f = &s_fw_files[idx - FW_ROWS_FIXED];
    snprintf(buf, len, "Install %s", f->version[0] && f->version[0] != '?' ? f->version : f->name);
}

static void fw_activate(void)
{
    if (s_sel == 0) return;
    if (s_sel == 1) {
        if (!s_fw_prev_ok) { ui_toast("No previous firmware"); return; }
        s_fw_action = -1;
    } else {
        if (!s_fw_nfiles) { ui_toast("Copy a .bin to /Firmware"); return; }
        s_fw_action = s_sel - FW_ROWS_FIXED;
    }
    go(SCR_FW_CONFIRM);
}

static void draw_fw_confirm(void)
{
    char l[48];
    gfx_clear(GFX_WHITE);
    draw_status_bar();
    if (s_fw_action < 0) {
        gfx_text(&font_ui14, 8, 30, "Switch to previous", GFX_BLACK);
        snprintf(l, sizeof l, "firmware (%s)?", s_fw_prev);
        gfx_text(&font_ui14, 8, 50, l, GFX_BLACK);
    } else {
        const fwu_file_t *f = &s_fw_files[s_fw_action];
        gfx_text(&font_ui14, 8, 30, "Install firmware", GFX_BLACK);
        snprintf(l, sizeof l, "%s?", f->version[0] != '?' ? f->version : "from file");
        gfx_text(&font_ui14, 8, 50, l, GFX_BLACK);
        gfx_text_ellipsis(&font_ui11, 8, 72, 186, f->name, GFX_DARK);
    }
    gfx_text(&font_ui11, 8, 98,  "play = go, back = cancel", GFX_BLACK);
    gfx_text(&font_ui11, 8, 126, "The current firmware is kept.", GFX_DARK);
    gfx_text(&font_ui11, 8, 142, "If the new one won't start,", GFX_DARK);
    gfx_text(&font_ui11, 8, 158, "it switches back by itself.", GFX_DARK);
}

static void fw_progress(int pct, const char *what)
{
    char l[32];
    gfx_clear(GFX_WHITE);
    draw_status_bar();
    center_text(&font_ui14, 60, what, GFX_BLACK);
    snprintf(l, sizeof l, "%d %%", pct);
    center_text(&font_ui18b, 88, l, GFX_BLACK);
    gfx_progress_bar(30, 120, 140, 10, (uint32_t)pct, 100);
    center_text(&font_ui11, 146, "Don't remove the SD card", GFX_DARK);
    if (pct >= 100) {
        /* The restart follows: leave a settled image and a sleeping panel
         * for whichever firmware starts next (display-test rule).         */
        eink_refresh_full();
        eink_power_off();
    } else {
        eink_refresh_partial();
        eink_settle();                          /* no main loop in here    */
    }
}

static void fw_go(void)
{
    if (usb_app_busy()) { ui_toast("Unplug USB first"); return; }
    player_stop();
    settings_flush();
    const char *err = "?";
    if (s_fw_action < 0) {
        fw_progress(100, "Restarting");
        diag_note_reset(DIAG_RESET_SOFTWARE);
        fwu_switch_previous(&err);
    } else {
        diag_note_reset(DIAG_RESET_SOFTWARE);
        fwu_install(s_fw_files[s_fw_action].name, fw_progress, &err);
    }
    /* only reached on failure                                             */
    eink_power_on();
    s_want_real_full = true;
    ui_toast(err);
    fw_screen_open();
}

/* ---- about ---------------------------------------------------------------------------------------- */

static void draw_about(void)
{
    char l[64];
    int y = 24;
    gfx_clear(GFX_WHITE);
    draw_status_bar();
    snprintf(l, sizeof l, "e.player %s %s", fwu_running_version(), FW_CHANNEL);
    gfx_text(&font_ui14, 6, y, l, GFX_BLACK);                      y += 22;

    settings_sd_status(l, sizeof l);
    gfx_text_ellipsis(&font_ui11, 6, y, 188, l, GFX_BLACK);        y += 15;

    const eink_stats_t *e = eink_stats();
    snprintf(l, sizeof l, "Display: %s%s", eink_drive() == EINK_DRIVE_FAST ? "fast" : "classic",
             eink_failed() ? ", NOT ANSWERING" :
             eink_safe_classic_on() ? " (classic after a fault)" :
             (eink_drive() == EINK_DRIVE_FAST && !eink_fast_active()) ? " (classic for USB)" : "");
    gfx_text_ellipsis(&font_ui11, 6, y, 188, l, GFX_BLACK);        y += 15;
    snprintf(l, sizeof l, "Scans %lu, since clean %lu", (unsigned long)e->scans,
             (unsigned long)e->since_clean);
    gfx_text_ellipsis(&font_ui11, 6, y, 188, l, GFX_BLACK);        y += 15;
    snprintf(l, sizeof l, "Scan %lu ms, clean %lu ms, faults %lu", (unsigned long)e->last_busy_ms,
             (unsigned long)e->last_full_ms, (unsigned long)e->faults);
    gfx_text_ellipsis(&font_ui11, 6, y, 188, l, GFX_BLACK);        y += 15;

    uint16_t mv = 0;
    int16_t deg = 0;
    bool has_mv = npm1300_vbat_mv(&mv), has_t = npm1300_die_temp_c(&deg);
    if (s_batt_absent)  snprintf(l, sizeof l, "Battery: none");
    else if (has_mv)    snprintf(l, sizeof l, "Battery: %u.%02u V, %s", mv / 1000u, (mv % 1000u) / 10u,
                                 npm1300_charger_state());
    else                snprintf(l, sizeof l, "Battery: ?");
    gfx_text_ellipsis(&font_ui11, 6, y, 188, l, GFX_BLACK);        y += 15;
    if (has_t) snprintf(l, sizeof l, "PMIC %d C, headphones %s", deg,
                        cs43131_headphones_present() ? "in" : "out");
    else       snprintf(l, sizeof l, "Headphones %s", cs43131_headphones_present() ? "in" : "out");
    gfx_text_ellipsis(&font_ui11, 6, y, 188, l, GFX_BLACK);        y += 15;

    char why[32];
    diag_summary(why, sizeof why);
    snprintf(l, sizeof l, "Last reset: %s", why);
    gfx_text_ellipsis(&font_ui11, 6, y, 188, l, GFX_BLACK);        y += 15;
    snprintf(l, sizeof l, "Library: %lu songs, %lu podcasts", (unsigned long)library_track_count(),
             (unsigned long)s_npods);
    gfx_text_ellipsis(&font_ui11, 6, y, 188, l, GFX_BLACK);
    gfx_text(&font_ui11, 6, 183, "play = refresh, back = exit", GFX_DARK);
}

/* ---- quick menu (2.7.0) --------------------------------------------------------------------------- *
 * Opened from Now Playing; the music keeps playing. Fixed rows first -
 * podcast speed (podcasts only), sleep timer, remove from playlist
 * (playlist files only), loop song - then "Up next": the rest of the
 * current list. Choosing a song there jumps to it and closes the menu;
 * the queue then starts after that song.                                 */

typedef enum { Q_SPEED, Q_TIMER, Q_REMOVE, Q_LOOP, Q_UPNEXT, Q_QUEUE } quick_id_t;

static uint8_t s_quick_rows[5];
static int     s_quick_fixed;                   /* rows before the queue  */

static void quick_build(void)
{
    s_quick_fixed = 0;
    if (player_is_podcast()) s_quick_rows[s_quick_fixed++] = Q_SPEED;
    s_quick_rows[s_quick_fixed++] = Q_TIMER;
    if (player_can_remove())  s_quick_rows[s_quick_fixed++] = Q_REMOVE;
    if (!player_is_podcast()) s_quick_rows[s_quick_fixed++] = Q_LOOP;
    if (player_queue_count()) s_quick_rows[s_quick_fixed++] = Q_UPNEXT;
}

static quick_id_t quick_id(int idx)
{
    return idx < s_quick_fixed ? (quick_id_t)s_quick_rows[idx] : Q_QUEUE;
}

static int quick_count(void) { return s_quick_fixed + (int)player_queue_count(); }

static row_kind_t quick_kind(int idx)
{
    return quick_id(idx) == Q_UPNEXT ? ROW_SECTION : ROW_ITEM;
}

static void quick_row(int idx, row_t *r)
{
    char v[24] = "";
    switch (quick_id(idx)) {
    case Q_SPEED:  row_set(r, "Speed");  speed_text(v, sizeof v); break;
    case Q_TIMER:
        row_set(r, "Sleep timer");
        if (player_timer_minutes()) snprintf(v, sizeof v, "%u min", player_timer_minutes());
        else snprintf(v, sizeof v, "off");
        break;
    case Q_REMOVE: row_set(r, "Remove from playlist"); break;
    case Q_LOOP:   row_set(r, "Loop song"); snprintf(v, sizeof v, "%s", k_on_off[player_loop()]); break;
    case Q_UPNEXT: row_set(r, "UP NEXT"); break;
    case Q_QUEUE:
        if (!player_queue_title((uint32_t)(idx - s_quick_fixed), r->text, sizeof r->text))
            row_set(r, "?");
        break;
    }
    row_val(r, v);
}

static void quick_open(void)
{
    quick_build();
    s_sel = s_top = 0;
    go(SCR_QUICK);
}

static void quick_reopen(void)
{
    quick_build();
    s_sel = s_quick_sel < quick_count() ? s_quick_sel : 0;
    s_top = 0;
    go(SCR_QUICK);
}

/* Sleep-timer durations offered (minutes); row 0 = off.                  */
static const uint8_t k_timer_min[] = { 0, 5, 10, 15, 20, 30, 45, 60, 90, 120 };
#define TIMER_ROWS ((int)(sizeof k_timer_min))

static void timer_row(int idx, row_t *r)
{
    if (!idx) { row_set(r, "Off"); return; }
    snprintf(r->text, sizeof r->text, "%u minutes", k_timer_min[idx]);
    if (k_timer_min[idx] == player_timer_minutes()) { row_val(r, "running"); r->small_value = true; }
}

static void timer_open(void)
{
    /* Cursor on the running duration, else on the one used last.         */
    uint8_t want = player_timer_minutes() ? player_timer_minutes() : settings_get()->timer_min;
    s_sel = 4;                                  /* 20 minutes             */
    for (int i = 1; i < TIMER_ROWS; i++) if (k_timer_min[i] == want) s_sel = i;
    s_top = 0;
    go(SCR_TIMER);
}

static void quick_activate(void)
{
    settings_t *c = settings_get();
    s_quick_sel = s_sel;
    switch (quick_id(s_sel)) {
    case Q_SPEED:
        c->pod_speed = (uint8_t)((c->pod_speed + 1) % SETTINGS_SPEED_COUNT);
        settings_save();
        player_speed_changed();
        s_seen_player_seq = player_seq();
        s_dirty = true;
        break;
    case Q_TIMER:
        timer_open();
        break;
    case Q_REMOVE:
        go(SCR_REMOVE);
        break;
    case Q_LOOP:
        player_set_loop(!player_loop());
        s_seen_player_seq = player_seq();
        s_dirty = true;
        break;
    case Q_UPNEXT:
        break;
    case Q_QUEUE:
        /* Skip to that song: the menu closes on it, and next time the
         * queue starts after it.                                          */
        if (player_jump((uint32_t)(s_sel - s_quick_fixed))) enter_now_playing(SCR_QUICK);
        else { play_error_toast(player_take_error()); s_dirty = true; }
        break;
    }
}

static void timer_activate(void)
{
    uint8_t min = k_timer_min[s_sel];
    player_timer_set(min);
    s_seen_player_seq = player_seq();
    if (min) {
        static char m[32];
        snprintf(m, sizeof m, "Sleep in %u min", min);
        ui_toast(m);
    } else {
        ui_toast("Sleep timer off");
    }
    /* Back to the song; the status bar now carries the timer mark.       */
    go(SCR_NOW_PLAYING);
}

static const char *playing_list_name(void)
{
    const char *file = player_playlist_file();
    for (uint32_t i = 0; i < s_nlists; i++)
        if (!strcmp(s_lists[i].file, file)) return s_lists[i].name;
    return file;
}

static void draw_remove(void)
{
    char l[80];
    gfx_clear(GFX_WHITE);
    draw_status_bar();
    gfx_text(&font_ui18b, 8, 26, "Remove this song?", GFX_BLACK);
    gfx_text_ellipsis(&font_ui14, 8, 58, 184, player_tags()->title, GFX_BLACK);
    snprintf(l, sizeof l, "from \"%s\"", playing_list_name());
    gfx_text_ellipsis(&font_ui11, 8, 80, 184, l, GFX_DARK);
    gfx_text(&font_ui11, 8, 102, "The file stays on the card.", GFX_DARK);

    /* the one action, drawn as a button so it reads as "hold this"       */
    gfx_fill_rect(8, 128, 184, 30, GFX_BLACK);
    int w = gfx_text_width(&font_ui14, "Hold play to remove");
    gfx_text(&font_ui14, (200 - w) / 2, 128 + (30 - font_ui14.height) / 2,
             "Hold play to remove", GFX_WHITE);
    center_text(&font_ui11, 168, "any other key = cancel", GFX_BLACK);
}

static void remove_confirmed(void)
{
    if (!player_remove_current()) {
        ui_toast("Couldn't change the playlist");
        quick_reopen();
        return;
    }
    ui_toast("Removed from playlist");
    s_seen_player_seq = player_seq();
    s_seen_track_seq  = player_track_seq();
    s_np_last_fill = -1;
    if (player_state() == PLAYER_STOPPED) {     /* it was the last song    */
        if (s_np_return == SCR_BROWSE && s_nav_n) { browse_load(); go(SCR_BROWSE); }
        else back_to_main();
    } else {
        go(SCR_NOW_PLAYING);
    }
}

/* ---- error / now playing ---------------------------------------------------------------------------- */

static void draw_error(void)
{
    char l[48];
    gfx_clear(GFX_WHITE);
    draw_status_bar();
    gfx_text(&font_ui14, 10, 60, s_err_msg ? s_err_msg : "Error", GFX_BLACK);
    if (s_codec_ok) {                           /* say why the card failed */
        settings_sd_status(l, sizeof l);
        gfx_text_ellipsis(&font_ui11, 10, 84, 184, l, GFX_DARK);
    }
    gfx_text(&font_ui11, 10, 108, "play = continue to menu", GFX_BLACK);
    gfx_text(&font_ui11, 10, 126, "reboot: hold vol- + vol+ 5 s", GFX_DARK);
}

static void fmt_time(char *buf, int len, uint32_t ms)
{
    if (ms >= 3600000u)
        snprintf(buf, len, "%lu:%02lu:%02lu", (unsigned long)(ms / 3600000u),
                 (unsigned long)((ms / 60000u) % 60u), (unsigned long)((ms / 1000u) % 60u));
    else
        snprintf(buf, len, "%lu:%02lu",
                 (unsigned long)(ms / 60000u), (unsigned long)((ms / 1000u) % 60u));
}

/* Track length text and the bar width that leaves room for it.          */
static int np_len_text(char *buf, int len)
{
    uint32_t ms = player_len_ms();
    if (ms) fmt_time(buf, len, ms);
    else    snprintf(buf, len, "-:--");
    return gfx_text_width(&font_ui11, buf);
}

static int np_bar_w(void)
{
    char t[16];
    return 196 - np_len_text(t, sizeof t) - 5 - TR_BAR_X;
}

static void draw_transport(void)
{
    uint32_t pos = player_pos_ms(), len = player_len_ms();
    char tbuf[16];
    int tw = np_len_text(tbuf, sizeof tbuf);
    gfx_fill_rect(0, TR_Y, 200, 200 - TR_Y, GFX_WHITE);
    gfx_progress_bar(TR_BAR_X, TR_BAR_Y, np_bar_w(), TR_BAR_H, pos, len ? len : 1);
    gfx_text(&font_ui11, 196 - tw, TR_BAR_Y + (TR_BAR_H - font_ui11.height) / 2,
             tbuf, GFX_BLACK);
}

/* Title under the art: bottom-aligned one gap above the bar, wrapped onto
 * a second line at a space when it doesn't fit and two lines still clear
 * the art by the gap (small text: exactly). Otherwise one line with "..". */
static void draw_np_title(const font_t *f, const char *s)
{
    const int maxw = 192;
    int h = f->height;
    if (gfx_text_width(f, s) > maxw && NP_TEXT_BOT - 2 * h >= NP_TEXT_TOP) {
        char l1[64];
        int n = 0, w = 0, brk = -1;
        for (; s[n] && n < (int)sizeof l1 - 1; n++) {
            char tmp[2] = { s[n], 0 };
            int a = gfx_text_width(f, tmp);
            if (w + a > maxw) break;
            if (s[n] == ' ') brk = n;
            w += a;
            l1[n] = s[n];
        }
        if (brk <= 0) brk = n;                  /* no space: hard break    */
        l1[brk] = '\0';
        const char *rest = s + brk;
        while (*rest == ' ') rest++;
        center_text(f, NP_TEXT_BOT - 2 * h, l1, GFX_BLACK);
        center_text(f, NP_TEXT_BOT - h, rest, GFX_BLACK);
    } else {
        int y = NP_TEXT_BOT - h;
        if (y < NP_TEXT_TOP) y = NP_TEXT_TOP;
        center_text(f, y, s, GFX_BLACK);
    }
}

/* Left-aligned text wrapped at spaces onto up to max_lines lines (the
 * last one ends in ".." if there is more). Returns the y below it.        */
static int draw_wrapped(const font_t *f, int x, int y, int maxw, int max_lines, const char *s)
{
    for (int line = 0; line < max_lines && *s; line++) {
        if (line == max_lines - 1 || gfx_text_width(f, s) <= maxw) {
            gfx_text_ellipsis(f, x, y, maxw, s, GFX_BLACK);
            return y + f->height;
        }
        char buf[64];
        int n = 0, w = 0, brk = -1;
        for (; s[n] && n < (int)sizeof buf - 1; n++) {
            char tmp[2] = { s[n], 0 };
            int a = gfx_text_width(f, tmp);
            if (w + a > maxw) break;
            if (s[n] == ' ') brk = n;
            w += a;
            buf[n] = s[n];
        }
        if (brk <= 0) brk = n;                  /* no space: hard break    */
        buf[brk] = '\0';
        gfx_text(f, x, y, buf, GFX_BLACK);
        y += f->height;
        s += brk;
        while (*s == ' ') s++;
    }
    return y;
}

static void draw_now_playing(void)
{
    const track_tags_t *t = player_tags();
    gfx_clear(GFX_WHITE);
    draw_status_bar();
    const font_t *f = list_font();
    const uint8_t *art = player_art();
    if (art && settings_get()->album_art) {
        gfx_rect(ART_X - 1, ART_Y - 1, ART_SIZE + 2, ART_SIZE + 2, GFX_LIGHT);
        gfx_blit_gray_dither(ART_X, ART_Y, ART_SIZE, ART_SIZE, art);
        draw_np_title(f, t->title);
    } else {
        /* No art (or art switched off, or a podcast): the title gets the
         * room, wrapped over up to three lines.                           */
        int y = draw_wrapped(&font_ui18b, 6, 34, 188, 3, t->title);
        if (t->album[0]) {
            gfx_text_ellipsis(f, 6, y + 6, 188, t->album, GFX_DARK);
            y += 6 + f->height;
        }
        if (player_is_podcast()) {
            char l[24], sp[12];
            speed_text(sp, sizeof sp);
            snprintf(l, sizeof l, "Speed %s", sp);
            gfx_text(&font_ui11, 6, y + 8, l, GFX_DARK);
        }
    }
    draw_transport();
    s_np_last_fill = gfx_progress_fill_px(np_bar_w(), player_pos_ms(),
                                          player_len_ms() ? player_len_ms() : 1);
}

/* ---- usb ------------------------------------------------------------------------------------------------ */

static const char *k_usb_items[] = { "USB storage", "USB DAC", "Charge only" };

static void draw_usb_prompt(void)
{
    gfx_clear(GFX_WHITE);
    draw_status_bar();
    gfx_text(&font_ui14, 16, 36, "Use this cable for:", GFX_BLACK);
    for (int i = 0; i < 3; i++) {
        int y = 70 + i * 30;
        gfx_text(&font_ui14, 24, y + 6, k_usb_items[i], GFX_BLACK);
        if (i == s_usb_sel) gfx_invert_rect(12, y, 176, 30);
    }
}

static void draw_usb_active(void)
{
    gfx_clear(GFX_WHITE);
    draw_status_bar();
    bool msc = usb_app_storage_owned();
    gfx_text(&font_ui18b, 10, 40, msc ? "USB storage" : "USB DAC", GFX_BLACK);
    if (msc) {
        gfx_text(&font_ui11, 10, 80,  "The computer has the SD card.", GFX_BLACK);
        gfx_text(&font_ui11, 10, 98,  "Eject it there, or unplug the", GFX_BLACK);
        gfx_text(&font_ui11, 10, 114, "cable, to return to the player.", GFX_BLACK);
    } else {
        char l[40];
        uint32_t r = pipe_out_rate();
        gfx_text(&font_ui11, 10, 80,  "Playing audio from the computer.", GFX_BLACK);
        gfx_text(&font_ui11, 10, 98,  "vol +/- set the output level.", GFX_BLACK);
        gfx_text(&font_ui11, 10, 114, "Unplug to return to the player.", GFX_BLACK);
        if (!player_output_allowed()) {
            gfx_text(&font_ui11, 10, 140, "Plug in headphones to listen.", GFX_BLACK);
        } else if (r) {
            snprintf(l, sizeof l, "%lu.%lu kHz%s", (unsigned long)(r / 1000),
                     (unsigned long)((r % 1000) / 100), pipe_bit_perfect() ? ", bit-perfect" : "");
            gfx_text(&font_ui11, 10, 140, l, GFX_DARK);
        }
    }
}

void ui_show_usb_prompt(void)
{
    settings_t *c = settings_get();
    if (c->usb_default != 0) {
        s_usb_choice = (ui_usb_choice_t)c->usb_default;
        return;
    }
    s_usb_choice = UI_USB_ASK;
    s_usb_sel = 0;
    if (s_scr != SCR_USB_PROMPT && s_scr != SCR_USB_ACTIVE) s_return_scr = s_scr;
    go(SCR_USB_PROMPT);
}

void ui_close_usb_prompt(void)
{
    if (s_scr == SCR_USB_PROMPT) go(s_return_scr);
    s_usb_choice = UI_USB_ASK;
}

ui_usb_choice_t ui_usb_choice(void) { return s_usb_choice; }

void ui_usb_mode_changed(void)
{
    if (usb_app_busy()) {
        if (s_scr != SCR_USB_PROMPT && s_scr != SCR_USB_ACTIVE) s_return_scr = s_scr;
        go(SCR_USB_ACTIVE);
        return;
    }
    if (s_scr == SCR_USB_PROMPT || s_scr == SCR_USB_ACTIVE) {
        screen_t r = s_return_scr;
        bool np_like = r == SCR_NOW_PLAYING || r == SCR_QUICK || r == SCR_TIMER || r == SCR_REMOVE;
        if (np_like) r = player_state() == PLAYER_STOPPED ? SCR_MENU_MAIN : SCR_NOW_PLAYING;
        if (r == SCR_USB_PROMPT || r == SCR_USB_ACTIVE || r == SCR_BROWSE) r = SCR_MENU_MAIN;
        if (r == SCR_MENU_MAIN) { s_nav_n = 0; s_sel = s_top = 0; }
        if (r == SCR_MENU_SETTINGS || r == SCR_SETTING_ADJUST) { settings_open(); return; }
        go(r);
    }
}

/* ---- input dispatch -------------------------------------------------------------------------------------- */

static bool is(const btn_event_t *ev, btn_id_t id, btn_event_type_t t)
{
    return ev->id == id && ev->type == t;
}

static bool short_or_repeat(const btn_event_t *ev, btn_id_t id)
{
    return ev->id == id && (ev->type == BTN_EV_SHORT || ev->type == BTN_EV_REPEAT);
}

/* The list on screen, if the screen is one.                               */
static bool cur_list(list_t *l)
{
    switch (s_scr) {
    case SCR_MENU_MAIN:     *l = (list_t){ main_row, NULL, main_count(), -1 };              return true;
    case SCR_MENU_SETTINGS: *l = (list_t){ settings_row, settings_kind, s_set_n, -1 };      return true;
    case SCR_FIRMWARE:      *l = (list_t){ fw_row, NULL, fw_count(), FW_ROWS_FIXED - 1 };   return true;
    case SCR_QUICK:         *l = (list_t){ quick_row, quick_kind, quick_count(), -1 };      return true;
    case SCR_TIMER:         *l = (list_t){ timer_row, NULL, TIMER_ROWS, 0 };                return true;
    case SCR_BROWSE:
        if (!s_nav_n || (browse_needs_lib(nav()->kind) && !library_ready())) return false;
        browse_list(l);
        return l->count > 0;
    default:
        return false;
    }
}

/* One step up or down, over section headers. A press wraps around at the
 * ends; a held key (auto-repeat) stops there.                             */
static void menu_nav(int d, bool held)
{
    list_t l;
    if (!cur_list(&l) || l.count <= 0) return;
    int i = s_sel;
    for (int guard = 0; guard < l.count; guard++) {
        i += d;
        if (i < 0 || i >= l.count) {
            if (held) return;
            i = (i < 0) ? l.count - 1 : 0;
        }
        if (list_kind(&l, i) == ROW_ITEM) {
            if (i != s_sel) { s_sel = i; s_dirty = true; }
            return;
        }
    }
}

/* SW2 = down, SW3 = up in every list.                                     */
static void nav_keys(const btn_event_t *ev)
{
    if (short_or_repeat(ev, BTN_SW2)) menu_nav(+1, ev->type == BTN_EV_REPEAT);
    if (short_or_repeat(ev, BTN_SW3)) menu_nav(-1, ev->type == BTN_EV_REPEAT);
}

static bool is_back(const btn_event_t *ev)
{
    return is(ev, BTN_SW1, BTN_EV_DOUBLE) || is(ev, BTN_SW3, BTN_EV_LONG);
}

static void volume_key(int8_t d)
{
    player_volume_delta(d);
    s_vol_shown = true;
    s_status_tick = true;               /* status-bar update only         */
}

static void leave_now_playing(void)
{
    if (s_np_return == SCR_BROWSE && s_nav_n) { browse_load(); go(SCR_BROWSE); }
    else if (s_np_return == SCR_MENU_SETTINGS) settings_open();
    else back_to_main();
}

void ui_handle_button(const btn_event_t *ev)
{
    s_btn_last = HAL_GetTick();         /* volume indicator timeout       */
    bool vol_ok = s_scr != SCR_SETTING_ADJUST && s_scr != SCR_EQ &&
                  !(s_scr == SCR_USB_ACTIVE && usb_app_storage_owned());
    if (vol_ok) {
        if (short_or_repeat(ev, BTN_SW4)) { volume_key(-2); return; }
        if (short_or_repeat(ev, BTN_SW5)) { volume_key(+2); return; }
    }

    /* Both skip keys held together: the quick menu (Now Playing only).    */
    if (ev->type == BTN_EV_CHORD) {
        if (s_scr == SCR_NOW_PLAYING && settings_get()->quick_key != QK_HOLD_PLAY) quick_open();
        return;
    }

    if (is(ev, BTN_SW1, BTN_EV_LONG)) {
        switch (s_scr) {
        case SCR_REMOVE:
            remove_confirmed();                 /* the confirming hold     */
            return;
        case SCR_NOW_PLAYING:
            if (settings_get()->quick_key != QK_SKIPS) quick_open();
            return;
        case SCR_USB_PROMPT: case SCR_USB_ACTIVE: case SCR_FW_CONFIRM:
        case SCR_QUICK: case SCR_TIMER:
            return;
        default:
            resume_last();                      /* "play what I had on"    */
            return;
        }
    }

    switch (s_scr) {
    case SCR_MENU_MAIN:
        nav_keys(ev);
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) main_activate();
        if (is_back(ev) && player_state() != PLAYER_STOPPED) {
            s_main_sel = s_sel; s_main_top = s_top;
            enter_now_playing(SCR_MENU_MAIN);
        }
        break;

    case SCR_BROWSE:
        nav_keys(ev);
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) browse_activate();
        if (is_back(ev)) browse_pop();
        break;

    case SCR_MENU_SETTINGS:
        nav_keys(ev);
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) settings_activate();
        if (is_back(ev)) back_to_main();
        break;

    case SCR_SETTING_ADJUST:
        if (short_or_repeat(ev, BTN_SW4)) adjust_delta(-1);
        if (short_or_repeat(ev, BTN_SW5)) adjust_delta(+1);
        if (is(ev, BTN_SW1, BTN_EV_SHORT) || is(ev, BTN_SW3, BTN_EV_SHORT) || is_back(ev))
            back_to_settings();
        break;

    case SCR_EQ:
        if (short_or_repeat(ev, BTN_SW4)) eq_edit(-1);
        if (short_or_repeat(ev, BTN_SW5)) eq_edit(+1);
        if (short_or_repeat(ev, BTN_SW2) && s_eq_band < EQ_BANDS - 1) { s_eq_band++; s_dirty = true; }
        if (is(ev, BTN_SW3, BTN_EV_SHORT) && s_eq_band > 0) { s_eq_band--; s_dirty = true; }
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) eq_next_preset();
        if (is_back(ev)) back_to_settings();
        break;

    case SCR_FIRMWARE:
        nav_keys(ev);
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) fw_activate();
        if (is_back(ev)) back_to_settings();
        break;

    case SCR_FW_CONFIRM:
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) fw_go();
        if (is(ev, BTN_SW3, BTN_EV_SHORT) || is_back(ev)) fw_screen_open();
        break;

    case SCR_ABOUT:
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) s_dirty = true;
        if (is(ev, BTN_SW3, BTN_EV_SHORT) || is_back(ev)) back_to_settings();
        break;

    case SCR_NOW_PLAYING:
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) {
            player_toggle_pause();
            play_error_toast(player_take_error());
        }
        if (is_back(ev)) leave_now_playing();
        if (is(ev, BTN_SW2, BTN_EV_SHORT)) player_next();
        if (is(ev, BTN_SW3, BTN_EV_SHORT)) player_prev();
        break;

    case SCR_QUICK:
        nav_keys(ev);
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) quick_activate();
        if (is_back(ev)) go(SCR_NOW_PLAYING);
        break;

    case SCR_TIMER:
        nav_keys(ev);
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) timer_activate();
        if (is_back(ev)) quick_reopen();
        break;

    case SCR_REMOVE:
        /* Only the long press of play (handled above) removes; anything
         * else backs out.                                                 */
        quick_reopen();
        break;

    case SCR_USB_PROMPT:
        if (is(ev, BTN_SW2, BTN_EV_SHORT)) { s_usb_sel = (s_usb_sel + 1) % 3; s_dirty = true; }
        if (is(ev, BTN_SW3, BTN_EV_SHORT)) { s_usb_sel = (s_usb_sel + 2) % 3; s_dirty = true; }
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) s_usb_choice = (ui_usb_choice_t)(s_usb_sel + 1);
        break;

    case SCR_USB_ACTIVE:
        break;

    case SCR_ERROR:
        if (is(ev, BTN_SW1, BTN_EV_SHORT)) { s_sel = s_top = 0; go(SCR_MENU_MAIN); }
        break;
    }
}

/* ---- lifecycle ---------------------------------------------------------------------------------------- */

void ui_splash(void)
{
    gfx_clear(GFX_WHITE);
    gfx_text(&font_ui18b, 55, 75, "e.player", GFX_BLACK);
    char l[32];
    snprintf(l, sizeof l, "v%s %s", FW_VERSION, FW_CHANNEL);
    center_text(&font_ui11, 100, l, GFX_BLACK);
    /* Factory waveform: proves the panel before a register LUT is loaded. */
    eink_boot_screen();
}

void ui_init(bool codec_ok, bool sd_ok)
{
    s_nlists = playlist_enumerate(s_lists, PL_MAX_LISTS);
    s_npods  = sd_ok ? podcast_refresh() : 0;
    s_seen_mount_seq  = settings_mount_seq();
    s_seen_player_seq = player_seq();
    s_seen_track_seq  = player_track_seq();
    s_codec_ok = codec_ok;
    s_sel = s_top = 0;
    s_batt_last_poll = HAL_GetTick() - 10000u;
    if (!codec_ok || !sd_ok) {
        s_err_msg = !sd_ok ? "No SD card / bad card" : "Audio codec error";
        go(SCR_ERROR);
    } else {
        go(SCR_MENU_MAIN);
    }
}

void ui_prepare_sleep(void)
{
    bool inv = gfx_invert();
    gfx_set_invert(false);
    gfx_clear(GFX_WHITE);
    gfx_set_invert(inv);
    eink_refresh_full();
    s_partials_since_full = 0;
}

void ui_after_wake(void)
{
    if (s_scr == SCR_BROWSE && s_nav_n && nav()->kind == B_PLAYLIST)
        browse_load();                       /* its file handle died       */
    s_dirty = true;
    s_want_full = false;
    s_force_partial = true;
    s_np_last_fill = -1;
    s_batt_last_poll = HAL_GetTick() - 10000u;
    ui_poll();
}

static bool partial_budget_spent(void)
{
    uint8_t a = settings_get()->anim_speed;
    if (a > 2) a = 1;
    if (eink_fast_active())
        return s_partials_since_full >= k_budget_fast[a] || eink_clean_due();
    return s_partials_since_full >= k_budget_classic[a];
}

/* Refresh policy.
 *   Fast drive (2.7.0): every change - cursor step, new screen, new song
 *     with its art - is a scan burst without a flash. A clean (flashing)
 *     refresh runs when the Full refresh budget is spent, when the driver
 *     nears its 2400-scan limit, and where every pixel changes anyway
 *     (dark mode, drive change).
 *   Classic drive (2.6.3 rules): Now Playing gets a full refresh on entry
 *     and on a track change; menus change screen with a partial plus a
 *     reinforcing pass ("gentle") or a full refresh ("classic"); a full
 *     refresh when the budget runs out. The OTP hot-weather "fast full" is
 *     no longer used: the display test measured it slower than the normal
 *     full on this panel.                                                 */
static void do_refresh(void)
{
    bool spent = partial_budget_spent();
    if (eink_fast_active()) {
        if (!s_force_partial && (s_want_real_full || spent)) {
            eink_refresh_full();
            s_partials_since_full = 0;
        } else {
            eink_refresh_partial();
            s_partials_since_full++;
        }
    } else if (s_force_partial || !(s_want_full || spent)) {
        eink_refresh_partial();
        s_partials_since_full++;
    } else if (s_scr == SCR_NOW_PLAYING || settings_get()->menu_refresh ||
               spent || s_want_real_full) {
        eink_refresh_full();
        s_partials_since_full = 0;
    } else {
        eink_refresh_partial_clean();
        s_partials_since_full += 2;
    }
    s_want_full = s_want_real_full = s_force_partial = false;
}

static bool np_family(screen_t s)
{
    return s == SCR_NOW_PLAYING || s == SCR_QUICK || s == SCR_TIMER || s == SCR_REMOVE;
}

static void poll_changes(void)
{
    if (player_seq() != s_seen_player_seq) {
        bool track = player_track_seq() != s_seen_track_seq;
        s_seen_player_seq = player_seq();
        s_seen_track_seq  = player_track_seq();
        play_error_toast(player_take_error());
        if (np_family(s_scr)) {
            if (player_state() == PLAYER_STOPPED) {
                leave_now_playing();
            } else if (s_scr == SCR_NOW_PLAYING) {
                if (track) { s_np_last_fill = -1; go(SCR_NOW_PLAYING); }
                else s_status_tick = true;
            } else if (s_scr == SCR_QUICK) {
                /* The song moved on under the menu: the queue is shorter. */
                quick_build();
                if (s_sel >= quick_count()) s_sel = quick_count() - 1;
                s_dirty = true;
            } else if (s_scr == SCR_REMOVE && track) {
                quick_reopen();                 /* not the song that was asked about */
            } else {
                s_status_tick = true;
            }
        } else {
            s_status_tick = true;
            if (s_scr == SCR_MENU_MAIN) s_dirty = true;   /* "Now playing" / "Last played" */
        }
    }

    if (settings_mount_seq() != s_seen_mount_seq) {
        s_seen_mount_seq = settings_mount_seq();
        s_nlists = playlist_enumerate(s_lists, PL_MAX_LISTS);
        s_npods  = settings_mounted() ? podcast_refresh() : 0;
        if (s_scr == SCR_BROWSE || s_scr == SCR_FIRMWARE || s_scr == SCR_FW_CONFIRM) {
            playlist_browse_close();
            s_nav_n = 0;
            s_sel = s_top = 0;
            s_scr = SCR_MENU_MAIN;
        }
        if (s_scr == SCR_MENU_SETTINGS) settings_build();
        if (s_scr == SCR_MENU_MAIN && s_sel >= main_count()) s_sel = main_count() - 1;
        if (s_scr == SCR_ERROR && s_codec_ok) { s_sel = s_top = 0; s_scr = SCR_MENU_MAIN; }
        s_dirty = s_want_full = true;
    }

    /* library progress / completion while a library list is waiting     */
    if (s_scr == SCR_BROWSE && s_nav_n && browse_needs_lib(nav()->kind)) {
        lib_state_t st = library_state();
        uint8_t pct = library_progress();
        uint32_t now = HAL_GetTick();
        if (st != s_seen_lib_state) {
            s_seen_lib_state = st;
            if (st == LIB_READY) browse_load();
            s_dirty = true;
        } else if (st == LIB_BUILDING && pct != s_seen_lib_pct && now - s_lib_draw_t >= 3000) {
            s_seen_lib_pct = pct;
            s_lib_draw_t = now;
            s_dirty = true;
        }
    }

    switch (fwu_poll()) {
    case FWU_EVT_INSTALLED: {
        static char m[32];
        snprintf(m, sizeof m, "Firmware %s installed", fwu_running_version());
        ui_toast(m);
        break;
    }
    case FWU_EVT_ROLLED_BACK: ui_toast("Update failed: rolled back"); break;
    default: break;
    }

    if (s_toast[0] && !toast_active()) {
        s_toast[0] = '\0';
        s_status_tick = true;
    }
    if (s_vol_shown && HAL_GetTick() - s_btn_last >= VOL_SHOW_MS) {
        s_vol_shown = false;
        s_status_tick = true;
    }
}

static void poll_battery(uint32_t now)
{
    if (now - s_batt_last_poll < 10000) return;
    s_batt_last_poll = now;

    bool absent = !npm1300_battery_present();
    if (absent != s_batt_absent) {
        if (++s_absent_votes >= 2 || s_batt_last_draw == 0) {
            s_batt_absent = absent;
            s_absent_votes = 0;
            s_batt_last_draw = now ? now : 1;
            s_batt_tick = true;
        } else {
            s_batt_last_poll = now - 8000u;
        }
    } else {
        s_absent_votes = 0;
    }
    if (s_batt_absent) return;

    int fg = fuelgauge_percent();                 /* -1 = gauge off/invalid */
    uint8_t pct = fg >= 0 ? (uint8_t)fg : npm1300_battery_percent();
    bool chg = npm1300_charging();
    bool crossed = gfx_battery_fill_px(pct) != gfx_battery_fill_px(s_batt_pct) ||
                   (fg >= 0 && fg != s_batt_shown_pct) || (fg < 0 && s_batt_shown_pct >= 0);
    if ((crossed && now - s_batt_last_draw >= 60000) || chg != s_batt_chg ||
        s_batt_last_draw == 0) {
        s_batt_pct = pct;
        s_batt_shown_pct = fg;
        s_batt_chg = chg;
        s_batt_last_draw = now ? now : 1;
        s_batt_tick = true;
    }
}

void ui_poll(void)
{
    uint32_t now = HAL_GetTick();

    /* The register waveforms hung 2.5.1-2.6.2 on exactly these screens and
     * the cause was never isolated: while a USB prompt or data mode is up
     * the panel is driven with the factory waveforms.                     */
    usb_state_t us = usb_app_state();
    eink_force_classic(us == USB_PROMPT || us == USB_MSC || us == USB_DAC);
    /* Now Playing decides on release (the two skip keys together open the
     * quick menu); lists may act on press.                                */
    buttons_press_mode(s_scr != SCR_NOW_PLAYING);

    /* Next scan of a running burst / boosters off / fault retry.          */
    static bool was_failed;
    (void)eink_service();
    if (was_failed && !eink_failed()) s_dirty = true;   /* panel is back: redraw */
    was_failed = eink_failed();
    if (!eink_is_asleep() && now - s_last_refresh >= PANEL_IDLE_SLEEP_MS)
        eink_sleep();

    poll_changes();
    poll_battery(now);

    if (s_scr == SCR_NOW_PLAYING && player_state() == PLAYER_PLAYING) {
        /* Fast drive: each update costs ~9 scans of the driver's 2400 per
         * clean refresh, so the bar moves in steps of 4 s.                */
        uint32_t every = eink_fast_active() ? 4000u : 2000u;
        uint32_t pos = player_pos_ms(), len = player_len_ms();
        int fill = gfx_progress_fill_px(np_bar_w(), pos, len ? len : 1);
        if (fill != s_np_last_fill && now - s_np_last_draw >= every) {
            s_np_last_draw = now;
            s_np_last_fill = fill;
            s_np_tick = true;
        }
    }

    if (!s_dirty && (s_batt_tick || s_np_tick || s_status_tick)) {
        if (partial_budget_spent()) {
            s_dirty = s_want_full = true;
        } else {
            diag_step(STEP_UI_DRAW);
            bool fast = eink_fast_active();
            if (s_status_tick || s_batt_tick) draw_status_bar();
            if (s_np_tick && s_scr == SCR_NOW_PLAYING) draw_transport();
            /* One refresh for whatever changed. Classic: an OTP partial
             * counts toward the budget. Fast: only the changed pixels are
             * driven and the scan limit is the driver's.                  */
            eink_refresh_partial();
            if (!fast) s_partials_since_full++;
            s_batt_tick = s_np_tick = s_status_tick = false;
            s_last_refresh = HAL_GetTick();
            return;
        }
    }

    if (!s_dirty) return;
    s_dirty = false;
    s_batt_tick = s_np_tick = s_status_tick = false;

    diag_step(STEP_UI_DRAW);
    list_t l;
    switch (s_scr) {
    case SCR_MENU_MAIN:
    case SCR_MENU_SETTINGS:
    case SCR_FIRMWARE:
    case SCR_QUICK:
    case SCR_TIMER:
        if (cur_list(&l)) draw_list(&l);
        break;
    case SCR_SETTING_ADJUST: draw_adjust();                            break;
    case SCR_NOW_PLAYING:    draw_now_playing();                       break;
    case SCR_USB_PROMPT:     draw_usb_prompt();                        break;
    case SCR_USB_ACTIVE:     draw_usb_active();                        break;
    case SCR_BROWSE:         draw_browse();                            break;
    case SCR_EQ:             draw_eq();                                break;
    case SCR_FW_CONFIRM:     draw_fw_confirm();                        break;
    case SCR_ERROR:          draw_error();                             break;
    case SCR_REMOVE:         draw_remove();                            break;
    case SCR_ABOUT:          draw_about();                             break;
    }

    do_refresh();
    s_last_refresh = HAL_GetTick();
}
