#include "flash_store.h"
#include "diag.h"
#include "fwupdate.h"
#include "esp_log.h"
#include "stm32u5xx_hal.h"
#include <string.h>

static const char *TAG = "flashst";

#define MAGIC       0x31535444u           /* "DTS1" */
#define SLOT_BYTES  256u
#define SLOTS       (8192u / SLOT_BYTES)
#define PAGE_INDEX  63u                   /* last page of a 512 KB bank */

_Static_assert(FLASH_STORE_PAYLOAD == SLOT_BYTES - 16u, "payload = slot minus header");

typedef struct { uint32_t magic, seq, layout_len, crc; } header_t;

static flash_store_info_t s_info;

const flash_store_info_t *flash_store_info(void) { return &s_info; }

static uint32_t crc32(const uint8_t *p, size_t n, uint32_t layout)
{
    uint32_t c = ~layout;
    while (n--) {
        c ^= *p++;
        for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & (0u - (c & 1u)));
    }
    return ~c;
}

static const uint8_t *slot_ptr(unsigned i) { return (const uint8_t *)(FLASH_STORE_ADDR + i * SLOT_BYTES); }

static bool slot_blank(unsigned i)
{
    const uint32_t *w = (const uint32_t *)slot_ptr(i);
    for (unsigned k = 0; k < SLOT_BYTES / 4u; k++) if (w[k] != 0xFFFFFFFFu) return false;
    return true;
}

/* Reads one slot's header + payload into RAM; false if an ECC NMI happened while reading.      */
static bool slot_copy(unsigned i, header_t *h, uint8_t *payload)
{
    uint32_t before = g_flash_ecc_nmi;
    memcpy(h, slot_ptr(i), sizeof *h);
    memcpy(payload, slot_ptr(i) + 16, FLASH_STORE_PAYLOAD);
    __DSB();
    return g_flash_ecc_nmi == before;
}

bool flash_store_load(void *out, size_t len, uint16_t layout)
{
    static uint8_t buf[FLASH_STORE_PAYLOAD] __attribute__((aligned(4)));
    if (len > FLASH_STORE_PAYLOAD) return false;
    memset(&s_info, 0, sizeof s_info);
    uint32_t best = 0;
    for (unsigned i = 0; i < SLOTS; i++) {
        if (slot_blank(i)) continue;
        s_info.used++;
        header_t h;
        if (!slot_copy(i, &h, buf) || h.magic != MAGIC) { s_info.damaged++; continue; }
        uint16_t lay = (uint16_t)(h.layout_len >> 16), n = (uint16_t)h.layout_len;
        if (n > FLASH_STORE_PAYLOAD || crc32(buf, n, lay) != h.crc) { s_info.damaged++; continue; }
        if (lay != layout || n != len || h.seq <= best) {
            if (h.seq > s_info.seq) s_info.seq = h.seq;       /* keep sequence monotonic        */
            continue;
        }
        best = h.seq;
        s_info.seq = h.seq;
        s_info.slot = (uint8_t)i;
        memcpy(out, buf, len);
    }
    ESP_LOGI(TAG, "LOAD,found,%u,seq,%lu,used,%u,damaged,%u", best != 0, (unsigned long)best,
             s_info.used, s_info.damaged);
    return best != 0;
}

static void cache_invalidate(void)
{
    ICACHE->CR |= ICACHE_CR_CACHEINV;
    while (ICACHE->SR & ICACHE_SR_BUSYF) { }
}

static bool erase_page(void)
{
    FLASH_EraseInitTypeDef er = {
        .TypeErase = FLASH_TYPEERASE_PAGES,
        /* The running bank: physical bank 2 when SWAP_BANK is set (fwupdate.c).                */
        .Banks     = fwu_bank_swapped() ? FLASH_BANK_2 : FLASH_BANK_1,
        .Page      = PAGE_INDEX,
        .NbPages   = 1,
    };
    uint32_t bad = 0;
    HAL_FLASH_Unlock();
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS);
    bool ok = HAL_FLASHEx_Erase(&er, &bad) == HAL_OK;
    HAL_FLASH_Lock();
    cache_invalidate();
    s_info.erase_failed = !ok;
    if (ok) { s_info.used = 0; s_info.damaged = 0; }
    return ok;
}

bool flash_store_erase(void) { s_info.seq = 0; return erase_page(); }

bool flash_store_save(const void *data, size_t len, uint16_t layout)
{
    static uint32_t rec[SLOT_BYTES / 4u] __attribute__((aligned(16)));
    if (len > FLASH_STORE_PAYLOAD) return false;
    int slot = -1;
    for (unsigned i = 0; i < SLOTS && slot < 0; i++) if (slot_blank(i)) slot = (int)i;
    if (slot < 0) {
        if (!erase_page()) return false;
        slot = 0;
    }
    memset(rec, 0xFF, sizeof rec);
    memcpy((uint8_t *)rec + 16, data, len);
    header_t h = { MAGIC, s_info.seq + 1u, (uint32_t)layout << 16 | (uint32_t)len,
                   crc32((const uint8_t *)rec + 16, len, layout) };
    memcpy(rec, &h, sizeof h);

    const uint32_t base = FLASH_STORE_ADDR + (uint32_t)slot * SLOT_BYTES;
    bool ok = true;
    HAL_FLASH_Unlock();
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS);
    /* Payload first (quadwords 1..15, skipping all-0xFF ones), header last.                      */
    for (unsigned q = 1; q < SLOT_BYTES / 16u && ok; q++) {
        const uint32_t *src = &rec[q * 4u];
        if ((src[0] & src[1] & src[2] & src[3]) == 0xFFFFFFFFu) continue;
        ok = HAL_FLASH_Program(FLASH_TYPEPROGRAM_QUADWORD, base + q * 16u, (uint32_t)src) == HAL_OK;
    }
    if (ok) ok = HAL_FLASH_Program(FLASH_TYPEPROGRAM_QUADWORD, base, (uint32_t)rec) == HAL_OK;
    HAL_FLASH_Lock();
    cache_invalidate();
    ok = ok && memcmp((const void *)base, rec, SLOT_BYTES) == 0;
    s_info.write_failed = !ok;
    if (ok) { s_info.seq = h.seq; s_info.slot = (uint8_t)slot; }
    s_info.used = (uint8_t)(slot + 1);
    ESP_LOGI(TAG, "SAVE,slot,%d,seq,%lu,ok,%u", slot, (unsigned long)h.seq, ok);
    return ok;
}
