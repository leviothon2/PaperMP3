/**
 * @file    library.h
 * @brief   Music library index: all songs (A-Z), artists, albums (2.6.0).
 *
 * Built in the background from the tags of every file found by the
 * "Play all" scan, and stored on the SD card in /.eplayer/ as fixed-size
 * record files, so browsing needs only a page of rows in RAM:
 *   tracks.db   tracks sorted by artist, album, disc, track number
 *   artists.db  artists A-Z (album artist if tagged, else artist), each
 *               with its range of albums and tracks
 *   albums.db   albums in artist order, each with its track range
 *   albaz.db    album numbers in A-Z order (the "Albums" list)
 *   songaz.db   track numbers in title A-Z order (the "Music" list)
 *   paths.db    path hash -> track (titles for playlist screens)
 * The build runs a slice at a time from the main loop (playback and the
 * UI keep running) and is skipped when the scan's signature (path list)
 * matches the stored index. Limits: 4096 songs, 1024 artists, 1536 albums.
 */
#ifndef LIBRARY_H
#define LIBRARY_H

#include <stdbool.h>
#include <stdint.h>

#define LIB_NAME_MAX 56

typedef enum {
    LIB_IDLE,          /* not checked since the card was mounted          */
    LIB_SCANNING,      /* directory scan / signature check                */
    LIB_BUILDING,      /* reading tags, sorting, writing the index        */
    LIB_READY,
    LIB_FAILED,        /* no card, no music, or write error               */
} lib_state_t;

typedef struct {
    char     name[LIB_NAME_MAX];
    uint16_t first_album, n_albums;
    uint32_t first_track, n_tracks;
} lib_artist_t;

typedef struct {
    char     name[LIB_NAME_MAX];
    uint16_t artist;
    uint16_t pad;
    uint32_t first_track, n_tracks;
} lib_album_t;

typedef struct {
    char     path[256];
    char     title[LIB_NAME_MAX];
    uint16_t artist, album;
    uint16_t trackno;
    uint8_t  disc;
    uint8_t  pad;
} lib_track_t;

void        library_service(void);       /* main loop: build slices      */
void        library_request(void);       /* UI wants the library         */
void        library_rebuild(void);       /* force a full rebuild         */
void        library_close(void);         /* before unmount / sleep       */
bool        library_try_cached(void);    /* accept index on card (resume)*/
lib_state_t library_state(void);
bool        library_ready(void);
uint8_t     library_progress(void);      /* 0..100 while building        */
uint32_t    library_sig(void);           /* identifies this index        */
bool        library_truncated(void);     /* hit a limit                  */

uint32_t library_track_count(void);
uint32_t library_artist_count(void);
uint32_t library_album_count(void);

bool library_artist(uint32_t idx, lib_artist_t *out);
bool library_album(uint32_t idx, lib_album_t *out);       /* artist order */
bool library_album_az(uint32_t pos, uint32_t *album_idx);
bool library_song_az(uint32_t pos, uint32_t *track_idx);
bool library_track(uint32_t idx, lib_track_t *out);
bool library_track_path(uint32_t idx, char *path, uint32_t len);
/* Title for a file path (playlist screens); false if not in the index. */
bool library_title_for_path(const char *path, char *title, uint32_t len);

#endif /* LIBRARY_H */
