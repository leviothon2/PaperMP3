/**
 * @file    ui.h
 * @brief   E-ink UI: menus, now-playing, settings, USB prompt / USB-active,
 *          diagnostics.
 *
 * The UI polls the other modules for changes (player_seq, the settings
 * mount counter, usb_app_state) instead of being called by them, so a
 * state change it didn't cause still updates the screen.
 */
#ifndef UI_H
#define UI_H

#include <stdbool.h>
#include "../drivers/buttons.h"

void ui_splash(void);
void ui_init(bool codec_ok, bool sd_ok);
void ui_handle_button(const btn_event_t *ev);
void ui_poll(void);

/* System sleep (power.c): blank the panel to pure white with one full
 * refresh / after wake redraw the same screen with a partial refresh.    */
void ui_prepare_sleep(void);
void ui_after_wake(void);

/* Short message in the status bar for a few seconds.                     */
void ui_toast(const char *msg);

/* USB integration (usb_app.c): ask the user what a new host should get.  */
typedef enum { UI_USB_ASK, UI_USB_MSC, UI_USB_DAC, UI_USB_CHARGE } ui_usb_choice_t;
void ui_show_usb_prompt(void);
void ui_close_usb_prompt(void);
ui_usb_choice_t ui_usb_choice(void);
void ui_usb_mode_changed(void);        /* usb_app entered/left a mode     */

#endif /* UI_H */
