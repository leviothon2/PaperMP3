/**
 * @file    fwupdate.h
 * @brief   Firmware update / rollback from the SD card (2.6.0).
 *
 * The STM32U575's 1 MB flash is two 512 KB banks. The firmware always
 * runs from whichever bank is mapped at 0x08000000; the other one (seen
 * at 0x08080000) holds the previous firmware. Installing:
 *   1. /Firmware/<name>.bin is checked (size <= 512 KB, valid vector
 *      table) and written into the OTHER bank - the running firmware is
 *      never touched, so a failed or interrupted write changes nothing;
 *   2. the copy is read back and compared byte for byte (CRC-32); the
 *      first 16 bytes (stack pointer + reset vector) are written last,
 *      so a half-written bank never looks bootable;
 *   3. the SWAP_BANK option bit is flipped and the chip restarts into
 *      the new firmware.
 * Rollback: the new firmware is "on trial" until it has run for 20 s.
 * Every restart before that counts; after 3 the banks are swapped back
 * automatically (a firmware that crashes on boot undoes itself). The
 * previous firmware stays in the other bank and can also be selected by
 * hand (Settings > Firmware > Previous). The trial state lives in an RTC
 * backup register (kept through resets, lost only on a full power cut).
 * This replaces the USB DFU entry, which only restarted the player.
 */
#ifndef FWUPDATE_H
#define FWUPDATE_H

#include <stdbool.h>
#include <stdint.h>

#define FWU_MAX_FILES  6

typedef struct {
    char     name[40];          /* file name in /Firmware                 */
    char     version[20];       /* from the image, "?" if not found       */
    uint32_t size;
} fwu_file_t;

typedef enum {
    FWU_EVT_NONE,
    FWU_EVT_INSTALLED,          /* new firmware passed its trial          */
    FWU_EVT_ROLLED_BACK,        /* a new firmware failed; this is the old */
} fwu_event_t;

typedef void (*fwu_progress_cb)(int percent, const char *what);

/* Very early in main() (after SystemClock_Config): trial bookkeeping,
 * automatic rollback.                                                    */
void        fwu_boot_check(void);
/* Main loop: confirms the trial after 20 s of uptime. Returns an event
 * once (UI shows a toast).                                               */
fwu_event_t fwu_poll(void);

const char *fwu_running_version(void);
bool        fwu_bank_swapped(void);
/* Other bank: true if it holds a bootable image; version "older" if it
 * predates 2.6.0 (no ident block).                                       */
bool        fwu_previous(char *version, uint32_t len);

uint32_t    fwu_list(fwu_file_t *out, uint32_t max);
/* Never return on success (restart). On failure return false and leave
 * the running firmware untouched; *err gets a short reason.             */
bool        fwu_install(const char *name, fwu_progress_cb cb, const char **err);
bool        fwu_switch_previous(const char **err);

#endif /* FWUPDATE_H */
