/**
 * @file    settings.h
 * @brief   User settings + resume state, stored on the SD card as
 *          /settings.txt (user-transferable, editable on a computer).
 *
 * 2.7.0: the device settings (everything except the volume and the resume
 * point) are also kept in internal flash - the last 8 KB page of the
 * running bank, app/flash_store.c, from the display-test firmware. They
 * are loaded before the SD card is touched, so the SD bus settings and the
 * display drive apply from the first mount and survive a missing card.
 * When settings.txt loads, it wins.
 */
#ifndef SETTINGS_H
#define SETTINGS_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint8_t  volume;            /* 0..100                                  */
    uint8_t  contrast;          /* 2.7.0: unused (kept so old files load)  */
    uint8_t  anim_speed;        /* 0..2: how often a clean (flashing)
                                   refresh runs: often / normal / rarely   */
    bool     shuffle;
    uint8_t  repeat;            /* 0 off, 1 all, 2 one                     */
    uint8_t  usb_default;       /* 0 ask, 1 MSC, 2 DAC, 3 charge-only      */
    bool     album_art;         /* show embedded art on Now Playing        */
    bool     dark_mode;         /* inverted colours (white on black)       */
    uint8_t  sleep_timeout;     /* index into power.c table (0..5, 5=never)*/
    uint16_t charge_ma;         /* battery charge current, 32..800 mA      */
    /* resume state ("play last played e.g. playlist 2 shuffle")           */
    char     last_playlist[64]; /* playlist file name, "" = all songs      */
    uint32_t last_track_idx;
    uint32_t last_pos_ms;
    uint32_t shuffle_seed;      /* order of the resumable shuffled list    */
    bool     last_shuffle;      /* was the resume context shuffled         */
    /* 2.6.0                                                               */
    bool     gapless;           /* seamless track changes                  */
    bool     eq_on;
    uint8_t  eq_preset;         /* 0..EQ_PRESET_COUNT-1 (6 = Custom)       */
    int8_t   eq_custom[10];     /* Custom curve, dB per band               */
    uint8_t  text_size;         /* 0 small (2.5 size), 1 medium, 2 large   */
    bool     fuel_gauge;        /* coulomb-counting battery % (optional)   */
    uint16_t batt_mah;          /* capacity for the fuel gauge             */
    /* 2.6.3                                                               */
    uint8_t  menu_refresh;      /* 0 gentle (no-flash menus), 1 classic    */
    /* 2.6.4                                                               */
    bool     no_thermistor;     /* force charging without an NTC           */
    /* 2.7.0 - display                                                     */
    uint8_t  drive;             /* 0 fast (InkBoy), 1 classic (OTP)        */
    uint8_t  ink;               /* fast drive: pulses per pixel, 4..8      */
    uint8_t  halo;              /* edge clean-up radius: 0 off, 1, 2 px    */
    uint8_t  highlight;         /* list cursor style, HL_*                 */
    bool     spi_fast;          /* panel SPI 20 MHz (else 10 MHz)          */
    /* 2.7.0 - playback                                                    */
    bool     hp_detect;         /* no playback with the jack empty         */
    uint8_t  pod_speed;         /* podcast speed index (settings_speed_x100)*/
    uint8_t  repeat_before_loop;/* repeat value to return to after "loop"  */
    /* 2.7.0 - sleep timer                                                 */
    uint8_t  timer_min;         /* last chosen duration, minutes           */
    uint8_t  timer_fade_s;      /* fade-out: 0, 10, 30 or 60 s             */
    bool     timer_song_end;    /* let the current song finish first       */
    /* 2.7.0 - controls                                                    */
    uint8_t  quick_key;         /* quick menu: 0 both skip keys, 1 hold
                                   play, 2 either                          */
    bool     sw1_double;        /* play double-press = back                */
    bool     nav_on_press;      /* list keys act on press, not release     */
    uint16_t long_ms;           /* long-press time                         */
    /* 2.7.0 - SD bus (settings.txt / flash only; see drivers/sdcard.h)    */
    uint8_t  sd_clock_div;      /* 48 MHz / (2 x div): 1 = 24, 2 = 12 MHz  */
    bool     sd_4bit;
} settings_t;

/* List cursor styles (Device settings > Highlight).                       */
enum { HL_INVERT, HL_BOLD, HL_ARROW, HL_BAR, HL_FRAME, HL_COUNT };
/* Quick-menu trigger.                                                     */
enum { QK_SKIPS, QK_HOLD_PLAY, QK_EITHER, QK_COUNT };

/* Podcast speeds, x100 (index = settings.pod_speed).                      */
#define SETTINGS_SPEED_COUNT 6u
uint16_t settings_speed_x100(uint8_t idx);

/* Boot, before the SD card: defaults + the flash copy, then the parts
 * that must apply before the first mount (SD bus, key timing, display
 * drive).                                                                 */
void settings_boot(void);
/* Push the key timing / quick-menu options into the button engine.        */
void settings_apply_input(void);
/* Push drive, ink, halo and SPI speed into the panel driver.              */
void settings_apply_display(void);

/* Mount the SD volume AND treat it as a (possibly) new card: settings are
 * re-read from it and applied (charge rate, contrast, dark mode), the
 * "Play all" scan is marked stale and the mount counter moves, which the
 * UI watches to re-list playlists. Used at boot, card insert and after a
 * USB-storage session (the host may have edited the card).               */
bool settings_mount(void);
/* 2.7.0: start the card (up to three tries, each from a reset SDMMC) -
 * use instead of a bare sdcard_init().                                   */
bool settings_card_start(void);
/* One line for the status bar / About screen: why the card is or isn't
 * usable ("SD fail: IDENTIFY CTIMEOUT", "SD ok, 12 MHz 1-bit (fallback)"). */
void settings_sd_status(char *buf, unsigned n);
/* Wake from sleep with the same card: plain f_mount, nothing reloaded.  */
bool settings_remount_quiet(void);
void settings_unmount(void);            /* before SD power-off / USB MSC  */
bool settings_mounted(void);
uint32_t settings_mount_seq(void);
void settings_load(void);
void settings_apply(void);              /* push values into the drivers   */
void settings_save(void);               /* throttled, call freely         */
void settings_poll(void);               /* writes 5 s after the first
                                           unsaved change                 */
void settings_flush(void);              /* write now if anything pending  */
settings_t *settings_get(void);

/* Charge-rate choices offered in the UI (mA). 350 = 0.5C for the 700 mAh
 * Sony NP-BJ1; the higher steps are for larger replacement cells.        */
#define SETTINGS_CHARGE_OPTS   { 100, 200, 350, 500, 650, 800 }
#define SETTINGS_CHARGE_COUNT  6u

/* Push the EQ curve from the settings into the audio path.            */
void settings_apply_eq(void);
/* Current EQ gains (preset table or the Custom curve).                 */
const int8_t *settings_eq_gains(void);

#endif /* SETTINGS_H */
