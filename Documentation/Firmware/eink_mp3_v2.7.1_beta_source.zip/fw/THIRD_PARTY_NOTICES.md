# Third-party notices

## InkBoy (MIT)
These files come from InkBoy by kuslota, https://github.com/kuslota/InkBoy, through the display-test firmware's STM32U575 port:

- `drivers/ssd1681_fast/*` (except `ssd1681_port*`)
- `drivers/inkboy/fast_display.*` (dithered drive only)
- `drivers/inkboy/drive_counters.*`
- `drivers/inkboy/display_mode.h`
- `tools/check_safety.py`

Some are unchanged and some are modified; `docs/DISPLAY.md` says which. The MIT licence text is in `LICENSE-InkBoy` and must accompany copies.

InkBoy credits PaperBoy by Wenting Zhang (Zephray) for the per-pixel driving idea. No PaperBoy code is included.

## Waveshare e-Paper library (MIT-style notice)
`drivers/ssd1681_fast/ssd1681_vendor_tables.h` holds the two 159-byte arrays `WF_Full_1IN54` and `WF_PARTIAL_1IN54_0` from https://github.com/waveshareteam/e-Paper, as packaged by InkBoy. The Waveshare permission notice is reproduced in InkBoy's THIRD_PARTY_NOTICES.md, and it must accompany copies:

> Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
> associated documnetation files (the "Software"), to deal in the Software without restriction,
> including without limitation the rights to use, copy, modify, merge, publish, distribute,
> sublicense, and/or sell copies of the Software, and to permit persons to  whom the Software is
> furished to do so, subject to the following conditions: The above copyright notice and this
> permission notice shall be included in all copies or substantial portions of the Software.
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
> NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS OR A PARTICULAR PURPOSE AND
> NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
> DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
> OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## Fetched at build time (`third_party/fetch.sh`)
| Component | Version | Licence |
|---|---|---|
| STM32CubeU5 HAL + CMSIS device | v1.6.0 | BSD-3-Clause (ST); CMSIS Apache-2.0 |
| FatFs (ST mirror) | R0.15 | FatFs licence (BSD-style, ChaN) |
| dr_libs (dr_mp3, dr_flac, dr_wav) | pinned commit | public domain / MIT-0 |
| minimp4 | pinned commit | CC0 |
| picojpeg | pinned commit | public domain |
| Helix AAC (arduino-libhelix) | v0.8.6 | RPSL / RCSL - check fit before selling the product |
| libopus | v1.5.2 | BSD-3-Clause |
| TinyUSB | 0.17.0 | MIT |

## Fonts
`assets/font_ui*.c` are bitmaps rendered from DejaVu Sans Condensed (Bitstream Vera / DejaVu licence) by `tools/gen_font.py`.
