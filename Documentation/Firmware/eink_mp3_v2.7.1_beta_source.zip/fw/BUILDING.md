# Building and flashing the firmware (Windows)

There are three ways to get the `.hex`. Pick one:

| Way | You need | Good for |
|---|---|---|
| **A. Use the pre-built files** in `release\` | nothing to install except a flashing tool | trying the firmware right now |
| **B. VS Code** (recommended for development) | VS Code + STM32CubeCLT (or Arm GCC + CMake + Ninja) | editing, one-click build, flash and debug |
| **C. PowerShell script** `tools\build_windows.ps1` | the script installs what it needs | building from a terminal without VS Code |

STM32CubeProgrammer **does not compile** code. It only loads a finished `.hex`/`.bin`/`.elf` into the chip. Section D covers it.

---

## A. Pre-built files (no compiling)

`release\` holds the current build:

| File | Use |
|---|---|
| `eink_mp3_v2.7.1_beta.hex` | flash this (contains the address, safest choice) |
| `eink_mp3_v2.7.1_beta.bin` | raw image; flash at address `0x08000000` |
| `eink_mp3_v2.7.1_beta.elf` | same image with debug symbols, for a debugger |
| `SHA256SUMS.txt` | checksums |

Go straight to **D. Flashing**.

---

## B. VS Code (step by step)

### B1. Install (once)

1. **VS Code**: https://code.visualstudio.com, or `winget install Microsoft.VisualStudioCode`.
2. **Compiler + build tools.** Choose one:
   - **STM32CubeCLT** from st.com (free ST account). It is one installer with the Arm GCC compiler, CMake, Ninja, the STM32CubeProgrammer command line and the ST-LINK GDB server. Install to the default `C:\ST\STM32CubeCLT_x.y.z`.
   - Or with winget:
     `winget install Arm.GnuArmEmbeddedToolchain Kitware.CMake Ninja-build.Ninja`
3. **STM32CubeProgrammer** (GUI) from st.com. This also installs the ST-LINK USB driver and the DFU driver.
4. Optional, only for the nanoDAP or for debugging through OpenOCD: **xPack OpenOCD**. Download the `win32-x64.zip` from GitHub (xpack-dev-tools/openocd-xpack releases) and unzip it, e.g. to `C:\Tools\xpack-openocd`.
5. Open a **new** PowerShell window and check:
   ```
   cmake --version
   ninja --version
   ```
   If either says "not recognized", add its folder to PATH. With CubeCLT these are `C:\ST\STM32CubeCLT_x.y.z\CMake\bin` and `...\Ninja\bin`: Start → "Edit the system environment variables" → Environment Variables → Path → New. Then reopen VS Code.

   You do **not** need to put the compiler on PATH. `cmake\arm-none-eabi.cmake` finds it automatically in CubeCLT, CubeIDE, Arm's installer or PlatformIO. If it still can't, set an environment variable `ARM_TOOLCHAIN_DIR` to the folder that contains `arm-none-eabi-gcc.exe`.

### B2. Open the project

1. **Copy the ready-made VS Code settings into place (once).** The files live in `tools\vscode\` because they couldn't be written straight into `.vscode\`. In PowerShell, from the `firmware` folder:
   ```
   Copy-Item -Recurse -Force tools\vscode .vscode
   ```
   Running `tools\build_windows.ps1` once also does this for you if `.vscode` doesn't exist yet. Or copy the folder in Explorer and rename the copy to `.vscode`.
2. VS Code → **File → Open Folder…** → choose the `firmware` folder. Open the folder that contains `CMakeLists.txt`, not the folder above it.
3. Click **Install** on the "recommended extensions" pop-up. That installs CMake Tools, C/C++ and Cortex-Debug. If it doesn't appear, go to the Extensions panel (Ctrl+Shift+X) and search `@recommended`.
4. CMake Tools reads `CMakePresets.json` and configures with the preset **"E-ink MP3 player (STM32U575, release)"**. If asked to pick a configure preset, choose that one. The status bar at the bottom shows it.

`third_party\` is already filled in. If it is ever missing, run `bash third_party/fetch.sh` from Git Bash in the `firmware` folder.

### B3. Build

Use any of:
- **Ctrl+Shift+B** (default build task "Build firmware");
- the **Build** button in the bottom status bar;
- **F7**.

The output panel ends with the memory summary (`FLASH: ~474 KB`) and creates:

```
build\eink_mp3.hex   build\eink_mp3.bin   build\eink_mp3.elf   build\eink_mp3.map
```

The first build compiles about 200 files and takes 1–3 minutes. After that, only changed files rebuild, in seconds.

### B4. Flash from VS Code

**Terminal → Run Task…**, then pick one of the following. Each one rebuilds first.

| Task | Probe |
|---|---|
| Flash: ST-LINK (CubeProgrammer, SWD 480 kHz) | clone ST-LINK V2 or STLINK-V3 |
| Flash: USB update mode (CubeProgrammer DFU) | none: player in Settings → Firmware update (USB) |
| Flash: nanoDAP / CMSIS-DAP (OpenOCD) | nanoDAP |
| Flash: ST-LINK clone (OpenOCD) | clone ST-LINK, if CubeProgrammer refuses it |

The CubeProgrammer and OpenOCD paths live in `.vscode\settings.json` (`eink.programmerCli`, `eink.openocd`). Edit them if you installed elsewhere. For example, set `"eink.openocd": "C:/Tools/xpack-openocd/bin/openocd.exe"`, and the same path in `cortex-debug.openocdPath`.

Wiring is the same as `BRINGUP.md` §4. With the 3.3 V clone or the nanoDAP, connect **GND, SWDIO and SWCLK only**.

### B5. Debug (optional)

Open the Run and Debug panel (Ctrl+Shift+D) and choose a configuration:
- **Debug: ST-LINK (OpenOCD)** or **Debug: nanoDAP / CMSIS-DAP (OpenOCD)**: needs OpenOCD (B1 step 4).
- **Debug: STLINK-V3 (ST GDB server, needs STM32CubeCLT)**.

Press **F5**. It builds, flashes and stops at `main()`. F10 steps over and F11 steps in. Set breakpoints by clicking left of a line number.

If Cortex-Debug can't find `arm-none-eabi-gdb`, set `cortex-debug.armToolchainPath` in `.vscode\settings.json` to the compiler's `bin` folder.

The board sleeps (Stop 2) after the idle timeout, which drops the debugger. While debugging, set `sleep_timeout=5` ("never") in `settings.txt` on the SD card.

---

## C. PowerShell script (no VS Code)

From the `firmware` folder:

```
powershell -ExecutionPolicy Bypass -File tools\build_windows.ps1 -Install   # first time
powershell -ExecutionPolicy Bypass -File tools\build_windows.ps1            # afterwards
```

Output is the same `build\eink_mp3.hex`.

Or, with the tools already installed:

```
cmake --preset release
cmake --build --preset release
```

---

## D. Flashing with STM32CubeProgrammer (GUI)

### First time: over SWD with a probe

1. Power the board (battery or USB). Then connect the probe: GND, SWDIO, SWCLK. Add NRST and VDD only with an STLINK-V3.
2. Open STM32CubeProgrammer. In the right panel select **ST-LINK** and set:
   - Port **SWD**, Frequency **480 kHz**;
   - Mode **Normal**, Reset mode **Software reset**. With an STLINK-V3 you can use 4000 kHz and "Under reset" / "Hardware reset".
3. Click **Connect**. The log should show "Device STM32U575/585" and the memory view fills in.
4. Check the **OB** (Option bytes) tab, left toolbar:
   - RDP = AA;
   - TZEN off;
   - nSWBOOT0 and nBOOT0 ticked;
   - BOR level 0.

   Click **Apply** only if you changed something.
5. Open the **Erasing & programming** tab (left toolbar, second icon):
   - **File path:** Browse → `build\eink_mp3.hex` (or `release\eink_mp3_v2.7.1_beta.hex`).
   - Tick **Verify programming** and **Run after programming**.
   - Click **Start Programming**. Expect about 20–40 s with a clone probe at 480 kHz, or 3–6 s with an STLINK-V3.
6. "File download complete" plus "Verify OK" means it's done. Click **Disconnect**. The e-ink should show **"e.player"**.

### After that: over USB (no probe)

1. On the player: **Settings → Firmware update (USB)** → play. Or hold play + vol− + vol+ for 5 s.
2. In CubeProgrammer, select **USB** instead of ST-LINK in the right panel. Click the refresh icon, Port **USB1**, then **Connect**.
   - If no USB1 appears and Device Manager shows "STM32 BOOTLOADER" with a warning, run `Drivers\DFU_Driver\STM32Bootloader.bat` from the CubeProgrammer install folder.
3. Erasing & programming → `.hex` → Verify + Run after programming → **Start Programming**. This takes about 10–20 s.

Using a `.bin` instead of a `.hex`: set **Start address = 0x08000000**.

---

## Troubleshooting

| Message | Fix |
|---|---|
| `Could not find ... arm-none-eabi-gcc` | Install CubeCLT or Arm GNU Toolchain (B1), or set env var `ARM_TOOLCHAIN_DIR` to its `bin` folder, then delete the `build` folder and reconfigure. |
| `CMake was unable to find a build program corresponding to "Ninja"` | Install Ninja (`winget install Ninja-build.Ninja`) or put CubeCLT's `Ninja\bin` on PATH; restart VS Code. |
| `Third-party sources missing - run third_party/fetch.sh first` | In Git Bash: `cd` to the firmware folder, then `./third_party/fetch.sh`. |
| CubeProgrammer: `No STM32 target found` | Check wiring and common GND, lower to 100 kHz, use Mode Normal / Software reset. See `BRINGUP.md` §4. |
| CubeProgrammer: ST-LINK firmware too old | Use the OpenOCD task instead; don't firmware-update a clone. |
| Changes don't seem to take effect | Make sure you flashed `build\…`, not the older `release\…` file. |
