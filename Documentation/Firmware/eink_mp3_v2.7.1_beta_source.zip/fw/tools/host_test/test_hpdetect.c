/* Host test (2.7.1): headphone detect in drivers/cs43131.c against a model
 * of the CS43131's detect block and INT pin.
 *
 * Model (DS1155F2 4.5.1, 7.5.11/12, 7.6.1/6):
 *   - the jack pulls HP_DETECT low with a plug in (HPDETECT_INV flips it);
 *   - rising (unplug) / falling (plug) debounce from R_HP_DETECT bits 4:3 / 2:1;
 *   - enabling detect reports the current state as a plug/unplug event;
 *   - INT_STATUS1 flags are sticky, cleared on read; INT# is open drain, low
 *     while any unmasked flag is set;
 *   - the MCU pin is high only if something pulls it up: with GPIO_NOPULL (no
 *     resistor on V2) it keeps its last driven level - the 2.7.0 failure;
 *   - EXTI10 fires on a high->low change of the MCU pin.
 * HP_STATUS polarity is a guess in the driver, so every scenario also runs
 * with the model's HP_STATUS bits swapped: the driver must then fall back to
 * the event flags and still be right.                                      */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "stm32u5xx_hal.h"
#include "cs43131.h"

GPIO_TypeDef host_gpiob;

/* ---- model ---------------------------------------------------------------- */
static uint32_t now_ms;
static bool plugged;                /* physical state of the jack           */
static bool hpst_swapped;           /* model HP_STATUS with bits swapped    */
static uint8_t r_hpdet = 0x04, r_mask1 = 0xFF, r_st1, r_pdn = 0xFE, r_pll1;
static int  deb_level = -1;         /* debounced pin level, -1 = none yet   */
static int  raw_level = -1;         /* pin level seen by the debouncer      */
static uint32_t raw_since;
static bool int_pullup;             /* MCU pin configured with pull-up      */
static bool mcu_pin_high = true;    /* what HAL_GPIO_ReadPin sees           */
static bool exti_flag;              /* EXTI10 pending (set on falling)      */
static bool drop_next_edge;         /* lose one EXTI edge (missed IRQ test) */

static bool detect_on(void) { return (r_hpdet & 0xC0) == 0xC0; }
static int  pin_level(void)
{
    int lv = plugged ? 0 : 1;
    return (r_hpdet & 0x20) ? !lv : lv;
}
static uint32_t dbc_ms(uint8_t code) { static const uint32_t t[4] = { 0, 250, 500, 1000 }; return t[code & 3]; }

static void update_int(void)
{
    bool asserted = (r_st1 & (uint8_t)~r_mask1) != 0;
    bool high = asserted ? false : (int_pullup ? true : mcu_pin_high);   /* floats */
    if (mcu_pin_high && !high) {
        if (drop_next_edge) drop_next_edge = false;
        else exti_flag = true;
    }
    mcu_pin_high = high;
}

static void model_step(void)
{
    if (!detect_on()) { deb_level = -1; raw_level = -1; update_int(); return; }
    int lv = pin_level();
    if (lv != raw_level) { raw_level = lv; raw_since = now_ms; }
    uint32_t need = lv ? dbc_ms(r_hpdet >> 3) : dbc_ms(r_hpdet >> 1);
    if (lv != deb_level && now_ms - raw_since >= need) {
        deb_level = lv;
        bool plug_ev = (lv == 0);       /* low = plug (after INV) */
        r_st1 |= plug_ev ? 0x40 : 0x20;
    }
    update_int();
}

static void advance(uint32_t ms) { while (ms--) { now_ms++; model_step(); } }

uint32_t HAL_GetTick(void) { return now_ms; }
void HAL_Delay(uint32_t ms) { advance(ms ? ms : 1); }
void HAL_GPIO_Init(GPIO_TypeDef *p, GPIO_InitTypeDef *g)
{
    (void)p;
    if (g->Pin == GPIO_PIN_10) { int_pullup = (g->Pull == GPIO_PULLUP); update_int(); }
}
void HAL_GPIO_WritePin(GPIO_TypeDef *p, uint32_t pin, GPIO_PinState s) { (void)p; (void)pin; (void)s; }
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef *p, uint32_t pin)
{
    (void)p; (void)pin;
    return mcu_pin_high ? GPIO_PIN_SET : GPIO_PIN_RESET;
}

static uint8_t reg_read(uint32_t r)
{
    uint8_t v = 0;
    switch (r) {
    case 0x010000: v = 0x43; break;
    case 0x020000: v = r_pdn; break;
    case 0x030001: v = r_pll1; break;
    case 0x0D0000: v = r_hpdet; break;
    case 0x0D0001:
        if (detect_on() && deb_level >= 0) {
            bool plug = (deb_level == 0);
            if (hpst_swapped) plug = !plug;
            v = plug ? 0x40 : 0x20;
        }
        break;
    case 0x0F0000: v = r_st1; r_st1 = 0; break;
    case 0x0F0010: v = r_mask1; break;
    default: break;
    }
    update_int();
    return v;
}

static void reg_write(uint32_t r, uint8_t v)
{
    switch (r) {
    case 0x020000:
        if ((r_pdn & 0x08) && !(v & 0x08)) r_st1 |= 0x10;            /* XTAL_READY */
        if ((r_pdn & 0x04) && !(v & 0x04) && (r_pll1 & 1)) r_st1 |= 0x04; /* PLL */
        r_pdn = v; break;
    case 0x030001: r_pll1 = v; break;
    case 0x0D0000: {
        bool was = detect_on();
        r_hpdet = v;
        if (!detect_on()) r_st1 &= (uint8_t)~0x60;   /* DS: CTRL=00 clears them */
        if (!was && detect_on()) { raw_level = -1; deb_level = -1; }
        break;
    }
    case 0x0F0010: r_mask1 = v; break;
    default: break;
    }
    model_step();
}

bool i2c_write(uint8_t a, const uint8_t *d, uint16_t n)
{
    (void)a;
    if (n == 5) reg_write(((uint32_t)d[0] << 16) | ((uint32_t)d[1] << 8) | d[2], d[4]);
    return true;
}
bool i2c_write_read(uint8_t a, const uint8_t *w, uint16_t wn, uint8_t *r, uint16_t rn)
{
    (void)a; (void)wn; (void)rn;
    *r = reg_read(((uint32_t)w[0] << 16) | ((uint32_t)w[1] << 8) | w[2]);
    return true;
}

/* ---- harness ------------------------------------------------------------ */
static int fails;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("  FAIL %s:%d: ", __FILE__, __LINE__); \
                                         printf(__VA_ARGS__); printf("\n"); } } while (0)

/* What the main loop does each lap (player_power_poll + EXTI flag). */
static cs_hp_event_t lap(void)
{
    bool irq = exti_flag; exti_flag = false;
    return cs43131_hp_poll(irq);
}
/* Run the main loop for ms (1 ms laps); return the last non-NONE event. */
static cs_hp_event_t run(uint32_t ms)
{
    cs_hp_event_t last = CS_HP_EVENT_NONE;
    for (uint32_t i = 0; i < ms; i++) {
        advance(1);
        cs_hp_event_t e = lap();
        if (e != CS_HP_EVENT_NONE) last = e;
    }
    return last;
}

/* Fresh codec + driver. The driver's statics persist, so each scenario is
 * its own process (see main).                                             */
static void boot(bool with_plug)
{
    plugged = with_plug;
    CHECK(cs43131_init(), "init");
    run(50);
}

static void scenario(int n)
{
    switch (n) {
    case 1:     /* boot without, then plug / unplug / plug */
        boot(false);
        CHECK(!cs43131_headphones_present(), "boot without -> out");
        plugged = true;
        CHECK(run(700) == CS_HP_EVENT_PLUG, "plug event");
        CHECK(cs43131_headphones_present(), "plug -> in");
        plugged = false;
        CHECK(run(100) == CS_HP_EVENT_UNPLUG, "unplug event");
        CHECK(!cs43131_headphones_present(), "unplug -> out");
        plugged = true; run(700);
        CHECK(cs43131_headphones_present(), "replug -> in");
        break;
    case 2:     /* boot with, then unplug / plug / unplug */
        boot(true);
        CHECK(cs43131_headphones_present(), "boot with -> in");
        plugged = false;
        CHECK(run(100) == CS_HP_EVENT_UNPLUG, "unplug event");
        CHECK(!cs43131_headphones_present(), "unplug -> out");
        plugged = true;  run(700);
        CHECK(cs43131_headphones_present(), "plug -> in");
        plugged = false; run(100);
        CHECK(!cs43131_headphones_present(), "unplug again -> out");
        break;
    case 3:     /* missed EXTI edge: INT level still gets served */
        boot(true);
        drop_next_edge = true;
        plugged = false;
        CHECK(run(100) == CS_HP_EVENT_UNPLUG, "unplug seen without an edge");
        CHECK(mcu_pin_high, "INT released");
        plugged = true; run(700);
        CHECK(cs43131_headphones_present(), "later plug still seen");
        break;
    case 4: {   /* unplug while asleep (masked): seen on wake */
        boot(true);
        cs_hp_event_t e = cs43131_sleep();
        CHECK(e == CS_HP_EVENT_NONE, "sleep entry: no event (%d)", e);
        plugged = false; advance(200);
        CHECK(!exti_flag, "masked unplug must not raise INT while asleep");
        cs43131_wake();
        CHECK(run(10) == CS_HP_EVENT_UNPLUG, "unplug reported after wake");
        CHECK(!cs43131_headphones_present(), "out after wake");
        break;
    }
    case 5: {   /* plug while asleep wakes; out-and-in while asleep also wakes */
        boot(false);
        (void)cs43131_sleep();
        plugged = true; advance(700);
        CHECK(exti_flag, "plug raises INT while asleep");
        exti_flag = false;
        CHECK(cs43131_service_irq_event() == CS_HP_EVENT_PLUG, "sleep loop sees PLUG");
        cs43131_wake(); run(10);
        CHECK(cs43131_headphones_present(), "in after wake");
        (void)cs43131_sleep();
        plugged = false; advance(50); plugged = true; advance(700);
        exti_flag = false;
        CHECK(cs43131_service_irq_event() == CS_HP_EVENT_PLUG, "out+in while asleep wakes");
        cs43131_wake(); run(10);
        CHECK(cs43131_headphones_present(), "still in");
        break;
    }
    case 6: {   /* the 2.7.0 failure, for reference: no pull-up -> stuck */
        boot(false);
        int_pullup = false; mcu_pin_high = false;    /* line left floating low */
        exti_flag = false;
        plugged = true;
        /* 2.7.1 serves INT by level too, so even then it is not stuck.  */
        run(700);
        CHECK(cs43131_headphones_present(), "level service rescues a floating-low INT");
        break;
    }
    }
}

int main(int argc, char **argv)
{
    if (argc == 3) {                    /* child: one scenario, one variant */
        hpst_swapped = argv[2][0] == '1';
        scenario(argv[1][0] - '0');
        return fails ? 1 : 0;
    }
    int bad = 0;
    for (int s = 1; s <= 6; s++)
        for (int v = 0; v <= 1; v++) {
            char cmd[512];
            snprintf(cmd, sizeof cmd, "%s %d %d", argv[0], s, v);
            int rc = system(cmd);
            printf("%s hpdetect scenario %d%s\n", rc ? "FAIL" : "PASS", s,
                   v ? " (HP_STATUS polarity swapped)" : "");
            bad |= rc;
        }
    return bad ? 1 : 0;
}
