/* host-test stand-in: eink.c needs nothing from the pin map */
#pragma once
