/* host-test stand-in for the STM32 HAL: just the tick */
#pragma once
#include <stdint.h>
uint32_t HAL_GetTick(void);
