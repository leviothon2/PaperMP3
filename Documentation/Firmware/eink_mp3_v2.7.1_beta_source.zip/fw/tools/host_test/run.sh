#!/usr/bin/env bash
# Host tests (native gcc, no board):
#   1. the player's panel front-end (drivers/eink.c) + InkBoy driver fork against a fake SSD1681
#      (host_port.c) that records the command stream and models the RAM planes, gate direction and
#      each pixel's last drive - see test_eink.c for what is checked;
#   2. the podcast time-stretcher (audio/timestretch.c): speed ratio and no discontinuities.
#   3. playlist removal, the /Podcasts list and listening positions with the real FatFs on a RAM
#      disk (test_storage.c).
# V=1 prints the driver's log lines.
set -euo pipefail
cd "$(dirname "$0")"
R=../..
gcc -std=gnu11 -O1 -g -Wall -Wextra -Wno-unused-parameter \
    -Istub -I$R/Core/esp_compat -I$R/Core/Inc -I$R/drivers -I$R/drivers/ssd1681_fast -I$R/drivers/inkboy -I$R/assets \
    test_eink.c host_port.c $R/drivers/eink.c $R/drivers/gfx.c $R/assets/font_ui18b.c \
    $R/drivers/ssd1681_fast/ssd1681_fast.c $R/drivers/inkboy/fast_display.c $R/drivers/inkboy/drive_counters.c \
    -o host_test_eink
./host_test_eink
gcc -std=gnu11 -O2 -Wall -Wextra -I$R/audio test_timestretch.c $R/audio/timestretch.c -lm -o host_test_ts
./host_test_ts
# 3. card-side code with the real FatFs on a RAM disk: playlist removal, /Podcasts list, positions.
#    FatFs is copied next to a host ffconf.h (the firmware's, plus f_mkfs and no RTC).
mkdir -p ff_host
cp $R/third_party/fatfs/ff.c $R/third_party/fatfs/ff.h $R/third_party/fatfs/ffunicode.c $R/third_party/fatfs/diskio.h ff_host/
sed -e 's/^#define FF_USE_MKFS[[:space:]].*/#define FF_USE_MKFS\t\t1/' \
    -e 's/^#define FF_FS_NORTC[[:space:]].*/#define FF_FS_NORTC\t\t1/' $R/third_party/fatfs/ffconf.h > ff_host/ffconf.h
gcc -std=gnu11 -O1 -g -Wall -Wextra -Wno-unused-parameter \
    -Istub -Iff_host -I$R/Core/Inc -I$R/app -I$R/audio \
    test_storage.c $R/app/playlist.c $R/app/podcast.c ff_host/ff.c ff_host/ffunicode.c \
    -o host_test_storage
./host_test_storage
# 4. headphone detect (2.7.1): drivers/cs43131.c against a model of the codec's detect block and
#    the INT line - plug/unplug both ways from either boot state, a missed EXTI edge, unplug and
#    plug during system sleep; each also with HP_STATUS polarity swapped.
gcc -std=gnu11 -O1 -g -Wall -Wextra -Wno-unused-parameter -include stdlib.h \
    -Istub_codec -I$R/drivers test_hpdetect.c $R/drivers/cs43131.c -o host_test_hpdetect
./host_test_hpdetect
