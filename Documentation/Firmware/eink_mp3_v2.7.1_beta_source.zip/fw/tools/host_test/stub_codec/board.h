/* host-test stand-in: the codec pins from Core/Inc/board.h */
#pragma once
#define CODEC_RST_PORT          GPIOB
#define CODEC_RST_PIN           GPIO_PIN_0
#define CODEC_INT_PORT          GPIOB
#define CODEC_INT_PIN           GPIO_PIN_10
#define CODEC_INT_EXTI_IRQn     EXTI10_IRQn
#ifndef BOARD_HPDETECT_INVERT
#define BOARD_HPDETECT_INVERT   0
#endif
