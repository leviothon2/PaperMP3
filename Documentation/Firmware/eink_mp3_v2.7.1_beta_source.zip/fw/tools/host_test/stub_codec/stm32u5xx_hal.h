/* host-test stand-in for the STM32 HAL: what drivers/cs43131.c touches */
#pragma once
#include <stdint.h>
#include <stddef.h>
typedef struct { uint32_t Pin, Mode, Pull, Speed, Alternate; } GPIO_InitTypeDef;
typedef struct { int dummy; } GPIO_TypeDef;
typedef enum { GPIO_PIN_RESET = 0, GPIO_PIN_SET } GPIO_PinState;
extern GPIO_TypeDef host_gpiob;
#define GPIOB                 (&host_gpiob)
#define GPIO_PIN_0            0x0001u
#define GPIO_PIN_10           0x0400u
#define GPIO_MODE_OUTPUT_PP   1u
#define GPIO_MODE_IT_FALLING  2u
#define GPIO_NOPULL           0u
#define GPIO_PULLUP           1u
#define EXTI10_IRQn           10
#define __HAL_RCC_GPIOB_CLK_ENABLE() do {} while (0)
uint32_t HAL_GetTick(void);
void HAL_Delay(uint32_t ms);
void HAL_GPIO_Init(GPIO_TypeDef *p, GPIO_InitTypeDef *g);
void HAL_GPIO_WritePin(GPIO_TypeDef *p, uint32_t pin, GPIO_PinState s);
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef *p, uint32_t pin);
static inline void HAL_NVIC_SetPriority(int irq, uint32_t a, uint32_t b) { (void)irq; (void)a; (void)b; }
static inline void HAL_NVIC_EnableIRQ(int irq) { (void)irq; }
