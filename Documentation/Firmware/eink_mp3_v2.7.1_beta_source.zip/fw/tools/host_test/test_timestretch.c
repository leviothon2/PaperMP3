#include "timestretch.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* voiced-speech-like test signal: harmonic source with slowly varying pitch + amplitude */
static double ph;
static void gen(int32_t *b, int n, int rate, long t0) {
    for (int i = 0; i < n; i++) {
        double t = (double)(t0 + i) / rate;
        double f0 = 120 + 30 * sin(2 * M_PI * 0.7 * t);
        ph += 2 * M_PI * f0 / rate;
        double v = 0;
        for (int h = 1; h <= 8; h++) v += sin(h * ph) / h;
        v *= 0.25 * (0.6 + 0.4 * sin(2 * M_PI * 3 * t));
        b[2*i] = b[2*i+1] = (int32_t)(v * 2147483000.0 * 0.5);
    }
}
int main(void) {
    int fails = 0;
    static const int rates[] = { 22050, 44100, 48000 };
    static const int speeds[] = { 80, 120, 150, 175, 200 };
    for (unsigned r = 0; r < 3; r++) for (unsigned s = 0; s < 5; s++) {
        int rate = rates[r], sp = speeds[s];
        if (!ts_begin(rate, sp)) { printf("FAIL begin\n"); return 1; }
        long in_total = 0, out_total = 0; ph = 0;
        static int32_t in[512*2], out[512*2];
        double maxjump = 0, prev = 0, peak = 0; int first = 1;
        while (in_total < rate * 20L) {
            uint32_t room = ts_room(); if (room > 512) room = 512;
            if (room) { gen(in, room, rate, in_total); ts_push(in, room); in_total += room; }
            uint32_t m;
            while ((m = ts_pull(out, 512)) > 0) {
                for (uint32_t i = 0; i < m; i++) {
                    double v = out[2*i] / 2147483648.0;
                    if (!first) { double j = fabs(v - prev); if (j > maxjump) maxjump = j; }
                    if (fabs(v) > peak) peak = fabs(v);
                    prev = v; first = 0;
                }
                out_total += m;
            }
        }
        double ratio = (double)in_total / out_total;
        /* the source's own steepest step (8 harmonics, <=150 Hz) is ~0.06 of full scale at 22 kHz */
        int ok = fabs(ratio - sp / 100.0) < 0.02 * sp / 100.0 && maxjump < 0.12 && peak < 0.6;
        printf("rate %5d speed %3d%%: in/out %.3f  max step %.4f  peak %.3f  %s\n", rate, sp, ratio, maxjump, peak, ok ? "ok" : "FAIL");
        fails += !ok;
        ts_end();
    }
    printf(fails ? "TS TEST FAILED\n" : "TS TEST PASSED\n");
    return fails;
}
