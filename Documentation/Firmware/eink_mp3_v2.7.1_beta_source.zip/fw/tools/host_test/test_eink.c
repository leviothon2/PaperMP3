/* Host test for the player's panel front-end (drivers/eink.c) on top of the InkBoy driver fork,
 * against the fake SSD1681 in host_port.c. The real gfx.c draws the frames.
 *
 * Checks, after every settled refresh, that each pixel's last drive matches the framebuffer:
 *   boot screen (OTP), first fast session, cursor-style updates, a target that changes mid-burst,
 *   the USB guard (fast -> classic -> fast), system sleep / wake, the classic drive with panel idle
 *   sleep, session renewal at the driver's activation limit, a panel fault and its recovery,
 *   and that the OTP-programming command 0x30 is never sent. */
#include "eink.h"
#include "gfx.h"
#include "diag.h"
#include "ssd1681_fast.h"
#include "drive_counters.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern uint8_t host_cmds[]; extern unsigned host_ncmds, host_activations, host_hook_calls;
extern int8_t host_drive[]; extern int host_verbose, host_fail_spi, host_busy_missing;
extern int64_t host_now;
volatile uint32_t g_diag_step;
static int fails;
#define CHECK(c, ...) do { if (!(c)) { printf("FAIL: " __VA_ARGS__); printf("\n"); fails++; } } while (0)

static int mismatches(void)
{
    const uint8_t *fb = eink_framebuffer();
    int bad = 0;
    for (int i = 0; i < 40000; ++i) {
        int black = !(fb[i / 8] & (0x80 >> (i % 8)));
        if (host_drive[i] != (black ? 1 : -1)) bad++;
    }
    return bad;
}

static void screen(int n)
{
    char t[32];
    gfx_clear(GFX_WHITE);
    snprintf(t, sizeof t, "Screen %d", n);
    gfx_text(&font_ui18b, 10, 10 + (n * 13) % 150, t, GFX_BLACK);
    gfx_fill_rect((n * 37) % 150, (n * 53) % 150, 40, 30, n & 1 ? GFX_BLACK : GFX_DARK);
    gfx_invert_rect(0, 20 + (n % 6) * 30, 196, 30);
}

static void settle(void)
{
    unsigned guard = 0;
    while (eink_service() && guard++ < 100) host_now += 1000;
    CHECK(!eink_settling(), "burst never settled");
}

static unsigned hook_n;
static void hook(void) { hook_n++; }

int main(void)
{
    host_verbose = getenv("V") != NULL;
    eink_set_idle_hook(hook);
    eink_init();
    CHECK(!eink_failed(), "init");

    /* boot screen: factory waveform */
    screen(0);
    unsigned c0 = host_ncmds;
    eink_boot_screen();
    CHECK(mismatches() == 0, "boot screen: %d", mismatches());
    int lut = 0; for (unsigned i = c0; i < host_ncmds; i++) lut += host_cmds[i] == 0x32;
    CHECK(lut == 0, "boot screen loaded a register LUT");
    CHECK(hook_n > 0, "idle hook not called during a refresh");

    /* first menu: shown at once with an OTP partial, fast session starts from the main loop */
    screen(1);
    eink_refresh_partial();
    CHECK(mismatches() == 0, "first partial: %d", mismatches());
    CHECK(eink_settling(), "session start not pending");
    settle();
    CHECK(eink_stats()->sessions == 1, "sessions %u", (unsigned)eink_stats()->sessions);
    CHECK(mismatches() == 0, "after session start: %d", mismatches());

    /* cursor steps: each a burst */
    for (int n = 2; n < 12; n++) {
        screen(n);
        unsigned a0 = host_activations;
        eink_refresh_partial();
        /* one scan; the first after a session start also powers the boosters (0xC0) */
        CHECK(host_activations - a0 <= (n == 2 ? 2u : 1u), "partial must return after one scan");
        settle();
        CHECK(mismatches() == 0, "step %d: %d", n, mismatches());
        CHECK(host_activations - a0 <= 11, "step %d took %u scans", n, host_activations - a0);
    }
    /* target replaced mid-burst (key pressed between scans) */
    screen(20); eink_refresh_partial(); eink_service(); eink_service();
    screen(21); eink_refresh_partial(); eink_service();
    screen(22); eink_refresh_partial();
    settle();
    CHECK(mismatches() == 0, "retarget: %d", mismatches());

    /* edge clean-up still settles exactly */
    eink_set_halo(2);
    screen(23); eink_refresh_partial(); settle();
    CHECK(mismatches() == 0, "halo: %d", mismatches());
    eink_set_halo(0);

    /* lighter ink */
    eink_set_ink(5);
    screen(24); unsigned a1 = host_activations; eink_refresh_partial(); settle();
    CHECK(mismatches() == 0, "ink 5: %d", mismatches());
    CHECK(host_activations - a1 <= 7, "ink 5 took %u scans", host_activations - a1);
    eink_set_ink(8);

    /* USB guard: mid-burst switch to the factory waveforms and back */
    screen(30); eink_refresh_partial(); eink_service();
    eink_force_classic(true);
    CHECK(!eink_fast_active(), "guard");
    screen(31);
    c0 = host_ncmds;
    eink_refresh_partial_clean();
    CHECK(mismatches() == 0, "classic under guard: %d", mismatches());
    screen(32); eink_refresh_partial();
    CHECK(mismatches() == 0, "classic partial: %d", mismatches());
    screen(33); eink_refresh_full();
    CHECK(mismatches() == 0, "classic full: %d", mismatches());
    lut = 0; for (unsigned i = c0; i < host_ncmds; i++) lut += host_cmds[i] == 0x32;
    CHECK(lut == 0, "register LUT loaded while the USB guard was on");
    eink_force_classic(false);
    screen(34); eink_refresh_partial();
    CHECK(mismatches() == 0, "back to fast, first frame: %d", mismatches());
    settle();
    CHECK(mismatches() == 0, "back to fast: %d", mismatches());
    CHECK(eink_stats()->sessions == 2, "sessions after guard %u", (unsigned)eink_stats()->sessions);

    /* system sleep: white, off; wake: screen back without waiting for the clean refresh */
    gfx_clear(GFX_WHITE); eink_refresh_full();
    CHECK(mismatches() == 0, "white: %d", mismatches());
    eink_power_off();
    CHECK(eink_is_asleep(), "not asleep");
    host_now += 3600LL * 1000000;
    eink_power_on();
    screen(40); eink_refresh_partial();
    CHECK(mismatches() == 0, "wake partial: %d", mismatches());
    settle();
    CHECK(mismatches() == 0, "wake session: %d", mismatches());

    /* session renewal: far more scans than the driver allows per power-on */
    unsigned s0 = eink_stats()->sessions;
    for (int n = 0; n < 700 && !eink_failed(); n++) {
        screen(100 + n);
        if (eink_clean_due()) eink_refresh_full(); else eink_refresh_partial();
        settle();
        if (mismatches()) { CHECK(0, "long run step %d: %d", n, mismatches()); break; }
        CHECK(eink_stats()->scans < SSD1681_MAX_UPDATES, "activation limit reached");
    }
    CHECK(!eink_failed(), "long run faulted");
    CHECK(eink_stats()->sessions > s0 + 1, "session never renewed (%u)", (unsigned)eink_stats()->sessions);
    /* ... and without the UI's help (eink_clean_due ignored) */
    for (int n = 0; n < 700 && !eink_failed(); n++) {
        screen(900 + n); eink_refresh_partial(); settle();
        if (mismatches()) { CHECK(0, "unassisted step %d: %d", n, mismatches()); break; }
    }
    CHECK(!eink_failed(), "unassisted long run faulted");

    /* classic drive as the setting, with the panel's idle deep sleep */
    eink_set_drive(EINK_DRIVE_CLASSIC);
    screen(50); eink_refresh_full();
    CHECK(mismatches() == 0, "classic: %d", mismatches());
    for (int n = 51; n < 60; n++) {
        screen(n); eink_refresh_partial();
        CHECK(mismatches() == 0, "classic step %d: %d", n, mismatches());
        host_now += 2000000; eink_service();
        if (n % 3 == 0) { eink_sleep(); CHECK(eink_is_asleep(), "classic idle sleep"); }
    }
    for (int n = 0; n < 2600 && !eink_failed(); n++) {      /* past the activation limit */
        screen(n); eink_refresh_partial();
        if (mismatches()) { CHECK(0, "classic long run %d: %d", n, mismatches()); break; }
    }
    CHECK(!eink_failed(), "classic long run faulted");
    eink_set_drive(EINK_DRIVE_FAST);
    screen(60); eink_refresh_partial(); settle();
    CHECK(mismatches() == 0, "fast again: %d", mismatches());

    /* panel fault: BUSY never answers -> closed, retried from a reset, recovered */
    host_busy_missing = 1;
    screen(70); eink_refresh_partial();
    CHECK(eink_failed(), "fault not latched");
    unsigned f0 = eink_stats()->faults;
    eink_service();
    CHECK(eink_failed(), "retried too early");
    host_now += 3100000; eink_service();                     /* try 1: still dead */
    host_now += 3100000; eink_service();                     /* try 2: still dead */
    CHECK(eink_failed() && eink_wants_rail_cycle(), "rail cycle not requested after two tries");
    CHECK(eink_stats()->faults > f0, "faults not counted");
    host_busy_missing = 0;
    eink_power_off(); eink_power_on(); eink_rail_cycled();   /* what power_panel_service() does */
    CHECK(!eink_wants_rail_cycle(), "second rail cycle requested for the same fault");
    eink_service();
    CHECK(!eink_failed(), "not recovered after the rail cycle");
    CHECK(mismatches() == 0, "recovered image: %d", mismatches());
    settle();
    screen(71); eink_refresh_partial(); settle();
    CHECK(mismatches() == 0, "after recovery: %d", mismatches());

    /* SPI error path */
    host_fail_spi = 1;
    screen(72); eink_refresh_partial();
    CHECK(eink_failed(), "SPI fault not latched");
    host_fail_spi = 0;
    host_now += 3100000; eink_service();
    CHECK(!eink_failed(), "not recovered from the SPI fault");
    settle();
    CHECK(mismatches() == 0, "after SPI recovery: %d", mismatches());

    for (unsigned i = 0; i < host_ncmds && i < 200000; ++i) CHECK(host_cmds[i] != 0x30, "OTP program command sent");
    printf("activations %u, sessions %u, faults %u, hook calls %u\n", host_activations,
           (unsigned)eink_stats()->sessions, (unsigned)eink_stats()->faults, hook_n);
    printf(fails ? "EINK HOST TEST FAILED (%d)\n" : "EINK HOST TEST PASSED\n", fails);
    return fails != 0;
}
