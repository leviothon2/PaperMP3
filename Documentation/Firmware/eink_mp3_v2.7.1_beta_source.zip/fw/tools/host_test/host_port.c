/* Host test double for the STM32 port: a fake SSD1681 that records the command stream and models
 * RAM planes + "last drive direction" per pixel, with a virtual microsecond clock.
 * (display-test firmware tools/host_test/host_port.c; player 2.7.0 adds the fault switches, the
 * busy hook and the HAL tick.) */
#include "ssd1681_port.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

int64_t host_now;
int host_fail_spi, host_busy_missing;   /* fault injection */
unsigned host_hook_calls;
static void (*busy_hook)(void);
void ssd1681_port_set_busy_hook(void (*hook)(void)) { busy_hook = hook; }
uint32_t HAL_GetTick(void) { return (uint32_t)(host_now / 1000); }
int64_t esp_timer_get_time(void) { return host_now; }
void port_timer_init(void) {}
void port_delay_ms(uint32_t ms) { host_now += (int64_t)ms * 1000; }
void port_set_idle_hook(void (*h)(void)) { (void)h; }
const char *esp_err_to_name(esp_err_t c) { static char b[16]; snprintf(b, 16, "%d", c); return b; }
size_t heap_caps_get_free_size(unsigned c) { (void)c; return 1u << 20; }
size_t heap_caps_get_largest_free_block(unsigned c) { (void)c; return 1u << 20; }
int host_verbose;
void port_log(esp_log_level_t l, const char *tag, const char *fmt, ...)
{
    if (!host_verbose && l > ESP_LOG_WARN) return;
    va_list ap; va_start(ap, fmt); printf("[%s] ", tag); vprintf(fmt, ap); printf("\n"); va_end(ap);
}
unsigned port_log_lines(const char **l, unsigned m) { (void)l; (void)m; return 0; }

/* ---- fake panel ---- */
uint8_t host_cmds[200000]; unsigned host_ncmds;
unsigned host_lut_writes, host_lut_len, host_activations;
uint8_t host_ram_bw[5000], host_ram_red[5000];
int8_t host_drive[40000];            /* last drive: +1 black, -1 white, 0 never */
static uint8_t cur_cmd; static unsigned data_n; static int win_x0, win_x1, win_y0, win_y1, ax, ay;
static int entry = 3, tb; static uint8_t ctrl; static bool busy_pending, powered;
static uint8_t args[16];

esp_err_t ssd1681_port_init(void) { return ESP_OK; }
esp_err_t ssd1681_port_power(bool on) { powered = on; return ESP_OK; }
void ssd1681_port_rst(int level) { (void)level; }
int ssd1681_port_busy(void) { return 0; }
void ssd1681_port_busy_arm(void) {}
void ssd1681_port_allow_fast(bool a) { (void)a; }
bool ssd1681_port_fast_allowed(void) { return true; }
unsigned ssd1681_port_active_hz(void) { return 20000000; }

static void ram_byte(uint8_t v)
{
    uint8_t *ram = cur_cmd == 0x24 ? host_ram_bw : host_ram_red;
    if (ax >= 0 && ax < 25 && ay >= 0 && ay < 200) ram[ay * 25 + ax] = v;
    /* entry 0x03: X+, then Y+ ; entry 0x01: X+, then Y- */
    ax++;
    if (ax > win_x1) { ax = win_x0; ay += (entry & 2) ? 1 : -1; }
}

/* Glass pixel i reads RAM row (tb ? 199 - row : row). */
static int ram_index(int i) { int y = i / 200, x = i % 200; return (tb ? 199 - y : y) * 200 + x; }

static void activate(void)
{
    host_activations++;
    int64_t dur = 14000;
    if (ctrl == 0x0c) {                  /* mixed scan: R/BW pair per pixel */
        for (int i = 0; i < 40000; ++i) {
            int j = ram_index(i), byte = j / 8, bit = 0x80 >> (j % 8);
            int r = !!(host_ram_red[byte] & bit), bw = !!(host_ram_bw[byte] & bit);
            if (r && !bw) host_drive[i] = 1;
            else if (!r && bw) host_drive[i] = -1;
            else if (r && bw) host_drive[i] = 2;   /* special row */
        }
    } else if (ctrl == 0xc7 || ctrl == 0xf7 || ctrl == 0xfc) {
        dur = ctrl == 0xfc ? 300000 : 2000000;
        for (int i = 0; i < 40000; ++i) {
            int j = ram_index(i), byte = j / 8, bit = 0x80 >> (j % 8);
            host_drive[i] = (host_ram_bw[byte] & bit) ? -1 : 1;
        }
    }
    host_now += dur;
    busy_pending = true;
}

esp_err_t ssd1681_port_write(bool data, const uint8_t *bytes, size_t n, unsigned hz)
{
    (void)hz;
    if (!powered) return ESP_ERR_INVALID_STATE;
    if (host_fail_spi) return ESP_FAIL;
    host_now += (int64_t)n * 8 / 20;     /* 20 MHz */
    if (!data) {
        cur_cmd = bytes[0]; data_n = 0;
        if (host_ncmds < sizeof host_cmds) host_cmds[host_ncmds++] = cur_cmd;
        if (cur_cmd == 0x20) activate();
        if (cur_cmd == 0x24 || cur_cmd == 0x26) { ax = win_x0; ay = (entry & 2) ? win_y0 : win_y1; }
        return ESP_OK;
    }
    for (size_t i = 0; i < n; ++i, ++data_n) {
        uint8_t v = bytes[i];
        if (cur_cmd == 0x24 || cur_cmd == 0x26) { ram_byte(v); continue; }
        if (data_n < sizeof args) args[data_n] = v;
        if (cur_cmd == 0x32) host_lut_len = data_n + 1;
        if (cur_cmd == 0x11 && data_n == 0) entry = v;
        if (cur_cmd == 0x01 && data_n == 2) tb = v & 1;   /* gate scan reversed */
        if (cur_cmd == 0x22 && data_n == 0) ctrl = v;
        if (cur_cmd == 0x44 && data_n == 1) { win_x0 = args[0]; win_x1 = args[1]; }
        if (cur_cmd == 0x45 && data_n == 3) {
            int a = args[0] | (args[1] << 8), b = args[2] | (args[3] << 8);
            win_y0 = a < b ? a : b; win_y1 = a < b ? b : a;
        }
    }
    if (cur_cmd == 0x32) host_lut_writes++;
    return ESP_OK;
}

bool ssd1681_port_busy_wait(uint32_t t, int64_t *rise, int64_t *fall)
{
    if (host_busy_missing) { host_now += (int64_t)t * 1000; busy_pending = false; return false; }
    if (!busy_pending) return false;
    if (busy_hook) { busy_hook(); host_hook_calls++; }
    busy_pending = false;
    *rise = host_now - 14000; *fall = host_now;
    return true;
}
