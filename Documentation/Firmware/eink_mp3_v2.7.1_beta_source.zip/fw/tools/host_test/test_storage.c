/* Host test for the card-side code of 2.7.0 with the real FatFs on a RAM disk:
 *   - playlist_remove(): the entry disappears from the /Playlists file, comments and the other
 *     lines stay byte for byte, the play order (shuffled or not) of the remaining songs is kept;
 *   - the /Podcasts list: sorted by name, sub-folders, non-audio files ignored, opened as "@pod";
 *   - podcasts are not picked up by the music scan when the card has no /Music folder;
 *   - listening positions: started / finished, written to the card and read back. */
#include "playlist.h"
#include "podcast.h"
#include "library.h"
#include "settings.h"
#include "decoder.h"
#include "diag.h"
#include "ff.h"
#include "diskio.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

static int fails;
#define CHECK(c, ...) do { if (!(c)) { printf("FAIL: " __VA_ARGS__); printf("\n"); fails++; } } while (0)

/* ---- RAM disk ---- */
#define SECTORS 32768u                       /* 16 MB */
static uint8_t *disk;
DSTATUS disk_initialize(BYTE d) { (void)d; return 0; }
DSTATUS disk_status(BYTE d) { (void)d; return 0; }
DRESULT disk_read(BYTE d, BYTE *b, LBA_t s, UINT n) { (void)d; memcpy(b, disk + s * 512u, n * 512u); return RES_OK; }
DRESULT disk_write(BYTE d, const BYTE *b, LBA_t s, UINT n) { (void)d; memcpy(disk + s * 512u, b, n * 512u); return RES_OK; }
DRESULT disk_ioctl(BYTE d, BYTE c, void *b)
{
    (void)d;
    if (c == GET_SECTOR_COUNT) *(LBA_t *)b = SECTORS;
    if (c == GET_SECTOR_SIZE) *(WORD *)b = 512;
    if (c == GET_BLOCK_SIZE) *(DWORD *)b = 1;
    return RES_OK;
}

/* ---- firmware stubs ---- */
volatile uint32_t g_diag_step;
static uint32_t tick = 1000, mount_seq = 1;
uint32_t HAL_GetTick(void) { return tick; }
bool settings_mounted(void) { return true; }
uint32_t settings_mount_seq(void) { return mount_seq; }
dec_format_t dec_format_from_path(const char *p)
{
    const char *d = strrchr(p, '.');
    if (!d) return DEC_FMT_UNKNOWN;
    return !strcasecmp(d, ".mp3") ? DEC_FMT_MP3 : !strcasecmp(d, ".flac") ? DEC_FMT_FLAC :
           !strcasecmp(d, ".m4a") ? DEC_FMT_M4A : DEC_FMT_UNKNOWN;
}
bool library_try_cached(void) { return false; }
uint32_t library_sig(void) { return 0; }
uint32_t library_track_count(void) { return 0; }
bool library_song_az(uint32_t p, uint32_t *t) { (void)p; (void)t; return false; }
bool library_track_path(uint32_t i, char *p, uint32_t l) { (void)i; (void)p; (void)l; return false; }

/* ---- helpers ---- */
static void put(const char *path, const char *text)
{
    FIL f; UINT bw;
    if (f_open(&f, path, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) { CHECK(0, "create %s", path); return; }
    f_write(&f, text, (UINT)strlen(text), &bw);
    f_close(&f);
}
static char *slurp(const char *path)
{
    static char buf[4096];
    FIL f; UINT br = 0;
    buf[0] = 0;
    if (f_open(&f, path, FA_READ) != FR_OK) return buf;
    f_read(&f, buf, sizeof buf - 1, &br);
    buf[br] = 0;
    f_close(&f);
    return buf;
}
static void order(char out[][64], uint32_t *n)
{
    char p[PL_PATH_MAX];
    *n = playlist_count();
    for (uint32_t i = 0; i < *n; i++) { playlist_track(i, p, sizeof p); snprintf(out[i], 64, "%.63s", p); }
}

#define LIST "0:/Playlists/Mix.m3u"
static const char k_list[] =
    "#EXTM3U\r\n"
    "Music/a.mp3\r\n"
    "# a comment that must survive\n"
    "Music/b.flac\n"
    "\n"
    "0:/Music/sub/c.mp3\r\n"
    "Music/d.mp3\n"
    "Music/e.mp3\n"
    "Music/f.mp3";                       /* no newline at the end */

static void test_remove(bool shuffle, uint32_t seed)
{
    put(LIST, k_list);
    CHECK(playlist_open("Mix.m3u"), "open");
    playlist_set_shuffle(shuffle, seed);
    CHECK(playlist_is_file(), "is_file");
    char before[8][64], after[8][64]; uint32_t nb, na;
    order(before, &nb);
    CHECK(nb == 6, "count %u", (unsigned)nb);

    for (uint32_t round = 0; nb > 0; round++) {
        uint32_t pos = round == 0 ? 2 : round == 1 ? nb - 1 : 0;   /* middle, last, then first */
        char gone[64]; snprintf(gone, sizeof gone, "%s", before[pos]);
        CHECK(playlist_remove(pos), "remove pos %u of %u", (unsigned)pos, (unsigned)nb);
        order(after, &na);
        CHECK(na == nb - 1, "count after remove %u (was %u)", (unsigned)na, (unsigned)nb);
        for (uint32_t i = 0, j = 0; i < nb; i++) {
            if (i == pos) continue;
            CHECK(!strcmp(before[i], after[j]), "order changed at %u: %s vs %s", (unsigned)j, before[i], after[j]);
            j++;
        }
        const char *file = slurp(LIST);
        const char *name = strrchr(gone, '/') + 1;
        CHECK(!strstr(file, name), "%s still in the file", name);
        CHECK(strstr(file, "#EXTM3U\r\n") == file, "first line damaged");
        CHECK(strstr(file, "# a comment that must survive\n"), "comment lost");
        FILINFO fi;
        CHECK(f_stat("0:/Playlists/~list.tmp", &fi) != FR_OK, "temp file left behind");
        memcpy(before, after, sizeof before); nb = na;
    }
    CHECK(!playlist_remove(0), "remove from an empty list must fail");
}

int main(void)
{
    disk = calloc(SECTORS, 512);
    static FATFS fs; static BYTE work[4096];
    MKFS_PARM fmt = { FM_ANY, 0, 0, 0, 0 };
    CHECK(f_mkfs("0:", &fmt, work, sizeof work) == FR_OK, "mkfs");
    CHECK(f_mount(&fs, "0:", 1) == FR_OK, "mount");
    f_mkdir("0:/Playlists");

    /* ---- playlist removal ---- */
    test_remove(false, 0);
    test_remove(true, 0xC0FFEE42u);
    test_remove(true, 12345u);
    /* not a playlist file: refused */
    f_mkdir("0:/Podcasts"); f_mkdir("0:/Podcasts/Show B"); f_mkdir("0:/Songs");
    put("0:/Podcasts/zeta 03.mp3", "x"); put("0:/Podcasts/alpha 01.mp3", "x");
    put("0:/Podcasts/Show B/ep 2.m4a", "x"); put("0:/Podcasts/Show B/ep 10.m4a", "x");
    put("0:/Podcasts/cover.jpg", "x"); put("0:/Podcasts/.hidden.mp3", "x");
    put("0:/Podcasts/Beta 02.MP3", "x");
    put("0:/Songs/one.mp3", "x"); put("0:/Songs/two.flac", "x"); put("0:/top.mp3", "x");

    /* ---- podcast list ---- */
    CHECK(podcast_refresh() == 5, "podcast count %u", (unsigned)podcast_refresh());
    static const char *want[] = { "0:/Podcasts/alpha 01.mp3", "0:/Podcasts/Beta 02.MP3",
        "0:/Podcasts/Show B/ep 10.m4a", "0:/Podcasts/Show B/ep 2.m4a", "0:/Podcasts/zeta 03.mp3" };
    char p[PL_PATH_MAX], nm[64];
    for (uint32_t i = 0; i < 5; i++) {
        CHECK(podcast_entry(i, p, sizeof p) && !strcmp(p, want[i]), "podcast %u = %s", (unsigned)i, p);
    }
    podcast_name(want[2], nm, sizeof nm);
    CHECK(!strcmp(nm, "ep 10"), "name '%s'", nm);
    CHECK(podcast_path_is("0:/podcasts/x.mp3") && !podcast_path_is("0:/Music/x.mp3"), "path test");
    CHECK(playlist_open(POD_LIST_SPEC) && playlist_count() == 5, "@pod list");
    CHECK(playlist_is_podcasts() && !playlist_is_file(), "@pod flags");
    CHECK(!playlist_remove(0), "episodes cannot be removed");
    CHECK(playlist_track(4, p, sizeof p) && !strcmp(p, want[4]), "@pod entry: %s", p);

    /* ---- music scan on a card without /Music leaves the podcasts out ---- */
    CHECK(playlist_open("") && playlist_count() == 3, "music scan found %u files (want 3)", (unsigned)playlist_count());
    for (uint32_t i = 0; i < playlist_count(); i++) {
        playlist_track(i, p, sizeof p);
        CHECK(!podcast_path_is(p), "episode in the music list: %s", p);
    }
    CHECK(!playlist_is_file(), "scan is not a playlist file");

    /* ---- listening positions ---- */
    pod_progress_t pg;
    podcast_progress(want[0], &pg);
    CHECK(pg.state == POD_NEW, "new episode");
    podcast_note(want[0], 3000, 1800000, false);
    podcast_progress(want[0], &pg);
    CHECK(pg.state == POD_NEW && pg.len_ms == 1800000, "3 s in is still 'new'");
    podcast_note(want[0], 600000, 1800000, false);
    podcast_note(want[1], 1795000, 1800000, false);        /* within 15 s of the end */
    podcast_note(want[2], 0, 2400000, true);
    tick += 30000; podcast_poll();                         /* deferred write */
    podcast_card_changed();                                /* forget RAM: read the card again */
    mount_seq++;
    CHECK(podcast_refresh() == 5, "list after remount");
    podcast_progress(want[0], &pg);
    CHECK(pg.state == POD_STARTED && pg.pos_ms == 600000 && pg.len_ms == 1800000, "started, saved: %d %u", pg.state, (unsigned)pg.pos_ms);
    podcast_progress(want[1], &pg);
    CHECK(pg.state == POD_DONE, "ending counts as finished");
    podcast_progress(want[2], &pg);
    CHECK(pg.state == POD_DONE && pg.len_ms == 2400000, "finished");
    podcast_progress(want[3], &pg);
    CHECK(pg.state == POD_NEW, "untouched");
    podcast_note(want[2], 120000, 2400000, false);         /* listening again un-finishes it */
    podcast_progress(want[2], &pg);
    CHECK(pg.state == POD_STARTED, "replay");

    printf(fails ? "STORAGE HOST TEST FAILED (%d)\n" : "STORAGE HOST TEST PASSED\n", fails);
    return fails != 0;
}
