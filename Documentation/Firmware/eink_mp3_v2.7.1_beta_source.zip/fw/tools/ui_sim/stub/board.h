/* ui_sim stand-in for the pin map: the constants ui.c uses */
#pragma once
#define BATT_CHARGE_MA_DEFAULT     350u
#define BATT_CHARGE_MA_NO_NTC_MAX  350u
