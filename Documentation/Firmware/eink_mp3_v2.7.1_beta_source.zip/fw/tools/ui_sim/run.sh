#!/usr/bin/env bash
# UI simulator: builds the firmware's real ui.c / gfx.c / fonts / eq.c with mocks (sim.c), runs a
# scripted walk through every screen, checks the navigation rules and writes the screens to
# out/*.png (2x) plus out/contact_sheet.png. Needs gcc and python3 with Pillow.
set -euo pipefail
cd "$(dirname "$0")"
R=../..
mkdir -p out && rm -f out/*.raw out/*.png
gcc -std=gnu11 -O1 -g -Wall -Wextra -Wno-unused-parameter -Wno-misleading-indentation \
    -DFW_VERSION='"2.7.0"' -DFW_CHANNEL='"beta"' \
    -Istub -I$R -I$R/Core/Inc -I$R/drivers -I$R/app -I$R/audio -I$R/assets \
    -I$R/third_party/fatfs \
    sim.c $R/app/ui.c $R/drivers/gfx.c $R/assets/font_ui*.c $R/audio/eq.c -lm -o ui_sim
status=0
./ui_sim || status=$?
python3 - <<'PY'
import glob, os
from PIL import Image, ImageDraw
files = sorted(glob.glob('out/*.raw'))
imgs = []
for p in files:
    im = Image.frombytes('L', (200, 200), open(p, 'rb').read())
    im.resize((400, 400), Image.NEAREST).save(p[:-4] + '.png')
    imgs.append((os.path.basename(p)[:-4], im))
    os.remove(p)
cols = 6
rows = (len(imgs) + cols - 1) // cols
sheet = Image.new('L', (cols * 212 + 12, rows * 228 + 12), 150)
d = ImageDraw.Draw(sheet)
for i, (name, im) in enumerate(imgs):
    x, y = 12 + (i % cols) * 212, 12 + (i // cols) * 228
    sheet.paste(im, (x, y))
    d.text((x, y + 202), name[:34], fill=0)
sheet.save('out/contact_sheet.png')
print(len(imgs), 'screens ->', 'out/contact_sheet.png')
PY
exit $status
