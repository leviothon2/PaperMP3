/* UI simulator: the firmware's real app/ui.c, drivers/gfx.c, fonts and audio/eq.c on the PC, with
 * the player, library, storage, USB and panel replaced by small mocks. A script of key presses
 * walks the screens and each one is written as a 200x200 8-bit raw image (run.sh turns them into
 * PNGs and a contact sheet). It also checks behaviour: wrap-around, section rows are skipped, the
 * quick menu's triggers, the sleep-timer indicator, the remove confirmation and the queue jump. */
#include "app/ui.h"
#include "app/player.h"
#include "app/playlist.h"
#include "app/library.h"
#include "app/podcast.h"
#include "app/settings.h"
#include "app/usb_app.h"
#include "app/power.h"
#include "app/fuelgauge.h"
#include "app/fwupdate.h"
#include "Core/Inc/diag.h"
#include "drivers/eink.h"
#include "drivers/gfx.h"
#include "drivers/npm1300.h"
#include "drivers/cs43131.h"
#include "audio/audio_pipeline.h"
#include "audio/eq.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int fails;
#define CHECK(c, ...) do { if (!(c)) { printf("FAIL: " __VA_ARGS__); printf("\n"); fails++; } } while (0)

/* ---- time ---- */
static uint32_t now_ms = 100000;
uint32_t HAL_GetTick(void) { return now_ms; }
volatile uint32_t g_diag_step;

/* ---- panel mock ---- */
static uint8_t fb[5000];
static unsigned n_full, n_partial;
static bool drive_fast = true, force_classic;
uint8_t *eink_framebuffer(void) { return fb; }
void eink_refresh_full(void) { n_full++; }
void eink_refresh_full_fast(void) { n_full++; }
void eink_boot_screen(void) { n_full++; }
void eink_refresh_partial(void) { n_partial++; }
void eink_refresh_partial_clean(void) { n_partial++; }
void eink_refresh_partial_area(int x, int y, int w, int h) { (void)x; (void)y; (void)w; (void)h; n_partial++; }
bool eink_service(void) { return false; }
bool eink_settling(void) { return false; }
void eink_settle(void) {}
void eink_sleep(void) {}
bool eink_is_asleep(void) { return false; }
void eink_power_off(void) {}
void eink_power_on(void) {}
void eink_set_drive(eink_drive_t d) { drive_fast = d == EINK_DRIVE_FAST; }
eink_drive_t eink_drive(void) { return drive_fast ? EINK_DRIVE_FAST : EINK_DRIVE_CLASSIC; }
bool eink_fast_active(void) { return drive_fast && !force_classic; }
void eink_force_classic(bool on) { force_classic = on; }
void eink_set_ink(uint8_t p) { (void)p; }
void eink_set_halo(uint8_t r) { (void)r; }
void eink_set_spi_fast(bool on) { (void)on; }
bool eink_clean_due(void) { return false; }
bool eink_failed(void) { return false; }
void eink_safe_classic(bool on) { (void)on; }
bool eink_safe_classic_on(void) { return false; }
const eink_stats_t *eink_stats(void) { static eink_stats_t s = { 412, 388, 21, 1840, 0, 3 }; return &s; }

/* ---- settings mock ---- */
static settings_t cfg = { .volume = 40, .anim_speed = 1, .album_art = true, .sleep_timeout = 2,
    .charge_ma = 350, .gapless = true, .batt_mah = 700, .ink = 8, .spi_fast = true, .hp_detect = true,
    .pod_speed = 1, .timer_min = 20, .timer_fade_s = 30, .sw1_double = true, .long_ms = 700,
    .sd_clock_div = 2, .sd_4bit = true };
settings_t *settings_get(void) { return &cfg; }
void settings_save(void) {}
void settings_flush(void) {}
bool settings_mounted(void) { return true; }
uint32_t settings_mount_seq(void) { return 1; }
void settings_apply_eq(void) { eq_configure(cfg.eq_preset != 0, settings_eq_gains()); }
const int8_t *settings_eq_gains(void) { const int8_t *g = eq_preset_gains(cfg.eq_preset); return g ? g : cfg.eq_custom; }
void settings_apply_input(void) {}
void settings_apply_display(void) { drive_fast = cfg.drive == 0; }
void settings_sd_status(char *b, unsigned n) { snprintf(b, n, "SD ok, 12 MHz 4-bit"); }
uint16_t settings_speed_x100(uint8_t i) { static const uint16_t k[] = { 80, 100, 120, 150, 175, 200 }; return k[i < 6 ? i : 1]; }

/* ---- library / playlists / podcasts mock ---- */
static const char *k_artists[] = { "Bonobo", "Caribou", "Four Tet", "Khruangbin", "Nils Frahm", "Tycho", "Yussef Dayes" };
static const char *k_albums[] = { "Awake", "Black Sands", "Dive", "Migration", "Mordechai", "New Energy", "Our Love", "Spaces" };
static const char *k_songs[] = { "A Walk", "Adrift", "Awake", "Break Apart", "Cirrus", "Daydream", "Dive", "Kerala",
    "Kong", "L", "Montana", "Outlier", "Says", "See", "Spectre", "Time Moves Slow (feat. Sam Herring)", "Two Thousand and Seventeen" };
#define N(a) (sizeof(a) / sizeof(a[0]))
void library_request(void) {}
void library_rebuild(void) {}
lib_state_t library_state(void) { return LIB_READY; }
bool library_ready(void) { return true; }
uint8_t library_progress(void) { return 42; }
uint32_t library_sig(void) { return 0x1234; }
uint32_t library_track_count(void) { return N(k_songs); }
uint32_t library_artist_count(void) { return N(k_artists); }
uint32_t library_album_count(void) { return N(k_albums); }
bool library_artist(uint32_t i, lib_artist_t *o) { if (i >= N(k_artists)) return false; memset(o, 0, sizeof *o); snprintf(o->name, sizeof o->name, "%s", k_artists[i]); o->n_albums = 2; o->first_album = i % 6; o->n_tracks = 9; return true; }
bool library_album(uint32_t i, lib_album_t *o) { if (i >= N(k_albums)) return false; memset(o, 0, sizeof *o); snprintf(o->name, sizeof o->name, "%s", k_albums[i]); o->n_tracks = 8; o->first_track = i; return true; }
bool library_album_az(uint32_t p, uint32_t *a) { *a = p; return p < N(k_albums); }
bool library_song_az(uint32_t p, uint32_t *t) { *t = p; return p < N(k_songs); }
bool library_track(uint32_t i, lib_track_t *o) { memset(o, 0, sizeof *o); snprintf(o->title, sizeof o->title, "%s", k_songs[i % N(k_songs)]); o->trackno = (uint16_t)(i % 8 + 1); return true; }
bool library_title_for_path(const char *p, char *t, uint32_t l) { (void)p; (void)t; (void)l; return false; }

static const char *k_lists[] = { "Evening", "Focus", "Gym", "Road trip" };
uint32_t playlist_enumerate(playlist_desc_t *o, uint32_t max) { uint32_t n = 0; for (; n < N(k_lists) && n < max; n++) { snprintf(o[n].name, PL_NAME_MAX, "%s", k_lists[n]); snprintf(o[n].file, PL_NAME_MAX, "%s.m3u", k_lists[n]); } return n; }
bool playlist_scan_needed(void) { return false; }
uint32_t playlist_browse_open(const char *f) { (void)f; return 9; }
void playlist_browse_close(void) {}
uint32_t playlist_browse_count(void) { return 9; }
bool playlist_browse_entry(uint32_t n, char *p, uint32_t l) { snprintf(p, l, "0:/Music/%s.flac", k_songs[(n * 3) % N(k_songs)]); return true; }

static const char *k_pods[] = { "99pi 512 - The Lost Subways", "Cautionary Tales - The Dunning-Kruger Hijack",
    "Darknet Diaries 141", "Hardcore History 70", "In Our Time - The Kalevala", "Radiolab - Colors", "Reply All 158" };
static uint32_t n_pods = N(k_pods);
uint32_t podcast_refresh(void) { return n_pods; }
bool podcast_entry(uint32_t n, char *p, uint32_t l) { if (n >= n_pods) return false; snprintf(p, l, "0:/Podcasts/%s.mp3", k_pods[n]); return true; }
void podcast_name(const char *path, char *buf, uint32_t len) { const char *b = strrchr(path, '/'); snprintf(buf, len, "%s", b ? b + 1 : path); char *d = strrchr(buf, '.'); if (d) *d = 0; }
void podcast_progress(const char *path, pod_progress_t *o)
{
    *o = (pod_progress_t){ POD_NEW, 0, 0 };
    if (strstr(path, "99pi"))       *o = (pod_progress_t){ POD_DONE, 0, 2400000 };
    if (strstr(path, "Cautionary")) *o = (pod_progress_t){ POD_STARTED, 700000, 2260000 };
    if (strstr(path, "Hardcore"))   *o = (pod_progress_t){ POD_STARTED, 3600000, 14500000 };
    if (strstr(path, "Radiolab"))   *o = (pod_progress_t){ POD_DONE, 0, 1800000 };
}

/* ---- player mock ---- */
static player_state_t p_state = PLAYER_STOPPED;
static track_tags_t p_tags;
static uint8_t p_art[ART_SIZE * ART_SIZE];
static bool p_has_art = true, p_shuf, p_pod, p_file_list;
static uint32_t p_seq, p_tseq, p_pos, p_len = 247000, p_track, p_count = 12;
static player_err_t p_err;
static uint8_t p_timer;
static char p_list[64];
static bool hp_in = true;
static unsigned n_removed, n_jump;

static void make_art(uint32_t seed)
{
    for (int y = 0; y < ART_SIZE; y++) for (int x = 0; x < ART_SIZE; x++) {
        double dx = x - 60 - 20 * sin(seed), dy = y - 60, r = sqrt(dx * dx + dy * dy);
        double v = 128 + 100 * sin(r / (5.0 + seed % 4)) * cos((x + y * (1 + seed % 3)) / 23.0);
        if (r < 22) v = 235; if (y > 96) v = 40 + (x * 150) / 120;
        p_art[y * ART_SIZE + x] = (uint8_t)(v < 0 ? 0 : v > 255 ? 255 : v);
    }
}
static void load(uint32_t pos)
{
    p_track = pos;
    memset(&p_tags, 0, sizeof p_tags);
    if (p_pod) { char path[256]; podcast_entry(pos, path, sizeof path); podcast_name(path, p_tags.title, sizeof p_tags.title); p_len = 2260000; p_has_art = false; }
    else { snprintf(p_tags.title, sizeof p_tags.title, "%s", k_songs[(pos * 5 + 4) % N(k_songs)]); snprintf(p_tags.artist, sizeof p_tags.artist, "%s", k_artists[pos % N(k_artists)]);
           snprintf(p_tags.album, sizeof p_tags.album, "%s", k_albums[pos % N(k_albums)]); p_len = 200000 + pos * 17000; p_has_art = true; make_art(pos); }
    p_pos = 0; p_tseq++; p_seq++;
    p_state = hp_in || !cfg.hp_detect ? PLAYER_PLAYING : PLAYER_PAUSED;
    if (p_state == PLAYER_PAUSED) p_err = PLAYER_ERR_NO_HEADPHONES;
}
bool player_play(const char *list, uint32_t pos, bool shuffle)
{
    snprintf(p_list, sizeof p_list, "%s", list);
    p_pod = !strcmp(list, POD_LIST_SPEC); p_shuf = shuffle;
    p_file_list = list[0] && list[0] != '@';
    p_count = p_pod ? n_pods : 12;
    load(pos); return true;
}
bool player_resume_last(void) { return player_play("Focus.m3u", 3, false); }
void player_toggle_pause(void)
{
    if (p_state == PLAYER_PLAYING) p_state = PLAYER_PAUSED;
    else if (p_state == PLAYER_PAUSED) { if (!player_output_allowed()) { p_err = PLAYER_ERR_NO_HEADPHONES; p_seq++; return; } p_state = PLAYER_PLAYING; }
    p_seq++;
}
void player_next(void) { if (p_track + 1 < p_count) load(p_track + 1); }
void player_prev(void) { if (p_track) load(p_track - 1); }
void player_stop(void) { p_state = PLAYER_STOPPED; p_seq++; }
void player_volume_delta(int8_t d) { int v = cfg.volume + d; cfg.volume = (uint8_t)(v < 0 ? 0 : v > 100 ? 100 : v); }
player_state_t player_state(void) { return p_state; }
const track_tags_t *player_tags(void) { return &p_tags; }
const uint8_t *player_art(void) { return p_has_art ? p_art : NULL; }
uint32_t player_pos_ms(void) { return p_pos; }
uint32_t player_len_ms(void) { return p_len; }
const char *player_playlist_file(void) { return p_list; }
bool player_shuffled(void) { return p_shuf; }
uint32_t player_seq(void) { return p_seq; }
uint32_t player_track_seq(void) { return p_tseq; }
player_err_t player_take_error(void) { player_err_t e = p_err; p_err = PLAYER_ERR_NONE; return e; }
bool player_output_allowed(void) { return !cfg.hp_detect || hp_in; }
uint32_t player_queue_count(void) { return p_state == PLAYER_STOPPED ? 0 : p_count - p_track - 1; }
bool player_queue_title(uint32_t n, char *b, uint32_t l)
{
    uint32_t pos = p_track + 1 + n;
    if (p_pod) { char path[256]; if (!podcast_entry(pos, path, sizeof path)) return false; podcast_name(path, b, l); return true; }
    snprintf(b, l, "%s", k_songs[(pos * 5 + 4) % N(k_songs)]); return true;
}
bool player_jump(uint32_t n) { n_jump++; load(p_track + 1 + n); return true; }
void player_set_loop(bool on) { cfg.repeat = on ? 2 : 0; p_seq++; }
bool player_loop(void) { return cfg.repeat == 2; }
bool player_can_remove(void) { return p_state != PLAYER_STOPPED && p_file_list; }
bool player_remove_current(void) { n_removed++; p_count--; load(p_track); return true; }
bool player_is_podcast(void) { return p_pod && p_state != PLAYER_STOPPED; }
void player_speed_changed(void) { p_seq++; }
void player_timer_set(uint8_t m) { p_timer = m; if (m) cfg.timer_min = m; p_seq++; }
uint8_t player_timer_minutes(void) { return p_timer; }

/* ---- the rest ---- */
static usb_state_t usb = USB_OFF;
usb_state_t usb_app_state(void) { return usb; }
bool usb_app_busy(void) { return usb == USB_MSC || usb == USB_DAC; }
bool usb_app_storage_owned(void) { return usb == USB_MSC; }
const char *power_timeout_label(uint8_t i) { static const char *k[] = { "2 min", "5 min", "10 min", "30 min", "1 hour", "never" }; return k[i < 6 ? i : 2]; }
void fuelgauge_enable(bool on, uint16_t mah) { (void)on; (void)mah; }
int fuelgauge_percent(void) { return cfg.fuel_gauge ? 72 : -1; }
fwu_event_t fwu_poll(void) { return FWU_EVT_NONE; }
const char *fwu_running_version(void) { return FW_VERSION; }
bool fwu_previous(char *v, uint32_t l) { snprintf(v, l, "2.6.7"); return true; }
uint32_t fwu_list(fwu_file_t *o, uint32_t max) { (void)max; snprintf(o[0].name, sizeof o[0].name, "eink_mp3_v2.7.1_beta.bin"); snprintf(o[0].version, sizeof o[0].version, "2.7.1"); snprintf(o[1].name, sizeof o[1].name, "display_test_v0.2.1.bin"); snprintf(o[1].version, sizeof o[1].version, "dt-0.2.1"); return 2; }
bool fwu_install(const char *n, fwu_progress_cb cb, const char **e) { (void)n; (void)cb; *e = "sim"; return false; }
bool fwu_switch_previous(const char **e) { *e = "sim"; return false; }
void diag_note_reset(diag_reset_t k) { (void)k; }
void diag_summary(char *b, int l) { snprintf(b, l, "power on"); }
bool npm1300_set_charge_current(uint16_t ma) { (void)ma; return true; }
bool npm1300_set_no_ntc(bool n) { (void)n; return true; }
const char *npm1300_charger_state(void) { return "no USB"; }
bool npm1300_charging(void) { return false; }
bool npm1300_battery_present(void) { return true; }
uint8_t npm1300_battery_percent(void) { return 72; }
bool npm1300_vbat_mv(uint16_t *mv) { *mv = 3920; return true; }
bool npm1300_die_temp_c(int16_t *d) { *d = 27; return true; }
bool cs43131_headphones_present(void) { return hp_in; }
uint32_t pipe_out_rate(void) { return 48000; }
bool pipe_bit_perfect(void) { return true; }
static bool press_mode = true;
void buttons_press_mode(bool a) { press_mode = a; }

/* ---- scripting ---- */
static void poll(void) { now_ms += 20; ui_poll(); }
static void key(btn_id_t id, btn_event_type_t t) { btn_event_t e = { id, t, now_ms }; ui_handle_button(&e); poll(); }
#define SEL()   key(BTN_SW1, BTN_EV_SHORT)
#define BACK()  key(BTN_SW1, BTN_EV_DOUBLE)
#define DOWN()  key(BTN_SW2, BTN_EV_SHORT)
#define UP()    key(BTN_SW3, BTN_EV_SHORT)
#define HOLDP() key(BTN_SW1, BTN_EV_LONG)
#define CHORD() key(BTN_SW2, BTN_EV_CHORD)
static void downs(int n) { while (n--) DOWN(); }

static int shot_n;
static void shot_now(const char *name)
{
    char path[160];
    snprintf(path, sizeof path, "out/%02d_%s.raw", ++shot_n, name);
    FILE *f = fopen(path, "wb");
    for (int i = 0; i < 40000; i++) fputc((fb[i / 8] & (0x80 >> (i % 8))) ? 255 : 0, f);
    fclose(f);
}
static void shot(const char *name) { poll(); shot_now(name); }
/* Row the cursor is on = the row whose pixels differ most from a plain row is hard to read back;
 * the checks below use behaviour (what SELECT does) instead. */
static bool title_is(const char *want)
{
    /* the status-bar title is drawn from screen_title(); compare via a fresh render of the text */
    static uint8_t a[5000]; memcpy(a, fb, 5000);
    gfx_fill_rect(0, 0, 100, 19, GFX_WHITE); gfx_text(&font_ui11, 4, 3, want, GFX_BLACK);
    bool same = !memcmp(a, fb, 25 * 19 / 2);   /* left half of the bar, top rows */
    memcpy(fb, a, 5000);
    return same;
}

int main(void)
{
    gfx_set_invert(false);
    ui_splash();                               shot_now("splash");
    ui_init(true, true);
    poll();                                    shot("main_menu");
    CHECK(title_is("e.player"), "main title");

    /* wrap-around: up from the first row lands on Device settings, down from it on the first */
    UP();                                      shot("main_menu_wrapped_to_bottom");
    SEL();   CHECK(title_is("Device settings"), "wrap up -> last row");
    BACK();  DOWN(); SEL();                    /* wraps to "Last played" -> resumes */
    CHECK(p_state == PLAYER_PLAYING && title_is(p_tags.artist), "wrap down -> first row (Last played)");
    BACK();
    /* a held key stops at the end instead of wrapping */
    for (int i = 0; i < 20; i++) key(BTN_SW2, BTN_EV_REPEAT);
    SEL();   CHECK(title_is("Device settings"), "held key must stop on the last row");
    BACK();  player_stop(); poll();

    /* highlight styles on the main menu */
    static const char *hl[] = { "invert", "bold", "arrow", "bar", "frame" };
    for (int h = 0; h < HL_COUNT; h++) {
        cfg.highlight = (uint8_t)h;
        for (int i = 0; i < 20; i++) key(BTN_SW3, BTN_EV_REPEAT);   /* top */
        downs(2);
        char n[40]; snprintf(n, sizeof n, "highlight_%s", hl[h]); shot(n);
    }
    cfg.highlight = HL_BOLD; cfg.text_size = 2; UP(); shot("highlight_bold_large_text");
    cfg.highlight = HL_ARROW; cfg.text_size = 1; DOWN(); shot("highlight_arrow_medium_text");
    cfg.text_size = 0; cfg.highlight = HL_INVERT;
    cfg.dark_mode = true; gfx_set_invert(true); DOWN(); UP(); shot("main_menu_dark");
    cfg.dark_mode = false; gfx_set_invert(false);

    /* playlists */
    for (int i = 0; i < 20; i++) key(BTN_SW3, BTN_EV_REPEAT);
    DOWN(); SEL();                             shot("playlists");
    CHECK(title_is("Playlists"), "Playlists is the second row");
    DOWN(); SEL();                             shot("playlist_focus");
    downs(3); SEL();                           shot("now_playing");
    CHECK(p_state == PLAYER_PLAYING && !strcmp(p_list, "Focus.m3u") && p_track == 1, "play from playlist");
    CHECK(!press_mode, "Now Playing must decide on release (skip chord)");

    /* quick menu by the skip-key chord; hold-play does nothing in this mode */
    HOLDP(); CHECK(title_is(p_tags.artist), "hold play must not open the quick menu (skip-keys mode)");
    CHORD();                                   shot("quick_menu");
    CHECK(title_is(p_tags.title), "chord opens the quick menu");
    CHECK(p_state == PLAYER_PLAYING, "music keeps playing under the quick menu");
    /* sleep timer -> duration list -> back on the song with the mark in the bar */
    SEL();                                     shot("sleep_timer_pick");
    CHECK(title_is("Sleep timer"), "timer list");
    SEL();   CHECK(p_timer == 20, "timer preset 20 min, got %u", p_timer);
    now_ms += 5000; poll();                    shot("now_playing_timer_set");
    CHECK(title_is(p_tags.artist), "back on the song after choosing a time");
    /* loop */
    CHORD(); downs(1); SEL();                  /* Remove from playlist: confirm screen */
    shot("remove_confirm");
    CHECK(title_is("Remove song"), "remove asks first");
    SEL();   CHECK(n_removed == 0 && title_is(p_tags.title), "short press must cancel the removal");
    SEL(); HOLDP();                            /* cursor is back on Remove */
    CHECK(n_removed == 1, "hold play removes");
    now_ms += 5000; poll();
    CHECK(title_is(p_tags.artist), "after removal: the next song");
    CHORD(); downs(2); SEL();                  shot("quick_menu_loop_on");
    CHECK(cfg.repeat == 2, "loop song");
    BACK();                                    shot("now_playing_loop_timer_shuffle");
    /* the queue: scroll past the fixed rows, pick the third upcoming song */
    CHORD(); downs(3);                         /* over the UP NEXT header onto the first song */
    shot("quick_menu_queue");
    downs(2);
    uint32_t before = p_track; unsigned qn = player_queue_count();
    SEL();
    CHECK(n_jump == 1 && p_track == before + 3, "queue jump: track %u -> %u", (unsigned)before, (unsigned)p_track);
    CHECK(title_is(p_tags.artist), "queue pick leaves the quick menu for the new song");
    CHORD(); CHECK(player_queue_count() == qn - 3, "queue restarts after the picked song");
    shot("quick_menu_after_jump");
    /* song ends by itself while the menu is open: the menu stays, the queue shortens */
    player_next(); poll();
    CHECK(title_is(p_tags.title), "menu stays open over a track change");
    BACK(); BACK();                            shot("back_in_playlist");

    /* hold-play as the trigger */
    cfg.quick_key = QK_HOLD_PLAY;
    key(BTN_SW2, BTN_EV_SHORT); SEL();         /* some song */
    CHORD(); CHECK(title_is(p_tags.artist), "chord must not open the menu in hold-play mode");
    HOLDP(); CHECK(title_is(p_tags.title), "hold play opens the quick menu");
    BACK(); cfg.quick_key = QK_SKIPS;
    player_timer_set(0); cfg.repeat = 0;

    /* headphone gate */
    hp_in = false;
    SEL(); now_ms += 100; poll();              /* pause */
    SEL();                                     shot("now_playing_no_headphones");
    CHECK(p_state == PLAYER_PAUSED, "play with the jack empty must stay paused");
    hp_in = true; SEL(); CHECK(p_state == PLAYER_PLAYING, "plays once headphones are in");
    now_ms += 5000; poll();
    BACK(); BACK(); BACK();

    /* library */
    for (int i = 0; i < 20; i++) key(BTN_SW3, BTN_EV_REPEAT);
    downs(3); SEL();                           shot("music");
    BACK(); DOWN(); SEL();                     shot("albums");
    SEL();                                     shot("album");
    BACK(); BACK(); DOWN(); SEL();             shot("artists");
    BACK();

    /* podcasts */
    DOWN(); SEL();                             shot("podcasts");
    CHECK(title_is("Podcasts"), "Podcasts row");
    DOWN(); SEL();                             shot("now_playing_podcast");
    CHECK(p_pod && p_track == 1, "episode chosen directly (no Shuffle/Play rows)");
    CHORD();                                   shot("quick_menu_podcast");
    SEL(); CHECK(cfg.pod_speed == 2, "speed row is first for podcasts");
    SEL(); SEL();                              shot("quick_menu_podcast_speed");
    BACK(); shot("now_playing_podcast_speed");
    BACK(); BACK(); player_stop(); poll();

    /* device settings: every page */
    for (int i = 0; i < 20; i++) key(BTN_SW2, BTN_EV_REPEAT);
    SEL();                                     shot("device_settings_1");
    /* cursor starts on the first item, not on the DISPLAY header */
    SEL(); CHECK(cfg.highlight == HL_BOLD, "first selectable row is Highlight"); cfg.highlight = HL_INVERT;
    int page = 1; char nm[40];
    for (int i = 0; i < 27; i++) {             /* 28 items: ends on About */
        DOWN();
        if (i == 5 || i == 9 || i == 13 || i == 17 || i == 22) { snprintf(nm, sizeof nm, "device_settings_%d", ++page); shot(nm); }
    }
    shot("device_settings_last");
    SEL();                                     shot("about");
    BACK(); DOWN();                            /* wraps to Highlight */
    SEL(); CHECK(cfg.highlight == HL_BOLD, "settings wrap skips the header row"); cfg.highlight = HL_INVERT;
    downs(4); SEL(); /* Display drive -> classic */
    CHECK(cfg.drive == 1, "display drive toggles (got %u)", cfg.drive);
    shot("device_settings_classic_drive");
    SEL(); CHECK(cfg.drive == 0, "cursor stays on Display drive");
    downs(2); SEL();                           shot("ink_strength");
    BACK(); BACK();

    /* usb */
    usb = USB_PROMPT; ui_show_usb_prompt();    shot("usb_prompt");
    CHECK(force_classic, "USB prompt must switch the panel to the factory waveforms");
    usb = USB_DAC; ui_usb_mode_changed();      shot("usb_dac");
    usb = USB_OFF; ui_usb_mode_changed(); poll();
    CHECK(!force_classic, "fast drive back after USB");

    printf("%d screens, %u full + %u partial refreshes\n", shot_n, n_full, n_partial);
    printf(fails ? "UI SIM FAILED (%d)\n" : "UI SIM PASSED\n", fails);
    return fails != 0;
}
