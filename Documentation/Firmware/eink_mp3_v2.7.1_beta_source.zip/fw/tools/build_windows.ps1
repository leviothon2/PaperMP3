<#
.SYNOPSIS
  Build the e-ink MP3 player firmware on Windows.

.DESCRIPTION
  1. Finds (or with -Install, installs via winget) the Arm GNU toolchain,
     CMake, Ninja and Git. Already-present copies are reused, including the
     ones bundled with PlatformIO, STM32CubeCLT and STM32CubeIDE.
  2. Runs third_party/fetch.sh through Git Bash if the dependencies are
     missing.
  3. Configures and builds build/eink_mp3.elf/.bin/.hex.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File tools\build_windows.ps1 -Install
  powershell -ExecutionPolicy Bypass -File tools\build_windows.ps1
#>
param([switch]$Install, [switch]$Clean)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

function Find-Tool([string]$exe, [string[]]$globs) {
    $c = Get-Command $exe -ErrorAction SilentlyContinue
    if ($c) { return Split-Path -Parent $c.Source }
    foreach ($g in $globs) {
        $hit = Get-ChildItem -Path $g -Filter $exe -Recurse -ErrorAction SilentlyContinue |
               Sort-Object FullName -Descending | Select-Object -First 1
        if ($hit) { return $hit.DirectoryName }
    }
    return $null
}

$u = $env:USERPROFILE
$pf = $env:ProgramFiles
$pf86 = ${env:ProgramFiles(x86)}
$want = @(
  @{ exe='arm-none-eabi-gcc.exe'; id='Arm.GnuArmEmbeddedToolchain';
     globs=@("$pf\Arm GNU Toolchain arm-none-eabi\*\bin", "$pf86\Arm GNU Toolchain arm-none-eabi\*\bin",
             "$pf86\GNU Arm Embedded Toolchain\*\bin", "$u\.platformio\packages\toolchain-gccarmnoneeabi*\bin",
             "C:\ST\STM32CubeCLT*\GNU-tools-for-STM32\bin", "C:\ST\STM32CubeIDE*\STM32CubeIDE\plugins\*gnu-tools-for-stm32*\tools\bin") },
  @{ exe='cmake.exe'; id='Kitware.CMake';
     globs=@("$pf\CMake\bin", "$u\.platformio\packages\tool-cmake\bin", "C:\ST\STM32CubeCLT*\CMake\bin") },
  @{ exe='ninja.exe'; id='Ninja-build.Ninja';
     globs=@("$u\.platformio\packages\tool-ninja", "C:\ST\STM32CubeCLT*\Ninja\bin", "$env:LOCALAPPDATA\Microsoft\WinGet\Packages\Ninja-build*") },
  @{ exe='bash.exe'; id='Git.Git'; globs=@("$pf\Git\bin", "$pf86\Git\bin") }
)

foreach ($t in $want) {
    $dir = Find-Tool $t.exe $t.globs
    if (-not $dir -and $Install) {
        Write-Host "Installing $($t.id) ..."
        winget install --id $t.id -e --accept-source-agreements --accept-package-agreements | Out-Host
        $dir = Find-Tool $t.exe $t.globs
    }
    if (-not $dir) {
        throw "$($t.exe) not found. Re-run with -Install, or install $($t.id) manually."
    }
    Write-Host ("{0,-22} {1}" -f $t.exe, $dir)
    $env:PATH = "$dir;$env:PATH"
}

# VS Code settings: tools\vscode -> .vscode (first run only)
$vsDst = Join-Path $root '.vscode'
$vsSrc = Join-Path $root 'tools\vscode'
if (-not (Test-Path $vsDst) -and (Test-Path $vsSrc)) {
    Copy-Item -Recurse $vsSrc $vsDst
    Write-Host 'Installed VS Code project settings into .vscode'
}

# Dependencies
$hal = Join-Path $root 'third_party\STM32CubeU5\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal.h'
$tusb = Join-Path $root 'third_party\tinyusb\src\tusb.c'
if (-not (Test-Path $hal) -or -not (Test-Path $tusb)) {
    Write-Host 'Fetching third-party sources ...'
    & bash.exe -lc "cd '$($root -replace '\\','/')' && ./third_party/fetch.sh"
    if ($LASTEXITCODE -ne 0) { throw 'fetch.sh failed' }
}

# Build
$build = Join-Path $root 'build'
if ($Clean -and (Test-Path $build)) { Remove-Item -Recurse -Force $build }
cmake -S $root -B $build -G Ninja "-DCMAKE_TOOLCHAIN_FILE=$root/cmake/arm-none-eabi.cmake" -DCMAKE_BUILD_TYPE=Release
if ($LASTEXITCODE -ne 0) { throw 'CMake configure failed' }
cmake --build $build
if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
Write-Host "`nOK: $build\eink_mp3.elf / .bin / .hex"
