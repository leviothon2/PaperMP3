#!/usr/bin/env python3
"""Fail closed on changes to the reviewed SSD1681 command surface (InkBoy tools/check_safety.py,
ported to the STM32U575 fork by the display-test firmware; paths adapted to the player in 2.7.0).
Run it after any change to drivers/eink.c, drivers/ssd1681_fast, drivers/inkboy, app/flash_store.c
or app/fwupdate.c:   python3 tools/check_safety.py

Same rules as InkBoy:
  - the driver sends only a reviewed list of commands; 0x30 (program waveform OTP) is not in it and
    the literal does not appear anywhere in the display code (drivers/eink.c, drivers/ssd1681_fast,
    drivers/inkboy);
  - every LUT goes through the single fixed vendor loader (command 0x32, volatile);
  - no general LUT / raw-voltage API in the public header.
Changes for this board:
  - one extra reviewed command: 0x1A (write the volatile temperature register), used only by the
    OTP reference "fast full" refresh, exactly as the player firmware does;
  - the panel transport is SPI1 in ssd1681_port_stm32.c; nothing else may write SPI1;
  - instead of ESP32 secure-boot/flash-encryption, the board-lock risk on the STM32 is the option
    bytes: the SD updater may only touch SWAP_BANK, never RDP (level 2 is permanent) or WRP.
dt-0.2.0:
  - internal flash is written in exactly two places: the SD updater (other bank) and the settings
    log (app/flash_store.c), which may only erase page 63 of the running bank and program inside
    0x0807E000..0x0807FFFF; the linker keeps the image out of that page (FLASH <= 504K).
player 2.7.0:
  - the player's front-end (drivers/eink.c) may only call the driver's public functions: it sends no
    command of its own and never touches the SPI.
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
strip = lambda t: re.sub(r'/\*.*?\*/|//[^\n]*', '', t, flags=re.S)

source = strip((ROOT / 'drivers/ssd1681_fast/ssd1681_fast.c').read_text())
expected = {0x01, 0x10, 0x11, 0x12, 0x18, 0x20, 0x22, 0x24,
            0x26, 0x32, 0x3c, 0x44, 0x45, 0x4e, 0x4f}
vendor_commands = {0x03, 0x04, 0x2c, 0x37, 0x3f}
port_commands = {0x1a}
commands = dict((name, int(value, 16)) for name, value in
                re.findall(r'(CMD_\w+)\s*=\s*(0x[0-9a-fA-F]+)', source))
assert set(v for n, v in commands.items() if n.startswith('CMD_VENDOR_')) == vendor_commands
assert set(commands.values()) == expected | vendor_commands | port_commands, \
    'Command enum changed: review required'
guard = source.split('switch (command)', 1)[1].split('default:', 1)[0]
assert set(re.findall(r'case (CMD_\w+):', guard)) == set(commands), 'Whitelist mismatch'
assert 'default: return ESP_ERR_NOT_SUPPORTED;' in source
assert source.count('transfer(d, false,') == 1, 'Raw command path changed'
assert source.count('reg_write(d, CMD_LUT,') == 1, 'LUT upload must stay in the fixed vendor loader'
assert source.count('CMD_TEMPERATURE_WRITE,') == 1, 'Temperature write must stay in the OTP forced-temperature full'
header = (ROOT / 'drivers/ssd1681_fast/ssd1681_fast.h').read_text()
assert 'load_lut' not in header, 'General LUT API returned'

files = [p for d in ('app', 'audio', 'drivers', 'Core') for p in (ROOT / d).rglob('*.c')]
display = [ROOT / 'drivers/eink.c'] + list((ROOT / 'drivers/ssd1681_fast').glob('*.c')) + \
          list((ROOT / 'drivers/inkboy').glob('*.c'))
for path in display:
    assert not re.search(r'\b0x30\b', strip(path.read_text()), re.I), f'Forbidden literal in {path}'
front = strip((ROOT / 'drivers/eink.c').read_text())
assert not re.search(r'reg_write|reg_byte|send_command|ssd1681_port_write', front), \
    'eink.c must go through the driver, not send commands itself'
for path in files:
    code = strip(path.read_text())
    if path.name != 'ssd1681_port_stm32.c':
        assert not re.search(r'\bHAL_SPI_(Transmit|TransmitReceive)\w*\s*\(', code), \
            f'Panel transport bypass in {path}'
        assert 'EINK_SPI' not in code, f'Panel SPI used outside the port in {path}'
    assert not re.search(r'OB_RDP_LEVEL|OPTIONBYTE_RDP|OPTIONBYTE_WRP|OB_WRPSTATE', code), \
        f'Read/write-protection option bytes touched in {path}'
fw = strip((ROOT / 'app/fwupdate.c').read_text())
assert re.findall(r'OB_USER_\w+', fw) == ['OB_USER_SWAP_BANK'], 'Updater must only change SWAP_BANK'
flash_writers = {p.name for p in files
                 if re.search(r'\bHAL_FLASH(Ex)?_(Program|Erase)\s*\(', strip(p.read_text()))}
assert flash_writers <= {'fwupdate.c', 'flash_store.c'}, f'Unexpected flash writers: {flash_writers}'
fs = strip((ROOT / 'app/flash_store.c').read_text())
assert re.search(r'#define PAGE_INDEX\s+63u', fs) and '.NbPages   = 1' in fs, 'Settings erase must be page 63 only'
assert '#define FLASH_STORE_ADDR     0x0807E000u' in (ROOT / 'app/flash_store.h').read_text()
assert 'base + q * 16u' in fs and 'FLASH_STORE_ADDR + (uint32_t)slot * SLOT_BYTES' in fs
ld = (ROOT / 'ld/STM32U575xG.ld').read_text()
assert re.search(r'FLASH \(rx\)\s*:\s*ORIGIN = 0x08000000, LENGTH = 504K', ld), 'Image must stay below the settings page'
print('PASS: flash writes limited to the updater and settings page 63; image <= 504K')
print('PASS: reviewed command whitelist (+0x1A temperature); no OTP-program literal; single LUT loader; '
      'SPI1 only in the port; option bytes limited to SWAP_BANK')
